-- MySQL dump 10.13  Distrib 8.0.45, for Linux (x86_64)
--
-- Host: localhost    Database: customer_site
-- ------------------------------------------------------
-- Server version	8.0.45-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `access_gates`
--

DROP TABLE IF EXISTS `access_gates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `access_gates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `access_list_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `redirect_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_duration` int unsigned NOT NULL DEFAULT '1440',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `access_gates_slug_unique` (`slug`),
  KEY `access_gates_access_list_id_foreign` (`access_list_id`),
  CONSTRAINT `access_gates_access_list_id_foreign` FOREIGN KEY (`access_list_id`) REFERENCES `access_lists` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access_gates`
--

LOCK TABLES `access_gates` WRITE;
/*!40000 ALTER TABLE `access_gates` DISABLE KEYS */;
/*!40000 ALTER TABLE `access_gates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `access_list_entries`
--

DROP TABLE IF EXISTS `access_list_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `access_list_entries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `access_list_id` bigint unsigned NOT NULL,
  `national_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `access_list_entries_access_list_id_national_id_index` (`access_list_id`,`national_id`),
  KEY `access_list_entries_access_list_id_last_name_index` (`access_list_id`,`last_name`),
  CONSTRAINT `access_list_entries_access_list_id_foreign` FOREIGN KEY (`access_list_id`) REFERENCES `access_lists` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access_list_entries`
--

LOCK TABLES `access_list_entries` WRITE;
/*!40000 ALTER TABLE `access_list_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `access_list_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `access_lists`
--

DROP TABLE IF EXISTS `access_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `access_lists` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `match_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'national_id',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `entry_count` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access_lists`
--

LOCK TABLES `access_lists` WRITE;
/*!40000 ALTER TABLE `access_lists` DISABLE KEYS */;
INSERT INTO `access_lists` VALUES (1,'ثبت نام گروه',NULL,'national_id',1,0,'2026-06-14 18:47:55','2026-06-14 18:47:55');
/*!40000 ALTER TABLE `access_lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `access_verifications`
--

DROP TABLE IF EXISTS `access_verifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `access_verifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `access_gate_id` bigint unsigned NOT NULL,
  `access_list_entry_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `success` tinyint(1) NOT NULL DEFAULT '0',
  `input_national_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `input_last_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `access_verifications_access_list_entry_id_foreign` (`access_list_entry_id`),
  KEY `access_verifications_access_gate_id_success_created_at_index` (`access_gate_id`,`success`,`created_at`),
  CONSTRAINT `access_verifications_access_gate_id_foreign` FOREIGN KEY (`access_gate_id`) REFERENCES `access_gates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `access_verifications_access_list_entry_id_foreign` FOREIGN KEY (`access_list_entry_id`) REFERENCES `access_list_entries` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access_verifications`
--

LOCK TABLES `access_verifications` WRITE;
/*!40000 ALTER TABLE `access_verifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `access_verifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_deletion_requests`
--

DROP TABLE IF EXISTS `account_deletion_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_deletion_requests` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `requested_at` timestamp NOT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `confirmed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `account_deletion_requests_user_id_foreign` (`user_id`),
  CONSTRAINT `account_deletion_requests_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_deletion_requests`
--

LOCK TABLES `account_deletion_requests` WRITE;
/*!40000 ALTER TABLE `account_deletion_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_deletion_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_activity_log`
--

DROP TABLE IF EXISTS `admin_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_activity_log` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `admin_user_id` bigint unsigned DEFAULT NULL,
  `causer_id` bigint unsigned DEFAULT NULL,
  `action` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject_type` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject_id` bigint unsigned DEFAULT NULL,
  `properties` json DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_activity_log_action_index` (`action`),
  KEY `admin_activity_log_subject_idx` (`subject_type`,`subject_id`),
  KEY `admin_activity_log_created_at_idx` (`created_at`),
  KEY `admin_activity_log_admin_created_idx` (`admin_user_id`,`created_at`),
  KEY `admin_activity_log_causer_id_foreign` (`causer_id`),
  CONSTRAINT `admin_activity_log_admin_user_id_foreign` FOREIGN KEY (`admin_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `admin_activity_log_causer_id_foreign` FOREIGN KEY (`causer_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_activity_log`
--

LOCK TABLES `admin_activity_log` WRITE;
/*!40000 ALTER TABLE `admin_activity_log` DISABLE KEYS */;
INSERT INTO `admin_activity_log` VALUES (1,1,1,'license.activated','فعال‌سازی لایسنس برای دامنهٔ safhenokhost.ir','App\\Models\\License',1,'{\"domain\": \"safhenokhost.ir\", \"causer_id\": 1, \"modules_count\": 18}','2.187.121.226','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-09 15:23:03','2026-06-09 15:23:03'),(2,1,1,'license.refreshed_modules','بروزرسانی فهرست ماژول‌ها از پلتفرم','App\\Models\\License',1,'{\"added\": [], \"removed\": [], \"causer_id\": 1, \"modules_after_count\": 18, \"modules_before_count\": 18}','2.187.121.226','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-09 16:34:07','2026-06-09 16:34:07'),(3,1,1,'license.refreshed_modules','بروزرسانی فهرست ماژول‌ها از پلتفرم','App\\Models\\License',1,'{\"added\": [], \"removed\": [], \"causer_id\": 1, \"modules_after_count\": 18, \"modules_before_count\": 18}','2.187.121.226','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-09 16:34:15','2026-06-09 16:34:15'),(4,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'2.187.121.226','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-09 16:42:21','2026-06-09 16:42:21'),(5,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'2.187.121.226','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-09 16:42:42','2026-06-09 16:42:42'),(6,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'2.187.121.226','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-09 16:43:10','2026-06-09 16:43:10'),(7,1,1,'license.refreshed_modules','بروزرسانی فهرست ماژول‌ها از پلتفرم','App\\Models\\License',1,'{\"added\": [], \"removed\": [], \"causer_id\": 1, \"modules_after_count\": 18, \"modules_before_count\": 18}','2.187.121.226','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-09 17:56:41','2026-06-09 17:56:41'),(8,1,1,'license.refreshed_modules','بروزرسانی فهرست ماژول‌ها از پلتفرم','App\\Models\\License',1,'{\"added\": [], \"removed\": [], \"causer_id\": 1, \"modules_after_count\": 18, \"modules_before_count\": 18}','2.187.121.226','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-09 17:56:48','2026-06-09 17:56:48'),(9,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'46.51.66.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-09 19:50:52','2026-06-09 19:50:52'),(10,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'46.51.66.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-09 19:51:26','2026-06-09 19:51:26'),(11,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'46.51.66.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-09 19:59:28','2026-06-09 19:59:28'),(12,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'46.51.66.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-09 20:02:34','2026-06-09 20:02:34'),(13,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم',NULL,NULL,NULL,'46.51.66.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-09 20:02:40','2026-06-09 20:02:40'),(14,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'46.51.66.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-09 20:07:53','2026-06-09 20:07:53'),(15,1,1,'license.activated','فعال‌سازی لایسنس برای دامنهٔ safhenokhost.ir','App\\Models\\License',1,'{\"domain\": \"safhenokhost.ir\", \"causer_id\": 1, \"modules_count\": 18}','46.51.66.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-09 20:19:43','2026-06-09 20:19:43'),(16,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'46.51.66.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-09 20:19:53','2026-06-09 20:19:53'),(17,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'46.51.66.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-09 20:22:17','2026-06-09 20:22:17'),(18,1,1,'license.activated','فعال‌سازی لایسنس برای دامنهٔ safhenokhost.ir','App\\Models\\License',2,'{\"domain\": \"safhenokhost.ir\", \"causer_id\": 1, \"modules_count\": 18}','46.51.66.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-09 20:22:54','2026-06-09 20:22:54'),(19,1,1,'license.refreshed_modules','بروزرسانی فهرست ماژول‌ها از پلتفرم','App\\Models\\License',2,'{\"added\": [], \"removed\": [], \"causer_id\": 1, \"modules_after_count\": 18, \"modules_before_count\": 18}','46.51.66.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-09 20:23:01','2026-06-09 20:23:01'),(20,1,1,'license.refreshed_modules','بروزرسانی فهرست ماژول‌ها از پلتفرم','App\\Models\\License',2,'{\"added\": [], \"removed\": [], \"causer_id\": 1, \"modules_after_count\": 18, \"modules_before_count\": 18}','46.51.66.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-09 20:29:12','2026-06-09 20:29:12'),(21,1,1,'blog.post_published','انتشار مطلب','App\\Models\\Post',1,'{\"slug\": \"sayt-hmh-karh\", \"title\": \"چطور یک محتوای مناسب تولید کنیم؟ راهنمای کامل\", \"post_id\": 1, \"causer_id\": 1, \"is_published\": true, \"published_at\": \"2026-06-10T19:40:01+00:00\", \"editorial_status\": \"published\"}','2.187.121.111','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-10 19:40:01','2026-06-10 19:40:01'),(22,1,1,'blog.post_published','انتشار مطلب','App\\Models\\Post',1,'{\"slug\": \"sayt-hmh-karh\", \"title\": \"چطور یک محتوای مناسب تولید کنیم؟ راهنمای کامل\", \"post_id\": 1, \"causer_id\": 1, \"is_published\": true, \"published_at\": \"2026-06-10T19:40:01+00:00\", \"editorial_status\": \"published\"}','2.187.121.111','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-10 19:41:01','2026-06-10 19:41:01'),(23,1,1,'blog.post_published','انتشار مطلب','App\\Models\\Post',1,'{\"slug\": \"sayt-hmh-karh\", \"title\": \"چطور یک محتوای مناسب تولید کنیم؟ راهنمای کامل\", \"post_id\": 1, \"causer_id\": 1, \"is_published\": true, \"published_at\": \"2026-06-10T19:56:12+00:00\", \"editorial_status\": \"published\"}','2.187.121.111','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-10 19:56:12','2026-06-10 19:56:12'),(24,1,1,'license.refreshed_modules','بروزرسانی فهرست ماژول‌ها از پلتفرم','App\\Models\\License',2,'{\"added\": [], \"removed\": [], \"causer_id\": 1, \"modules_after_count\": 18, \"modules_before_count\": 18}','2.187.121.111','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-10 20:12:21','2026-06-10 20:12:21'),(25,1,1,'license.refreshed_modules','بروزرسانی فهرست ماژول‌ها از پلتفرم','App\\Models\\License',2,'{\"added\": [], \"removed\": [], \"causer_id\": 1, \"modules_after_count\": 18, \"modules_before_count\": 18}','2.187.121.111','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-10 20:12:26','2026-06-10 20:12:26'),(26,1,1,'license.refreshed_modules','بروزرسانی فهرست ماژول‌ها از پلتفرم','App\\Models\\License',2,'{\"added\": [], \"removed\": [], \"causer_id\": 1, \"modules_after_count\": 18, \"modules_before_count\": 18}','192.15.6.124','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-10 21:04:53','2026-06-10 21:04:53'),(27,1,1,'license.refreshed_modules','بروزرسانی فهرست ماژول‌ها از پلتفرم','App\\Models\\License',2,'{\"added\": [], \"removed\": [], \"causer_id\": 1, \"modules_after_count\": 18, \"modules_before_count\": 18}','192.15.6.124','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-10 21:05:04','2026-06-10 21:05:04'),(28,1,1,'blog.post_published','انتشار مطلب','App\\Models\\Post',2,'{\"slug\": \"dr-mord-jam-jhany-fotbal-2026-chh-my-danyd\", \"title\": \"در مورد جام جهانی فوتبال 2026 چه می دانید؟\", \"post_id\": 2, \"causer_id\": 1, \"is_published\": true, \"published_at\": \"2026-06-11T07:57:08+00:00\", \"editorial_status\": \"published\"}','192.15.6.124','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-11 07:57:08','2026-06-11 07:57:08'),(29,1,1,'blog.post_published','انتشار مطلب','App\\Models\\Post',2,'{\"slug\": \"dr-mord-jam-jhany-fotbal-2026-chh-my-danyd\", \"title\": \"در مورد جام جهانی فوتبال 2026 چه می دانید؟\", \"post_id\": 2, \"causer_id\": 1, \"is_published\": true, \"published_at\": \"2026-06-11T07:57:08+00:00\", \"editorial_status\": \"published\"}','192.15.6.124','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-11 08:12:40','2026-06-11 08:12:40'),(30,1,1,'license.refreshed_modules','بروزرسانی فهرست ماژول‌ها از پلتفرم','App\\Models\\License',2,'{\"added\": [], \"removed\": [], \"causer_id\": 1, \"modules_after_count\": 18, \"modules_before_count\": 18}','192.15.6.124','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-11 08:45:11','2026-06-11 08:45:11'),(31,3,NULL,'platform_agent.provisioned','ادمین پلتفرم برای این سایت ثبت شد',NULL,NULL,'{\"source\": \"platform\"}','192.15.6.124','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-11 09:42:16','2026-06-11 09:42:16'),(32,3,NULL,'platform_agent.login','ورود ادمین پلتفرم به پنل مدیریت سایت',NULL,NULL,'{\"mobile\": \"09169398161\", \"source\": \"platform_agent\"}','192.15.6.124','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-11 09:44:04','2026-06-11 09:44:04'),(33,3,NULL,'platform_agent.access_recorded','ثبت دسترسی ادمین پلتفرم از پنل مدیریت',NULL,NULL,'{\"source\": \"platform\"}','192.15.6.124','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-11 09:47:54','2026-06-11 09:47:54'),(34,1,1,'license.refreshed_modules','بروزرسانی فهرست ماژول‌ها از پلتفرم','App\\Models\\License',2,'{\"added\": [], \"removed\": [], \"causer_id\": 1, \"modules_after_count\": 18, \"modules_before_count\": 18}','192.15.6.124','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-11 09:52:37','2026-06-11 09:52:37'),(35,1,1,'license.refreshed_modules','بروزرسانی فهرست ماژول‌ها از پلتفرم','App\\Models\\License',2,'{\"added\": [], \"removed\": [], \"causer_id\": 1, \"modules_after_count\": 18, \"modules_before_count\": 18}','192.15.6.124','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-11 09:52:46','2026-06-11 09:52:46'),(36,1,1,'license.refreshed_modules','بروزرسانی فهرست ماژول‌ها از پلتفرم','App\\Models\\License',2,'{\"added\": [\"module_labels\", \"advanced_search\", \"currency_reform\", \"seo_advanced\", \"multi_currency\", \"marketplace_sync\", \"video\", \"projects\", \"qa\", \"menu\", \"announcements\", \"backup\", \"cloud\", \"podcast\", \"marketing_automation\", \"discount_advanced\", \"wallet\", \"product_bundling\", \"shipping\", \"inventory\", \"accounting\", \"gallery\", \"services\", \"tasks\", \"contract\", \"media\", \"brand\", \"i18n\", \"crm\", \"analytics\", \"recruitment\", \"portfolio\", \"omnichannel\"], \"removed\": [], \"causer_id\": 1, \"modules_after_count\": 51, \"modules_before_count\": 18}','2.187.120.243','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-11 17:54:32','2026-06-11 17:54:32'),(37,1,1,'license.refreshed_modules','بروزرسانی فهرست ماژول‌ها از پلتفرم','App\\Models\\License',2,'{\"added\": [], \"removed\": [], \"causer_id\": 1, \"modules_after_count\": 51, \"modules_before_count\": 51}','2.187.120.234','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-12 17:55:21','2026-06-12 17:55:21'),(38,1,1,'license.refreshed_modules','بروزرسانی فهرست ماژول‌ها از پلتفرم','App\\Models\\License',2,'{\"added\": [], \"removed\": [], \"causer_id\": 1, \"modules_after_count\": 51, \"modules_before_count\": 51}','2.187.120.234','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-12 17:55:28','2026-06-12 17:55:28'),(39,1,1,'license.refreshed_modules','بروزرسانی فهرست ماژول‌ها از پلتفرم','App\\Models\\License',2,'{\"added\": [], \"removed\": [], \"causer_id\": 1, \"modules_after_count\": 51, \"modules_before_count\": 51}','2.187.120.234','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-12 17:55:53','2026-06-12 17:55:53'),(40,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'83.120.191.15','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-14 08:37:52','2026-06-14 08:37:52'),(41,1,1,'license.refreshed_modules','بروزرسانی فهرست ماژول‌ها از پلتفرم','App\\Models\\License',2,'{\"added\": [], \"removed\": [], \"causer_id\": 1, \"modules_after_count\": 56, \"modules_before_count\": 56}','2.187.121.152','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-14 18:46:19','2026-06-14 18:46:19'),(42,1,1,'license.refreshed_modules','بروزرسانی فهرست ماژول‌ها از پلتفرم','App\\Models\\License',2,'{\"added\": [], \"removed\": [], \"causer_id\": 1, \"modules_after_count\": 56, \"modules_before_count\": 56}','83.120.238.130','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-15 04:36:40','2026-06-15 04:36:40'),(43,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'83.120.238.130','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-16 05:33:59','2026-06-16 05:33:59'),(44,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'80.191.216.179','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-06-16 06:52:48','2026-06-16 06:52:48'),(45,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'80.191.216.179','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-06-16 06:54:39','2026-06-16 06:54:39'),(46,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'2.187.121.168','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-16 11:32:01','2026-06-16 11:32:01'),(47,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'2.187.121.168','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-16 11:32:30','2026-06-16 11:32:30'),(48,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم',NULL,NULL,NULL,'2.187.121.168','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-16 11:32:35','2026-06-16 11:32:35'),(49,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'2.187.121.168','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-16 11:39:36','2026-06-16 11:39:36'),(50,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم',NULL,NULL,NULL,'2.187.121.168','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-16 11:40:20','2026-06-16 11:40:20'),(51,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'2.187.121.181','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-19 06:37:38','2026-06-19 06:37:38'),(52,1,1,'license.refreshed_modules','بروزرسانی فهرست ماژول‌ها از پلتفرم','App\\Models\\License',2,'{\"added\": [], \"removed\": [], \"causer_id\": 1, \"modules_after_count\": 56, \"modules_before_count\": 56}','2.187.121.181','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-19 19:09:20','2026-06-19 19:09:20'),(53,1,1,'license.refreshed_modules','بروزرسانی فهرست ماژول‌ها از پلتفرم','App\\Models\\License',2,'{\"added\": [], \"removed\": [], \"causer_id\": 1, \"modules_after_count\": 56, \"modules_before_count\": 56}','2.187.121.181','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-20 14:39:46','2026-06-20 14:39:46'),(54,1,1,'license.refreshed_modules','بروزرسانی فهرست ماژول‌ها از پلتفرم','App\\Models\\License',2,'{\"added\": [], \"removed\": [], \"causer_id\": 1, \"modules_after_count\": 56, \"modules_before_count\": 56}','2.187.121.181','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-20 16:58:16','2026-06-20 16:58:16'),(55,1,1,'license.refreshed_modules','بروزرسانی فهرست ماژول‌ها از پلتفرم','App\\Models\\License',2,'{\"added\": [], \"removed\": [], \"causer_id\": 1, \"modules_after_count\": 56, \"modules_before_count\": 56}','2.187.121.181','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-20 17:09:58','2026-06-20 17:09:58'),(56,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'2.187.121.22','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-23 07:32:52','2026-06-23 07:32:52'),(57,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'2.187.121.22','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-23 07:34:32','2026-06-23 07:34:32'),(58,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'2.187.121.22','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-23 08:40:46','2026-06-23 08:40:46'),(59,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'2.187.121.22','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-23 13:44:50','2026-06-23 13:44:50'),(60,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'2.187.121.160','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-24 05:03:12','2026-06-24 05:03:12'),(61,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'2.187.121.160','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-24 07:12:05','2026-06-24 07:12:05'),(62,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'2.187.121.160','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-24 17:08:22','2026-06-24 17:08:22'),(63,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'2.187.121.160','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-24 17:08:42','2026-06-24 17:08:42'),(64,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'2.187.120.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-25 07:04:37','2026-06-25 07:04:37'),(65,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'2.187.120.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-25 07:08:21','2026-06-25 07:08:21'),(66,1,1,'license.refreshed_modules','بروزرسانی فهرست ماژول‌ها از پلتفرم','App\\Models\\License',2,'{\"added\": [], \"removed\": [], \"causer_id\": 1, \"modules_after_count\": 56, \"modules_before_count\": 56}','83.121.95.162','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-28 13:02:48','2026-06-28 13:02:48'),(67,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'2.187.121.61','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-06-30 12:16:43','2026-06-30 12:16:43'),(68,1,1,'license.refreshed_modules','بروزرسانی فهرست ماژول‌ها از پلتفرم','App\\Models\\License',2,'{\"added\": [], \"removed\": [], \"causer_id\": 1, \"modules_after_count\": 56, \"modules_before_count\": 56}','2.187.121.61','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-06-30 12:16:49','2026-06-30 12:16:49'),(69,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم',NULL,NULL,NULL,'2.187.121.61','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-06-30 12:17:24','2026-06-30 12:17:24'),(70,1,1,'license.refreshed_modules','بروزرسانی فهرست ماژول‌ها از پلتفرم','App\\Models\\License',2,'{\"added\": [], \"removed\": [], \"causer_id\": 1, \"modules_after_count\": 56, \"modules_before_count\": 56}','45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-16 14:22:29','2026-07-16 14:22:29'),(71,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-23 16:41:16','2026-07-23 16:41:16'),(72,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-23 16:41:59','2026-07-23 16:41:59'),(73,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'2.187.121.224','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-24 11:50:39','2026-07-24 11:50:39'),(74,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'2.187.121.224','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-24 11:51:23','2026-07-24 11:51:23'),(75,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم',NULL,NULL,NULL,'2.187.121.224','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-24 09:49:01','2026-07-24 09:49:01'),(76,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'2.187.121.224','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-24 09:49:11','2026-07-24 09:49:11'),(77,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'2.187.121.224','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-24 15:49:27','2026-07-24 15:49:27'),(78,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-31 08:48:52','2026-07-31 08:48:52'),(79,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'37.63.176.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-08-01 17:57:38','2026-08-01 17:57:38'),(80,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'37.63.176.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-08-02 18:23:20','2026-08-02 18:23:20'),(81,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'37.63.176.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-08-05 16:04:15','2026-08-05 16:04:15'),(82,1,1,'license.refreshed_modules','بروزرسانی فهرست ماژول‌ها از پلتفرم','App\\Models\\License',2,'{\"added\": [], \"removed\": [], \"causer_id\": 1, \"modules_after_count\": 56, \"modules_before_count\": 56}','37.63.176.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-08-05 16:27:02','2026-08-05 16:27:02'),(83,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم',NULL,NULL,NULL,'37.63.176.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-08-05 16:27:07','2026-08-05 16:27:07'),(84,1,1,'license.refreshed_modules','بروزرسانی فهرست ماژول‌ها از پلتفرم','App\\Models\\License',2,'{\"added\": [], \"removed\": [], \"causer_id\": 1, \"modules_after_count\": 56, \"modules_before_count\": 56}','2.187.120.42','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-08-11 07:06:57','2026-08-11 07:06:57'),(85,1,1,'license.refreshed_config','بازخوانی تنظیمات و اعلان‌ها از پلتفرم (GET)',NULL,NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:154.0) Gecko/20100101 Firefox/154.0','2026-08-19 17:15:27','2026-08-19 17:15:27');
/*!40000 ALTER TABLE `admin_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_notifications`
--

DROP TABLE IF EXISTS `admin_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_notifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci,
  `link` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_notifications_type_index` (`type`),
  KEY `admin_notifications_is_read_index` (`is_read`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_notifications`
--

LOCK TABLES `admin_notifications` WRITE;
/*!40000 ALTER TABLE `admin_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `advertisements`
--

DROP TABLE IF EXISTS `advertisements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `advertisements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `image_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'header',
  `order` int unsigned NOT NULL DEFAULT '0',
  `starts_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `options` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `advertisements`
--

LOCK TABLES `advertisements` WRITE;
/*!40000 ALTER TABLE `advertisements` DISABLE KEYS */;
/*!40000 ALTER TABLE `advertisements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ai_generation_jobs`
--

DROP TABLE IF EXISTS `ai_generation_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_generation_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mode` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'full',
  `prompt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_context` text COLLATE utf8mb4_unicode_ci,
  `step_count` int NOT NULL DEFAULT '5',
  `status` enum('pending','processing','done','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `result` longtext COLLATE utf8mb4_unicode_ci,
  `error` text COLLATE utf8mb4_unicode_ci,
  `provider` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `picked_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ai_generation_jobs_status_index` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ai_generation_jobs`
--

LOCK TABLES `ai_generation_jobs` WRITE;
/*!40000 ALTER TABLE `ai_generation_jobs` DISABLE KEYS */;
INSERT INTO `ai_generation_jobs` VALUES (1,'procedure','steps','روال قسطی خرید',NULL,5,'done','\"test content here\"',NULL,'deepseek-local','2026-06-10 08:37:51','2026-06-10 08:14:39','2026-06-10 08:38:48'),(2,'procedure','steps','روال قسطی خرید',NULL,5,'done','\"{\\n  \\\"title\\\": \\\"\\u0631\\u0648\\u0627\\u0644 \\u0642\\u0633\\u0637\\u06cc \\u062e\\u0631\\u06cc\\u062f\\\",\\n  \\\"excerpt\\\": \\\"\\u0631\\u0627\\u0647\\u0646\\u0645\\u0627\\u06cc \\u06af\\u0627\\u0645 \\u0628\\u0647 \\u06af\\u0627\\u0645 \\u0628\\u0631\\u0627\\u06cc \\u062e\\u0631\\u06cc\\u062f \\u0627\\u0642\\u0633\\u0627\\u0637\\u06cc \\u06a9\\u0627\\u0644\\u0627\\u0647\\u0627 \\u0648 \\u062e\\u062f\\u0645\\u0627\\u062a\\\",\\n  \\\"steps\\\": [\\n    {\\n      \\\"title\\\": \\\"\\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u06a9\\u0627\\u0644\\u0627 \\u0648 \\u0641\\u0631\\u0648\\u0634\\u0646\\u062f\\u0647\\\",\\n      \\\"body\\\": \\\"\\u0627\\u0628\\u062a\\u062f\\u0627 \\u06a9\\u0627\\u0644\\u0627 \\u06cc\\u0627 \\u062e\\u062f\\u0645\\u0627\\u062a \\u0645\\u0648\\u0631\\u062f \\u0646\\u0638\\u0631 \\u062e\\u0648\\u062f \\u0631\\u0627 \\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u06a9\\u0631\\u062f\\u0647 \\u0648 \\u0627\\u0632 \\u0641\\u0631\\u0648\\u0634\\u0646\\u062f\\u0647 \\u0628\\u067e\\u0631\\u0633\\u06cc\\u062f \\u06a9\\u0647 \\u0622\\u06cc\\u0627 \\u0627\\u0645\\u06a9\\u0627\\u0646 \\u062e\\u0631\\u06cc\\u062f \\u0627\\u0642\\u0633\\u0627\\u0637\\u06cc \\u0648\\u062c\\u0648\\u062f \\u062f\\u0627\\u0631\\u062f \\u06cc\\u0627 \\u062e\\u06cc\\u0631. \\u0641\\u0631\\u0648\\u0634\\u06af\\u0627\\u0647\\u200c\\u0647\\u0627\\u06cc \\u0645\\u0639\\u062a\\u0628\\u0631 \\u0645\\u0639\\u0645\\u0648\\u0644\\u0627\\u064b \\u0627\\u06cc\\u0646 \\u06af\\u0632\\u06cc\\u0646\\u0647 \\u0631\\u0627 \\u0627\\u0631\\u0627\\u0626\\u0647 \\u0645\\u06cc\\u200c\\u062f\\u0647\\u0646\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u0628\\u0631\\u0631\\u0633\\u06cc \\u0634\\u0631\\u0627\\u06cc\\u0637 \\u0648 \\u0645\\u062f\\u0627\\u0631\\u06a9\\\",\\n      \\\"body\\\": \\\"\\u0634\\u0631\\u0627\\u06cc\\u0637 \\u0627\\u0642\\u0633\\u0627\\u0637 \\u0645\\u0627\\u0646\\u0646\\u062f \\u0645\\u0628\\u0644\\u063a \\u067e\\u06cc\\u0634\\u200c\\u067e\\u0631\\u062f\\u0627\\u062e\\u062a\\u060c \\u062a\\u0639\\u062f\\u0627\\u062f \\u0627\\u0642\\u0633\\u0627\\u0637\\u060c \\u0646\\u0631\\u062e \\u0628\\u0647\\u0631\\u0647 \\u0648 \\u0647\\u0632\\u06cc\\u0646\\u0647\\u200c\\u0647\\u0627\\u06cc \\u0627\\u0636\\u0627\\u0641\\u06cc \\u0631\\u0627 \\u0628\\u0631\\u0631\\u0633\\u06cc \\u06a9\\u0646\\u06cc\\u062f. \\u0647\\u0645\\u0686\\u0646\\u06cc\\u0646 \\u0645\\u062f\\u0627\\u0631\\u06a9 \\u0645\\u0648\\u0631\\u062f \\u0646\\u06cc\\u0627\\u0632 \\u0645\\u0627\\u0646\\u0646\\u062f \\u06a9\\u0627\\u0631\\u062a \\u0634\\u0646\\u0627\\u0633\\u0627\\u06cc\\u06cc\\u060c \\u0641\\u06cc\\u0634 \\u062d\\u0642\\u0648\\u0642\\u06cc \\u06cc\\u0627 \\u0636\\u0627\\u0645\\u0646 \\u0631\\u0627 \\u0622\\u0645\\u0627\\u062f\\u0647 \\u06a9\\u0646\\u06cc\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u062a\\u06a9\\u0645\\u06cc\\u0644 \\u0641\\u0631\\u0645 \\u062f\\u0631\\u062e\\u0648\\u0627\\u0633\\u062a\\\",\\n      \\\"body\\\": \\\"\\u0641\\u0631\\u0645 \\u062f\\u0631\\u062e\\u0648\\u0627\\u0633\\u062a \\u0627\\u0642\\u0633\\u0627\\u0637 \\u0631\\u0627 \\u067e\\u0631 \\u06a9\\u0631\\u062f\\u0647 \\u0648 \\u0627\\u0637\\u0644\\u0627\\u0639\\u0627\\u062a \\u0634\\u062e\\u0635\\u06cc \\u0648 \\u0634\\u063a\\u0644\\u06cc \\u062e\\u0648\\u062f \\u0631\\u0627 \\u0628\\u0647 \\u062f\\u0642\\u062a \\u0648\\u0627\\u0631\\u062f \\u06a9\\u0646\\u06cc\\u062f. \\u062f\\u0631 \\u0635\\u0648\\u0631\\u062a \\u0644\\u0632\\u0648\\u0645\\u060c \\u0645\\u062f\\u0627\\u0631\\u06a9 \\u0631\\u0627 \\u0636\\u0645\\u06cc\\u0645\\u0647 \\u06a9\\u0646\\u06cc\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u0627\\u0646\\u062a\\u0638\\u0627\\u0631 \\u0628\\u0631\\u0627\\u06cc \\u062a\\u0623\\u06cc\\u06cc\\u062f \\u0627\\u0639\\u062a\\u0628\\u0627\\u0631\\\",\\n      \\\"body\\\": \\\"\\u067e\\u0633 \\u0627\\u0632 \\u0627\\u0631\\u0633\\u0627\\u0644 \\u062f\\u0631\\u062e\\u0648\\u0627\\u0633\\u062a\\u060c \\u0641\\u0631\\u0648\\u0634\\u0646\\u062f\\u0647 \\u06cc\\u0627 \\u0634\\u0631\\u06a9\\u062a \\u0627\\u0639\\u062a\\u0628\\u0627\\u0631\\u06cc \\u0633\\u0627\\u0628\\u0642\\u0647 \\u0627\\u0639\\u062a\\u0628\\u0627\\u0631\\u06cc \\u0634\\u0645\\u0627 \\u0631\\u0627 \\u0628\\u0631\\u0631\\u0633\\u06cc \\u0645\\u06cc\\u200c\\u06a9\\u0646\\u062f. \\u0627\\u06cc\\u0646 \\u0641\\u0631\\u0622\\u06cc\\u0646\\u062f \\u0645\\u0645\\u06a9\\u0646 \\u0627\\u0633\\u062a \\u0627\\u0632 \\u0686\\u0646\\u062f \\u0633\\u0627\\u0639\\u062a \\u062a\\u0627 \\u0686\\u0646\\u062f \\u0631\\u0648\\u0632 \\u0637\\u0648\\u0644 \\u0628\\u06a9\\u0634\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u0627\\u0645\\u0636\\u0627\\u06cc \\u0642\\u0631\\u0627\\u0631\\u062f\\u0627\\u062f \\u0648 \\u062f\\u0631\\u06cc\\u0627\\u0641\\u062a \\u06a9\\u0627\\u0644\\u0627\\\",\\n      \\\"body\\\": \\\"\\u067e\\u0633 \\u0627\\u0632 \\u062a\\u0623\\u06cc\\u06cc\\u062f\\u060c \\u0642\\u0631\\u0627\\u0631\\u062f\\u0627\\u062f \\u0627\\u0642\\u0633\\u0627\\u0637 \\u0631\\u0627 \\u0645\\u0637\\u0627\\u0644\\u0639\\u0647 \\u06a9\\u0631\\u062f\\u0647 \\u0648 \\u0627\\u0645\\u0636\\u0627 \\u06a9\\u0646\\u06cc\\u062f. \\u0645\\u0628\\u0644\\u063a \\u067e\\u06cc\\u0634\\u200c\\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u0631\\u0627 \\u0628\\u067e\\u0631\\u062f\\u0627\\u0632\\u06cc\\u062f \\u0648 \\u06a9\\u0627\\u0644\\u0627 \\u0631\\u0627 \\u062a\\u062d\\u0648\\u06cc\\u0644 \\u0628\\u06af\\u06cc\\u0631\\u06cc\\u062f. \\u0633\\u067e\\u0633 \\u0637\\u0628\\u0642 \\u0628\\u0631\\u0646\\u0627\\u0645\\u0647 \\u0627\\u0642\\u0633\\u0627\\u0637\\u060c \\u0645\\u0628\\u0627\\u0644\\u063a \\u0631\\u0627 \\u0628\\u0647 \\u0645\\u0648\\u0642\\u0639 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u06a9\\u0646\\u06cc\\u062f.\\\"\\n    }\\n  ]\\n}\"',NULL,'deepseek-local','2026-06-10 08:51:41','2026-06-10 08:16:16','2026-06-10 08:51:48'),(3,'procedure','steps','روال قسطی خرید',NULL,5,'done','\"{\\n  \\\"title\\\": \\\"\\u0631\\u0648\\u0627\\u0644 \\u0642\\u0633\\u0637\\u06cc \\u062e\\u0631\\u06cc\\u062f\\\",\\n  \\\"excerpt\\\": \\\"\\u0631\\u0627\\u0647\\u0646\\u0645\\u0627\\u06cc \\u06af\\u0627\\u0645\\u200c\\u0628\\u0647\\u200c\\u06af\\u0627\\u0645 \\u0628\\u0631\\u0627\\u06cc \\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u06a9\\u0627\\u0644\\u0627\\u0647\\u0627 \\u0648 \\u062e\\u062f\\u0645\\u0627\\u062a\\u060c \\u0634\\u0627\\u0645\\u0644 \\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u0641\\u0631\\u0648\\u0634\\u0646\\u062f\\u0647\\u060c \\u0628\\u0631\\u0631\\u0633\\u06cc \\u0634\\u0631\\u0627\\u06cc\\u0637\\u060c \\u062b\\u0628\\u062a\\u200c\\u0646\\u0627\\u0645\\u060c \\u0627\\u0645\\u0636\\u0627\\u06cc \\u0642\\u0631\\u0627\\u0631\\u062f\\u0627\\u062f \\u0648 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u0627\\u0642\\u0633\\u0627\\u0637.\\\",\\n  \\\"steps\\\": [\\n    {\\n      \\\"title\\\": \\\"\\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u0641\\u0631\\u0648\\u0634\\u0646\\u062f\\u0647 \\u0648 \\u06a9\\u0627\\u0644\\u0627\\\",\\n      \\\"body\\\": \\\"\\u0627\\u0628\\u062a\\u062f\\u0627 \\u0641\\u0631\\u0648\\u0634\\u0646\\u062f\\u0647\\u200c\\u0627\\u06cc \\u0631\\u0627 \\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u06a9\\u0646\\u06cc\\u062f \\u06a9\\u0647 \\u0627\\u0645\\u06a9\\u0627\\u0646 \\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u0631\\u0627 \\u0627\\u0631\\u0627\\u0626\\u0647 \\u0645\\u06cc\\u200c\\u062f\\u0647\\u062f. \\u0645\\u06cc\\u200c\\u062a\\u0648\\u0627\\u0646\\u06cc\\u062f \\u0627\\u0632 \\u0641\\u0631\\u0648\\u0634\\u06af\\u0627\\u0647\\u200c\\u0647\\u0627\\u06cc \\u0622\\u0646\\u0644\\u0627\\u06cc\\u0646 \\u06cc\\u0627 \\u062d\\u0636\\u0648\\u0631\\u06cc \\u0645\\u0639\\u062a\\u0628\\u0631 \\u0627\\u0633\\u062a\\u0641\\u0627\\u062f\\u0647 \\u06a9\\u0646\\u06cc\\u062f. \\u0633\\u067e\\u0633 \\u06a9\\u0627\\u0644\\u0627 \\u06cc\\u0627 \\u062e\\u062f\\u0645\\u0627\\u062a \\u0645\\u0648\\u0631\\u062f \\u0646\\u0638\\u0631 \\u062e\\u0648\\u062f \\u0631\\u0627 \\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u06a9\\u0631\\u062f\\u0647 \\u0648 \\u0627\\u0632 \\u0645\\u0648\\u062c\\u0648\\u062f\\u06cc \\u0648 \\u0642\\u06cc\\u0645\\u062a \\u0646\\u0647\\u0627\\u06cc\\u06cc \\u0645\\u0637\\u0644\\u0639 \\u0634\\u0648\\u06cc\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u0628\\u0631\\u0631\\u0633\\u06cc \\u0634\\u0631\\u0627\\u06cc\\u0637 \\u0627\\u0642\\u0633\\u0627\\u0637\\\",\\n      \\\"body\\\": \\\"\\u0634\\u0631\\u0627\\u06cc\\u0637 \\u0627\\u0642\\u0633\\u0627\\u0637 \\u0634\\u0627\\u0645\\u0644 \\u062a\\u0639\\u062f\\u0627\\u062f \\u0645\\u0627\\u0647\\u200c\\u0647\\u0627\\u060c \\u0646\\u0631\\u062e \\u0633\\u0648\\u062f\\u060c \\u0645\\u0628\\u0644\\u063a \\u067e\\u06cc\\u0634\\u200c\\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u0648 \\u062c\\u0631\\u06cc\\u0645\\u0647 \\u062f\\u06cc\\u0631\\u06a9\\u0631\\u062f \\u0631\\u0627 \\u0628\\u0647 \\u062f\\u0642\\u062a \\u0645\\u0637\\u0627\\u0644\\u0639\\u0647 \\u06a9\\u0646\\u06cc\\u062f. \\u0627\\u0637\\u0645\\u06cc\\u0646\\u0627\\u0646 \\u062d\\u0627\\u0635\\u0644 \\u06a9\\u0646\\u06cc\\u062f \\u06a9\\u0647 \\u0627\\u0642\\u0633\\u0627\\u0637 \\u0628\\u0627 \\u0628\\u0648\\u062f\\u062c\\u0647 \\u0645\\u0627\\u0647\\u0627\\u0646\\u0647 \\u0634\\u0645\\u0627 \\u0647\\u0645\\u0627\\u0647\\u0646\\u06af \\u0627\\u0633\\u062a \\u0648 \\u062a\\u0645\\u0627\\u0645 \\u0647\\u0632\\u06cc\\u0646\\u0647\\u200c\\u0647\\u0627\\u06cc \\u067e\\u0646\\u0647\\u0627\\u0646 \\u0631\\u0627 \\u0634\\u0641\\u0627\\u0641 \\u0645\\u06cc\\u200c\\u06a9\\u0646\\u06cc\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u062b\\u0628\\u062a\\u200c\\u0646\\u0627\\u0645 \\u0648 \\u0627\\u0631\\u0627\\u0626\\u0647 \\u0645\\u062f\\u0627\\u0631\\u06a9\\\",\\n      \\\"body\\\": \\\"\\u0628\\u0631\\u0627\\u06cc \\u0634\\u0631\\u0648\\u0639 \\u0641\\u0631\\u0622\\u06cc\\u0646\\u062f\\u060c \\u0627\\u0637\\u0644\\u0627\\u0639\\u0627\\u062a \\u0634\\u062e\\u0635\\u06cc \\u062e\\u0648\\u062f \\u0631\\u0627 \\u062f\\u0631 \\u0633\\u0627\\u0645\\u0627\\u0646\\u0647 \\u0641\\u0631\\u0648\\u0634\\u0646\\u062f\\u0647 \\u062b\\u0628\\u062a \\u06a9\\u0646\\u06cc\\u062f. \\u0645\\u062f\\u0627\\u0631\\u06a9 \\u0645\\u0648\\u0631\\u062f \\u0646\\u06cc\\u0627\\u0632 \\u0645\\u0639\\u0645\\u0648\\u0644\\u0627\\u064b \\u0634\\u0627\\u0645\\u0644 \\u06a9\\u0627\\u0631\\u062a \\u0645\\u0644\\u06cc\\u060c \\u0634\\u0646\\u0627\\u0633\\u0646\\u0627\\u0645\\u0647\\u060c \\u0648 \\u0645\\u062f\\u0631\\u06a9 \\u0634\\u063a\\u0644\\u06cc \\u06cc\\u0627 \\u062f\\u0631\\u0622\\u0645\\u062f\\u06cc \\u0627\\u0633\\u062a. \\u0645\\u0645\\u06a9\\u0646 \\u0627\\u0633\\u062a \\u0646\\u06cc\\u0627\\u0632 \\u0628\\u0647 \\u062a\\u0623\\u06cc\\u06cc\\u062f \\u0627\\u0639\\u062a\\u0628\\u0627\\u0631 \\u0633\\u0646\\u062c\\u06cc \\u062f\\u0627\\u0634\\u062a\\u0647 \\u0628\\u0627\\u0634\\u06cc\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u0627\\u0645\\u0636\\u0627\\u06cc \\u0642\\u0631\\u0627\\u0631\\u062f\\u0627\\u062f\\\",\\n      \\\"body\\\": \\\"\\u067e\\u0633 \\u0627\\u0632 \\u062a\\u0623\\u06cc\\u06cc\\u062f \\u0627\\u0639\\u062a\\u0628\\u0627\\u0631\\u060c \\u0642\\u0631\\u0627\\u0631\\u062f\\u0627\\u062f \\u0642\\u0633\\u0637\\u06cc \\u0631\\u0627 \\u0645\\u0637\\u0627\\u0644\\u0639\\u0647 \\u06a9\\u0631\\u062f\\u0647 \\u0648 \\u0627\\u0645\\u0636\\u0627 \\u06a9\\u0646\\u06cc\\u062f. \\u062f\\u0631 \\u0642\\u0631\\u0627\\u0631\\u062f\\u0627\\u062f\\u060c \\u0645\\u0628\\u0644\\u063a \\u06a9\\u0644\\u060c \\u062a\\u0639\\u062f\\u0627\\u062f \\u0627\\u0642\\u0633\\u0627\\u0637\\u060c \\u0645\\u0628\\u0644\\u063a \\u0647\\u0631 \\u0642\\u0633\\u0637 \\u0648 \\u062a\\u0627\\u0631\\u06cc\\u062e \\u0633\\u0631\\u0631\\u0633\\u06cc\\u062f\\u0647\\u0627 \\u0645\\u0634\\u062e\\u0635 \\u0634\\u062f\\u0647 \\u0627\\u0633\\u062a. \\u062d\\u062a\\u0645\\u0627\\u064b \\u0627\\u0632 \\u0634\\u0641\\u0627\\u0641 \\u0628\\u0648\\u062f\\u0646 \\u0628\\u0646\\u062f\\u0647\\u0627 \\u0627\\u0637\\u0645\\u06cc\\u0646\\u0627\\u0646 \\u062d\\u0627\\u0635\\u0644 \\u06a9\\u0646\\u06cc\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u0628\\u0647 \\u0645\\u0648\\u0642\\u0639 \\u0627\\u0642\\u0633\\u0627\\u0637\\\",\\n      \\\"body\\\": \\\"\\u067e\\u0633 \\u0627\\u0632 \\u062f\\u0631\\u06cc\\u0627\\u0641\\u062a \\u06a9\\u0627\\u0644\\u0627\\u060c \\u0637\\u0628\\u0642 \\u0628\\u0631\\u0646\\u0627\\u0645\\u0647 \\u0627\\u0642\\u0633\\u0627\\u0637\\u06cc\\u060c \\u0645\\u0628\\u0644\\u063a \\u0647\\u0631 \\u0642\\u0633\\u0637 \\u0631\\u0627 \\u0628\\u0647 \\u0645\\u0648\\u0642\\u0639 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u06a9\\u0646\\u06cc\\u062f. \\u0645\\u06cc\\u200c\\u062a\\u0648\\u0627\\u0646\\u06cc\\u062f \\u0627\\u0632 \\u0631\\u0648\\u0634\\u200c\\u0647\\u0627\\u06cc \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u0622\\u0646\\u0644\\u0627\\u06cc\\u0646\\u060c \\u06a9\\u0627\\u0631\\u062a \\u0628\\u0647 \\u06a9\\u0627\\u0631\\u062a \\u06cc\\u0627 \\u062d\\u0636\\u0648\\u0631\\u06cc \\u0627\\u0633\\u062a\\u0641\\u0627\\u062f\\u0647 \\u06a9\\u0646\\u06cc\\u062f. \\u0628\\u0631\\u0627\\u06cc \\u062c\\u0644\\u0648\\u06af\\u06cc\\u0631\\u06cc \\u0627\\u0632 \\u062c\\u0631\\u06cc\\u0645\\u0647 \\u062f\\u06cc\\u0631\\u06a9\\u0631\\u062f\\u060c \\u062a\\u0627\\u0631\\u06cc\\u062e \\u0633\\u0631\\u0631\\u0633\\u06cc\\u062f\\u0647\\u0627 \\u0631\\u0627 \\u062f\\u0631 \\u062a\\u0642\\u0648\\u06cc\\u0645 \\u062e\\u0648\\u062f \\u0639\\u0644\\u0627\\u0645\\u062a \\u0628\\u0632\\u0646\\u06cc\\u062f.\\\"\\n    }\\n  ]\\n}\"',NULL,'deepseek-local','2026-06-10 08:51:41','2026-06-10 08:22:20','2026-06-10 08:51:56'),(4,'procedure','steps','روال قسطی خرید',NULL,5,'done','\"{\\n  \\\"title\\\": \\\"\\u0631\\u0648\\u0627\\u0644 \\u0642\\u0633\\u0637\\u06cc \\u062e\\u0631\\u06cc\\u062f\\\",\\n  \\\"excerpt\\\": \\\"\\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u0628\\u0647 \\u0634\\u0645\\u0627 \\u0627\\u0645\\u06a9\\u0627\\u0646 \\u0645\\u06cc\\u200c\\u062f\\u0647\\u062f \\u06a9\\u0627\\u0644\\u0627 \\u06cc\\u0627 \\u062e\\u062f\\u0645\\u0627\\u062a \\u0645\\u0648\\u0631\\u062f \\u0646\\u0638\\u0631 \\u062e\\u0648\\u062f \\u0631\\u0627 \\u062f\\u0631 \\u0627\\u0642\\u0633\\u0627\\u0637 \\u0645\\u0627\\u0647\\u0627\\u0646\\u0647 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u06a9\\u0646\\u06cc\\u062f. \\u0627\\u06cc\\u0646 \\u0631\\u0627\\u0647\\u0646\\u0645\\u0627 \\u0645\\u0631\\u0627\\u062d\\u0644 \\u0633\\u0627\\u062f\\u0647 \\u0628\\u0631\\u0627\\u06cc \\u0627\\u0646\\u062c\\u0627\\u0645 \\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u0631\\u0627 \\u062a\\u0648\\u0636\\u06cc\\u062d \\u0645\\u06cc\\u200c\\u062f\\u0647\\u062f.\\\",\\n  \\\"steps\\\": [\\n    {\\n      \\\"title\\\": \\\"\\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u0641\\u0631\\u0648\\u0634\\u06af\\u0627\\u0647 \\u06cc\\u0627 \\u0633\\u0631\\u0648\\u06cc\\u0633\\u200c\\u062f\\u0647\\u0646\\u062f\\u0647 \\u0645\\u0639\\u062a\\u0628\\u0631\\\",\\n      \\\"body\\\": \\\"\\u0628\\u0631\\u0627\\u06cc \\u0634\\u0631\\u0648\\u0639\\u060c \\u0641\\u0631\\u0648\\u0634\\u06af\\u0627\\u0647 \\u06cc\\u0627 \\u0633\\u0631\\u0648\\u06cc\\u0633\\u200c\\u062f\\u0647\\u0646\\u062f\\u0647\\u200c\\u0627\\u06cc \\u0631\\u0627 \\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u06a9\\u0646\\u06cc\\u062f \\u06a9\\u0647 \\u06af\\u0632\\u06cc\\u0646\\u0647 \\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u0631\\u0627 \\u0627\\u0631\\u0627\\u0626\\u0647 \\u0645\\u06cc\\u200c\\u062f\\u0647\\u062f. \\u0627\\u0632 \\u0645\\u0639\\u062a\\u0628\\u0631 \\u0628\\u0648\\u062f\\u0646 \\u0641\\u0631\\u0648\\u0634\\u0646\\u062f\\u0647 \\u0648 \\u0634\\u0641\\u0627\\u0641 \\u0628\\u0648\\u062f\\u0646 \\u0634\\u0631\\u0627\\u06cc\\u0637 \\u0627\\u0637\\u0645\\u06cc\\u0646\\u0627\\u0646 \\u062d\\u0627\\u0635\\u0644 \\u06a9\\u0646\\u06cc\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u06a9\\u0627\\u0644\\u0627 \\u06cc\\u0627 \\u062e\\u062f\\u0645\\u0627\\u062a \\u0648 \\u0628\\u0631\\u0631\\u0633\\u06cc \\u0634\\u0631\\u0627\\u06cc\\u0637 \\u0627\\u0642\\u0633\\u0627\\u0637\\\",\\n      \\\"body\\\": \\\"\\u06a9\\u0627\\u0644\\u0627 \\u06cc\\u0627 \\u062e\\u062f\\u0645\\u0627\\u062a \\u0645\\u0648\\u0631\\u062f \\u0646\\u0638\\u0631 \\u062e\\u0648\\u062f \\u0631\\u0627 \\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u06a9\\u0646\\u06cc\\u062f. \\u0633\\u067e\\u0633 \\u0634\\u0631\\u0627\\u06cc\\u0637 \\u0642\\u0633\\u0637\\u06cc \\u0634\\u0627\\u0645\\u0644 \\u062a\\u0639\\u062f\\u0627\\u062f \\u0627\\u0642\\u0633\\u0627\\u0637\\u060c \\u0646\\u0631\\u062e \\u0633\\u0648\\u062f \\u06cc\\u0627 \\u06a9\\u0627\\u0631\\u0645\\u0632\\u062f\\u060c \\u0645\\u0628\\u0644\\u063a \\u0647\\u0631 \\u0642\\u0633\\u0637 \\u0648 \\u062a\\u0627\\u0631\\u06cc\\u062e \\u0633\\u0631\\u0631\\u0633\\u06cc\\u062f \\u0631\\u0627 \\u0628\\u0647 \\u062f\\u0642\\u062a \\u0645\\u0637\\u0627\\u0644\\u0639\\u0647 \\u06a9\\u0646\\u06cc\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u062b\\u0628\\u062a \\u0646\\u0627\\u0645 \\u0648 \\u062a\\u06a9\\u0645\\u06cc\\u0644 \\u0627\\u0637\\u0644\\u0627\\u0639\\u0627\\u062a \\u0647\\u0648\\u06cc\\u062a\\u06cc\\\",\\n      \\\"body\\\": \\\"\\u0628\\u0631\\u0627\\u06cc \\u0627\\u0633\\u062a\\u0641\\u0627\\u062f\\u0647 \\u0627\\u0632 \\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc\\u060c \\u0645\\u0639\\u0645\\u0648\\u0644\\u0627\\u064b \\u0646\\u06cc\\u0627\\u0632 \\u0628\\u0647 \\u062b\\u0628\\u062a \\u0646\\u0627\\u0645 \\u0648 \\u0627\\u0631\\u0627\\u0626\\u0647 \\u0627\\u0637\\u0644\\u0627\\u0639\\u0627\\u062a \\u0647\\u0648\\u06cc\\u062a\\u06cc \\u0645\\u0627\\u0646\\u0646\\u062f \\u0646\\u0627\\u0645\\u060c \\u0646\\u0627\\u0645 \\u062e\\u0627\\u0646\\u0648\\u0627\\u062f\\u06af\\u06cc\\u060c \\u06a9\\u062f \\u0645\\u0644\\u06cc\\u060c \\u0634\\u0645\\u0627\\u0631\\u0647 \\u062a\\u0645\\u0627\\u0633 \\u0648 \\u0622\\u062f\\u0631\\u0633 \\u062f\\u0627\\u0631\\u06cc\\u062f. \\u0627\\u06cc\\u0646 \\u0627\\u0637\\u0644\\u0627\\u0639\\u0627\\u062a \\u0628\\u0631\\u0627\\u06cc \\u0627\\u062d\\u0631\\u0627\\u0632 \\u0647\\u0648\\u06cc\\u062a \\u0648 \\u0627\\u0639\\u062a\\u0628\\u0627\\u0631\\u0633\\u0646\\u062c\\u06cc \\u0627\\u0633\\u062a\\u0641\\u0627\\u062f\\u0647 \\u0645\\u06cc\\u200c\\u0634\\u0648\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u0627\\u0639\\u062a\\u0628\\u0627\\u0631\\u0633\\u0646\\u062c\\u06cc \\u0648 \\u062a\\u0627\\u06cc\\u06cc\\u062f \\u062f\\u0631\\u062e\\u0648\\u0627\\u0633\\u062a\\\",\\n      \\\"body\\\": \\\"\\u067e\\u0633 \\u0627\\u0632 \\u062b\\u0628\\u062a \\u0627\\u0637\\u0644\\u0627\\u0639\\u0627\\u062a\\u060c \\u0641\\u0631\\u0648\\u0634\\u0646\\u062f\\u0647 \\u06cc\\u0627 \\u0633\\u0631\\u0648\\u06cc\\u0633\\u200c\\u062f\\u0647\\u0646\\u062f\\u0647 \\u0627\\u0639\\u062a\\u0628\\u0627\\u0631 \\u0634\\u0645\\u0627 \\u0631\\u0627 \\u0628\\u0631\\u0631\\u0633\\u06cc \\u0645\\u06cc\\u200c\\u06a9\\u0646\\u062f. \\u0627\\u06cc\\u0646 \\u0645\\u0631\\u062d\\u0644\\u0647 \\u0645\\u0645\\u06a9\\u0646 \\u0627\\u0633\\u062a \\u0634\\u0627\\u0645\\u0644 \\u0627\\u0633\\u062a\\u0639\\u0644\\u0627\\u0645 \\u0627\\u0632 \\u0633\\u0627\\u0645\\u0627\\u0646\\u0647\\u200c\\u0647\\u0627\\u06cc \\u0627\\u0639\\u062a\\u0628\\u0627\\u0631\\u0633\\u0646\\u062c\\u06cc \\u06cc\\u0627 \\u0628\\u0631\\u0631\\u0633\\u06cc \\u0633\\u0648\\u0627\\u0628\\u0642 \\u0645\\u0627\\u0644\\u06cc \\u0628\\u0627\\u0634\\u062f. \\u062f\\u0631 \\u0635\\u0648\\u0631\\u062a \\u062a\\u0627\\u06cc\\u06cc\\u062f\\u060c \\u0642\\u0631\\u0627\\u0631\\u062f\\u0627\\u062f \\u06cc\\u0627 \\u062a\\u0648\\u0627\\u0641\\u0642\\u0646\\u0627\\u0645\\u0647 \\u0627\\u0642\\u0633\\u0627\\u0637 \\u0628\\u0631\\u0627\\u06cc \\u0634\\u0645\\u0627 \\u0627\\u0631\\u0633\\u0627\\u0644 \\u0645\\u06cc\\u200c\\u0634\\u0648\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u067e\\u06cc\\u0634 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a (\\u062f\\u0631 \\u0635\\u0648\\u0631\\u062a \\u0646\\u06cc\\u0627\\u0632) \\u0648 \\u062f\\u0631\\u06cc\\u0627\\u0641\\u062a \\u06a9\\u0627\\u0644\\u0627\\\",\\n      \\\"body\\\": \\\"\\u0628\\u0631 \\u0627\\u0633\\u0627\\u0633 \\u0634\\u0631\\u0627\\u06cc\\u0637\\u060c \\u0645\\u0645\\u06a9\\u0646 \\u0627\\u0633\\u062a \\u0646\\u06cc\\u0627\\u0632 \\u0628\\u0647 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u067e\\u06cc\\u0634\\u200c\\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u062f\\u0627\\u0634\\u062a\\u0647 \\u0628\\u0627\\u0634\\u06cc\\u062f. \\u067e\\u0633 \\u0627\\u0632 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a\\u060c \\u06a9\\u0627\\u0644\\u0627 \\u062a\\u062d\\u0648\\u06cc\\u0644 \\u062f\\u0627\\u062f\\u0647 \\u0645\\u06cc\\u200c\\u0634\\u0648\\u062f \\u06cc\\u0627 \\u0633\\u0631\\u0648\\u06cc\\u0633 \\u0622\\u063a\\u0627\\u0632 \\u0645\\u06cc\\u200c\\u06af\\u0631\\u062f\\u062f. \\u0633\\u067e\\u0633 \\u0637\\u0628\\u0642 \\u0628\\u0631\\u0646\\u0627\\u0645\\u0647 \\u0627\\u0642\\u0633\\u0627\\u0637\\u060c \\u0645\\u0628\\u0627\\u0644\\u063a \\u062a\\u0639\\u06cc\\u06cc\\u0646 \\u0634\\u062f\\u0647 \\u0631\\u0627 \\u0628\\u0647 \\u0635\\u0648\\u0631\\u062a \\u0645\\u0627\\u0647\\u0627\\u0646\\u0647 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u06a9\\u0646\\u06cc\\u062f.\\\"\\n    }\\n  ]\\n}\"',NULL,'deepseek-local','2026-06-10 08:51:41','2026-06-10 08:22:36','2026-06-10 08:52:04'),(5,'procedure','steps','روال قسطی خرید',NULL,5,'done','\"{\\n  \\\"title\\\": \\\"\\u0631\\u0648\\u0627\\u0644 \\u0642\\u0633\\u0637\\u06cc \\u062e\\u0631\\u06cc\\u062f\\\",\\n  \\\"excerpt\\\": \\\"\\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u0631\\u0648\\u0634\\u06cc \\u0627\\u0633\\u062a \\u06a9\\u0647 \\u0628\\u0647 \\u0634\\u0645\\u0627 \\u0627\\u0645\\u06a9\\u0627\\u0646 \\u0645\\u06cc\\u200c\\u062f\\u0647\\u062f \\u06a9\\u0627\\u0644\\u0627 \\u06cc\\u0627 \\u062e\\u062f\\u0645\\u0627\\u062a \\u0631\\u0627 \\u0628\\u0647 \\u0635\\u0648\\u0631\\u062a \\u0627\\u0642\\u0633\\u0627\\u0637 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u06a9\\u0646\\u06cc\\u062f. \\u062f\\u0631 \\u0627\\u06cc\\u0646 \\u0631\\u0627\\u0647\\u0646\\u0645\\u0627\\u060c \\u0645\\u0631\\u0627\\u062d\\u0644 \\u0627\\u0635\\u0644\\u06cc \\u0627\\u06cc\\u0646 \\u0641\\u0631\\u0622\\u06cc\\u0646\\u062f \\u0631\\u0627 \\u062a\\u0648\\u0636\\u06cc\\u062d \\u0645\\u06cc\\u200c\\u062f\\u0647\\u06cc\\u0645.\\\",\\n  \\\"steps\\\": [\\n    {\\n      \\\"title\\\": \\\"\\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u0641\\u0631\\u0648\\u0634\\u06af\\u0627\\u0647 \\u0648 \\u0645\\u062d\\u0635\\u0648\\u0644\\\",\\n      \\\"body\\\": \\\"\\u0627\\u0628\\u062a\\u062f\\u0627 \\u0641\\u0631\\u0648\\u0634\\u06af\\u0627\\u0647\\u06cc \\u0631\\u0627 \\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u06a9\\u0646\\u06cc\\u062f \\u06a9\\u0647 \\u06af\\u0632\\u06cc\\u0646\\u0647 \\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u0631\\u0627 \\u0627\\u0631\\u0627\\u0626\\u0647 \\u0645\\u06cc\\u200c\\u062f\\u0647\\u062f. \\u0633\\u067e\\u0633 \\u0645\\u062d\\u0635\\u0648\\u0644 \\u0645\\u0648\\u0631\\u062f \\u0646\\u0638\\u0631 \\u062e\\u0648\\u062f \\u0631\\u0627 \\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u06a9\\u0631\\u062f\\u0647 \\u0648 \\u0634\\u0631\\u0627\\u06cc\\u0637 \\u0642\\u0633\\u0637\\u06cc \\u0622\\u0646 \\u0631\\u0627 \\u0628\\u0631\\u0631\\u0633\\u06cc \\u06a9\\u0646\\u06cc\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u0628\\u0631\\u0631\\u0633\\u06cc \\u0634\\u0631\\u0627\\u06cc\\u0637 \\u0648 \\u0645\\u062f\\u0627\\u0631\\u06a9\\\",\\n      \\\"body\\\": \\\"\\u0634\\u0631\\u0627\\u06cc\\u0637 \\u0627\\u0642\\u0633\\u0627\\u0637 \\u0631\\u0627 \\u0645\\u0637\\u0627\\u0644\\u0639\\u0647 \\u06a9\\u0646\\u06cc\\u062f: \\u062a\\u0639\\u062f\\u0627\\u062f \\u0627\\u0642\\u0633\\u0627\\u0637\\u060c \\u0646\\u0631\\u062e \\u0628\\u0647\\u0631\\u0647\\u060c \\u0645\\u0628\\u0644\\u063a \\u067e\\u06cc\\u0634\\u200c\\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u0648 \\u062c\\u0631\\u06cc\\u0645\\u0647 \\u062f\\u06cc\\u0631\\u06a9\\u0631\\u062f. \\u0633\\u067e\\u0633 \\u0645\\u062f\\u0627\\u0631\\u06a9 \\u0645\\u0648\\u0631\\u062f \\u0646\\u06cc\\u0627\\u0632 \\u0645\\u0627\\u0646\\u0646\\u062f \\u06a9\\u0627\\u0631\\u062a \\u0645\\u0644\\u06cc\\u060c \\u0634\\u0646\\u0627\\u0633\\u0646\\u0627\\u0645\\u0647\\u060c \\u0641\\u06cc\\u0634 \\u062d\\u0642\\u0648\\u0642\\u06cc \\u06cc\\u0627 \\u0636\\u0627\\u0645\\u0646 \\u0631\\u0627 \\u0622\\u0645\\u0627\\u062f\\u0647 \\u06a9\\u0646\\u06cc\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u062b\\u0628\\u062a \\u062f\\u0631\\u062e\\u0648\\u0627\\u0633\\u062a \\u0648 \\u0627\\u0633\\u062a\\u0639\\u0644\\u0627\\u0645 \\u0627\\u0639\\u062a\\u0628\\u0627\\u0631\\\",\\n      \\\"body\\\": \\\"\\u0641\\u0631\\u0645 \\u062f\\u0631\\u062e\\u0648\\u0627\\u0633\\u062a \\u0631\\u0627 \\u067e\\u0631 \\u06a9\\u0646\\u06cc\\u062f \\u0648 \\u0645\\u062f\\u0627\\u0631\\u06a9 \\u0631\\u0627 \\u062a\\u062d\\u0648\\u06cc\\u0644 \\u062f\\u0647\\u06cc\\u062f. \\u0641\\u0631\\u0648\\u0634\\u06af\\u0627\\u0647 \\u06cc\\u0627 \\u0634\\u0631\\u06a9\\u062a \\u0644\\u06cc\\u0632\\u06cc\\u0646\\u06af\\u060c \\u0627\\u0639\\u062a\\u0628\\u0627\\u0631 \\u0634\\u0645\\u0627 \\u0631\\u0627 \\u0627\\u0632 \\u0637\\u0631\\u06cc\\u0642 \\u0633\\u0627\\u0645\\u0627\\u0646\\u0647\\u200c\\u0647\\u0627\\u06cc \\u0645\\u0639\\u062a\\u0628\\u0631 \\u0627\\u0633\\u062a\\u0639\\u0644\\u0627\\u0645 \\u0645\\u06cc\\u200c\\u06a9\\u0646\\u062f \\u062a\\u0627 \\u062a\\u0648\\u0627\\u0646\\u0627\\u06cc\\u06cc \\u0628\\u0627\\u0632\\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u0631\\u0627 \\u0628\\u0631\\u0631\\u0633\\u06cc \\u06a9\\u0646\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u0627\\u0645\\u0636\\u0627\\u06cc \\u0642\\u0631\\u0627\\u0631\\u062f\\u0627\\u062f \\u0648 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u067e\\u06cc\\u0634\\u200c\\u067e\\u0631\\u062f\\u0627\\u062e\\u062a\\\",\\n      \\\"body\\\": \\\"\\u067e\\u0633 \\u0627\\u0632 \\u062a\\u0623\\u06cc\\u06cc\\u062f \\u0627\\u0639\\u062a\\u0628\\u0627\\u0631\\u060c \\u0642\\u0631\\u0627\\u0631\\u062f\\u0627\\u062f \\u0627\\u0642\\u0633\\u0627\\u0637\\u06cc \\u0631\\u0627 \\u0645\\u0637\\u0627\\u0644\\u0639\\u0647 \\u06a9\\u0631\\u062f\\u0647 \\u0648 \\u0627\\u0645\\u0636\\u0627 \\u06a9\\u0646\\u06cc\\u062f. \\u0645\\u0639\\u0645\\u0648\\u0644\\u0627\\u064b \\u0628\\u0627\\u06cc\\u062f \\u0645\\u0628\\u0644\\u063a \\u067e\\u06cc\\u0634\\u200c\\u067e\\u0631\\u062f\\u0627\\u062e\\u062a (\\u0645\\u062b\\u0644\\u0627\\u064b \\u06f2\\u06f0\\u066a \\u0642\\u06cc\\u0645\\u062a \\u0645\\u062d\\u0635\\u0648\\u0644) \\u0631\\u0627 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u06a9\\u0646\\u06cc\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u062a\\u062d\\u0648\\u06cc\\u0644 \\u06a9\\u0627\\u0644\\u0627 \\u0648 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u0627\\u0642\\u0633\\u0627\\u0637\\\",\\n      \\\"body\\\": \\\"\\u067e\\u0633 \\u0627\\u0632 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u067e\\u06cc\\u0634\\u200c\\u067e\\u0631\\u062f\\u0627\\u062e\\u062a\\u060c \\u06a9\\u0627\\u0644\\u0627 \\u062a\\u062d\\u0648\\u06cc\\u0644 \\u062f\\u0627\\u062f\\u0647 \\u0645\\u06cc\\u200c\\u0634\\u0648\\u062f. \\u0633\\u067e\\u0633 \\u0637\\u0628\\u0642 \\u0628\\u0631\\u0646\\u0627\\u0645\\u0647 \\u0627\\u0642\\u0633\\u0627\\u0637\\u060c \\u0647\\u0631 \\u0645\\u0627\\u0647 \\u0645\\u0628\\u0644\\u063a \\u0645\\u0634\\u062e\\u0635\\u06cc \\u0631\\u0627 \\u062a\\u0627 \\u067e\\u0627\\u06cc\\u0627\\u0646 \\u062f\\u0648\\u0631\\u0647 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u0645\\u06cc\\u200c\\u06a9\\u0646\\u06cc\\u062f.\\\"\\n    }\\n  ]\\n}\"',NULL,'deepseek-local','2026-06-10 08:51:41','2026-06-10 08:32:15','2026-06-10 08:52:11'),(6,'procedure','steps','خرید قسطی کالا',NULL,5,'done','\"{\\n  \\\"title\\\": \\\"\\u0631\\u0627\\u0647\\u0646\\u0645\\u0627\\u06cc \\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u06a9\\u0627\\u0644\\u0627\\\",\\n  \\\"excerpt\\\": \\\"\\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u06a9\\u0627\\u0644\\u0627 \\u0628\\u0647 \\u0634\\u0645\\u0627 \\u0627\\u0645\\u06a9\\u0627\\u0646 \\u0645\\u06cc\\u200c\\u062f\\u0647\\u062f \\u06a9\\u0627\\u0644\\u0627\\u06cc \\u0645\\u0648\\u0631\\u062f \\u0646\\u0638\\u0631 \\u062e\\u0648\\u062f \\u0631\\u0627 \\u0627\\u0642\\u0633\\u0627\\u0637\\u06cc \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u06a9\\u0646\\u06cc\\u062f. \\u062f\\u0631 \\u0627\\u06cc\\u0646 \\u0631\\u0627\\u0647\\u0646\\u0645\\u0627 \\u0645\\u0631\\u0627\\u062d\\u0644 \\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u0631\\u0627 \\u0628\\u0647 \\u0635\\u0648\\u0631\\u062a \\u06af\\u0627\\u0645 \\u0628\\u0647 \\u06af\\u0627\\u0645 \\u062a\\u0648\\u0636\\u06cc\\u062d \\u0645\\u06cc\\u200c\\u062f\\u0647\\u06cc\\u0645.\\\",\\n  \\\"steps\\\": [\\n    {\\n      \\\"title\\\": \\\"\\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u06a9\\u0627\\u0644\\u0627 \\u0648 \\u0641\\u0631\\u0648\\u0634\\u0646\\u062f\\u0647 \\u0645\\u0639\\u062a\\u0628\\u0631\\\",\\n      \\\"body\\\": \\\"\\u0627\\u0628\\u062a\\u062f\\u0627 \\u06a9\\u0627\\u0644\\u0627\\u06cc \\u0645\\u0648\\u0631\\u062f \\u0646\\u06cc\\u0627\\u0632 \\u062e\\u0648\\u062f \\u0631\\u0627 \\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u06a9\\u0646\\u06cc\\u062f \\u0648 \\u0627\\u0632 \\u0645\\u0639\\u062a\\u0628\\u0631 \\u0628\\u0648\\u062f\\u0646 \\u0641\\u0631\\u0648\\u0634\\u0646\\u062f\\u0647 \\u0627\\u0637\\u0645\\u06cc\\u0646\\u0627\\u0646 \\u062d\\u0627\\u0635\\u0644 \\u06a9\\u0646\\u06cc\\u062f. \\u0628\\u0647\\u062a\\u0631 \\u0627\\u0633\\u062a \\u0627\\u0632 \\u0641\\u0631\\u0648\\u0634\\u06af\\u0627\\u0647\\u200c\\u0647\\u0627\\u06cc\\u06cc \\u06a9\\u0647 \\u0637\\u0631\\u062d\\u200c\\u0647\\u0627\\u06cc \\u0642\\u0633\\u0637\\u06cc \\u0645\\u0639\\u062a\\u0628\\u0631 \\u062f\\u0627\\u0631\\u0646\\u062f \\u062e\\u0631\\u06cc\\u062f \\u06a9\\u0646\\u06cc\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u0628\\u0631\\u0631\\u0633\\u06cc \\u0634\\u0631\\u0627\\u06cc\\u0637 \\u0648 \\u0645\\u062f\\u0627\\u0631\\u06a9 \\u0645\\u0648\\u0631\\u062f \\u0646\\u06cc\\u0627\\u0632\\\",\\n      \\\"body\\\": \\\"\\u0634\\u0631\\u0627\\u06cc\\u0637 \\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u0645\\u0627\\u0646\\u0646\\u062f \\u062d\\u062f\\u0627\\u0642\\u0644 \\u0648 \\u062d\\u062f\\u0627\\u06a9\\u062b\\u0631 \\u0645\\u0628\\u0644\\u063a\\u060c \\u062a\\u0639\\u062f\\u0627\\u062f \\u0627\\u0642\\u0633\\u0627\\u0637\\u060c \\u0646\\u0631\\u062e \\u0633\\u0648\\u062f \\u0648 \\u062c\\u0631\\u06cc\\u0645\\u0647 \\u062f\\u06cc\\u0631\\u06a9\\u0631\\u062f \\u0631\\u0627 \\u0645\\u0637\\u0627\\u0644\\u0639\\u0647 \\u06a9\\u0646\\u06cc\\u062f. \\u0645\\u0639\\u0645\\u0648\\u0644\\u0627\\u064b \\u0645\\u062f\\u0627\\u0631\\u06a9\\u06cc \\u0645\\u0627\\u0646\\u0646\\u062f \\u06a9\\u0627\\u0631\\u062a \\u0645\\u0644\\u06cc\\u060c \\u0634\\u0646\\u0627\\u0633\\u0646\\u0627\\u0645\\u0647 \\u0648 \\u0641\\u06cc\\u0634 \\u062d\\u0642\\u0648\\u0642\\u06cc \\u0646\\u06cc\\u0627\\u0632 \\u0627\\u0633\\u062a.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u062a\\u06a9\\u0645\\u06cc\\u0644 \\u0641\\u0631\\u0645 \\u062f\\u0631\\u062e\\u0648\\u0627\\u0633\\u062a \\u0648 \\u062b\\u0628\\u062a \\u0633\\u0641\\u0627\\u0631\\u0634\\\",\\n      \\\"body\\\": \\\"\\u0641\\u0631\\u0645 \\u062f\\u0631\\u062e\\u0648\\u0627\\u0633\\u062a \\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u0631\\u0627 \\u067e\\u0631 \\u06a9\\u0646\\u06cc\\u062f \\u0648 \\u0627\\u0637\\u0644\\u0627\\u0639\\u0627\\u062a \\u0634\\u062e\\u0635\\u06cc \\u0648 \\u0634\\u063a\\u0644\\u06cc \\u062e\\u0648\\u062f \\u0631\\u0627 \\u062f\\u0642\\u06cc\\u0642 \\u0648\\u0627\\u0631\\u062f \\u0646\\u0645\\u0627\\u06cc\\u06cc\\u062f. \\u0633\\u067e\\u0633 \\u0633\\u0641\\u0627\\u0631\\u0634 \\u062e\\u0648\\u062f \\u0631\\u0627 \\u062b\\u0628\\u062a \\u06a9\\u0646\\u06cc\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u0627\\u0631\\u0633\\u0627\\u0644 \\u0645\\u062f\\u0627\\u0631\\u06a9 \\u0648 \\u062a\\u0623\\u06cc\\u06cc\\u062f \\u0627\\u0639\\u062a\\u0628\\u0627\\u0631\\\",\\n      \\\"body\\\": \\\"\\u0645\\u062f\\u0627\\u0631\\u06a9 \\u0645\\u0648\\u0631\\u062f \\u0646\\u06cc\\u0627\\u0632 \\u0631\\u0627 \\u0628\\u0647 \\u0641\\u0631\\u0648\\u0634\\u0646\\u062f\\u0647 \\u06cc\\u0627 \\u0634\\u0631\\u06a9\\u062a \\u0644\\u06cc\\u0632\\u06cc\\u0646\\u06af \\u0627\\u0631\\u0627\\u0626\\u0647 \\u062f\\u0647\\u06cc\\u062f. \\u067e\\u0633 \\u0627\\u0632 \\u0628\\u0631\\u0631\\u0633\\u06cc\\u060c \\u0627\\u0639\\u062a\\u0628\\u0627\\u0631 \\u0634\\u0645\\u0627 \\u062a\\u0623\\u06cc\\u06cc\\u062f \\u0634\\u062f\\u0647 \\u0648 \\u0634\\u0631\\u0627\\u06cc\\u0637 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u0646\\u0647\\u0627\\u06cc\\u06cc \\u0645\\u06cc\\u200c\\u0634\\u0648\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u0627\\u0645\\u0636\\u0627\\u06cc \\u0642\\u0631\\u0627\\u0631\\u062f\\u0627\\u062f \\u0648 \\u062a\\u062d\\u0648\\u06cc\\u0644 \\u06a9\\u0627\\u0644\\u0627\\\",\\n      \\\"body\\\": \\\"\\u0642\\u0631\\u0627\\u0631\\u062f\\u0627\\u062f \\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u0631\\u0627 \\u0645\\u0637\\u0627\\u0644\\u0639\\u0647 \\u0648 \\u0627\\u0645\\u0636\\u0627 \\u06a9\\u0646\\u06cc\\u062f. \\u067e\\u0633 \\u0627\\u0632 \\u0627\\u0645\\u0636\\u0627\\u060c \\u06a9\\u0627\\u0644\\u0627 \\u0628\\u0647 \\u0634\\u0645\\u0627 \\u062a\\u062d\\u0648\\u06cc\\u0644 \\u062f\\u0627\\u062f\\u0647 \\u0645\\u06cc\\u200c\\u0634\\u0648\\u062f \\u0648 \\u0628\\u0627\\u06cc\\u062f \\u0627\\u0642\\u0633\\u0627\\u0637 \\u0631\\u0627 \\u062f\\u0631 \\u0645\\u0648\\u0639\\u062f \\u0645\\u0642\\u0631\\u0631 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u06a9\\u0646\\u06cc\\u062f.\\\"\\n    }\\n  ]\\n}\"',NULL,'deepseek-local','2026-06-10 08:51:41','2026-06-10 08:33:51','2026-06-10 08:52:17'),(7,'procedure','steps','خرید قسطی کالا',NULL,5,'done','\"{\\n\\\"title\\\": \\\"\\u0631\\u0627\\u0647\\u0646\\u0645\\u0627\\u06cc \\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u06a9\\u0627\\u0644\\u0627\\\",\\n\\\"excerpt\\\": \\\"\\u062f\\u0631 \\u0627\\u06cc\\u0646 \\u0631\\u0627\\u0647\\u0646\\u0645\\u0627 \\u0645\\u0631\\u0627\\u062d\\u0644 \\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u06a9\\u0627\\u0644\\u0627 \\u0631\\u0627 \\u0628\\u0647 \\u0635\\u0648\\u0631\\u062a \\u06af\\u0627\\u0645 \\u0628\\u0647 \\u06af\\u0627\\u0645 \\u062a\\u0648\\u0636\\u06cc\\u062d \\u0645\\u06cc\\u200c\\u062f\\u0647\\u06cc\\u0645.\\\",\\n\\\"steps\\\": [\\n{\\n\\\"title\\\": \\\"\\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u0641\\u0631\\u0648\\u0634\\u06af\\u0627\\u0647 \\u0648 \\u06a9\\u0627\\u0644\\u0627\\\",\\n\\\"body\\\": \\\"\\u0627\\u0628\\u062a\\u062f\\u0627 \\u0641\\u0631\\u0648\\u0634\\u06af\\u0627\\u0647\\u06cc \\u0631\\u0627 \\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u06a9\\u0646\\u06cc\\u062f \\u06a9\\u0647 \\u06af\\u0632\\u06cc\\u0646\\u0647 \\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u0631\\u0627 \\u0627\\u0631\\u0627\\u0626\\u0647 \\u0645\\u06cc\\u200c\\u062f\\u0647\\u062f. \\u0633\\u067e\\u0633 \\u06a9\\u0627\\u0644\\u0627\\u06cc \\u0645\\u0648\\u0631\\u062f \\u0646\\u0638\\u0631 \\u062e\\u0648\\u062f \\u0631\\u0627 \\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u06a9\\u0631\\u062f\\u0647 \\u0648 \\u0627\\u0632 \\u0634\\u0631\\u0627\\u06cc\\u0637 \\u0641\\u0631\\u0648\\u0634 \\u0627\\u0642\\u0633\\u0627\\u0637\\u06cc \\u0645\\u0627\\u0646\\u0646\\u062f \\u062a\\u0639\\u062f\\u0627\\u062f \\u0627\\u0642\\u0633\\u0627\\u0637\\u060c \\u0646\\u0631\\u062e \\u0633\\u0648\\u062f \\u0648 \\u067e\\u06cc\\u0634\\u200c\\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u0645\\u0637\\u0644\\u0639 \\u0634\\u0648\\u06cc\\u062f.\\\"\\n},\\n{\\n\\\"title\\\": \\\"\\u062a\\u06a9\\u0645\\u06cc\\u0644 \\u0645\\u062f\\u0627\\u0631\\u06a9 \\u0648 \\u0627\\u0639\\u062a\\u0628\\u0627\\u0631\\u0633\\u0646\\u062c\\u06cc\\\",\\n\\\"body\\\": \\\"\\u0645\\u062f\\u0627\\u0631\\u06a9 \\u0644\\u0627\\u0632\\u0645 \\u0645\\u0627\\u0646\\u0646\\u062f \\u06a9\\u0627\\u0631\\u062a \\u0645\\u0644\\u06cc\\u060c \\u0634\\u0646\\u0627\\u0633\\u0646\\u0627\\u0645\\u0647\\u060c \\u0648 \\u0645\\u062f\\u0627\\u0631\\u06a9 \\u0634\\u063a\\u0644\\u06cc \\u06cc\\u0627 \\u062f\\u0631\\u0622\\u0645\\u062f\\u06cc \\u0631\\u0627 \\u062a\\u0647\\u06cc\\u0647 \\u06a9\\u0646\\u06cc\\u062f. \\u0641\\u0631\\u0648\\u0634\\u06af\\u0627\\u0647 \\u0645\\u062f\\u0627\\u0631\\u06a9 \\u0634\\u0645\\u0627 \\u0631\\u0627 \\u0628\\u0631\\u0631\\u0633\\u06cc \\u06a9\\u0631\\u062f\\u0647 \\u0648 \\u0627\\u0639\\u062a\\u0628\\u0627\\u0631 \\u0633\\u0646\\u062c\\u06cc \\u0627\\u0648\\u0644\\u06cc\\u0647 \\u0631\\u0627 \\u0627\\u0646\\u062c\\u0627\\u0645 \\u0645\\u06cc\\u200c\\u062f\\u0647\\u062f \\u062a\\u0627 \\u0645\\u06cc\\u0632\\u0627\\u0646 \\u0627\\u0639\\u062a\\u0628\\u0627\\u0631 \\u062e\\u0631\\u06cc\\u062f \\u0634\\u0645\\u0627 \\u062a\\u0639\\u06cc\\u06cc\\u0646 \\u0634\\u0648\\u062f.\\\"\\n},\\n{\\n\\\"title\\\": \\\"\\u0627\\u0646\\u0639\\u0642\\u0627\\u062f \\u0642\\u0631\\u0627\\u0631\\u062f\\u0627\\u062f\\\",\\n\\\"body\\\": \\\"\\u067e\\u0633 \\u0627\\u0632 \\u062a\\u0623\\u06cc\\u06cc\\u062f \\u0627\\u0639\\u062a\\u0628\\u0627\\u0631\\u060c \\u0642\\u0631\\u0627\\u0631\\u062f\\u0627\\u062f \\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u0631\\u0627 \\u0645\\u0637\\u0627\\u0644\\u0639\\u0647 \\u06a9\\u0631\\u062f\\u0647 \\u0648 \\u0627\\u0645\\u0636\\u0627 \\u06a9\\u0646\\u06cc\\u062f. \\u062f\\u0631 \\u0627\\u06cc\\u0646 \\u0642\\u0631\\u0627\\u0631\\u062f\\u0627\\u062f \\u0645\\u0628\\u0644\\u063a \\u06a9\\u0644\\u060c \\u062a\\u0639\\u062f\\u0627\\u062f \\u0627\\u0642\\u0633\\u0627\\u0637\\u060c \\u0645\\u0628\\u0644\\u063a \\u0647\\u0631 \\u0642\\u0633\\u0637\\u060c \\u062a\\u0627\\u0631\\u06cc\\u062e\\u200c\\u0647\\u0627\\u06cc \\u0633\\u0631\\u0631\\u0633\\u06cc\\u062f \\u0648 \\u0634\\u0631\\u0627\\u06cc\\u0637 \\u0641\\u0633\\u062e \\u06cc\\u0627 \\u062c\\u0631\\u06cc\\u0645\\u0647 \\u062f\\u06cc\\u0631\\u06a9\\u0631\\u062f \\u0645\\u0634\\u062e\\u0635 \\u0634\\u062f\\u0647 \\u0627\\u0633\\u062a.\\\"\\n},\\n{\\n\\\"title\\\": \\\"\\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u067e\\u06cc\\u0634\\u200c\\u067e\\u0631\\u062f\\u0627\\u062e\\u062a\\\",\\n\\\"body\\\": \\\"\\u062f\\u0631 \\u0635\\u0648\\u0631\\u062a \\u0646\\u06cc\\u0627\\u0632 \\u0628\\u0647 \\u067e\\u06cc\\u0634\\u200c\\u067e\\u0631\\u062f\\u0627\\u062e\\u062a\\u060c \\u0645\\u0628\\u0644\\u063a \\u062a\\u0639\\u06cc\\u06cc\\u0646 \\u0634\\u062f\\u0647 \\u0631\\u0627 \\u0628\\u0647 \\u0641\\u0631\\u0648\\u0634\\u06af\\u0627\\u0647 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u06a9\\u0646\\u06cc\\u062f. \\u067e\\u0633 \\u0627\\u0632 \\u0622\\u0646\\u060c \\u06a9\\u0627\\u0644\\u0627 \\u062a\\u062d\\u0648\\u06cc\\u0644 \\u0634\\u0645\\u0627 \\u062f\\u0627\\u062f\\u0647 \\u0645\\u06cc\\u200c\\u0634\\u0648\\u062f \\u06cc\\u0627 \\u0641\\u0631\\u0622\\u06cc\\u0646\\u062f \\u062a\\u062d\\u0648\\u06cc\\u0644 \\u0622\\u063a\\u0627\\u0632 \\u0645\\u06cc\\u200c\\u06af\\u0631\\u062f\\u062f.\\\"\\n},\\n{\\n\\\"title\\\": \\\"\\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u0627\\u0642\\u0633\\u0627\\u0637 \\u062a\\u0627 \\u067e\\u0627\\u06cc\\u0627\\u0646 \\u062f\\u0648\\u0631\\u0647\\\",\\n\\\"body\\\": \\\"\\u062f\\u0631 \\u062a\\u0627\\u0631\\u06cc\\u062e\\u200c\\u0647\\u0627\\u06cc \\u0645\\u0634\\u062e\\u0635 \\u0634\\u062f\\u0647 \\u062f\\u0631 \\u0642\\u0631\\u0627\\u0631\\u062f\\u0627\\u062f\\u060c \\u0647\\u0631 \\u0642\\u0633\\u0637 \\u0631\\u0627 \\u0628\\u0647 \\u0645\\u0648\\u0642\\u0639 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u06a9\\u0646\\u06cc\\u062f. \\u0645\\u06cc\\u200c\\u062a\\u0648\\u0627\\u0646\\u06cc\\u062f \\u0627\\u0632 \\u0631\\u0648\\u0634\\u200c\\u0647\\u0627\\u06cc \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u0622\\u0646\\u0644\\u0627\\u06cc\\u0646\\u060c \\u06a9\\u0627\\u0631\\u062a \\u0628\\u0647 \\u06a9\\u0627\\u0631\\u062a \\u06cc\\u0627 \\u0645\\u0631\\u0627\\u062c\\u0639\\u0647 \\u062d\\u0636\\u0648\\u0631\\u06cc \\u0627\\u0633\\u062a\\u0641\\u0627\\u062f\\u0647 \\u06a9\\u0646\\u06cc\\u062f. \\u067e\\u0633 \\u0627\\u0632 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u0622\\u062e\\u0631\\u06cc\\u0646 \\u0642\\u0633\\u0637\\u060c \\u0645\\u0627\\u0644\\u06a9\\u06cc\\u062a \\u06a9\\u0627\\u0645\\u0644 \\u06a9\\u0627\\u0644\\u0627 \\u0628\\u0647 \\u0634\\u0645\\u0627 \\u0645\\u0646\\u062a\\u0642\\u0644 \\u0645\\u06cc\\u200c\\u0634\\u0648\\u062f.\\\"\\n}\\n]\\n}\"',NULL,'deepseek-local','2026-06-10 09:24:34','2026-06-10 08:54:34','2026-06-10 09:24:41'),(8,'procedure','steps','خرید قسطی کالا',NULL,5,'done','\"{\\n  \\\"title\\\": \\\"\\u0631\\u0627\\u0647\\u0646\\u0645\\u0627\\u06cc \\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u06a9\\u0627\\u0644\\u0627\\\",\\n  \\\"excerpt\\\": \\\"\\u0627\\u06cc\\u0646 \\u0631\\u0627\\u0647\\u0646\\u0645\\u0627 \\u0645\\u0631\\u0627\\u062d\\u0644 \\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u06a9\\u0627\\u0644\\u0627 \\u0631\\u0627 \\u0628\\u0647 \\u0635\\u0648\\u0631\\u062a \\u06af\\u0627\\u0645 \\u0628\\u0647 \\u06af\\u0627\\u0645 \\u062a\\u0648\\u0636\\u06cc\\u062d \\u0645\\u06cc\\u200c\\u062f\\u0647\\u062f.\\\",\\n  \\\"steps\\\": [\\n    {\\n      \\\"title\\\": \\\"\\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u0641\\u0631\\u0648\\u0634\\u0646\\u062f\\u0647 \\u0645\\u0639\\u062a\\u0628\\u0631\\\",\\n      \\\"body\\\": \\\"\\u0627\\u0628\\u062a\\u062f\\u0627 \\u0641\\u0631\\u0648\\u0634\\u0646\\u062f\\u0647\\u200c\\u0627\\u06cc \\u0631\\u0627 \\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u06a9\\u0646\\u06cc\\u062f \\u06a9\\u0647 \\u0627\\u0645\\u06a9\\u0627\\u0646 \\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u0631\\u0627 \\u0641\\u0631\\u0627\\u0647\\u0645 \\u0645\\u06cc\\u200c\\u06a9\\u0646\\u062f. \\u0627\\u0632 \\u0645\\u0639\\u062a\\u0628\\u0631 \\u0628\\u0648\\u062f\\u0646 \\u0641\\u0631\\u0648\\u0634\\u06af\\u0627\\u0647 \\u0648 \\u062f\\u0627\\u0634\\u062a\\u0646 \\u0645\\u062c\\u0648\\u0632\\u0647\\u0627\\u06cc \\u0644\\u0627\\u0632\\u0645 \\u0627\\u0637\\u0645\\u06cc\\u0646\\u0627\\u0646 \\u062d\\u0627\\u0635\\u0644 \\u06a9\\u0646\\u06cc\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u0628\\u0631\\u0631\\u0633\\u06cc \\u0634\\u0631\\u0627\\u06cc\\u0637 \\u0627\\u0642\\u0633\\u0627\\u0637\\\",\\n      \\\"body\\\": \\\"\\u0634\\u0631\\u0627\\u06cc\\u0637 \\u0627\\u0642\\u0633\\u0627\\u0637 \\u0634\\u0627\\u0645\\u0644 \\u062a\\u0639\\u062f\\u0627\\u062f \\u0627\\u0642\\u0633\\u0627\\u0637\\u060c \\u0645\\u0628\\u0644\\u063a \\u0647\\u0631 \\u0642\\u0633\\u0637\\u060c \\u0646\\u0631\\u062e \\u0633\\u0648\\u062f \\u0648 \\u062c\\u0631\\u06cc\\u0645\\u0647 \\u062f\\u06cc\\u0631\\u06a9\\u0631\\u062f \\u0631\\u0627 \\u0628\\u0647 \\u062f\\u0642\\u062a \\u0645\\u0637\\u0627\\u0644\\u0639\\u0647 \\u06a9\\u0646\\u06cc\\u062f. \\u0645\\u0637\\u0645\\u0626\\u0646 \\u0634\\u0648\\u06cc\\u062f \\u06a9\\u0647 \\u0634\\u0631\\u0627\\u06cc\\u0637 \\u0628\\u0627 \\u062a\\u0648\\u0627\\u0646 \\u0645\\u0627\\u0644\\u06cc \\u0634\\u0645\\u0627 \\u0633\\u0627\\u0632\\u06af\\u0627\\u0631 \\u0627\\u0633\\u062a.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u062a\\u06a9\\u0645\\u06cc\\u0644 \\u0645\\u062f\\u0627\\u0631\\u06a9 \\u0645\\u0648\\u0631\\u062f \\u0646\\u06cc\\u0627\\u0632\\\",\\n      \\\"body\\\": \\\"\\u0645\\u062f\\u0627\\u0631\\u06a9 \\u0647\\u0648\\u06cc\\u062a\\u06cc \\u0645\\u0627\\u0646\\u0646\\u062f \\u06a9\\u0627\\u0631\\u062a \\u0645\\u0644\\u06cc\\u060c \\u0634\\u0646\\u0627\\u0633\\u0646\\u0627\\u0645\\u0647 \\u0648 \\u0645\\u062f\\u0627\\u0631\\u06a9 \\u0634\\u063a\\u0644\\u06cc \\u06cc\\u0627 \\u0636\\u0627\\u0645\\u0646 \\u0631\\u0627 \\u0637\\u0628\\u0642 \\u062f\\u0631\\u062e\\u0648\\u0627\\u0633\\u062a \\u0641\\u0631\\u0648\\u0634\\u0646\\u062f\\u0647 \\u0622\\u0645\\u0627\\u062f\\u0647 \\u06a9\\u0646\\u06cc\\u062f. \\u0628\\u0631\\u062e\\u06cc \\u0641\\u0631\\u0648\\u0634\\u0646\\u062f\\u06af\\u0627\\u0646 \\u0645\\u0645\\u06a9\\u0646 \\u0627\\u0633\\u062a \\u0628\\u0647 \\u0686\\u06a9 \\u06cc\\u0627 \\u0633\\u0641\\u062a\\u0647 \\u0646\\u06cc\\u0632 \\u0646\\u06cc\\u0627\\u0632 \\u062f\\u0627\\u0634\\u062a\\u0647 \\u0628\\u0627\\u0634\\u0646\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u0627\\u0645\\u0636\\u0627\\u06cc \\u0642\\u0631\\u0627\\u0631\\u062f\\u0627\\u062f\\\",\\n      \\\"body\\\": \\\"\\u067e\\u0633 \\u0627\\u0632 \\u062a\\u0648\\u0627\\u0641\\u0642 \\u0628\\u0631 \\u0633\\u0631 \\u0634\\u0631\\u0627\\u06cc\\u0637\\u060c \\u0642\\u0631\\u0627\\u0631\\u062f\\u0627\\u062f \\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u0631\\u0627 \\u0628\\u0647 \\u062f\\u0642\\u062a \\u0628\\u062e\\u0648\\u0627\\u0646\\u06cc\\u062f \\u0648 \\u0633\\u067e\\u0633 \\u0627\\u0645\\u0636\\u0627 \\u06a9\\u0646\\u06cc\\u062f. \\u062d\\u062a\\u0645\\u0627\\u064b \\u0628\\u0647 \\u0628\\u0646\\u062f\\u0647\\u0627\\u06cc \\u0645\\u0631\\u0628\\u0648\\u0637 \\u0628\\u0647 \\u0628\\u0627\\u0632\\u06af\\u0634\\u062a \\u06a9\\u0627\\u0644\\u0627 \\u0648 \\u062a\\u0639\\u0647\\u062f\\u0627\\u062a \\u0637\\u0631\\u0641\\u06cc\\u0646 \\u062a\\u0648\\u062c\\u0647 \\u06a9\\u0646\\u06cc\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u0627\\u0642\\u0633\\u0627\\u0637 \\u0628\\u0647 \\u0645\\u0648\\u0642\\u0639\\\",\\n      \\\"body\\\": \\\"\\u0628\\u0631\\u0646\\u0627\\u0645\\u0647 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u0627\\u0642\\u0633\\u0627\\u0637 \\u0631\\u0627 \\u062f\\u0631 \\u062a\\u0642\\u0648\\u06cc\\u0645 \\u062e\\u0648\\u062f \\u062b\\u0628\\u062a \\u06a9\\u0646\\u06cc\\u062f \\u0648 \\u0647\\u0631 \\u0642\\u0633\\u0637 \\u0631\\u0627 \\u062f\\u0631 \\u062a\\u0627\\u0631\\u06cc\\u062e \\u0645\\u0642\\u0631\\u0631 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u0646\\u0645\\u0627\\u06cc\\u06cc\\u062f \\u062a\\u0627 \\u0627\\u0632 \\u062c\\u0631\\u06cc\\u0645\\u0647 \\u062f\\u06cc\\u0631\\u06a9\\u0631\\u062f \\u062c\\u0644\\u0648\\u06af\\u06cc\\u0631\\u06cc \\u0634\\u0648\\u062f. \\u062f\\u0631 \\u0635\\u0648\\u0631\\u062a \\u0628\\u0631\\u0648\\u0632 \\u0645\\u0634\\u06a9\\u0644\\u060c \\u0633\\u0631\\u06cc\\u0639\\u0627\\u064b \\u0628\\u0627 \\u0641\\u0631\\u0648\\u0634\\u0646\\u062f\\u0647 \\u062a\\u0645\\u0627\\u0633 \\u0628\\u06af\\u06cc\\u0631\\u06cc\\u062f.\\\"\\n    }\\n  ]\\n}\"',NULL,'deepseek-local','2026-06-10 09:24:34','2026-06-10 08:56:02','2026-06-10 09:24:48'),(9,'procedure','steps','test job',NULL,3,'done','\"{\\n    \\\"title\\\": \\\"\\u0631\\u0627\\u0647\\u0646\\u0645\\u0627\\u06cc \\u0622\\u0632\\u0645\\u0648\\u0646 \\u0634\\u063a\\u0644\\u06cc\\\",\\n    \\\"excerpt\\\": \\\"\\u0627\\u06cc\\u0646 \\u0631\\u0627\\u0647\\u0646\\u0645\\u0627 \\u0634\\u0627\\u0645\\u0644 \\u0633\\u0647 \\u0645\\u0631\\u062d\\u0644\\u0647 \\u06a9\\u0644\\u06cc\\u062f\\u06cc \\u0628\\u0631\\u0627\\u06cc \\u0627\\u0646\\u062c\\u0627\\u0645 \\u0645\\u0648\\u0641\\u0642 \\u06cc\\u06a9 \\u0622\\u0632\\u0645\\u0648\\u0646 \\u0634\\u063a\\u0644\\u06cc \\u0627\\u0633\\u062a.\\\",\\n    \\\"steps\\\": [\\n        {\\n            \\\"title\\\": \\\"\\u0622\\u0645\\u0627\\u062f\\u0647\\u200c\\u0633\\u0627\\u0632\\u06cc \\u067e\\u06cc\\u0634 \\u0627\\u0632 \\u0622\\u0632\\u0645\\u0648\\u0646\\\",\\n            \\\"body\\\": \\\"\\u0627\\u0628\\u062a\\u062f\\u0627 \\u0628\\u0627 \\u0645\\u0637\\u0627\\u0644\\u0639\\u0647 \\u062f\\u0642\\u06cc\\u0642 \\u0634\\u0631\\u062d \\u0634\\u063a\\u0644 \\u0648 \\u0627\\u0644\\u0632\\u0627\\u0645\\u0627\\u062a \\u0622\\u0646\\u060c \\u0622\\u0645\\u0627\\u062f\\u0647 \\u0634\\u0648\\u06cc\\u062f. \\u0645\\u0646\\u0627\\u0628\\u0639 \\u0645\\u0631\\u062a\\u0628\\u0637 \\u0645\\u0627\\u0646\\u0646\\u062f \\u06a9\\u062a\\u0627\\u0628\\u200c\\u0647\\u0627\\u060c \\u0645\\u0642\\u0627\\u0644\\u0627\\u062a \\u0648 \\u062f\\u0648\\u0631\\u0647\\u200c\\u0647\\u0627\\u06cc \\u0622\\u0645\\u0648\\u0632\\u0634\\u06cc \\u0631\\u0627 \\u0645\\u0631\\u0648\\u0631 \\u06a9\\u0646\\u06cc\\u062f. \\u0647\\u0645\\u0686\\u0646\\u06cc\\u0646 \\u0627\\u0632 \\u0633\\u0644\\u0627\\u0645\\u062a \\u062c\\u0633\\u0645\\u06cc \\u0648 \\u0631\\u0648\\u062d\\u06cc \\u062e\\u0648\\u062f \\u0645\\u0637\\u0645\\u0626\\u0646 \\u0634\\u062f\\u0647 \\u0648 \\u0648\\u0633\\u0627\\u06cc\\u0644 \\u0645\\u0648\\u0631\\u062f \\u0646\\u06cc\\u0627\\u0632 \\u0645\\u0627\\u0646\\u0646\\u062f \\u0644\\u067e\\u200c\\u062a\\u0627\\u067e\\u060c \\u0627\\u06cc\\u0646\\u062a\\u0631\\u0646\\u062a \\u067e\\u0627\\u06cc\\u062f\\u0627\\u0631 \\u0648 \\u062f\\u0641\\u062a\\u0631\\u0686\\u0647 \\u06cc\\u0627\\u062f\\u062f\\u0627\\u0634\\u062a \\u0631\\u0627 \\u0641\\u0631\\u0627\\u0647\\u0645 \\u06a9\\u0646\\u06cc\\u062f.\\\"\\n        },\\n        {\\n            \\\"title\\\": \\\"\\u0627\\u062c\\u0631\\u0627\\u06cc \\u0622\\u0632\\u0645\\u0648\\u0646\\\",\\n            \\\"body\\\": \\\"\\u062f\\u0631 \\u0632\\u0645\\u0627\\u0646 \\u0645\\u0642\\u0631\\u0631\\u060c \\u0628\\u0627 \\u062a\\u0645\\u0631\\u06a9\\u0632 \\u0648 \\u0622\\u0631\\u0627\\u0645\\u0634 \\u0628\\u0647 \\u0633\\u0648\\u0627\\u0644\\u0627\\u062a \\u067e\\u0627\\u0633\\u062e \\u062f\\u0647\\u06cc\\u062f. \\u0627\\u0628\\u062a\\u062f\\u0627 \\u0633\\u0648\\u0627\\u0644\\u0627\\u062a \\u0622\\u0633\\u0627\\u0646 \\u0631\\u0627 \\u062d\\u0644 \\u06a9\\u0646\\u06cc\\u062f \\u062a\\u0627 \\u0627\\u0639\\u062a\\u0645\\u0627\\u062f \\u0628\\u0647 \\u0646\\u0641\\u0633 \\u06a9\\u0633\\u0628 \\u06a9\\u0646\\u06cc\\u062f. \\u0632\\u0645\\u0627\\u0646 \\u0631\\u0627 \\u0645\\u062f\\u06cc\\u0631\\u06cc\\u062a \\u06a9\\u0631\\u062f\\u0647 \\u0648 \\u0628\\u0631\\u0627\\u06cc \\u0633\\u0648\\u0627\\u0644\\u0627\\u062a \\u0633\\u062e\\u062a \\u0648\\u0642\\u062a \\u0628\\u06cc\\u0634 \\u0627\\u0632 \\u062d\\u062f \\u0635\\u0631\\u0641 \\u0646\\u06a9\\u0646\\u06cc\\u062f. \\u062f\\u0631 \\u0635\\u0648\\u0631\\u062a \\u0648\\u062c\\u0648\\u062f \\u0628\\u062e\\u0634 \\u0639\\u0645\\u0644\\u06cc\\u060c \\u062f\\u0642\\u06cc\\u0642 \\u0648 \\u0628\\u0627 \\u062f\\u0642\\u062a \\u0645\\u0631\\u0627\\u062d\\u0644 \\u0631\\u0627 \\u0627\\u0646\\u062c\\u0627\\u0645 \\u062f\\u0647\\u06cc\\u062f.\\\"\\n        },\\n        {\\n            \\\"title\\\": \\\"\\u0628\\u0631\\u0631\\u0633\\u06cc \\u0648 \\u0628\\u0627\\u0632\\u062e\\u0648\\u0631\\u062f\\\",\\n            \\\"body\\\": \\\"\\u067e\\u0633 \\u0627\\u0632 \\u067e\\u0627\\u06cc\\u0627\\u0646 \\u0622\\u0632\\u0645\\u0648\\u0646\\u060c \\u067e\\u0627\\u0633\\u062e\\u200c\\u0647\\u0627\\u06cc \\u062e\\u0648\\u062f \\u0631\\u0627 \\u0645\\u0631\\u0648\\u0631 \\u06a9\\u0646\\u06cc\\u062f \\u062a\\u0627 \\u0627\\u0632 \\u0635\\u062d\\u062a \\u0622\\u0646\\u0647\\u0627 \\u0627\\u0637\\u0645\\u06cc\\u0646\\u0627\\u0646 \\u06cc\\u0627\\u0628\\u06cc\\u062f. \\u062f\\u0631 \\u0635\\u0648\\u0631\\u062a \\u0627\\u0645\\u06a9\\u0627\\u0646\\u060c \\u0627\\u0632 \\u0622\\u0632\\u0645\\u0648\\u0646\\u200c\\u062f\\u0647\\u0646\\u062f\\u06af\\u0627\\u0646 \\u062f\\u06cc\\u06af\\u0631 \\u0628\\u0627\\u0632\\u062e\\u0648\\u0631\\u062f \\u0628\\u06af\\u06cc\\u0631\\u06cc\\u062f \\u0648 \\u0646\\u0642\\u0627\\u0637 \\u0636\\u0639\\u0641 \\u062e\\u0648\\u062f \\u0631\\u0627 \\u0634\\u0646\\u0627\\u0633\\u0627\\u06cc\\u06cc \\u06a9\\u0646\\u06cc\\u062f. \\u0646\\u062a\\u0627\\u06cc\\u062c \\u0631\\u0627 \\u062a\\u062d\\u0644\\u06cc\\u0644 \\u06a9\\u0631\\u062f\\u0647 \\u0648 \\u0628\\u0631\\u0627\\u06cc \\u0622\\u0632\\u0645\\u0648\\u0646\\u200c\\u0647\\u0627\\u06cc \\u0622\\u06cc\\u0646\\u062f\\u0647 \\u0628\\u0631\\u0646\\u0627\\u0645\\u0647\\u200c\\u0631\\u06cc\\u0632\\u06cc \\u06a9\\u0646\\u06cc\\u062f.\\\"\\n        }\\n    ]\\n}\"',NULL,'deepseek-local','2026-06-10 09:24:34','2026-06-10 09:20:30','2026-06-10 09:24:54'),(10,'procedure','steps','خرید قسطی کالا',NULL,5,'done','\"{\\n  \\\"title\\\": \\\"\\u0631\\u0627\\u0647\\u0646\\u0645\\u0627\\u06cc \\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u06a9\\u0627\\u0644\\u0627\\\",\\n  \\\"excerpt\\\": \\\"\\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u06a9\\u0627\\u0644\\u0627 \\u0631\\u0648\\u0634\\u06cc \\u0627\\u0633\\u062a \\u06a9\\u0647 \\u0628\\u0647 \\u0634\\u0645\\u0627 \\u0627\\u0645\\u06a9\\u0627\\u0646 \\u0645\\u06cc\\u200c\\u062f\\u0647\\u062f \\u06a9\\u0627\\u0644\\u0627\\u06cc \\u0645\\u0648\\u0631\\u062f \\u0646\\u0638\\u0631 \\u062e\\u0648\\u062f \\u0631\\u0627 \\u0628\\u062f\\u0648\\u0646 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u06cc\\u06a9\\u0628\\u0627\\u0631\\u0647 \\u0647\\u0632\\u06cc\\u0646\\u0647 \\u06a9\\u0627\\u0645\\u0644\\u060c \\u062f\\u0631 \\u0627\\u0642\\u0633\\u0627\\u0637 \\u0645\\u0627\\u0647\\u0627\\u0646\\u0647 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u06a9\\u0646\\u06cc\\u062f. \\u0627\\u06cc\\u0646 \\u0631\\u0627\\u0647\\u0646\\u0645\\u0627 \\u0645\\u0631\\u0627\\u062d\\u0644 \\u0627\\u0635\\u0644\\u06cc \\u0627\\u06cc\\u0646 \\u0641\\u0631\\u0622\\u06cc\\u0646\\u062f \\u0631\\u0627 \\u062a\\u0648\\u0636\\u06cc\\u062d \\u0645\\u06cc\\u200c\\u062f\\u0647\\u062f.\\\",\\n  \\\"steps\\\": [\\n    {\\n      \\\"title\\\": \\\"\\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u0641\\u0631\\u0648\\u0634\\u06af\\u0627\\u0647 \\u0648 \\u06a9\\u0627\\u0644\\u0627\\\",\\n      \\\"body\\\": \\\"\\u0627\\u0628\\u062a\\u062f\\u0627 \\u0641\\u0631\\u0648\\u0634\\u06af\\u0627\\u0647 \\u06cc\\u0627 \\u0641\\u0631\\u0648\\u0634\\u06af\\u0627\\u0647 \\u0622\\u0646\\u0644\\u0627\\u06cc\\u0646\\u06cc \\u0631\\u0627 \\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u06a9\\u0646\\u06cc\\u062f \\u06a9\\u0647 \\u0627\\u0645\\u06a9\\u0627\\u0646 \\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u0631\\u0627 \\u0641\\u0631\\u0627\\u0647\\u0645 \\u0645\\u06cc\\u200c\\u06a9\\u0646\\u062f. \\u0633\\u067e\\u0633 \\u06a9\\u0627\\u0644\\u0627\\u06cc \\u0645\\u0648\\u0631\\u062f \\u0646\\u0638\\u0631 \\u062e\\u0648\\u062f \\u0631\\u0627 \\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u06a9\\u0646\\u06cc\\u062f \\u0648 \\u0627\\u0632 \\u0634\\u0631\\u0627\\u06cc\\u0637 \\u0627\\u0642\\u0633\\u0627\\u0637 \\u0648 \\u0646\\u0631\\u062e \\u0628\\u0647\\u0631\\u0647 \\u0645\\u0637\\u0644\\u0639 \\u0634\\u0648\\u06cc\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u0628\\u0631\\u0631\\u0633\\u06cc \\u0634\\u0631\\u0627\\u06cc\\u0637 \\u0648 \\u0645\\u062f\\u0627\\u0631\\u06a9 \\u0645\\u0648\\u0631\\u062f \\u0646\\u06cc\\u0627\\u0632\\\",\\n      \\\"body\\\": \\\"\\u0634\\u0631\\u0627\\u06cc\\u0637 \\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u0645\\u0627\\u0646\\u0646\\u062f \\u062d\\u062f\\u0627\\u0642\\u0644 \\u0645\\u0628\\u0644\\u063a\\u060c \\u062a\\u0639\\u062f\\u0627\\u062f \\u0627\\u0642\\u0633\\u0627\\u0637 \\u0648 \\u0646\\u0631\\u062e \\u0633\\u0648\\u062f \\u0631\\u0627 \\u0628\\u0631\\u0631\\u0633\\u06cc \\u06a9\\u0646\\u06cc\\u062f. \\u0645\\u0639\\u0645\\u0648\\u0644\\u0627\\u064b \\u0646\\u06cc\\u0627\\u0632 \\u0628\\u0647 \\u0645\\u062f\\u0627\\u0631\\u06a9\\u06cc \\u0645\\u0627\\u0646\\u0646\\u062f \\u06a9\\u0627\\u0631\\u062a \\u0645\\u0644\\u06cc\\u060c \\u0634\\u0646\\u0627\\u0633\\u0646\\u0627\\u0645\\u0647 \\u0648 \\u0627\\u062b\\u0628\\u0627\\u062a \\u062f\\u0631\\u0622\\u0645\\u062f \\u062f\\u0627\\u0631\\u06cc\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u062b\\u0628\\u062a \\u062f\\u0631\\u062e\\u0648\\u0627\\u0633\\u062a \\u0648 \\u062a\\u06a9\\u0645\\u06cc\\u0644 \\u0641\\u0631\\u0645\\\",\\n      \\\"body\\\": \\\"\\u0641\\u0631\\u0645 \\u062f\\u0631\\u062e\\u0648\\u0627\\u0633\\u062a \\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u0631\\u0627 \\u067e\\u0631 \\u06a9\\u0646\\u06cc\\u062f. \\u0627\\u0637\\u0644\\u0627\\u0639\\u0627\\u062a \\u0634\\u062e\\u0635\\u06cc\\u060c \\u0634\\u063a\\u0644\\u06cc \\u0648 \\u0645\\u0627\\u0644\\u06cc \\u062e\\u0648\\u062f \\u0631\\u0627 \\u062f\\u0642\\u06cc\\u0642 \\u0648\\u0627\\u0631\\u062f \\u06a9\\u0646\\u06cc\\u062f \\u0648 \\u0645\\u062f\\u0627\\u0631\\u06a9 \\u0645\\u0648\\u0631\\u062f \\u0646\\u06cc\\u0627\\u0632 \\u0631\\u0627 \\u0628\\u0627\\u0631\\u06af\\u0630\\u0627\\u0631\\u06cc \\u06cc\\u0627 \\u0627\\u0631\\u0627\\u0626\\u0647 \\u062f\\u0647\\u06cc\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u0627\\u0646\\u062a\\u0638\\u0627\\u0631 \\u0628\\u0631\\u0627\\u06cc \\u062a\\u0623\\u06cc\\u06cc\\u062f \\u0627\\u0639\\u062a\\u0628\\u0627\\u0631\\\",\\n      \\\"body\\\": \\\"\\u067e\\u0633 \\u0627\\u0632 \\u062b\\u0628\\u062a \\u062f\\u0631\\u062e\\u0648\\u0627\\u0633\\u062a\\u060c \\u0641\\u0631\\u0648\\u0634\\u06af\\u0627\\u0647 \\u06cc\\u0627 \\u0628\\u0627\\u0646\\u06a9 (\\u062f\\u0631 \\u0635\\u0648\\u0631\\u062a \\u0627\\u0633\\u062a\\u0641\\u0627\\u062f\\u0647 \\u0627\\u0632 \\u062a\\u0633\\u0647\\u06cc\\u0644\\u0627\\u062a \\u0628\\u0627\\u0646\\u06a9\\u06cc) \\u0627\\u0639\\u062a\\u0628\\u0627\\u0631 \\u0634\\u0645\\u0627 \\u0631\\u0627 \\u0628\\u0631\\u0631\\u0633\\u06cc \\u0645\\u06cc\\u200c\\u06a9\\u0646\\u062f. \\u0627\\u06cc\\u0646 \\u0645\\u0631\\u062d\\u0644\\u0647 \\u0645\\u0645\\u06a9\\u0646 \\u0627\\u0633\\u062a \\u0686\\u0646\\u062f \\u0633\\u0627\\u0639\\u062a \\u062a\\u0627 \\u0686\\u0646\\u062f \\u0631\\u0648\\u0632 \\u0637\\u0648\\u0644 \\u0628\\u06a9\\u0634\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u0627\\u0646\\u0639\\u0642\\u0627\\u062f \\u0642\\u0631\\u0627\\u0631\\u062f\\u0627\\u062f \\u0648 \\u062f\\u0631\\u06cc\\u0627\\u0641\\u062a \\u06a9\\u0627\\u0644\\u0627\\\",\\n      \\\"body\\\": \\\"\\u067e\\u0633 \\u0627\\u0632 \\u062a\\u0623\\u06cc\\u06cc\\u062f \\u0627\\u0639\\u062a\\u0628\\u0627\\u0631\\u060c \\u0642\\u0631\\u0627\\u0631\\u062f\\u0627\\u062f \\u0627\\u0642\\u0633\\u0627\\u0637 \\u0631\\u0627 \\u0628\\u0647 \\u062f\\u0642\\u062a \\u0645\\u0637\\u0627\\u0644\\u0639\\u0647 \\u0648 \\u0627\\u0645\\u0636\\u0627 \\u06a9\\u0646\\u06cc\\u062f. \\u0633\\u067e\\u0633 \\u06a9\\u0627\\u0644\\u0627 \\u0631\\u0627 \\u062a\\u062d\\u0648\\u06cc\\u0644 \\u0628\\u06af\\u06cc\\u0631\\u06cc\\u062f \\u0648 \\u0645\\u0637\\u0627\\u0628\\u0642 \\u0628\\u0631\\u0646\\u0627\\u0645\\u0647 \\u0627\\u0642\\u0633\\u0627\\u0637\\u060c \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a\\u200c\\u0647\\u0627\\u06cc \\u0645\\u0627\\u0647\\u0627\\u0646\\u0647 \\u0631\\u0627 \\u0627\\u0646\\u062c\\u0627\\u0645 \\u062f\\u0647\\u06cc\\u062f.\\\"\\n    }\\n  ]\\n}\"',NULL,'deepseek-local','2026-06-10 09:39:58','2026-06-10 09:21:44','2026-06-10 09:40:04'),(11,'procedure','steps','خرید قسطی کالا',NULL,5,'done','\"{\\n  \\\"title\\\": \\\"\\u0631\\u0627\\u0647\\u0646\\u0645\\u0627\\u06cc \\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u06a9\\u0627\\u0644\\u0627\\\",\\n  \\\"excerpt\\\": \\\"\\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u06cc\\u06a9\\u06cc \\u0627\\u0632 \\u0631\\u0648\\u0634\\u200c\\u0647\\u0627\\u06cc \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u0627\\u0633\\u062a \\u06a9\\u0647 \\u0628\\u0647 \\u0634\\u0645\\u0627 \\u0627\\u0645\\u06a9\\u0627\\u0646 \\u0645\\u06cc\\u200c\\u062f\\u0647\\u062f \\u06a9\\u0627\\u0644\\u0627 \\u0631\\u0627 \\u0628\\u0647 \\u0635\\u0648\\u0631\\u062a \\u0627\\u0642\\u0633\\u0627\\u0637 \\u0645\\u0627\\u0647\\u0627\\u0646\\u0647 \\u062a\\u0647\\u06cc\\u0647 \\u06a9\\u0646\\u06cc\\u062f. \\u0627\\u06cc\\u0646 \\u0631\\u0627\\u0647\\u0646\\u0645\\u0627 \\u0634\\u0627\\u0645\\u0644 \\u06f5 \\u0645\\u0631\\u062d\\u0644\\u0647 \\u0628\\u0631\\u0627\\u06cc \\u0627\\u0646\\u062c\\u0627\\u0645 \\u0627\\u06cc\\u0646 \\u06a9\\u0627\\u0631 \\u0627\\u0633\\u062a.\\\",\\n  \\\"steps\\\": [\\n    {\\n      \\\"title\\\": \\\"\\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u0641\\u0631\\u0648\\u0634\\u06af\\u0627\\u0647 \\u06cc\\u0627 \\u0648\\u0628\\u200c\\u0633\\u0627\\u06cc\\u062a \\u0645\\u0639\\u062a\\u0628\\u0631\\\",\\n      \\\"body\\\": \\\"\\u0627\\u0628\\u062a\\u062f\\u0627 \\u0641\\u0631\\u0648\\u0634\\u06af\\u0627\\u0647\\u06cc \\u0631\\u0627 \\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u06a9\\u0646\\u06cc\\u062f \\u06a9\\u0647 \\u062e\\u062f\\u0645\\u0627\\u062a \\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u0627\\u0631\\u0627\\u0626\\u0647 \\u0645\\u06cc\\u200c\\u062f\\u0647\\u062f. \\u0645\\u0637\\u0645\\u0626\\u0646 \\u0634\\u0648\\u06cc\\u062f \\u0641\\u0631\\u0648\\u0634\\u06af\\u0627\\u0647 \\u0645\\u0639\\u062a\\u0628\\u0631 \\u0627\\u0633\\u062a \\u0648 \\u0634\\u0631\\u0627\\u06cc\\u0637 \\u0627\\u0642\\u0633\\u0627\\u0637 \\u0631\\u0627 \\u0628\\u0647 \\u0648\\u0636\\u0648\\u062d \\u0627\\u0639\\u0644\\u0627\\u0645 \\u06a9\\u0631\\u062f\\u0647 \\u0627\\u0633\\u062a.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u0628\\u0631\\u0631\\u0633\\u06cc \\u0634\\u0631\\u0627\\u06cc\\u0637 \\u0648 \\u0636\\u0648\\u0627\\u0628\\u0637 \\u0627\\u0642\\u0633\\u0627\\u0637\\\",\\n      \\\"body\\\": \\\"\\u0642\\u0628\\u0644 \\u0627\\u0632 \\u0647\\u0631 \\u0627\\u0642\\u062f\\u0627\\u0645\\u06cc\\u060c \\u0634\\u0631\\u0627\\u06cc\\u0637 \\u0627\\u0642\\u0633\\u0627\\u0637 \\u0645\\u0627\\u0646\\u0646\\u062f \\u0646\\u0631\\u062e \\u0633\\u0648\\u062f\\u060c \\u0645\\u062f\\u062a \\u0632\\u0645\\u0627\\u0646 \\u0628\\u0627\\u0632\\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u0648 \\u0645\\u0628\\u0644\\u063a \\u067e\\u06cc\\u0634\\u200c\\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u0631\\u0627 \\u0645\\u0637\\u0627\\u0644\\u0639\\u0647 \\u06a9\\u0646\\u06cc\\u062f. \\u0627\\u0637\\u0645\\u06cc\\u0646\\u0627\\u0646 \\u062d\\u0627\\u0635\\u0644 \\u06a9\\u0646\\u06cc\\u062f \\u06a9\\u0647 \\u0628\\u0627 \\u062a\\u0648\\u0627\\u0646 \\u0645\\u0627\\u0644\\u06cc \\u0634\\u0645\\u0627 \\u0633\\u0627\\u0632\\u06af\\u0627\\u0631 \\u0627\\u0633\\u062a.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u06a9\\u0627\\u0644\\u0627 \\u0648 \\u062b\\u0628\\u062a \\u0633\\u0641\\u0627\\u0631\\u0634\\\",\\n      \\\"body\\\": \\\"\\u06a9\\u0627\\u0644\\u0627\\u06cc \\u0645\\u0648\\u0631\\u062f \\u0646\\u0638\\u0631 \\u062e\\u0648\\u062f \\u0631\\u0627 \\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u06a9\\u0646\\u06cc\\u062f \\u0648 \\u0622\\u0646 \\u0631\\u0627 \\u0628\\u0647 \\u0633\\u0628\\u062f \\u062e\\u0631\\u06cc\\u062f \\u0627\\u0636\\u0627\\u0641\\u0647 \\u06a9\\u0646\\u06cc\\u062f. \\u062f\\u0631 \\u0645\\u0631\\u062d\\u0644\\u0647 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a\\u060c \\u06af\\u0632\\u06cc\\u0646\\u0647 \\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u0631\\u0627 \\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u06a9\\u0631\\u062f\\u0647 \\u0648 \\u0627\\u0637\\u0644\\u0627\\u0639\\u0627\\u062a \\u0645\\u0648\\u0631\\u062f \\u0646\\u06cc\\u0627\\u0632 \\u0631\\u0627 \\u0648\\u0627\\u0631\\u062f \\u06a9\\u0646\\u06cc\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u062a\\u06a9\\u0645\\u06cc\\u0644 \\u0645\\u062f\\u0627\\u0631\\u06a9 \\u0648 \\u062a\\u0623\\u06cc\\u06cc\\u062f \\u0627\\u0639\\u062a\\u0628\\u0627\\u0631\\\",\\n      \\\"body\\\": \\\"\\u0628\\u0631\\u0627\\u06cc \\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u0646\\u06cc\\u0627\\u0632 \\u0628\\u0647 \\u0627\\u0631\\u0627\\u0626\\u0647 \\u0645\\u062f\\u0627\\u0631\\u06a9 \\u0647\\u0648\\u06cc\\u062a\\u06cc \\u0648 \\u0627\\u062b\\u0628\\u0627\\u062a \\u062f\\u0631\\u0622\\u0645\\u062f \\u062f\\u0627\\u0631\\u06cc\\u062f. \\u0645\\u062f\\u0627\\u0631\\u06a9 \\u062e\\u0648\\u062f \\u0631\\u0627 \\u0622\\u067e\\u0644\\u0648\\u062f \\u06a9\\u0631\\u062f\\u0647 \\u0648 \\u0645\\u0646\\u062a\\u0638\\u0631 \\u062a\\u0623\\u06cc\\u06cc\\u062f \\u0627\\u0639\\u062a\\u0628\\u0627\\u0631 \\u0627\\u0632 \\u0633\\u0648\\u06cc \\u0641\\u0631\\u0648\\u0634\\u06af\\u0627\\u0647 \\u06cc\\u0627 \\u0628\\u0627\\u0646\\u06a9 \\u0628\\u0627\\u0634\\u06cc\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u0627\\u0642\\u0633\\u0627\\u0637 \\u0648 \\u062a\\u062d\\u0648\\u06cc\\u0644 \\u06a9\\u0627\\u0644\\u0627\\\",\\n      \\\"body\\\": \\\"\\u067e\\u0633 \\u0627\\u0632 \\u062a\\u0623\\u06cc\\u06cc\\u062f\\u060c \\u0642\\u0631\\u0627\\u0631\\u062f\\u0627\\u062f \\u0627\\u0642\\u0633\\u0627\\u0637 \\u0631\\u0627 \\u0627\\u0645\\u0636\\u0627 \\u06a9\\u0646\\u06cc\\u062f. \\u0627\\u0648\\u0644\\u06cc\\u0646 \\u0642\\u0633\\u0637 \\u0631\\u0627 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u06a9\\u0631\\u062f\\u0647 \\u0648 \\u06a9\\u0627\\u0644\\u0627 \\u0631\\u0627 \\u062a\\u062d\\u0648\\u06cc\\u0644 \\u0628\\u06af\\u06cc\\u0631\\u06cc\\u062f. \\u0627\\u0642\\u0633\\u0627\\u0637 \\u0628\\u0639\\u062f\\u06cc \\u0631\\u0627 \\u062f\\u0631 \\u0645\\u0648\\u0639\\u062f \\u0645\\u0642\\u0631\\u0631 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u06a9\\u0646\\u06cc\\u062f \\u062a\\u0627 \\u0627\\u0632 \\u062c\\u0631\\u06cc\\u0645\\u0647 \\u062f\\u06cc\\u0631\\u06a9\\u0631\\u062f \\u062c\\u0644\\u0648\\u06af\\u06cc\\u0631\\u06cc \\u0634\\u0648\\u062f.\\\"\\n    }\\n  ]\\n}\"',NULL,'deepseek-local','2026-06-10 09:39:58','2026-06-10 09:32:00','2026-06-10 09:40:10'),(12,'procedure','steps','خرید قسطی کالا',NULL,5,'done','\"{\\n  \\\"title\\\": \\\"\\u0631\\u0627\\u0647\\u0646\\u0645\\u0627\\u06cc \\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u06a9\\u0627\\u0644\\u0627\\\",\\n  \\\"excerpt\\\": \\\"\\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u0628\\u0647 \\u0634\\u0645\\u0627 \\u0627\\u0645\\u06a9\\u0627\\u0646 \\u0645\\u06cc\\u200c\\u062f\\u0647\\u062f \\u06a9\\u0627\\u0644\\u0627\\u0647\\u0627\\u06cc \\u0645\\u0648\\u0631\\u062f \\u0646\\u06cc\\u0627\\u0632 \\u062e\\u0648\\u062f \\u0631\\u0627 \\u0628\\u0647 \\u0635\\u0648\\u0631\\u062a \\u0627\\u0642\\u0633\\u0627\\u0637\\u06cc \\u062a\\u0647\\u06cc\\u0647 \\u06a9\\u0646\\u06cc\\u062f. \\u0627\\u06cc\\u0646 \\u0631\\u0627\\u0647\\u0646\\u0645\\u0627 \\u0634\\u0627\\u0645\\u0644 \\u06f5 \\u0645\\u0631\\u062d\\u0644\\u0647 \\u0633\\u0627\\u062f\\u0647 \\u0628\\u0631\\u0627\\u06cc \\u0627\\u0646\\u062c\\u0627\\u0645 \\u0627\\u06cc\\u0646 \\u0641\\u0631\\u0622\\u06cc\\u0646\\u062f \\u0627\\u0633\\u062a.\\\",\\n  \\\"steps\\\": [\\n    {\\n      \\\"title\\\": \\\"\\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u06a9\\u0627\\u0644\\u0627 \\u0648 \\u0641\\u0631\\u0648\\u0634\\u0646\\u062f\\u0647 \\u0645\\u0639\\u062a\\u0628\\u0631\\\",\\n      \\\"body\\\": \\\"\\u0627\\u0628\\u062a\\u062f\\u0627 \\u06a9\\u0627\\u0644\\u0627\\u06cc \\u0645\\u0648\\u0631\\u062f \\u0646\\u0638\\u0631 \\u062e\\u0648\\u062f \\u0631\\u0627 \\u0627\\u0632 \\u0641\\u0631\\u0648\\u0634\\u06af\\u0627\\u0647\\u200c\\u0647\\u0627\\u06cc \\u0645\\u0639\\u062a\\u0628\\u0631 \\u06a9\\u0647 \\u0637\\u0631\\u062d\\u200c\\u0647\\u0627\\u06cc \\u0641\\u0631\\u0648\\u0634 \\u0627\\u0642\\u0633\\u0627\\u0637\\u06cc \\u062f\\u0627\\u0631\\u0646\\u062f \\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u06a9\\u0646\\u06cc\\u062f. \\u0645\\u0637\\u0645\\u0626\\u0646 \\u0634\\u0648\\u06cc\\u062f \\u0641\\u0631\\u0648\\u0634\\u0646\\u062f\\u0647 \\u062f\\u0627\\u0631\\u0627\\u06cc \\u0645\\u062c\\u0648\\u0632\\u0647\\u0627\\u06cc \\u0644\\u0627\\u0632\\u0645 \\u0627\\u0633\\u062a \\u0648 \\u0634\\u0631\\u0627\\u06cc\\u0637 \\u0627\\u0642\\u0633\\u0627\\u0637\\u06cc \\u0631\\u0627 \\u0628\\u0647 \\u0635\\u0648\\u0631\\u062a \\u0634\\u0641\\u0627\\u0641 \\u0627\\u0639\\u0644\\u0627\\u0645 \\u06a9\\u0631\\u062f\\u0647 \\u0627\\u0633\\u062a.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u0628\\u0631\\u0631\\u0633\\u06cc \\u0634\\u0631\\u0627\\u06cc\\u0637 \\u0627\\u0642\\u0633\\u0627\\u0637\\\",\\n      \\\"body\\\": \\\"\\u067e\\u06cc\\u0634 \\u0627\\u0632 \\u0627\\u0642\\u062f\\u0627\\u0645 \\u0628\\u0647 \\u062e\\u0631\\u06cc\\u062f\\u060c \\u0634\\u0631\\u0627\\u06cc\\u0637 \\u0627\\u0642\\u0633\\u0627\\u0637 \\u0645\\u0627\\u0646\\u0646\\u062f \\u0646\\u0631\\u062e \\u0633\\u0648\\u062f\\u060c \\u062a\\u0639\\u062f\\u0627\\u062f \\u0627\\u0642\\u0633\\u0627\\u0637\\u060c \\u0645\\u0628\\u0644\\u063a \\u0647\\u0631 \\u0642\\u0633\\u0637 \\u0648 \\u0647\\u0632\\u06cc\\u0646\\u0647\\u200c\\u0647\\u0627\\u06cc \\u062c\\u0627\\u0646\\u0628\\u06cc (\\u0645\\u0627\\u0646\\u0646\\u062f \\u0628\\u06cc\\u0645\\u0647 \\u06cc\\u0627 \\u06a9\\u0627\\u0631\\u0645\\u0632\\u062f) \\u0631\\u0627 \\u0628\\u0647 \\u062f\\u0642\\u062a \\u0628\\u0631\\u0631\\u0633\\u06cc \\u06a9\\u0646\\u06cc\\u062f. \\u0627\\u0637\\u0645\\u06cc\\u0646\\u0627\\u0646 \\u062d\\u0627\\u0635\\u0644 \\u06a9\\u0646\\u06cc\\u062f \\u06a9\\u0647 \\u0634\\u0631\\u0627\\u06cc\\u0637 \\u0628\\u0627 \\u0628\\u0648\\u062f\\u062c\\u0647 \\u0634\\u0645\\u0627 \\u0633\\u0627\\u0632\\u06af\\u0627\\u0631 \\u0627\\u0633\\u062a.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u062a\\u06a9\\u0645\\u06cc\\u0644 \\u0627\\u0637\\u0644\\u0627\\u0639\\u0627\\u062a \\u0648 \\u0645\\u062f\\u0627\\u0631\\u06a9 \\u0645\\u0648\\u0631\\u062f \\u0646\\u06cc\\u0627\\u0632\\\",\\n      \\\"body\\\": \\\"\\u0628\\u0631\\u0627\\u06cc \\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u0645\\u0639\\u0645\\u0648\\u0644\\u0627\\u064b \\u0646\\u06cc\\u0627\\u0632 \\u0628\\u0647 \\u0627\\u0631\\u0627\\u0626\\u0647 \\u0645\\u062f\\u0627\\u0631\\u06a9 \\u0634\\u0646\\u0627\\u0633\\u0627\\u06cc\\u06cc (\\u0645\\u0627\\u0646\\u0646\\u062f \\u06a9\\u0627\\u0631\\u062a \\u0645\\u0644\\u06cc)\\u060c \\u0645\\u062f\\u0631\\u06a9 \\u0634\\u063a\\u0644 \\u0648 \\u062f\\u0631\\u0622\\u0645\\u062f\\u060c \\u0648 \\u06af\\u0627\\u0647\\u06cc \\u0636\\u0627\\u0645\\u0646 \\u0648\\u062c\\u0648\\u062f \\u062f\\u0627\\u0631\\u062f. \\u0641\\u0631\\u0645 \\u062f\\u0631\\u062e\\u0648\\u0627\\u0633\\u062a \\u0631\\u0627 \\u0628\\u0627 \\u062f\\u0642\\u062a \\u067e\\u0631 \\u06a9\\u0646\\u06cc\\u062f \\u0648 \\u0645\\u062f\\u0627\\u0631\\u06a9 \\u0631\\u0627 \\u0628\\u0647 \\u0635\\u0648\\u0631\\u062a \\u06a9\\u0627\\u0645\\u0644 \\u062a\\u062d\\u0648\\u06cc\\u0644 \\u062f\\u0647\\u06cc\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u0627\\u0645\\u0636\\u0627\\u06cc \\u0642\\u0631\\u0627\\u0631\\u062f\\u0627\\u062f \\u0648 \\u062a\\u0639\\u0647\\u062f\\u0627\\u062a\\\",\\n      \\\"body\\\": \\\"\\u067e\\u0633 \\u0627\\u0632 \\u062a\\u0627\\u06cc\\u06cc\\u062f \\u0627\\u0639\\u062a\\u0628\\u0627\\u0631 \\u0634\\u0645\\u0627\\u060c \\u0642\\u0631\\u0627\\u0631\\u062f\\u0627\\u062f \\u0641\\u0631\\u0648\\u0634 \\u0627\\u0642\\u0633\\u0627\\u0637\\u06cc \\u062a\\u0646\\u0638\\u06cc\\u0645 \\u0645\\u06cc\\u200c\\u0634\\u0648\\u062f. \\u0642\\u0631\\u0627\\u0631\\u062f\\u0627\\u062f \\u0631\\u0627 \\u0628\\u0647 \\u062f\\u0642\\u062a \\u0645\\u0637\\u0627\\u0644\\u0639\\u0647 \\u06a9\\u0646\\u06cc\\u062f \\u0648 \\u062a\\u0645\\u0627\\u0645 \\u0628\\u0646\\u062f\\u0647\\u0627 \\u0627\\u0632 \\u062c\\u0645\\u0644\\u0647 \\u062a\\u0639\\u0647\\u062f\\u0627\\u062a\\u060c \\u0632\\u0645\\u0627\\u0646\\u200c\\u0628\\u0646\\u062f\\u06cc \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a\\u200c\\u0647\\u0627 \\u0648 \\u062c\\u0631\\u06cc\\u0645\\u0647 \\u062f\\u06cc\\u0631\\u06a9\\u0631\\u062f \\u0631\\u0627 \\u0628\\u0631\\u0631\\u0633\\u06cc \\u0646\\u0645\\u0627\\u06cc\\u06cc\\u062f. \\u0633\\u067e\\u0633 \\u0642\\u0631\\u0627\\u0631\\u062f\\u0627\\u062f \\u0631\\u0627 \\u0627\\u0645\\u0636\\u0627 \\u06a9\\u0646\\u06cc\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u0627\\u0642\\u0633\\u0627\\u0637 \\u0648 \\u062a\\u062d\\u0648\\u06cc\\u0644 \\u06a9\\u0627\\u0644\\u0627\\\",\\n      \\\"body\\\": \\\"\\u067e\\u0633 \\u0627\\u0632 \\u0627\\u0645\\u0636\\u0627\\u06cc \\u0642\\u0631\\u0627\\u0631\\u062f\\u0627\\u062f \\u0648 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u067e\\u06cc\\u0634 \\u0642\\u0633\\u0637 (\\u062f\\u0631 \\u0635\\u0648\\u0631\\u062a \\u0648\\u062c\\u0648\\u062f)\\u060c \\u06a9\\u0627\\u0644\\u0627 \\u062a\\u062d\\u0648\\u06cc\\u0644 \\u062f\\u0627\\u062f\\u0647 \\u0645\\u06cc\\u200c\\u0634\\u0648\\u062f. \\u0633\\u067e\\u0633 \\u0628\\u0627\\u06cc\\u062f \\u0637\\u0628\\u0642 \\u062c\\u062f\\u0648\\u0644 \\u0632\\u0645\\u0627\\u0646\\u200c\\u0628\\u0646\\u062f\\u06cc\\u060c \\u0627\\u0642\\u0633\\u0627\\u0637 \\u0631\\u0627 \\u0628\\u0647 \\u0645\\u0648\\u0642\\u0639 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u06a9\\u0646\\u06cc\\u062f. \\u067e\\u0633 \\u0627\\u0632 \\u067e\\u0627\\u06cc\\u0627\\u0646 \\u0627\\u0642\\u0633\\u0627\\u0637\\u060c \\u0645\\u0627\\u0644\\u06a9\\u06cc\\u062a \\u06a9\\u0627\\u0645\\u0644 \\u06a9\\u0627\\u0644\\u0627 \\u0628\\u0647 \\u0634\\u0645\\u0627 \\u0645\\u0646\\u062a\\u0642\\u0644 \\u0645\\u06cc\\u200c\\u0634\\u0648\\u062f.\\\"\\n    }\\n  ]\\n}\"',NULL,'deepseek-local','2026-06-10 09:39:58','2026-06-10 09:34:23','2026-06-10 09:40:17'),(13,'procedure','steps','نحوه خرید قسطی کالا',NULL,3,'done','\"{\\n\\\"title\\\": \\\"\\u0646\\u062d\\u0648\\u0647 \\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u06a9\\u0627\\u0644\\u0627\\\",\\n\\\"excerpt\\\": \\\"\\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u06a9\\u0627\\u0644\\u0627 \\u0631\\u0648\\u0634\\u06cc \\u0645\\u0646\\u0627\\u0633\\u0628 \\u0628\\u0631\\u0627\\u06cc \\u0627\\u0641\\u0631\\u0627\\u062f\\u06cc \\u0627\\u0633\\u062a \\u06a9\\u0647 \\u062a\\u0648\\u0627\\u0646 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u06cc\\u06a9\\u0628\\u0627\\u0631\\u0647 \\u0642\\u06cc\\u0645\\u062a \\u06a9\\u0627\\u0644\\u0627 \\u0631\\u0627 \\u0646\\u062f\\u0627\\u0631\\u0646\\u062f. \\u062f\\u0631 \\u0627\\u06cc\\u0646 \\u0631\\u0627\\u0647\\u0646\\u0645\\u0627 \\u0645\\u0631\\u0627\\u062d\\u0644 \\u062e\\u0631\\u06cc\\u062f \\u0642\\u0633\\u0637\\u06cc \\u062a\\u0648\\u0636\\u06cc\\u062d \\u062f\\u0627\\u062f\\u0647 \\u0634\\u062f\\u0647 \\u0627\\u0633\\u062a.\\\",\\n\\\"steps\\\": [\\n{\\n\\\"title\\\": \\\"\\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u06a9\\u0627\\u0644\\u0627 \\u0648 \\u0641\\u0631\\u0648\\u0634\\u06af\\u0627\\u0647 \\u0645\\u0639\\u062a\\u0628\\u0631\\\",\\n\\\"body\\\": \\\"\\u0627\\u0628\\u062a\\u062f\\u0627 \\u06a9\\u0627\\u0644\\u0627\\u06cc \\u0645\\u0648\\u0631\\u062f \\u0646\\u0638\\u0631 \\u062e\\u0648\\u062f \\u0631\\u0627 \\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u06a9\\u0646\\u06cc\\u062f \\u0648 \\u0627\\u0632 \\u0641\\u0631\\u0648\\u0634\\u06af\\u0627\\u0647\\u200c\\u0647\\u0627\\u06cc\\u06cc \\u06a9\\u0647 \\u0637\\u0631\\u062d \\u0641\\u0631\\u0648\\u0634 \\u0627\\u0642\\u0633\\u0627\\u0637\\u06cc \\u0627\\u0631\\u0627\\u0626\\u0647 \\u0645\\u06cc\\u200c\\u062f\\u0647\\u0646\\u062f\\u060c \\u062e\\u0631\\u06cc\\u062f \\u06a9\\u0646\\u06cc\\u062f. \\u0645\\u0639\\u0645\\u0648\\u0644\\u0627\\u064b \\u0641\\u0631\\u0648\\u0634\\u06af\\u0627\\u0647\\u200c\\u0647\\u0627\\u06cc \\u0628\\u0632\\u0631\\u06af \\u0648 \\u0622\\u0646\\u0644\\u0627\\u06cc\\u0646 \\u0645\\u0639\\u062a\\u0628\\u0631 \\u0627\\u06cc\\u0646 \\u0627\\u0645\\u06a9\\u0627\\u0646 \\u0631\\u0627 \\u0641\\u0631\\u0627\\u0647\\u0645 \\u0645\\u06cc\\u200c\\u06a9\\u0646\\u0646\\u062f. \\u062a\\u0648\\u062c\\u0647 \\u062f\\u0627\\u0634\\u062a\\u0647 \\u0628\\u0627\\u0634\\u06cc\\u062f \\u06a9\\u0647 \\u0641\\u0631\\u0648\\u0634\\u06af\\u0627\\u0647 \\u0628\\u0627\\u06cc\\u062f \\u0645\\u062c\\u0648\\u0632\\u0647\\u0627\\u06cc \\u0644\\u0627\\u0632\\u0645 \\u0631\\u0627 \\u062f\\u0627\\u0634\\u062a\\u0647 \\u0628\\u0627\\u0634\\u062f.\\\"\\n},\\n{\\n\\\"title\\\": \\\"\\u0628\\u0631\\u0631\\u0633\\u06cc \\u0634\\u0631\\u0627\\u06cc\\u0637 \\u0648 \\u0645\\u062f\\u0627\\u0631\\u06a9 \\u0645\\u0648\\u0631\\u062f \\u0646\\u06cc\\u0627\\u0632\\\",\\n\\\"body\\\": \\\"\\u067e\\u0633 \\u0627\\u0632 \\u0627\\u0646\\u062a\\u062e\\u0627\\u0628 \\u06a9\\u0627\\u0644\\u0627\\u060c \\u0634\\u0631\\u0627\\u06cc\\u0637 \\u0627\\u0642\\u0633\\u0627\\u0637 \\u0631\\u0627 \\u0628\\u0631\\u0631\\u0633\\u06cc \\u06a9\\u0646\\u06cc\\u062f. \\u0645\\u0639\\u0645\\u0648\\u0644\\u0627\\u064b \\u0641\\u0631\\u0648\\u0634\\u06af\\u0627\\u0647\\u200c\\u0647\\u0627 \\u0646\\u06cc\\u0627\\u0632 \\u0628\\u0647 \\u0627\\u0631\\u0627\\u0626\\u0647 \\u0645\\u062f\\u0627\\u0631\\u06a9 \\u0634\\u0646\\u0627\\u0633\\u0627\\u06cc\\u06cc\\u060c \\u0627\\u062b\\u0628\\u0627\\u062a \\u062f\\u0631\\u0622\\u0645\\u062f \\u0648 \\u06af\\u0648\\u0627\\u0647\\u06cc \\u0628\\u0627\\u0646\\u06a9\\u06cc \\u062f\\u0627\\u0631\\u0646\\u062f. \\u0647\\u0645\\u0686\\u0646\\u06cc\\u0646 \\u0627\\u0632 \\u0646\\u0631\\u062e \\u0628\\u0647\\u0631\\u0647\\u060c \\u062a\\u0639\\u062f\\u0627\\u062f \\u0627\\u0642\\u0633\\u0627\\u0637 \\u0648 \\u0645\\u0628\\u0644\\u063a \\u0647\\u0631 \\u0642\\u0633\\u0637 \\u0645\\u0637\\u0645\\u0626\\u0646 \\u0634\\u0648\\u06cc\\u062f. \\u0628\\u0631\\u062e\\u06cc \\u0641\\u0631\\u0648\\u0634\\u06af\\u0627\\u0647\\u200c\\u0647\\u0627 \\u0628\\u0627 \\u0647\\u0645\\u06a9\\u0627\\u0631\\u06cc \\u0628\\u0627\\u0646\\u06a9\\u200c\\u0647\\u0627 \\u0648 \\u0634\\u0631\\u06a9\\u062a\\u200c\\u0647\\u0627\\u06cc \\u0627\\u0639\\u062a\\u0628\\u0627\\u0631\\u06cc \\u0627\\u06cc\\u0646 \\u0637\\u0631\\u062d \\u0631\\u0627 \\u0627\\u062c\\u0631\\u0627 \\u0645\\u06cc\\u200c\\u06a9\\u0646\\u0646\\u062f.\\\"\\n},\\n{\\n\\\"title\\\": \\\"\\u062a\\u06a9\\u0645\\u06cc\\u0644 \\u0641\\u0631\\u0622\\u06cc\\u0646\\u062f \\u062e\\u0631\\u06cc\\u062f \\u0648 \\u062f\\u0631\\u06cc\\u0627\\u0641\\u062a \\u06a9\\u0627\\u0644\\u0627\\\",\\n\\\"body\\\": \\\"\\u067e\\u0633 \\u0627\\u0632 \\u062a\\u0623\\u06cc\\u06cc\\u062f \\u0645\\u062f\\u0627\\u0631\\u06a9 \\u0648 \\u0627\\u0645\\u0636\\u0627\\u06cc \\u0642\\u0631\\u0627\\u0631\\u062f\\u0627\\u062f \\u0627\\u0642\\u0633\\u0627\\u0637\\u06cc\\u060c \\u0645\\u06cc\\u200c\\u062a\\u0648\\u0627\\u0646\\u06cc\\u062f \\u06a9\\u0627\\u0644\\u0627 \\u0631\\u0627 \\u062a\\u062d\\u0648\\u06cc\\u0644 \\u0628\\u06af\\u06cc\\u0631\\u06cc\\u062f. \\u062f\\u0642\\u062a \\u06a9\\u0646\\u06cc\\u062f \\u06a9\\u0647 \\u062a\\u0627\\u0631\\u06cc\\u062e \\u0633\\u0631\\u0631\\u0633\\u06cc\\u062f \\u0627\\u0642\\u0633\\u0627\\u0637 \\u0648 \\u0646\\u062d\\u0648\\u0647 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a (\\u062d\\u0636\\u0648\\u0631\\u06cc \\u06cc\\u0627 \\u0622\\u0646\\u0644\\u0627\\u06cc\\u0646) \\u0645\\u0634\\u062e\\u0635 \\u0634\\u0648\\u062f. \\u0628\\u0631\\u062e\\u06cc \\u0641\\u0631\\u0648\\u0634\\u06af\\u0627\\u0647\\u200c\\u0647\\u0627 \\u0627\\u0645\\u06a9\\u0627\\u0646 \\u067e\\u0631\\u062f\\u0627\\u062e\\u062a \\u0642\\u0633\\u0637\\u200c\\u0647\\u0627 \\u0631\\u0627 \\u0627\\u0632 \\u0637\\u0631\\u06cc\\u0642 \\u062f\\u0631\\u06af\\u0627\\u0647 \\u0627\\u06cc\\u0646\\u062a\\u0631\\u0646\\u062a\\u06cc \\u06cc\\u0627 \\u062f\\u0633\\u062a\\u06af\\u0627\\u0647\\u200c\\u0647\\u0627\\u06cc \\u062e\\u0648\\u062f\\u067e\\u0631\\u062f\\u0627\\u0632 \\u0641\\u0631\\u0627\\u0647\\u0645 \\u0645\\u06cc\\u200c\\u06a9\\u0646\\u0646\\u062f.\\\"\\n}\\n]\\n}\"',NULL,'deepseek-local','2026-06-10 09:39:58','2026-06-10 09:39:47','2026-06-10 09:40:23'),(14,'procedure','steps','خرید قسطی کالا',NULL,5,'done','\"{\\n  \\\"title\\\": \\\"\\u0631\\u0627\\u0647\\u0646\\u0645\\u0627\\u06cc \\u0627\\u0646\\u062c\\u0627\\u0645 \\u0645\\u0631\\u0627\\u062d\\u0644 \\u062a\\u0633\\u062a \\u0645\\u0648\\u0636\\u0648\\u0639\\\",\\n  \\\"excerpt\\\": \\\"\\u062e\\u0644\\u0627\\u0635\\u0647\\u200c\\u0627\\u06cc \\u0627\\u0632 \\u0633\\u0647 \\u0645\\u0631\\u062d\\u0644\\u0647 \\u0627\\u0633\\u0627\\u0633\\u06cc \\u0628\\u0631\\u0627\\u06cc \\u0627\\u0646\\u062c\\u0627\\u0645 \\u062a\\u0633\\u062a \\u0645\\u0648\\u0636\\u0648\\u0639.\\\",\\n  \\\"steps\\\": [\\n    {\\n      \\\"title\\\": \\\"\\u0645\\u0631\\u062d\\u0644\\u0647 \\u0627\\u0648\\u0644: \\u0622\\u0645\\u0627\\u062f\\u0647\\u200c\\u0633\\u0627\\u0632\\u06cc\\\",\\n      \\\"body\\\": \\\"\\u0627\\u0628\\u0632\\u0627\\u0631\\u0647\\u0627 \\u0648 \\u0645\\u0648\\u0627\\u062f \\u0644\\u0627\\u0632\\u0645 \\u0631\\u0627 \\u062c\\u0645\\u0639\\u200c\\u0622\\u0648\\u0631\\u06cc \\u06a9\\u0631\\u062f\\u0647 \\u0648 \\u0645\\u062d\\u06cc\\u0637 \\u06a9\\u0627\\u0631 \\u0631\\u0627 \\u0622\\u0645\\u0627\\u062f\\u0647 \\u06a9\\u0646\\u06cc\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u0645\\u0631\\u062d\\u0644\\u0647 \\u062f\\u0648\\u0645: \\u0627\\u062c\\u0631\\u0627\\u06cc \\u062a\\u0633\\u062a\\\",\\n      \\\"body\\\": \\\"\\u0645\\u0631\\u0627\\u062d\\u0644 \\u062a\\u0633\\u062a \\u0631\\u0627 \\u0637\\u0628\\u0642 \\u062f\\u0633\\u062a\\u0648\\u0631\\u0627\\u0644\\u0639\\u0645\\u0644 \\u0628\\u0647 \\u062a\\u0631\\u062a\\u06cc\\u0628 \\u0627\\u0646\\u062c\\u0627\\u0645 \\u062f\\u0647\\u06cc\\u062f \\u0648 \\u0646\\u062a\\u0627\\u06cc\\u062c \\u0631\\u0627 \\u062b\\u0628\\u062a \\u06a9\\u0646\\u06cc\\u062f.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u0645\\u0631\\u062d\\u0644\\u0647 \\u0633\\u0648\\u0645: \\u062a\\u062d\\u0644\\u06cc\\u0644 \\u0646\\u062a\\u0627\\u06cc\\u062c\\\",\\n      \\\"body\\\": \\\"\\u062f\\u0627\\u062f\\u0647\\u200c\\u0647\\u0627\\u06cc \\u062c\\u0645\\u0639\\u200c\\u0622\\u0648\\u0631\\u06cc \\u0634\\u062f\\u0647 \\u0631\\u0627 \\u0628\\u0631\\u0631\\u0633\\u06cc \\u06a9\\u0631\\u062f\\u0647 \\u0648 \\u0646\\u062a\\u06cc\\u062c\\u0647\\u200c\\u06af\\u06cc\\u0631\\u06cc \\u0646\\u0647\\u0627\\u06cc\\u06cc \\u0631\\u0627 \\u0627\\u0646\\u062c\\u0627\\u0645 \\u062f\\u0647\\u06cc\\u062f.\\\"\\n    }\\n  ]\\n}\"',NULL,'deepseek-local','2026-06-10 09:48:20','2026-06-10 09:45:27','2026-06-10 09:51:44'),(15,'article','full','مزایای خرید اینترنتی',NULL,0,'done','\"\\u0418\\u0437\\u0432\\u0438\\u043d\\u0438\\u0442\\u0435, \\u044f \\u0435\\u0449\\u0435 \\u043d\\u0435 \\u043d\\u0430\\u0443\\u0447\\u0438\\u043b\\u0441\\u044f \\u043e\\u0442\\u0432\\u0435\\u0447\\u0430\\u0442\\u044c \\u043d\\u0430 \\u044d\\u0442\\u043e\\u0442 \\u0432\\u043e\\u043f\\u0440\\u043e\\u0441. \\u0415\\u0441\\u043b\\u0438 \\u0443 \\u0432\\u0430\\u0441 \\u0435\\u0441\\u0442\\u044c \\u0434\\u0440\\u0443\\u0433\\u0438\\u0435 \\u0432\\u043e\\u043f\\u0440\\u043e\\u0441\\u044b, \\u044f \\u0441 \\u0443\\u0434\\u043e\\u0432\\u043e\\u043b\\u044c\\u0441\\u0442\\u0432\\u0438\\u0435\\u043c \\u043f\\u043e\\u043c\\u043e\\u0433\\u0443 \\u0432\\u0430\\u043c.\"',NULL,'deepseek-local','2026-06-10 11:47:56','2026-06-10 09:56:37','2026-06-10 11:47:59'),(16,'procedure','steps','خرید قسطی کالا',NULL,5,'done','\"{\\n  \\\"title\\\": \\\"\\u00d9\\u0086\\u00d8\\u00ad\\u00d9\\u0088\\u00d9\\u0087 \\u00d8\\u00aa\\u00d8\\u00b9\\u00d9\\u0085\\u00db\\u008c\\u00d8\\u00b1 \\u00d9\\u0084\\u00d9\\u00be\\u00e2\\u0080\\u008c\\u00d8\\u00aa\\u00d8\\u00a7\\u00d9\\u00be\\\",\\n  \\\"excerpt\\\": \\\"\\u00d8\\u00b1\\u00d8\\u00a7\\u00d9\\u0087\\u00d9\\u0086\\u00d9\\u0085\\u00d8\\u00a7\\u00db\\u008c \\u00da\\u00af\\u00d8\\u00a7\\u00d9\\u0085 \\u00d8\\u00a8\\u00d9\\u0087 \\u00da\\u00af\\u00d8\\u00a7\\u00d9\\u0085 \\u00d8\\u00a8\\u00d8\\u00b1\\u00d8\\u00a7\\u00db\\u008c \\u00d8\\u00aa\\u00d8\\u00b9\\u00d9\\u0085\\u00db\\u008c\\u00d8\\u00b1 \\u00d9\\u0085\\u00d8\\u00b4\\u00da\\u00a9\\u00d9\\u0084\\u00d8\\u00a7\\u00d8\\u00aa \\u00d8\\u00b1\\u00d8\\u00a7\\u00db\\u008c\\u00d8\\u00ac \\u00d9\\u0084\\u00d9\\u00be\\u00e2\\u0080\\u008c\\u00d8\\u00aa\\u00d8\\u00a7\\u00d9\\u00be\\\",\\n  \\\"steps\\\": [\\n    {\\n      \\\"title\\\": \\\"\\u00d8\\u00aa\\u00d8\\u00b4\\u00d8\\u00ae\\u00db\\u008c\\u00d8\\u00b5 \\u00d9\\u0085\\u00d8\\u00b4\\u00da\\u00a9\\u00d9\\u0084\\\",\\n      \\\"body\\\": \\\"\\u00d8\\u00a7\\u00d8\\u00a8\\u00d8\\u00aa\\u00d8\\u00af\\u00d8\\u00a7 \\u00d9\\u0085\\u00d8\\u00b4\\u00da\\u00a9\\u00d9\\u0084 \\u00d9\\u0084\\u00d9\\u00be\\u00e2\\u0080\\u008c\\u00d8\\u00aa\\u00d8\\u00a7\\u00d9\\u00be \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00b4\\u00d9\\u0086\\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00a7\\u00db\\u008c\\u00db\\u008c \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af. \\u00d8\\u00a2\\u00db\\u008c\\u00d8\\u00a7 \\u00d8\\u00b1\\u00d9\\u0088\\u00d8\\u00b4\\u00d9\\u0086 \\u00d9\\u0086\\u00d9\\u0085\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00d8\\u00b4\\u00d9\\u0088\\u00d8\\u00af\\u00d8\\u009f \\u00d8\\u00b5\\u00d9\\u0081\\u00d8\\u00ad\\u00d9\\u0087 \\u00d9\\u0086\\u00d9\\u0085\\u00d8\\u00a7\\u00db\\u008c\\u00d8\\u00b4 \\u00d9\\u0085\\u00d8\\u00b4\\u00da\\u00a9\\u00d9\\u0084 \\u00d8\\u00af\\u00d8\\u00a7\\u00d8\\u00b1\\u00d8\\u00af\\u00d8\\u009f \\u00db\\u008c\\u00d8\\u00a7 \\u00d8\\u00b5\\u00d8\\u00af\\u00d8\\u00a7 \\u00d9\\u0086\\u00d9\\u0085\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00d8\\u00af\\u00d9\\u0087\\u00d8\\u00af\\u00d8\\u009f \\u00d8\\u00a8\\u00d8\\u00a7 \\u00d8\\u00af\\u00d9\\u0082\\u00d8\\u00aa \\u00d8\\u00a8\\u00d9\\u0087 \\u00d9\\u0086\\u00d8\\u00b4\\u00d8\\u00a7\\u00d9\\u0086\\u00d9\\u0087\\u00e2\\u0080\\u008c\\u00d9\\u0087\\u00d8\\u00a7 \\u00d8\\u00aa\\u00d9\\u0088\\u00d8\\u00ac\\u00d9\\u0087 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d8\\u00ac\\u00d9\\u0085\\u00d8\\u00b9\\u00e2\\u0080\\u008c\\u00d8\\u00a2\\u00d9\\u0088\\u00d8\\u00b1\\u00db\\u008c \\u00d8\\u00a7\\u00d8\\u00a8\\u00d8\\u00b2\\u00d8\\u00a7\\u00d8\\u00b1 \\u00d9\\u0084\\u00d8\\u00a7\\u00d8\\u00b2\\u00d9\\u0085\\\",\\n      \\\"body\\\": \\\"\\u00d8\\u00a7\\u00d8\\u00a8\\u00d8\\u00b2\\u00d8\\u00a7\\u00d8\\u00b1\\u00d9\\u0087\\u00d8\\u00a7\\u00db\\u008c \\u00d9\\u0085\\u00d9\\u0088\\u00d8\\u00b1\\u00d8\\u00af \\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00a7\\u00d8\\u00b2 \\u00d9\\u0085\\u00d8\\u00a7\\u00d9\\u0086\\u00d9\\u0086\\u00d8\\u00af \\u00d9\\u00be\\u00db\\u008c\\u00da\\u0086\\u00e2\\u0080\\u008c\\u00da\\u00af\\u00d9\\u0088\\u00d8\\u00b4\\u00d8\\u00aa\\u00db\\u008c\\u00d8\\u008c \\u00da\\u00a9\\u00d8\\u00a7\\u00d8\\u00b1\\u00d8\\u00aa \\u00d9\\u00be\\u00d9\\u0084\\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa\\u00db\\u008c\\u00da\\u00a9\\u00db\\u008c\\u00d8\\u008c \\u00d8\\u00af\\u00d8\\u00b3\\u00d8\\u00aa\\u00d8\\u00a8\\u00d9\\u0086\\u00d8\\u00af \\u00d8\\u00a2\\u00d9\\u0086\\u00d8\\u00aa\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa\\u00d8\\u00a7\\u00d8\\u00aa\\u00db\\u008c\\u00da\\u00a9 \\u00d9\\u0088 \\u00d9\\u0082\\u00d8\\u00b7\\u00d8\\u00b9\\u00d8\\u00a7\\u00d8\\u00aa \\u00db\\u008c\\u00d8\\u00af\\u00da\\u00a9\\u00db\\u008c \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a2\\u00d9\\u0085\\u00d8\\u00a7\\u00d8\\u00af\\u00d9\\u0087 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d8\\u00a8\\u00d8\\u00a7\\u00d8\\u00b2 \\u00da\\u00a9\\u00d8\\u00b1\\u00d8\\u00af\\u00d9\\u0086 \\u00d9\\u0084\\u00d9\\u00be\\u00e2\\u0080\\u008c\\u00d8\\u00aa\\u00d8\\u00a7\\u00d9\\u00be\\\",\\n      \\\"body\\\": \\\"\\u00d9\\u0084\\u00d9\\u00be\\u00e2\\u0080\\u008c\\u00d8\\u00aa\\u00d8\\u00a7\\u00d9\\u00be \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00ae\\u00d8\\u00a7\\u00d9\\u0085\\u00d9\\u0088\\u00d8\\u00b4 \\u00d9\\u0088 \\u00d8\\u00a8\\u00d8\\u00a7\\u00d8\\u00aa\\u00d8\\u00b1\\u00db\\u008c \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00ac\\u00d8\\u00af\\u00d8\\u00a7 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af. \\u00d9\\u00be\\u00db\\u008c\\u00da\\u0086\\u00e2\\u0080\\u008c\\u00d9\\u0087\\u00d8\\u00a7\\u00db\\u008c \\u00d9\\u0082\\u00d8\\u00a7\\u00d8\\u00a8 \\u00d9\\u00be\\u00d8\\u00b4\\u00d8\\u00aa\\u00db\\u008c \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d8\\u00a7\\u00d8\\u00b2 \\u00da\\u00a9\\u00d8\\u00b1\\u00d8\\u00af\\u00d9\\u0087 \\u00d9\\u0088 \\u00d8\\u00a8\\u00d8\\u00a7 \\u00d8\\u00af\\u00d9\\u0082\\u00d8\\u00aa \\u00d9\\u0082\\u00d8\\u00a7\\u00d8\\u00a8 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d8\\u00b1\\u00d8\\u00af\\u00d8\\u00a7\\u00d8\\u00b1\\u00db\\u008c\\u00d8\\u00af.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d8\\u00aa\\u00d8\\u00b9\\u00d9\\u0085\\u00db\\u008c\\u00d8\\u00b1 \\u00db\\u008c\\u00d8\\u00a7 \\u00d8\\u00aa\\u00d8\\u00b9\\u00d9\\u0088\\u00db\\u008c\\u00d8\\u00b6 \\u00d9\\u0082\\u00d8\\u00b7\\u00d8\\u00b9\\u00d9\\u0087\\\",\\n      \\\"body\\\": \\\"\\u00d9\\u0082\\u00d8\\u00b7\\u00d8\\u00b9\\u00d9\\u0087 \\u00d9\\u0085\\u00d8\\u00b9\\u00db\\u008c\\u00d9\\u0088\\u00d8\\u00a8 \\u00d9\\u0085\\u00d8\\u00a7\\u00d9\\u0086\\u00d9\\u0086\\u00d8\\u00af \\u00d8\\u00b1\\u00d9\\u0085\\u00d8\\u008c \\u00d9\\u0087\\u00d8\\u00a7\\u00d8\\u00b1\\u00d8\\u00af \\u00d8\\u00af\\u00db\\u008c\\u00d8\\u00b3\\u00da\\u00a9 \\u00db\\u008c\\u00d8\\u00a7 \\u00d9\\u0081\\u00d9\\u0086 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00aa\\u00d8\\u00b9\\u00d9\\u0085\\u00db\\u008c\\u00d8\\u00b1 \\u00db\\u008c\\u00d8\\u00a7 \\u00d8\\u00aa\\u00d8\\u00b9\\u00d9\\u0088\\u00db\\u008c\\u00d8\\u00b6 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af. \\u00d9\\u0085\\u00d8\\u00b1\\u00d8\\u00a7\\u00d9\\u0082\\u00d8\\u00a8 \\u00d8\\u00a7\\u00d8\\u00aa\\u00d8\\u00b5\\u00d8\\u00a7\\u00d9\\u0084\\u00d8\\u00a7\\u00d8\\u00aa \\u00d9\\u0088 \\u00da\\u00a9\\u00d8\\u00a7\\u00d8\\u00a8\\u00d9\\u0084\\u00e2\\u0080\\u008c\\u00d9\\u0087\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d8\\u00a7\\u00d8\\u00b4\\u00db\\u008c\\u00d8\\u00af.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d8\\u00a8\\u00d8\\u00b3\\u00d8\\u00aa\\u00d9\\u0086 \\u00d9\\u0084\\u00d9\\u00be\\u00e2\\u0080\\u008c\\u00d8\\u00aa\\u00d8\\u00a7\\u00d9\\u00be \\u00d9\\u0088 \\u00d8\\u00aa\\u00d8\\u00b3\\u00d8\\u00aa\\\",\\n      \\\"body\\\": \\\"\\u00d9\\u0082\\u00d8\\u00a7\\u00d8\\u00a8 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d8\\u00a8\\u00d9\\u0086\\u00d8\\u00af\\u00db\\u008c\\u00d8\\u00af\\u00d8\\u008c \\u00d9\\u00be\\u00db\\u008c\\u00da\\u0086\\u00e2\\u0080\\u008c\\u00d9\\u0087\\u00d8\\u00a7 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d9\\u0085\\u00d8\\u00ad\\u00da\\u00a9\\u00d9\\u0085 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af \\u00d9\\u0088 \\u00d9\\u0084\\u00d9\\u00be\\u00e2\\u0080\\u008c\\u00d8\\u00aa\\u00d8\\u00a7\\u00d9\\u00be \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00b1\\u00d9\\u0088\\u00d8\\u00b4\\u00d9\\u0086 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af. \\u00d8\\u00b9\\u00d9\\u0085\\u00d9\\u0084\\u00da\\u00a9\\u00d8\\u00b1\\u00d8\\u00af \\u00d8\\u00a2\\u00d9\\u0086 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d8\\u00b1\\u00d8\\u00b1\\u00d8\\u00b3\\u00db\\u008c \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af \\u00d8\\u00aa\\u00d8\\u00a7 \\u00d9\\u0085\\u00d8\\u00b4\\u00da\\u00a9\\u00d9\\u0084 \\u00d8\\u00a8\\u00d8\\u00b1\\u00d8\\u00b7\\u00d8\\u00b1\\u00d9\\u0081 \\u00d8\\u00b4\\u00d8\\u00af\\u00d9\\u0087 \\u00d8\\u00a8\\u00d8\\u00a7\\u00d8\\u00b4\\u00d8\\u00af.\\\"\\n    }\\n  ]\\n}\"',NULL,'deepseek-local','2026-06-10 11:53:02','2026-06-10 10:07:39','2026-06-10 11:53:08'),(17,'procedure','steps','خرید قسطی کالا',NULL,5,'done','\"{\\n  \\\"title\\\": \\\"\\u00d8\\u00aa\\u00d8\\u00ba\\u00db\\u008c\\u00db\\u008c\\u00d8\\u00b1 \\u00d9\\u0084\\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa\\u00db\\u008c\\u00da\\u00a9 \\u00d8\\u00ae\\u00d9\\u0088\\u00d8\\u00af\\u00d8\\u00b1\\u00d9\\u0088\\\",\\n  \\\"excerpt\\\": \\\"\\u00d8\\u00b1\\u00d8\\u00a7\\u00d9\\u0087\\u00d9\\u0086\\u00d9\\u0085\\u00d8\\u00a7\\u00db\\u008c \\u00da\\u00af\\u00d8\\u00a7\\u00d9\\u0085 \\u00d8\\u00a8\\u00d9\\u0087 \\u00da\\u00af\\u00d8\\u00a7\\u00d9\\u0085 \\u00d8\\u00a8\\u00d8\\u00b1\\u00d8\\u00a7\\u00db\\u008c \\u00d8\\u00aa\\u00d8\\u00b9\\u00d9\\u0088\\u00db\\u008c\\u00d8\\u00b6 \\u00d9\\u0084\\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa\\u00db\\u008c\\u00da\\u00a9 \\u00d9\\u00be\\u00d9\\u0086\\u00da\\u0086\\u00d8\\u00b1 \\u00d8\\u00b4\\u00d8\\u00af\\u00d9\\u0087 \\u00d8\\u00ae\\u00d9\\u0088\\u00d8\\u00af\\u00d8\\u00b1\\u00d9\\u0088\\\",\\n  \\\"steps\\\": [\\n    {\\n      \\\"title\\\": \\\"\\u00d8\\u00a2\\u00d9\\u0085\\u00d8\\u00a7\\u00d8\\u00af\\u00d9\\u0087\\u00e2\\u0080\\u008c\\u00d8\\u00b3\\u00d8\\u00a7\\u00d8\\u00b2\\u00db\\u008c \\u00d9\\u0088 \\u00d8\\u00a7\\u00db\\u008c\\u00d9\\u0085\\u00d9\\u0086\\u00db\\u008c\\\",\\n      \\\"body\\\": \\\"\\u00d8\\u00ae\\u00d9\\u0088\\u00d8\\u00af\\u00d8\\u00b1\\u00d9\\u0088 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00af\\u00d8\\u00b1 \\u00d8\\u00b3\\u00d8\\u00b7\\u00d8\\u00ad \\u00d8\\u00b5\\u00d8\\u00a7\\u00d9\\u0081 \\u00d9\\u0088 \\u00d8\\u00a7\\u00db\\u008c\\u00d9\\u0085\\u00d9\\u0086 \\u00d9\\u00be\\u00d8\\u00a7\\u00d8\\u00b1\\u00da\\u00a9 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af. \\u00d8\\u00aa\\u00d8\\u00b1\\u00d9\\u0085\\u00d8\\u00b2 \\u00d8\\u00af\\u00d8\\u00b3\\u00d8\\u00aa\\u00db\\u008c \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a8\\u00da\\u00a9\\u00d8\\u00b4\\u00db\\u008c\\u00d8\\u00af \\u00d9\\u0088 \\u00da\\u0086\\u00d8\\u00b1\\u00d8\\u00a7\\u00d8\\u00ba\\u00e2\\u0080\\u008c\\u00d9\\u0087\\u00d8\\u00a7\\u00db\\u008c \\u00d8\\u00ae\\u00d8\\u00b7\\u00d8\\u00b1 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00b1\\u00d9\\u0088\\u00d8\\u00b4\\u00d9\\u0086 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af. \\u00d9\\u0085\\u00d8\\u00ab\\u00d9\\u0084\\u00d8\\u00ab \\u00d8\\u00ae\\u00d8\\u00b7\\u00d8\\u00b1 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00af\\u00d8\\u00b1 \\u00d9\\u0081\\u00d8\\u00a7\\u00d8\\u00b5\\u00d9\\u0084\\u00d9\\u0087 \\u00d9\\u0085\\u00d9\\u0086\\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00a8 \\u00d9\\u0082\\u00d8\\u00b1\\u00d8\\u00a7\\u00d8\\u00b1 \\u00d8\\u00af\\u00d9\\u0087\\u00db\\u008c\\u00d8\\u00af.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d8\\u00a8\\u00d8\\u00a7\\u00d8\\u00b2 \\u00da\\u00a9\\u00d8\\u00b1\\u00d8\\u00af\\u00d9\\u0086 \\u00d9\\u00be\\u00db\\u008c\\u00da\\u0086\\u00e2\\u0080\\u008c\\u00d9\\u0087\\u00d8\\u00a7\\u00db\\u008c \\u00da\\u0086\\u00d8\\u00b1\\u00d8\\u00ae\\\",\\n      \\\"body\\\": \\\"\\u00d8\\u00a8\\u00d8\\u00a7 \\u00d8\\u00a2\\u00da\\u0086\\u00d8\\u00a7\\u00d8\\u00b1 \\u00da\\u0086\\u00d8\\u00b1\\u00d8\\u00ae\\u00d8\\u008c \\u00d9\\u00be\\u00db\\u008c\\u00da\\u0086\\u00e2\\u0080\\u008c\\u00d9\\u0087\\u00d8\\u00a7\\u00db\\u008c \\u00da\\u0086\\u00d8\\u00b1\\u00d8\\u00ae \\u00d9\\u00be\\u00d9\\u0086\\u00da\\u0086\\u00d8\\u00b1 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00da\\u00a9\\u00d9\\u0085\\u00db\\u008c \\u00d8\\u00b4\\u00d9\\u0084 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af\\u00d8\\u008c \\u00d8\\u00a7\\u00d9\\u0085\\u00d8\\u00a7 \\u00da\\u00a9\\u00d8\\u00a7\\u00d9\\u0085\\u00d9\\u0084\\u00d8\\u00a7\\u00d9\\u008b \\u00d8\\u00a8\\u00d8\\u00a7\\u00d8\\u00b2 \\u00d9\\u0086\\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af. \\u00d8\\u00a7\\u00d8\\u00b2 \\u00d8\\u00ac\\u00da\\u00a9 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa\\u00d9\\u0081\\u00d8\\u00a7\\u00d8\\u00af\\u00d9\\u0087 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af \\u00d9\\u0088 \\u00d8\\u00ae\\u00d9\\u0088\\u00d8\\u00af\\u00d8\\u00b1\\u00d9\\u0088 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d8\\u00a7\\u00d9\\u0084\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d8\\u00a8\\u00d8\\u00b1\\u00db\\u008c\\u00d8\\u00af \\u00d8\\u00aa\\u00d8\\u00a7 \\u00da\\u0086\\u00d8\\u00b1\\u00d8\\u00ae \\u00d8\\u00a7\\u00d8\\u00b2 \\u00d8\\u00b2\\u00d9\\u0085\\u00db\\u008c\\u00d9\\u0086 \\u00d9\\u0081\\u00d8\\u00a7\\u00d8\\u00b5\\u00d9\\u0084\\u00d9\\u0087 \\u00d8\\u00a8\\u00da\\u00af\\u00db\\u008c\\u00d8\\u00b1\\u00d8\\u00af.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d8\\u00a8\\u00d8\\u00b1\\u00d8\\u00af\\u00d8\\u00a7\\u00d8\\u00b4\\u00d8\\u00aa\\u00d9\\u0086 \\u00da\\u0086\\u00d8\\u00b1\\u00d8\\u00ae \\u00d9\\u00be\\u00d9\\u0086\\u00da\\u0086\\u00d8\\u00b1\\\",\\n      \\\"body\\\": \\\"\\u00d9\\u00be\\u00d8\\u00b3 \\u00d8\\u00a7\\u00d8\\u00b2 \\u00d8\\u00a8\\u00d8\\u00a7\\u00d9\\u0084\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d8\\u00b1\\u00d8\\u00af\\u00d9\\u0086 \\u00d8\\u00ae\\u00d9\\u0088\\u00d8\\u00af\\u00d8\\u00b1\\u00d9\\u0088\\u00d8\\u008c \\u00d9\\u00be\\u00db\\u008c\\u00da\\u0086\\u00e2\\u0080\\u008c\\u00d9\\u0087\\u00d8\\u00a7 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00da\\u00a9\\u00d8\\u00a7\\u00d9\\u0085\\u00d9\\u0084\\u00d8\\u00a7\\u00d9\\u008b \\u00d8\\u00a8\\u00d8\\u00a7\\u00d8\\u00b2 \\u00da\\u00a9\\u00d8\\u00b1\\u00d8\\u00af\\u00d9\\u0087 \\u00d9\\u0088 \\u00da\\u0086\\u00d8\\u00b1\\u00d8\\u00ae \\u00d9\\u00be\\u00d9\\u0086\\u00da\\u0086\\u00d8\\u00b1 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a7\\u00d8\\u00b2 \\u00d9\\u0085\\u00d8\\u00ad\\u00d9\\u0088\\u00d8\\u00b1 \\u00d8\\u00ae\\u00d8\\u00a7\\u00d8\\u00b1\\u00d8\\u00ac \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af. \\u00d9\\u0085\\u00d8\\u00b1\\u00d8\\u00a7\\u00d9\\u0082\\u00d8\\u00a8 \\u00d8\\u00a8\\u00d8\\u00a7\\u00d8\\u00b4\\u00db\\u008c\\u00d8\\u00af \\u00da\\u0086\\u00d8\\u00b1\\u00d8\\u00ae \\u00d8\\u00b3\\u00d9\\u0086\\u00da\\u00af\\u00db\\u008c\\u00d9\\u0086 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d9\\u0086\\u00d8\\u00b5\\u00d8\\u00a8 \\u00d9\\u0084\\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa\\u00db\\u008c\\u00da\\u00a9 \\u00d8\\u00b2\\u00d8\\u00a7\\u00d9\\u00be\\u00d8\\u00a7\\u00d8\\u00b3\\\",\\n      \\\"body\\\": \\\"\\u00d9\\u0084\\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa\\u00db\\u008c\\u00da\\u00a9 \\u00d8\\u00b2\\u00d8\\u00a7\\u00d9\\u00be\\u00d8\\u00a7\\u00d8\\u00b3 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00b1\\u00d9\\u0088\\u00db\\u008c \\u00d9\\u0085\\u00d8\\u00ad\\u00d9\\u0088\\u00d8\\u00b1 \\u00d9\\u0082\\u00d8\\u00b1\\u00d8\\u00a7\\u00d8\\u00b1 \\u00d8\\u00af\\u00d9\\u0087\\u00db\\u008c\\u00d8\\u00af \\u00d9\\u0088 \\u00d9\\u00be\\u00db\\u008c\\u00da\\u0086\\u00e2\\u0080\\u008c\\u00d9\\u0087\\u00d8\\u00a7 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d9\\u0087 \\u00d8\\u00b5\\u00d9\\u0088\\u00d8\\u00b1\\u00d8\\u00aa \\u00d8\\u00b6\\u00d8\\u00b1\\u00d8\\u00a8\\u00d8\\u00af\\u00d8\\u00b1\\u00db\\u008c \\u00d8\\u00a8\\u00d8\\u00a7 \\u00d8\\u00af\\u00d8\\u00b3\\u00d8\\u00aa \\u00d9\\u0085\\u00d8\\u00ad\\u00da\\u00a9\\u00d9\\u0085 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af. \\u00d8\\u00b3\\u00d9\\u00be\\u00d8\\u00b3 \\u00d8\\u00ae\\u00d9\\u0088\\u00d8\\u00af\\u00d8\\u00b1\\u00d9\\u0088 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d9\\u00be\\u00d8\\u00a7\\u00db\\u008c\\u00db\\u008c\\u00d9\\u0086 \\u00d8\\u00a8\\u00db\\u008c\\u00d8\\u00a7\\u00d9\\u0088\\u00d8\\u00b1\\u00db\\u008c\\u00d8\\u00af \\u00d8\\u00aa\\u00d8\\u00a7 \\u00da\\u0086\\u00d8\\u00b1\\u00d8\\u00ae \\u00d8\\u00b1\\u00d9\\u0088\\u00db\\u008c \\u00d8\\u00b2\\u00d9\\u0085\\u00db\\u008c\\u00d9\\u0086 \\u00d9\\u0082\\u00d8\\u00b1\\u00d8\\u00a7\\u00d8\\u00b1 \\u00da\\u00af\\u00db\\u008c\\u00d8\\u00b1\\u00d8\\u00af.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d9\\u0085\\u00d8\\u00ad\\u00da\\u00a9\\u00d9\\u0085 \\u00da\\u00a9\\u00d8\\u00b1\\u00d8\\u00af\\u00d9\\u0086 \\u00d9\\u00be\\u00db\\u008c\\u00da\\u0086\\u00e2\\u0080\\u008c\\u00d9\\u0087\\u00d8\\u00a7 \\u00d9\\u0088 \\u00d8\\u00ac\\u00d9\\u0085\\u00d8\\u00b9\\u00e2\\u0080\\u008c\\u00d8\\u00a2\\u00d9\\u0088\\u00d8\\u00b1\\u00db\\u008c\\\",\\n      \\\"body\\\": \\\"\\u00d8\\u00a8\\u00d8\\u00a7 \\u00d8\\u00a2\\u00da\\u0086\\u00d8\\u00a7\\u00d8\\u00b1 \\u00da\\u0086\\u00d8\\u00b1\\u00d8\\u00ae\\u00d8\\u008c \\u00d9\\u00be\\u00db\\u008c\\u00da\\u0086\\u00e2\\u0080\\u008c\\u00d9\\u0087\\u00d8\\u00a7 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d9\\u0087 \\u00d8\\u00b5\\u00d9\\u0088\\u00d8\\u00b1\\u00d8\\u00aa \\u00d8\\u00b6\\u00d8\\u00b1\\u00d8\\u00a8\\u00d8\\u00af\\u00d8\\u00b1\\u00db\\u008c \\u00d9\\u0085\\u00d8\\u00ad\\u00da\\u00a9\\u00d9\\u0085 \\u00d8\\u00a8\\u00d8\\u00a8\\u00d9\\u0086\\u00d8\\u00af\\u00db\\u008c\\u00d8\\u00af. \\u00d8\\u00ac\\u00da\\u00a9 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d9\\u00be\\u00d8\\u00a7\\u00db\\u008c\\u00db\\u008c\\u00d9\\u0086 \\u00d8\\u00a8\\u00da\\u00a9\\u00d8\\u00b4\\u00db\\u008c\\u00d8\\u00af \\u00d9\\u0088 \\u00d8\\u00a7\\u00d8\\u00a8\\u00d8\\u00b2\\u00d8\\u00a7\\u00d8\\u00b1\\u00d9\\u0087\\u00d8\\u00a7 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00ac\\u00d9\\u0085\\u00d8\\u00b9 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af. \\u00d9\\u0084\\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa\\u00db\\u008c\\u00da\\u00a9 \\u00d9\\u00be\\u00d9\\u0086\\u00da\\u0086\\u00d8\\u00b1 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00af\\u00d8\\u00b1 \\u00d8\\u00b5\\u00d9\\u0086\\u00d8\\u00af\\u00d9\\u0088\\u00d9\\u0082 \\u00d8\\u00a8\\u00da\\u00af\\u00d8\\u00b0\\u00d8\\u00a7\\u00d8\\u00b1\\u00db\\u008c\\u00d8\\u00af.\\\"\\n    }\\n  ]\\n}\"',NULL,'deepseek-local','2026-06-10 11:53:02','2026-06-10 10:18:36','2026-06-10 11:53:14'),(18,'procedure','steps','خرید قسطی کالا',NULL,5,'done','\"{\\n  \\\"title\\\": \\\"\\u00d8\\u00b7\\u00d8\\u00b1\\u00d8\\u00b2 \\u00d8\\u00aa\\u00d9\\u0087\\u00db\\u008c\\u00d9\\u0087 \\u00da\\u00a9\\u00db\\u008c\\u00da\\u00a9 \\u00d8\\u00b4\\u00da\\u00a9\\u00d9\\u0084\\u00d8\\u00a7\\u00d8\\u00aa\\u00db\\u008c\\\",\\n  \\\"excerpt\\\": \\\"\\u00db\\u008c\\u00da\\u00a9 \\u00d8\\u00b1\\u00d9\\u0088\\u00d8\\u00b4 \\u00d8\\u00b3\\u00d8\\u00a7\\u00d8\\u00af\\u00d9\\u0087 \\u00d9\\u0088 \\u00d8\\u00ae\\u00d9\\u0088\\u00d8\\u00b4\\u00d9\\u0085\\u00d8\\u00b2\\u00d9\\u0087 \\u00d8\\u00a8\\u00d8\\u00b1\\u00d8\\u00a7\\u00db\\u008c \\u00d8\\u00aa\\u00d9\\u0087\\u00db\\u008c\\u00d9\\u0087 \\u00da\\u00a9\\u00db\\u008c\\u00da\\u00a9 \\u00d8\\u00b4\\u00da\\u00a9\\u00d9\\u0084\\u00d8\\u00a7\\u00d8\\u00aa\\u00db\\u008c \\u00d8\\u00af\\u00d8\\u00b1 \\u00d8\\u00ae\\u00d8\\u00a7\\u00d9\\u0086\\u00d9\\u0087\\\",\\n  \\\"steps\\\": [\\n    {\\n      \\\"title\\\": \\\"\\u00d8\\u00a2\\u00d9\\u0085\\u00d8\\u00a7\\u00d8\\u00af\\u00d9\\u0087\\u00e2\\u0080\\u008c\\u00d8\\u00b3\\u00d8\\u00a7\\u00d8\\u00b2\\u00db\\u008c \\u00d9\\u0085\\u00d9\\u0088\\u00d8\\u00a7\\u00d8\\u00af \\u00d8\\u00a7\\u00d9\\u0088\\u00d9\\u0084\\u00db\\u008c\\u00d9\\u0087\\\",\\n      \\\"body\\\": \\\"\\u00d9\\u0085\\u00d9\\u0088\\u00d8\\u00a7\\u00d8\\u00af \\u00d9\\u0084\\u00d8\\u00a7\\u00d8\\u00b2\\u00d9\\u0085 \\u00d8\\u00b4\\u00d8\\u00a7\\u00d9\\u0085\\u00d9\\u0084 \\u00db\\u00b2 \\u00d9\\u00be\\u00db\\u008c\\u00d9\\u0085\\u00d8\\u00a7\\u00d9\\u0086\\u00d9\\u0087 \\u00d8\\u00a2\\u00d8\\u00b1\\u00d8\\u00af\\u00d8\\u008c \\u00db\\u00b1 \\u00d9\\u00be\\u00db\\u008c\\u00d9\\u0085\\u00d8\\u00a7\\u00d9\\u0086\\u00d9\\u0087 \\u00d8\\u00b4\\u00da\\u00a9\\u00d8\\u00b1\\u00d8\\u008c \\u00db\\u00b1 \\u00d9\\u00be\\u00db\\u008c\\u00d9\\u0085\\u00d8\\u00a7\\u00d9\\u0086\\u00d9\\u0087 \\u00d9\\u00be\\u00d9\\u0088\\u00d8\\u00af\\u00d8\\u00b1 \\u00da\\u00a9\\u00d8\\u00a7\\u00da\\u00a9\\u00d8\\u00a7\\u00d8\\u00a6\\u00d9\\u0088\\u00d8\\u008c \\u00db\\u00b1 \\u00d9\\u0082\\u00d8\\u00a7\\u00d8\\u00b4\\u00d9\\u0082 \\u00da\\u0086\\u00d8\\u00a7\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00d8\\u00ae\\u00d9\\u0088\\u00d8\\u00b1\\u00db\\u008c \\u00d8\\u00a8\\u00db\\u008c\\u00da\\u00a9\\u00db\\u008c\\u00d9\\u0086\\u00da\\u00af \\u00d9\\u00be\\u00d9\\u0088\\u00d8\\u00af\\u00d8\\u00b1\\u00d8\\u008c \\u00db\\u00b1 \\u00d9\\u0082\\u00d8\\u00a7\\u00d8\\u00b4\\u00d9\\u0082 \\u00da\\u0086\\u00d8\\u00a7\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00d8\\u00ae\\u00d9\\u0088\\u00d8\\u00b1\\u00db\\u008c \\u00d9\\u0088\\u00d8\\u00a7\\u00d9\\u0086\\u00db\\u008c\\u00d9\\u0084\\u00d8\\u008c \\u00db\\u00b2 \\u00d8\\u00b9\\u00d8\\u00af\\u00d8\\u00af \\u00d8\\u00aa\\u00d8\\u00ae\\u00d9\\u0085\\u00e2\\u0080\\u008c\\u00d9\\u0085\\u00d8\\u00b1\\u00d8\\u00ba\\u00d8\\u008c \\u00db\\u00b1 \\u00d9\\u00be\\u00db\\u008c\\u00d9\\u0085\\u00d8\\u00a7\\u00d9\\u0086\\u00d9\\u0087 \\u00d8\\u00b4\\u00db\\u008c\\u00d8\\u00b1 \\u00d9\\u0088 \\u00d9\\u0086\\u00d8\\u00b5\\u00d9\\u0081 \\u00d9\\u00be\\u00db\\u008c\\u00d9\\u0085\\u00d8\\u00a7\\u00d9\\u0086\\u00d9\\u0087 \\u00d8\\u00b1\\u00d9\\u0088\\u00d8\\u00ba\\u00d9\\u0086 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a2\\u00d9\\u0085\\u00d8\\u00a7\\u00d8\\u00af\\u00d9\\u0087 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d9\\u0085\\u00d8\\u00ae\\u00d9\\u0084\\u00d9\\u0088\\u00d8\\u00b7 \\u00da\\u00a9\\u00d8\\u00b1\\u00d8\\u00af\\u00d9\\u0086 \\u00d9\\u0085\\u00d9\\u0088\\u00d8\\u00a7\\u00d8\\u00af \\u00d8\\u00ae\\u00d8\\u00b4\\u00da\\u00a9\\\",\\n      \\\"body\\\": \\\"\\u00d8\\u00a2\\u00d8\\u00b1\\u00d8\\u00af\\u00d8\\u008c \\u00d9\\u00be\\u00d9\\u0088\\u00d8\\u00af\\u00d8\\u00b1 \\u00da\\u00a9\\u00d8\\u00a7\\u00da\\u00a9\\u00d8\\u00a7\\u00d8\\u00a6\\u00d9\\u0088 \\u00d9\\u0088 \\u00d8\\u00a8\\u00db\\u008c\\u00da\\u00a9\\u00db\\u008c\\u00d9\\u0086\\u00da\\u00af \\u00d9\\u00be\\u00d9\\u0088\\u00d8\\u00af\\u00d8\\u00b1 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00af\\u00d8\\u00b1 \\u00db\\u008c\\u00da\\u00a9 \\u00da\\u00a9\\u00d8\\u00a7\\u00d8\\u00b3\\u00d9\\u0087 \\u00d8\\u00a8\\u00d8\\u00b2\\u00d8\\u00b1\\u00da\\u00af \\u00d8\\u00a7\\u00d9\\u0084\\u00da\\u00a9 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af \\u00d9\\u0088 \\u00d8\\u00ae\\u00d9\\u0088\\u00d8\\u00a8 \\u00d9\\u0085\\u00d8\\u00ae\\u00d9\\u0084\\u00d9\\u0088\\u00d8\\u00b7 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d8\\u00a7\\u00d9\\u0081\\u00d8\\u00b2\\u00d9\\u0088\\u00d8\\u00af\\u00d9\\u0086 \\u00d9\\u0085\\u00d9\\u0088\\u00d8\\u00a7\\u00d8\\u00af \\u00d8\\u00aa\\u00d8\\u00b1\\\",\\n      \\\"body\\\": \\\"\\u00d8\\u00aa\\u00d8\\u00ae\\u00d9\\u0085\\u00e2\\u0080\\u008c\\u00d9\\u0085\\u00d8\\u00b1\\u00d8\\u00ba\\u00e2\\u0080\\u008c\\u00d9\\u0087\\u00d8\\u00a7\\u00d8\\u008c \\u00d8\\u00b4\\u00da\\u00a9\\u00d8\\u00b1\\u00d8\\u008c \\u00d9\\u0088\\u00d8\\u00a7\\u00d9\\u0086\\u00db\\u008c\\u00d9\\u0084\\u00d8\\u008c \\u00d8\\u00b4\\u00db\\u008c\\u00d8\\u00b1 \\u00d9\\u0088 \\u00d8\\u00b1\\u00d9\\u0088\\u00d8\\u00ba\\u00d9\\u0086 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d9\\u0087 \\u00d9\\u0085\\u00d9\\u0088\\u00d8\\u00a7\\u00d8\\u00af \\u00d8\\u00ae\\u00d8\\u00b4\\u00da\\u00a9 \\u00d8\\u00a7\\u00d8\\u00b6\\u00d8\\u00a7\\u00d9\\u0081\\u00d9\\u0087 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af \\u00d9\\u0088 \\u00d8\\u00a8\\u00d8\\u00a7 \\u00d9\\u0087\\u00d9\\u0085\\u00d8\\u00b2\\u00d9\\u0086 \\u00d8\\u00a8\\u00d8\\u00b1\\u00d9\\u0082\\u00db\\u008c \\u00d8\\u00a8\\u00d9\\u0087 \\u00d9\\u0085\\u00d8\\u00af\\u00d8\\u00aa \\u00db\\u00b2 \\u00d8\\u00af\\u00d9\\u0082\\u00db\\u008c\\u00d9\\u0082\\u00d9\\u0087 \\u00d8\\u00a8\\u00d8\\u00b2\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af \\u00d8\\u00aa\\u00d8\\u00a7 \\u00d9\\u0085\\u00d8\\u00ae\\u00d9\\u0084\\u00d9\\u0088\\u00d8\\u00b7 \\u00db\\u008c\\u00da\\u00a9\\u00d8\\u00af\\u00d8\\u00b3\\u00d8\\u00aa \\u00d8\\u00b4\\u00d9\\u0088\\u00d8\\u00af.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d9\\u00be\\u00d8\\u00ae\\u00d8\\u00aa \\u00da\\u00a9\\u00db\\u008c\\u00da\\u00a9\\\",\\n      \\\"body\\\": \\\"\\u00d9\\u0082\\u00d8\\u00a7\\u00d9\\u0084\\u00d8\\u00a8 \\u00da\\u00a9\\u00db\\u008c\\u00da\\u00a9 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00da\\u0086\\u00d8\\u00b1\\u00d8\\u00a8 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af \\u00d9\\u0088 \\u00d9\\u0085\\u00d8\\u00a7\\u00db\\u008c\\u00d9\\u0087 \\u00da\\u00a9\\u00db\\u008c\\u00da\\u00a9 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00af\\u00d8\\u00b1 \\u00d8\\u00a2\\u00d9\\u0086 \\u00d8\\u00a8\\u00d8\\u00b1\\u00db\\u008c\\u00d8\\u00b2\\u00db\\u008c\\u00d8\\u00af. \\u00d9\\u0081\\u00d8\\u00b1 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d8\\u00a7 \\u00d8\\u00af\\u00d9\\u0085\\u00d8\\u00a7\\u00db\\u008c \\u00db\\u00b1\\u00db\\u00b8\\u00db\\u00b0 \\u00d8\\u00af\\u00d8\\u00b1\\u00d8\\u00ac\\u00d9\\u0087 \\u00d8\\u00b3\\u00d8\\u00a7\\u00d9\\u0086\\u00d8\\u00aa\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00da\\u00af\\u00d8\\u00b1\\u00d8\\u00a7\\u00d8\\u00af \\u00da\\u00af\\u00d8\\u00b1\\u00d9\\u0085 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af \\u00d9\\u0088 \\u00da\\u00a9\\u00db\\u008c\\u00da\\u00a9 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d9\\u0087 \\u00d9\\u0085\\u00d8\\u00af\\u00d8\\u00aa \\u00db\\u00b3\\u00db\\u00b0 \\u00d8\\u00aa\\u00d8\\u00a7 \\u00db\\u00b3\\u00db\\u00b5 \\u00d8\\u00af\\u00d9\\u0082\\u00db\\u008c\\u00d9\\u0082\\u00d9\\u0087 \\u00d8\\u00a8\\u00d9\\u00be\\u00d8\\u00b2\\u00db\\u008c\\u00d8\\u00af.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d8\\u00b3\\u00d8\\u00b1\\u00d9\\u0088 \\u00da\\u00a9\\u00db\\u008c\\u00da\\u00a9\\\",\\n      \\\"body\\\": \\\"\\u00d9\\u00be\\u00d8\\u00b3 \\u00d8\\u00a7\\u00d8\\u00b2 \\u00d9\\u00be\\u00d8\\u00ae\\u00d8\\u00aa\\u00d8\\u008c \\u00da\\u00a9\\u00db\\u008c\\u00da\\u00a9 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a7\\u00d8\\u00b2 \\u00d9\\u0081\\u00d8\\u00b1 \\u00d8\\u00ae\\u00d8\\u00a7\\u00d8\\u00b1\\u00d8\\u00ac \\u00da\\u00a9\\u00d8\\u00b1\\u00d8\\u00af\\u00d9\\u0087 \\u00d9\\u0088 \\u00d8\\u00a8\\u00da\\u00af\\u00d8\\u00b0\\u00d8\\u00a7\\u00d8\\u00b1\\u00db\\u008c\\u00d8\\u00af \\u00d8\\u00ae\\u00d9\\u0086\\u00da\\u00a9 \\u00d8\\u00b4\\u00d9\\u0088\\u00d8\\u00af. \\u00d8\\u00b3\\u00d9\\u00be\\u00d8\\u00b3 \\u00d8\\u00a8\\u00d8\\u00a7 \\u00d9\\u00be\\u00d9\\u0088\\u00d8\\u00af\\u00d8\\u00b1 \\u00d9\\u0082\\u00d9\\u0086\\u00d8\\u00af \\u00db\\u008c\\u00d8\\u00a7 \\u00d8\\u00ae\\u00d8\\u00a7\\u00d9\\u0085\\u00d9\\u0087 \\u00d8\\u00aa\\u00d8\\u00b2\\u00d8\\u00a6\\u00db\\u008c\\u00d9\\u0086 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af \\u00d9\\u0088 \\u00d8\\u00b3\\u00d8\\u00b1\\u00d9\\u0088 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af.\\\"\\n    }\\n  ]\\n}\"',NULL,'deepseek-local','2026-06-10 11:53:02','2026-06-10 10:23:38','2026-06-10 11:53:21'),(19,'procedure','steps','خرید قسطی کالا',NULL,5,'done','\"{\\n  \\\"title\\\": \\\"\\u00d9\\u0086\\u00d8\\u00ad\\u00d9\\u0088\\u00d9\\u0087 \\u00d8\\u00af\\u00d8\\u00b1\\u00d8\\u00b3\\u00d8\\u00aa \\u00da\\u00a9\\u00d8\\u00b1\\u00d8\\u00af\\u00d9\\u0086 \\u00db\\u008c\\u00da\\u00a9 \\u00d9\\u0082\\u00d9\\u0087\\u00d9\\u0088\\u00d9\\u0087 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d9\\u00be\\u00d8\\u00b1\\u00d8\\u00b3\\u00d9\\u0088\\\",\\n  \\\"excerpt\\\": \\\"\\u00d8\\u00a7\\u00db\\u008c\\u00d9\\u0086 \\u00d8\\u00b1\\u00d8\\u00a7\\u00d9\\u0087\\u00d9\\u0086\\u00d9\\u0085\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d9\\u0087 \\u00d8\\u00b4\\u00d9\\u0085\\u00d8\\u00a7 \\u00d9\\u0086\\u00d8\\u00b4\\u00d8\\u00a7\\u00d9\\u0086 \\u00d9\\u0085\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00d8\\u00af\\u00d9\\u0087\\u00d8\\u00af \\u00da\\u00a9\\u00d9\\u0087 \\u00da\\u0086\\u00da\\u00af\\u00d9\\u0088\\u00d9\\u0086\\u00d9\\u0087 \\u00db\\u008c\\u00da\\u00a9 \\u00d9\\u0082\\u00d9\\u0087\\u00d9\\u0088\\u00d9\\u0087 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d9\\u00be\\u00d8\\u00b1\\u00d8\\u00b3\\u00d9\\u0088\\u00db\\u008c \\u00d8\\u00b9\\u00d8\\u00a7\\u00d9\\u0084\\u00db\\u008c \\u00d8\\u00af\\u00d8\\u00b1 \\u00d8\\u00ae\\u00d8\\u00a7\\u00d9\\u0086\\u00d9\\u0087 \\u00d8\\u00aa\\u00d9\\u0087\\u00db\\u008c\\u00d9\\u0087 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af.\\\",\\n  \\\"steps\\\": [\\n    {\\n      \\\"title\\\": \\\"\\u00d8\\u00a2\\u00d9\\u0085\\u00d8\\u00a7\\u00d8\\u00af\\u00d9\\u0087\\u00e2\\u0080\\u008c\\u00d8\\u00b3\\u00d8\\u00a7\\u00d8\\u00b2\\u00db\\u008c \\u00d8\\u00af\\u00d8\\u00b3\\u00d8\\u00aa\\u00da\\u00af\\u00d8\\u00a7\\u00d9\\u0087 \\u00d9\\u0088 \\u00d9\\u0085\\u00d9\\u0088\\u00d8\\u00a7\\u00d8\\u00af \\u00d8\\u00a7\\u00d9\\u0088\\u00d9\\u0084\\u00db\\u008c\\u00d9\\u0087\\\",\\n      \\\"body\\\": \\\"\\u00d8\\u00af\\u00d8\\u00b3\\u00d8\\u00aa\\u00da\\u00af\\u00d8\\u00a7\\u00d9\\u0087 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d9\\u00be\\u00d8\\u00b1\\u00d8\\u00b3\\u00d9\\u0088\\u00d8\\u00b3\\u00d8\\u00a7\\u00d8\\u00b2 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00b1\\u00d9\\u0088\\u00d8\\u00b4\\u00d9\\u0086 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af \\u00d8\\u00aa\\u00d8\\u00a7 \\u00da\\u00af\\u00d8\\u00b1\\u00d9\\u0085 \\u00d8\\u00b4\\u00d9\\u0088\\u00d8\\u00af. \\u00d8\\u00af\\u00d8\\u00a7\\u00d9\\u0086\\u00d9\\u0087\\u00e2\\u0080\\u008c\\u00d9\\u0087\\u00d8\\u00a7\\u00db\\u008c \\u00d9\\u0082\\u00d9\\u0087\\u00d9\\u0088\\u00d9\\u0087 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a2\\u00d8\\u00b3\\u00db\\u008c\\u00d8\\u00a7\\u00d8\\u00a8 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af \\u00d8\\u00aa\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d9\\u0087 \\u00d9\\u00be\\u00d9\\u0088\\u00d8\\u00af\\u00d8\\u00b1\\u00db\\u008c \\u00d9\\u0086\\u00d8\\u00b1\\u00d9\\u0085 \\u00d8\\u00aa\\u00d8\\u00a8\\u00d8\\u00af\\u00db\\u008c\\u00d9\\u0084 \\u00d8\\u00b4\\u00d9\\u0088\\u00d8\\u00af. \\u00d8\\u00ad\\u00d8\\u00af\\u00d9\\u0088\\u00d8\\u00af 18 \\u00d8\\u00aa\\u00d8\\u00a7 20 \\u00da\\u00af\\u00d8\\u00b1\\u00d9\\u0085 \\u00d9\\u0082\\u00d9\\u0087\\u00d9\\u0088\\u00d9\\u0087 \\u00d8\\u00a8\\u00d8\\u00b1\\u00d8\\u00a7\\u00db\\u008c \\u00db\\u008c\\u00da\\u00a9 \\u00d8\\u00af\\u00d9\\u0088\\u00d8\\u00b2 \\u00d8\\u00af\\u00d9\\u0088\\u00d8\\u00a8\\u00d9\\u0084 \\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00a7\\u00d8\\u00b2 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d9\\u0081\\u00d8\\u00b4\\u00d8\\u00b1\\u00d8\\u00af\\u00d9\\u0087\\u00e2\\u0080\\u008c\\u00d8\\u00b3\\u00d8\\u00a7\\u00d8\\u00b2\\u00db\\u008c \\u00d9\\u0082\\u00d9\\u0087\\u00d9\\u0088\\u00d9\\u0087\\\",\\n      \\\"body\\\": \\\"\\u00d9\\u00be\\u00d9\\u0088\\u00d8\\u00af\\u00d8\\u00b1 \\u00d9\\u0082\\u00d9\\u0087\\u00d9\\u0088\\u00d9\\u0087 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d9\\u0087 \\u00d8\\u00b5\\u00d9\\u0088\\u00d8\\u00b1\\u00d8\\u00aa \\u00db\\u008c\\u00da\\u00a9\\u00d9\\u0086\\u00d9\\u0088\\u00d8\\u00a7\\u00d8\\u00ae\\u00d8\\u00aa \\u00d8\\u00af\\u00d8\\u00b1 \\u00d9\\u00be\\u00d8\\u00b1\\u00d8\\u00aa\\u00d8\\u00a7\\u00d9\\u0081\\u00db\\u008c\\u00d9\\u0084\\u00d8\\u00aa\\u00d8\\u00b1 \\u00d8\\u00a8\\u00d8\\u00b1\\u00db\\u008c\\u00d8\\u00b2\\u00db\\u008c\\u00d8\\u00af \\u00d9\\u0088 \\u00d8\\u00a8\\u00d8\\u00a7 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa\\u00d9\\u0081\\u00d8\\u00a7\\u00d8\\u00af\\u00d9\\u0087 \\u00d8\\u00a7\\u00d8\\u00b2 \\u00d8\\u00aa\\u00d9\\u0085\\u00d9\\u00be\\u00d8\\u00b1 \\u00d8\\u00a8\\u00d8\\u00a7 \\u00d9\\u0081\\u00d8\\u00b4\\u00d8\\u00a7\\u00d8\\u00b1 \\u00d8\\u00ad\\u00d8\\u00af\\u00d9\\u0088\\u00d8\\u00af 15 \\u00d8\\u00aa\\u00d8\\u00a7 20 \\u00da\\u00a9\\u00db\\u008c\\u00d9\\u0084\\u00d9\\u0088\\u00da\\u00af\\u00d8\\u00b1\\u00d9\\u0085 \\u00d8\\u00a2\\u00d9\\u0086 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d9\\u0081\\u00d8\\u00b4\\u00d8\\u00b1\\u00d8\\u00af\\u00d9\\u0087 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af \\u00d8\\u00aa\\u00d8\\u00a7 \\u00d8\\u00b3\\u00d8\\u00b7\\u00d8\\u00ad \\u00d8\\u00b5\\u00d8\\u00a7\\u00d9\\u0081 \\u00d8\\u00b4\\u00d9\\u0088\\u00d8\\u00af.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d9\\u0082\\u00d8\\u00b1\\u00d8\\u00a7\\u00d8\\u00b1 \\u00d8\\u00af\\u00d8\\u00a7\\u00d8\\u00af\\u00d9\\u0086 \\u00d9\\u00be\\u00d8\\u00b1\\u00d8\\u00aa\\u00d8\\u00a7\\u00d9\\u0081\\u00db\\u008c\\u00d9\\u0084\\u00d8\\u00aa\\u00d8\\u00b1 \\u00d8\\u00af\\u00d8\\u00b1 \\u00d8\\u00af\\u00d8\\u00b3\\u00d8\\u00aa\\u00da\\u00af\\u00d8\\u00a7\\u00d9\\u0087\\\",\\n      \\\"body\\\": \\\"\\u00d9\\u00be\\u00d8\\u00b1\\u00d8\\u00aa\\u00d8\\u00a7\\u00d9\\u0081\\u00db\\u008c\\u00d9\\u0084\\u00d8\\u00aa\\u00d8\\u00b1 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00af\\u00d8\\u00b1 \\u00d9\\u0087\\u00d8\\u00af\\u00da\\u00af\\u00d8\\u00b1\\u00d9\\u0088\\u00d9\\u00be \\u00d8\\u00af\\u00d8\\u00b3\\u00d8\\u00aa\\u00da\\u00af\\u00d8\\u00a7\\u00d9\\u0087 \\u00d9\\u0082\\u00d8\\u00b1\\u00d8\\u00a7\\u00d8\\u00b1 \\u00d8\\u00af\\u00d9\\u0087\\u00db\\u008c\\u00d8\\u00af \\u00d9\\u0088 \\u00d8\\u00a2\\u00d9\\u0086 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a8\\u00da\\u0086\\u00d8\\u00b1\\u00d8\\u00ae\\u00d8\\u00a7\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af \\u00d8\\u00aa\\u00d8\\u00a7 \\u00d9\\u0085\\u00d8\\u00ad\\u00da\\u00a9\\u00d9\\u0085 \\u00d8\\u00b4\\u00d9\\u0088\\u00d8\\u00af. \\u00d9\\u0081\\u00d9\\u0086\\u00d8\\u00ac\\u00d8\\u00a7\\u00d9\\u0086 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00b2\\u00db\\u008c\\u00d8\\u00b1 \\u00d8\\u00ae\\u00d8\\u00b1\\u00d9\\u0088\\u00d8\\u00ac\\u00db\\u008c \\u00d8\\u00a7\\u00d8\\u00b3\\u00d9\\u00be\\u00d8\\u00b1\\u00d8\\u00b3\\u00d9\\u0088 \\u00d9\\u0082\\u00d8\\u00b1\\u00d8\\u00a7\\u00d8\\u00b1 \\u00d8\\u00af\\u00d9\\u0087\\u00db\\u008c\\u00d8\\u00af.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d8\\u00b4\\u00d8\\u00b1\\u00d9\\u0088\\u00d8\\u00b9 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa\\u00d8\\u00ae\\u00d8\\u00b1\\u00d8\\u00a7\\u00d8\\u00ac \\u00d8\\u00a7\\u00d8\\u00b3\\u00d9\\u00be\\u00d8\\u00b1\\u00d8\\u00b3\\u00d9\\u0088\\\",\\n      \\\"body\\\": \\\"\\u00d8\\u00af\\u00da\\u00a9\\u00d9\\u0085\\u00d9\\u0087 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa\\u00d8\\u00ae\\u00d8\\u00b1\\u00d8\\u00a7\\u00d8\\u00ac \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d9\\u0081\\u00d8\\u00b4\\u00d8\\u00a7\\u00d8\\u00b1 \\u00d8\\u00af\\u00d9\\u0087\\u00db\\u008c\\u00d8\\u00af. \\u00d8\\u00b2\\u00d9\\u0085\\u00d8\\u00a7\\u00d9\\u0086 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa\\u00d8\\u00ae\\u00d8\\u00b1\\u00d8\\u00a7\\u00d8\\u00ac \\u00d8\\u00a8\\u00d8\\u00a7\\u00db\\u008c\\u00d8\\u00af \\u00d8\\u00ad\\u00d8\\u00af\\u00d9\\u0088\\u00d8\\u00af 25 \\u00d8\\u00aa\\u00d8\\u00a7 30 \\u00d8\\u00ab\\u00d8\\u00a7\\u00d9\\u0086\\u00db\\u008c\\u00d9\\u0087 \\u00d8\\u00a8\\u00d8\\u00a7\\u00d8\\u00b4\\u00d8\\u00af \\u00d9\\u0088 \\u00d8\\u00ad\\u00d8\\u00ac\\u00d9\\u0085 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d9\\u00be\\u00d8\\u00b1\\u00d8\\u00b3\\u00d9\\u0088 \\u00d8\\u00ad\\u00d8\\u00af\\u00d9\\u0088\\u00d8\\u00af 30 \\u00d9\\u0085\\u00db\\u008c\\u00d9\\u0084\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00d9\\u0084\\u00db\\u008c\\u00d8\\u00aa\\u00d8\\u00b1 \\u00d8\\u00a8\\u00d8\\u00b1\\u00d8\\u00a7\\u00db\\u008c \\u00db\\u008c\\u00da\\u00a9 \\u00d8\\u00b4\\u00d8\\u00a7\\u00d8\\u00aa \\u00d8\\u00af\\u00d9\\u0088\\u00d8\\u00a8\\u00d9\\u0084.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d8\\u00a8\\u00d8\\u00b1\\u00d8\\u00b1\\u00d8\\u00b3\\u00db\\u008c \\u00d9\\u0088 \\u00d8\\u00b3\\u00d8\\u00b1\\u00d9\\u0088 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d9\\u00be\\u00d8\\u00b1\\u00d8\\u00b3\\u00d9\\u0088\\\",\\n      \\\"body\\\": \\\"\\u00d8\\u00a7\\u00d8\\u00b3\\u00d9\\u00be\\u00d8\\u00b1\\u00d8\\u00b3\\u00d9\\u0088\\u00db\\u008c \\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa\\u00d8\\u00ae\\u00d8\\u00b1\\u00d8\\u00a7\\u00d8\\u00ac \\u00d8\\u00b4\\u00d8\\u00af\\u00d9\\u0087 \\u00d8\\u00a8\\u00d8\\u00a7\\u00db\\u008c\\u00d8\\u00af \\u00da\\u00a9\\u00d8\\u00b1\\u00d9\\u0085\\u00d8\\u00a7\\u00db\\u008c \\u00d8\\u00b7\\u00d9\\u0084\\u00d8\\u00a7\\u00db\\u008c\\u00db\\u008c \\u00d9\\u0088 \\u00d8\\u00ba\\u00d9\\u0084\\u00db\\u008c\\u00d8\\u00b8 \\u00d8\\u00af\\u00d8\\u00a7\\u00d8\\u00b4\\u00d8\\u00aa\\u00d9\\u0087 \\u00d8\\u00a8\\u00d8\\u00a7\\u00d8\\u00b4\\u00d8\\u00af. \\u00d8\\u00a7\\u00da\\u00af\\u00d8\\u00b1 \\u00d8\\u00b2\\u00d9\\u0088\\u00d8\\u00af\\u00d8\\u00aa\\u00d8\\u00b1 \\u00d8\\u00a7\\u00d8\\u00b2 20 \\u00d8\\u00ab\\u00d8\\u00a7\\u00d9\\u0086\\u00db\\u008c\\u00d9\\u0087 \\u00d8\\u00aa\\u00d9\\u0085\\u00d8\\u00a7\\u00d9\\u0085 \\u00d8\\u00b4\\u00d8\\u00af\\u00d8\\u008c \\u00d8\\u00a2\\u00d8\\u00b3\\u00db\\u008c\\u00d8\\u00a7\\u00d8\\u00a8 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00b1\\u00db\\u008c\\u00d8\\u00b2\\u00d8\\u00aa\\u00d8\\u00b1 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af. \\u00d8\\u00a7\\u00da\\u00af\\u00d8\\u00b1 \\u00d8\\u00af\\u00db\\u008c\\u00d8\\u00b1\\u00d8\\u00aa\\u00d8\\u00b1 \\u00d8\\u00a7\\u00d8\\u00b2 30 \\u00d8\\u00ab\\u00d8\\u00a7\\u00d9\\u0086\\u00db\\u008c\\u00d9\\u0087 \\u00d8\\u00aa\\u00d9\\u0085\\u00d8\\u00a7\\u00d9\\u0085 \\u00d8\\u00b4\\u00d8\\u00af\\u00d8\\u008c \\u00d8\\u00a2\\u00d8\\u00b3\\u00db\\u008c\\u00d8\\u00a7\\u00d8\\u00a8 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00af\\u00d8\\u00b1\\u00d8\\u00b4\\u00d8\\u00aa\\u00e2\\u0080\\u008c\\u00d8\\u00aa\\u00d8\\u00b1 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af. \\u00d8\\u00a7\\u00d8\\u00b3\\u00d9\\u00be\\u00d8\\u00b1\\u00d8\\u00b3\\u00d9\\u0088 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d9\\u0084\\u00d8\\u00a7\\u00d9\\u0081\\u00d8\\u00a7\\u00d8\\u00b5\\u00d9\\u0084\\u00d9\\u0087 \\u00d8\\u00b3\\u00d8\\u00b1\\u00d9\\u0088 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af.\\\"\\n    }\\n  ]\\n}\"',NULL,'deepseek-local','2026-06-10 11:53:02','2026-06-10 10:28:59','2026-06-10 11:53:27'),(20,'procedure','steps','خرید قسطی کالا',NULL,5,'done','\"{\\n  \\\"title\\\": \\\"\\u00d8\\u00b7\\u00d8\\u00b1\\u00d8\\u00b2 \\u00d8\\u00aa\\u00d9\\u0087\\u00db\\u008c\\u00d9\\u0087 \\u00d9\\u0082\\u00d9\\u0087\\u00d9\\u0088\\u00d9\\u0087 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d9\\u00be\\u00d8\\u00b1\\u00d8\\u00b3\\u00d9\\u0088\\\",\\n  \\\"excerpt\\\": \\\"\\u00d8\\u00a7\\u00db\\u008c\\u00d9\\u0086 \\u00d8\\u00b1\\u00d8\\u00a7\\u00d9\\u0087\\u00d9\\u0086\\u00d9\\u0085\\u00d8\\u00a7 \\u00d9\\u0085\\u00d8\\u00b1\\u00d8\\u00a7\\u00d8\\u00ad\\u00d9\\u0084 \\u00d8\\u00af\\u00d8\\u00b1\\u00d8\\u00b3\\u00d8\\u00aa \\u00da\\u00a9\\u00d8\\u00b1\\u00d8\\u00af\\u00d9\\u0086 \\u00db\\u008c\\u00da\\u00a9 \\u00d9\\u0081\\u00d9\\u0086\\u00d8\\u00ac\\u00d8\\u00a7\\u00d9\\u0086 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d9\\u00be\\u00d8\\u00b1\\u00d8\\u00b3\\u00d9\\u0088\\u00db\\u008c \\u00d8\\u00b9\\u00d8\\u00a7\\u00d9\\u0084\\u00db\\u008c \\u00d8\\u00af\\u00d8\\u00b1 \\u00d8\\u00ae\\u00d8\\u00a7\\u00d9\\u0086\\u00d9\\u0087 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a2\\u00d9\\u0085\\u00d9\\u0088\\u00d8\\u00b2\\u00d8\\u00b4 \\u00d9\\u0085\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00d8\\u00af\\u00d9\\u0087\\u00d8\\u00af.\\\",\\n  \\\"steps\\\": [\\n    {\\n      \\\"title\\\": \\\"\\u00d8\\u00a2\\u00d9\\u0085\\u00d8\\u00a7\\u00d8\\u00af\\u00d9\\u0087\\u00e2\\u0080\\u008c\\u00d8\\u00b3\\u00d8\\u00a7\\u00d8\\u00b2\\u00db\\u008c \\u00d8\\u00af\\u00d8\\u00b3\\u00d8\\u00aa\\u00da\\u00af\\u00d8\\u00a7\\u00d9\\u0087 \\u00d9\\u0088 \\u00d9\\u0085\\u00d9\\u0088\\u00d8\\u00a7\\u00d8\\u00af \\u00d8\\u00a7\\u00d9\\u0088\\u00d9\\u0084\\u00db\\u008c\\u00d9\\u0087\\\",\\n      \\\"body\\\": \\\"\\u00d8\\u00a7\\u00d8\\u00a8\\u00d8\\u00aa\\u00d8\\u00af\\u00d8\\u00a7 \\u00d8\\u00af\\u00d8\\u00b3\\u00d8\\u00aa\\u00da\\u00af\\u00d8\\u00a7\\u00d9\\u0087 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d9\\u00be\\u00d8\\u00b1\\u00d8\\u00b3\\u00d9\\u0088\\u00d8\\u00b3\\u00d8\\u00a7\\u00d8\\u00b2 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00b1\\u00d9\\u0088\\u00d8\\u00b4\\u00d9\\u0086 \\u00da\\u00a9\\u00d8\\u00b1\\u00d8\\u00af\\u00d9\\u0087 \\u00d9\\u0088 \\u00d8\\u00a7\\u00d8\\u00ac\\u00d8\\u00a7\\u00d8\\u00b2\\u00d9\\u0087 \\u00d8\\u00af\\u00d9\\u0087\\u00db\\u008c\\u00d8\\u00af \\u00d8\\u00aa\\u00d8\\u00a7 \\u00da\\u00af\\u00d8\\u00b1\\u00d9\\u0085 \\u00d8\\u00b4\\u00d9\\u0088\\u00d8\\u00af. \\u00d8\\u00af\\u00d8\\u00b1 \\u00d8\\u00a7\\u00db\\u008c\\u00d9\\u0086 \\u00d8\\u00ad\\u00db\\u008c\\u00d9\\u0086\\u00d8\\u008c \\u00d8\\u00af\\u00d8\\u00a7\\u00d9\\u0086\\u00d9\\u0087\\u00e2\\u0080\\u008c\\u00d9\\u0087\\u00d8\\u00a7\\u00db\\u008c \\u00d9\\u0082\\u00d9\\u0087\\u00d9\\u0088\\u00d9\\u0087 \\u00d8\\u00aa\\u00d8\\u00a7\\u00d8\\u00b2\\u00d9\\u0087 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a2\\u00d8\\u00b3\\u00db\\u008c\\u00d8\\u00a7\\u00d8\\u00a8 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af \\u00d8\\u00aa\\u00d8\\u00a7 \\u00d9\\u00be\\u00d9\\u0088\\u00d8\\u00af\\u00d8\\u00b1\\u00db\\u008c \\u00d8\\u00b1\\u00db\\u008c\\u00d8\\u00b2 \\u00d9\\u0088 \\u00db\\u008c\\u00da\\u00a9\\u00d8\\u00af\\u00d8\\u00b3\\u00d8\\u00aa \\u00d8\\u00a8\\u00d9\\u0087 \\u00d8\\u00af\\u00d8\\u00b3\\u00d8\\u00aa \\u00d8\\u00a2\\u00db\\u008c\\u00d8\\u00af. \\u00d8\\u00a8\\u00d8\\u00b1\\u00d8\\u00a7\\u00db\\u008c \\u00db\\u008c\\u00da\\u00a9 \\u00d8\\u00b4\\u00d8\\u00a7\\u00d8\\u00aa \\u00d8\\u00a7\\u00d8\\u00b3\\u00d9\\u00be\\u00d8\\u00b1\\u00d8\\u00b3\\u00d9\\u0088\\u00d8\\u008c \\u00d8\\u00ad\\u00d8\\u00af\\u00d9\\u0088\\u00d8\\u00af \\u00db\\u00b7 \\u00d8\\u00aa\\u00d8\\u00a7 \\u00db\\u00b9 \\u00da\\u00af\\u00d8\\u00b1\\u00d9\\u0085 \\u00d9\\u0082\\u00d9\\u0087\\u00d9\\u0088\\u00d9\\u0087 \\u00d8\\u00a2\\u00d8\\u00b3\\u00db\\u008c\\u00d8\\u00a7\\u00d8\\u00a8 \\u00d8\\u00b4\\u00d8\\u00af\\u00d9\\u0087 \\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00a7\\u00d8\\u00b2 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d9\\u00be\\u00d8\\u00b1 \\u00da\\u00a9\\u00d8\\u00b1\\u00d8\\u00af\\u00d9\\u0086 \\u00d9\\u00be\\u00d8\\u00b1\\u00d8\\u00aa\\u00d8\\u00a7\\u00d9\\u0081\\u00db\\u008c\\u00d9\\u0084\\u00d8\\u00aa\\u00d8\\u00b1 \\u00d9\\u0088 \\u00d8\\u00aa\\u00d9\\u0085\\u00d9\\u00be\\u00d8\\u00b1 \\u00da\\u00a9\\u00d8\\u00b1\\u00d8\\u00af\\u00d9\\u0086\\\",\\n      \\\"body\\\": \\\"\\u00d9\\u00be\\u00d8\\u00b1\\u00d8\\u00aa\\u00d8\\u00a7\\u00d9\\u0081\\u00db\\u008c\\u00d9\\u0084\\u00d8\\u00aa\\u00d8\\u00b1 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a7\\u00d8\\u00b2 \\u00d8\\u00af\\u00d8\\u00b3\\u00d8\\u00aa\\u00da\\u00af\\u00d8\\u00a7\\u00d9\\u0087 \\u00d8\\u00ae\\u00d8\\u00a7\\u00d8\\u00b1\\u00d8\\u00ac \\u00da\\u00a9\\u00d8\\u00b1\\u00d8\\u00af\\u00d9\\u0087 \\u00d9\\u0088 \\u00d9\\u0082\\u00d9\\u0087\\u00d9\\u0088\\u00d9\\u0087 \\u00d8\\u00a2\\u00d8\\u00b3\\u00db\\u008c\\u00d8\\u00a7\\u00d8\\u00a8 \\u00d8\\u00b4\\u00d8\\u00af\\u00d9\\u0087 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00af\\u00d8\\u00a7\\u00d8\\u00ae\\u00d9\\u0084 \\u00d8\\u00a2\\u00d9\\u0086 \\u00d8\\u00a8\\u00d8\\u00b1\\u00db\\u008c\\u00d8\\u00b2\\u00db\\u008c\\u00d8\\u00af. \\u00d8\\u00a8\\u00d8\\u00a7 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa\\u00d9\\u0081\\u00d8\\u00a7\\u00d8\\u00af\\u00d9\\u0087 \\u00d8\\u00a7\\u00d8\\u00b2 \\u00db\\u008c\\u00da\\u00a9 \\u00d8\\u00a7\\u00d8\\u00a8\\u00d8\\u00b2\\u00d8\\u00a7\\u00d8\\u00b1 \\u00d8\\u00aa\\u00d9\\u0085\\u00d9\\u00be\\u00d8\\u00b1\\u00d8\\u008c \\u00d9\\u0082\\u00d9\\u0087\\u00d9\\u0088\\u00d9\\u0087 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d9\\u0085\\u00d8\\u00ad\\u00da\\u00a9\\u00d9\\u0085 \\u00d9\\u0088 \\u00db\\u008c\\u00da\\u00a9\\u00d9\\u0086\\u00d9\\u0088\\u00d8\\u00a7\\u00d8\\u00ae\\u00d8\\u00aa \\u00d9\\u0081\\u00d8\\u00b4\\u00d8\\u00a7\\u00d8\\u00b1 \\u00d8\\u00af\\u00d9\\u0087\\u00db\\u008c\\u00d8\\u00af. \\u00d9\\u0081\\u00d8\\u00b4\\u00d8\\u00a7\\u00d8\\u00b1 \\u00d8\\u00a8\\u00d8\\u00a7\\u00db\\u008c\\u00d8\\u00af \\u00d8\\u00ad\\u00d8\\u00af\\u00d9\\u0088\\u00d8\\u00af \\u00db\\u00b1\\u00db\\u00b5 \\u00d8\\u00aa\\u00d8\\u00a7 \\u00db\\u00b2\\u00db\\u00b0 \\u00da\\u00a9\\u00db\\u008c\\u00d9\\u0084\\u00d9\\u0088\\u00da\\u00af\\u00d8\\u00b1\\u00d9\\u0085 \\u00d8\\u00a8\\u00d8\\u00a7\\u00d8\\u00b4\\u00d8\\u00af \\u00d8\\u00aa\\u00d8\\u00a7 \\u00d8\\u00b3\\u00d8\\u00b7\\u00d8\\u00ad \\u00d9\\u0082\\u00d9\\u0087\\u00d9\\u0088\\u00d9\\u0087 \\u00d8\\u00b5\\u00d8\\u00a7\\u00d9\\u0081 \\u00d9\\u0088 \\u00d9\\u0081\\u00d8\\u00b4\\u00d8\\u00b1\\u00d8\\u00af\\u00d9\\u0087 \\u00d8\\u00b4\\u00d9\\u0088\\u00d8\\u00af.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d9\\u0086\\u00d8\\u00b5\\u00d8\\u00a8 \\u00d9\\u00be\\u00d8\\u00b1\\u00d8\\u00aa\\u00d8\\u00a7\\u00d9\\u0081\\u00db\\u008c\\u00d9\\u0084\\u00d8\\u00aa\\u00d8\\u00b1 \\u00d9\\u0088 \\u00d8\\u00b4\\u00d8\\u00b1\\u00d9\\u0088\\u00d8\\u00b9 \\u00d8\\u00b9\\u00d8\\u00b5\\u00d8\\u00a7\\u00d8\\u00b1\\u00d9\\u0087\\u00e2\\u0080\\u008c\\u00da\\u00af\\u00db\\u008c\\u00d8\\u00b1\\u00db\\u008c\\\",\\n      \\\"body\\\": \\\"\\u00d9\\u00be\\u00d8\\u00b1\\u00d8\\u00aa\\u00d8\\u00a7\\u00d9\\u0081\\u00db\\u008c\\u00d9\\u0084\\u00d8\\u00aa\\u00d8\\u00b1 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d9\\u0087 \\u00d8\\u00af\\u00d8\\u00b3\\u00d8\\u00aa\\u00da\\u00af\\u00d8\\u00a7\\u00d9\\u0087 \\u00d9\\u0085\\u00d8\\u00aa\\u00d8\\u00b5\\u00d9\\u0084 \\u00da\\u00a9\\u00d8\\u00b1\\u00d8\\u00af\\u00d9\\u0087 \\u00d9\\u0088 \\u00d8\\u00af\\u00d8\\u00b3\\u00d8\\u00aa\\u00d9\\u0087 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d9\\u0085\\u00d8\\u00ad\\u00da\\u00a9\\u00d9\\u0085 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af. \\u00db\\u008c\\u00da\\u00a9 \\u00d9\\u0081\\u00d9\\u0086\\u00d8\\u00ac\\u00d8\\u00a7\\u00d9\\u0086 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d9\\u00be\\u00d8\\u00b1\\u00d8\\u00b3\\u00d9\\u0088 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00b2\\u00db\\u008c\\u00d8\\u00b1 \\u00d8\\u00ae\\u00d8\\u00b1\\u00d9\\u0088\\u00d8\\u00ac\\u00db\\u008c \\u00d9\\u0082\\u00d8\\u00b1\\u00d8\\u00a7\\u00d8\\u00b1 \\u00d8\\u00af\\u00d9\\u0087\\u00db\\u008c\\u00d8\\u00af. \\u00d8\\u00b3\\u00d9\\u00be\\u00d8\\u00b3 \\u00d8\\u00af\\u00da\\u00a9\\u00d9\\u0085\\u00d9\\u0087 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa\\u00d8\\u00ae\\u00d8\\u00b1\\u00d8\\u00a7\\u00d8\\u00ac \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d9\\u0081\\u00d8\\u00b4\\u00d8\\u00a7\\u00d8\\u00b1 \\u00d8\\u00af\\u00d9\\u0087\\u00db\\u008c\\u00d8\\u00af \\u00d8\\u00aa\\u00d8\\u00a7 \\u00d8\\u00a2\\u00d8\\u00a8 \\u00d8\\u00af\\u00d8\\u00a7\\u00d8\\u00ba \\u00d8\\u00a7\\u00d8\\u00b2 \\u00d9\\u0085\\u00db\\u008c\\u00d8\\u00a7\\u00d9\\u0086 \\u00d9\\u0082\\u00d9\\u0087\\u00d9\\u0088\\u00d9\\u0087 \\u00d8\\u00b9\\u00d8\\u00a8\\u00d9\\u0088\\u00d8\\u00b1 \\u00da\\u00a9\\u00d9\\u0086\\u00d8\\u00af. \\u00d8\\u00b2\\u00d9\\u0085\\u00d8\\u00a7\\u00d9\\u0086 \\u00d8\\u00b9\\u00d8\\u00b5\\u00d8\\u00a7\\u00d8\\u00b1\\u00d9\\u0087\\u00e2\\u0080\\u008c\\u00da\\u00af\\u00db\\u008c\\u00d8\\u00b1\\u00db\\u008c \\u00d8\\u00a8\\u00d8\\u00a7\\u00db\\u008c\\u00d8\\u00af \\u00d8\\u00ad\\u00d8\\u00af\\u00d9\\u0088\\u00d8\\u00af \\u00db\\u00b2\\u00db\\u00b5 \\u00d8\\u00aa\\u00d8\\u00a7 \\u00db\\u00b3\\u00db\\u00b0 \\u00d8\\u00ab\\u00d8\\u00a7\\u00d9\\u0086\\u00db\\u008c\\u00d9\\u0087 \\u00d8\\u00a8\\u00d8\\u00a7\\u00d8\\u00b4\\u00d8\\u00af.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d8\\u00a8\\u00d8\\u00b1\\u00d8\\u00b1\\u00d8\\u00b3\\u00db\\u008c \\u00da\\u00a9\\u00db\\u008c\\u00d9\\u0081\\u00db\\u008c\\u00d8\\u00aa \\u00d8\\u00a7\\u00d8\\u00b3\\u00d9\\u00be\\u00d8\\u00b1\\u00d8\\u00b3\\u00d9\\u0088\\\",\\n      \\\"body\\\": \\\"\\u00d8\\u00af\\u00d8\\u00b1 \\u00d8\\u00ad\\u00db\\u008c\\u00d9\\u0086 \\u00d8\\u00b9\\u00d8\\u00b5\\u00d8\\u00a7\\u00d8\\u00b1\\u00d9\\u0087\\u00e2\\u0080\\u008c\\u00da\\u00af\\u00db\\u008c\\u00d8\\u00b1\\u00db\\u008c\\u00d8\\u008c \\u00d8\\u00b1\\u00d9\\u0086\\u00da\\u00af \\u00d9\\u0088 \\u00d8\\u00ac\\u00d8\\u00b1\\u00db\\u008c\\u00d8\\u00a7\\u00d9\\u0086 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d9\\u00be\\u00d8\\u00b1\\u00d8\\u00b3\\u00d9\\u0088 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d9\\u0085\\u00d8\\u00b4\\u00d8\\u00a7\\u00d9\\u0087\\u00d8\\u00af\\u00d9\\u0087 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af. \\u00db\\u008c\\u00da\\u00a9 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d9\\u00be\\u00d8\\u00b1\\u00d8\\u00b3\\u00d9\\u0088\\u00db\\u008c \\u00d8\\u00ae\\u00d9\\u0088\\u00d8\\u00a8 \\u00d8\\u00a8\\u00d8\\u00a7\\u00db\\u008c\\u00d8\\u00af \\u00d8\\u00a7\\u00d8\\u00a8\\u00d8\\u00aa\\u00d8\\u00af\\u00d8\\u00a7 \\u00d8\\u00b1\\u00d9\\u0086\\u00da\\u00af\\u00db\\u008c \\u00d8\\u00aa\\u00db\\u008c\\u00d8\\u00b1\\u00d9\\u0087 \\u00d9\\u0088 \\u00d8\\u00ba\\u00d9\\u0084\\u00db\\u008c\\u00d8\\u00b8 (\\u00da\\u00a9\\u00d9\\u0090\\u00d8\\u00b1\\u00d9\\u0085\\u00d8\\u00a7) \\u00d8\\u00af\\u00d8\\u00a7\\u00d8\\u00b4\\u00d8\\u00aa\\u00d9\\u0087 \\u00d8\\u00a8\\u00d8\\u00a7\\u00d8\\u00b4\\u00d8\\u00af \\u00d9\\u0088 \\u00d8\\u00b3\\u00d9\\u00be\\u00d8\\u00b3 \\u00d8\\u00a8\\u00d9\\u0087 \\u00d9\\u0082\\u00d9\\u0087\\u00d9\\u0088\\u00d9\\u0087\\u00e2\\u0080\\u008c\\u00d8\\u00a7\\u00db\\u008c \\u00d8\\u00b7\\u00d9\\u0084\\u00d8\\u00a7\\u00db\\u008c\\u00db\\u008c \\u00d8\\u00aa\\u00d8\\u00a8\\u00d8\\u00af\\u00db\\u008c\\u00d9\\u0084 \\u00d8\\u00b4\\u00d9\\u0088\\u00d8\\u00af. \\u00d8\\u00ac\\u00d8\\u00b1\\u00db\\u008c\\u00d8\\u00a7\\u00d9\\u0086 \\u00d8\\u00a8\\u00d8\\u00a7\\u00db\\u008c\\u00d8\\u00af \\u00d8\\u00a2\\u00d8\\u00b1\\u00d8\\u00a7\\u00d9\\u0085 \\u00d9\\u0088 \\u00d9\\u00be\\u00db\\u008c\\u00d9\\u0088\\u00d8\\u00b3\\u00d8\\u00aa\\u00d9\\u0087 \\u00d8\\u00a8\\u00d8\\u00a7\\u00d8\\u00b4\\u00d8\\u00af\\u00d8\\u008c \\u00d9\\u0086\\u00d9\\u0087 \\u00d8\\u00ae\\u00db\\u008c\\u00d9\\u0084\\u00db\\u008c \\u00d8\\u00b3\\u00d8\\u00b1\\u00db\\u008c\\u00d8\\u00b9 \\u00d9\\u0088 \\u00d9\\u0086\\u00d9\\u0087 \\u00d8\\u00ae\\u00db\\u008c\\u00d9\\u0084\\u00db\\u008c \\u00da\\u00a9\\u00d9\\u0086\\u00d8\\u00af.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d8\\u00b3\\u00d8\\u00b1\\u00d9\\u0088 \\u00d9\\u0088 \\u00d9\\u0084\\u00d8\\u00b0\\u00d8\\u00aa \\u00d8\\u00a8\\u00d8\\u00b1\\u00d8\\u00af\\u00d9\\u0086\\\",\\n      \\\"body\\\": \\\"\\u00d9\\u00be\\u00d8\\u00b3 \\u00d8\\u00a7\\u00d8\\u00b2 \\u00d8\\u00a7\\u00d8\\u00aa\\u00d9\\u0085\\u00d8\\u00a7\\u00d9\\u0085 \\u00d8\\u00b9\\u00d8\\u00b5\\u00d8\\u00a7\\u00d8\\u00b1\\u00d9\\u0087\\u00e2\\u0080\\u008c\\u00da\\u00af\\u00db\\u008c\\u00d8\\u00b1\\u00db\\u008c\\u00d8\\u008c \\u00d9\\u0081\\u00d9\\u0086\\u00d8\\u00ac\\u00d8\\u00a7\\u00d9\\u0086 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d8\\u00b1\\u00d8\\u00af\\u00d8\\u00a7\\u00d8\\u00b4\\u00d8\\u00aa\\u00d9\\u0087 \\u00d9\\u0088 \\u00d8\\u00a8\\u00d9\\u0084\\u00d8\\u00a7\\u00d9\\u0081\\u00d8\\u00a7\\u00d8\\u00b5\\u00d9\\u0084\\u00d9\\u0087 \\u00d8\\u00b3\\u00d8\\u00b1\\u00d9\\u0088 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af. \\u00d9\\u0085\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00d8\\u00aa\\u00d9\\u0088\\u00d8\\u00a7\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af \\u00d8\\u00a7\\u00d8\\u00b3\\u00d9\\u00be\\u00d8\\u00b1\\u00d8\\u00b3\\u00d9\\u0088 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d9\\u0087 \\u00d8\\u00aa\\u00d9\\u0086\\u00d9\\u0087\\u00d8\\u00a7\\u00db\\u008c\\u00db\\u008c \\u00d8\\u00a8\\u00d9\\u0086\\u00d9\\u0088\\u00d8\\u00b4\\u00db\\u008c\\u00d8\\u00af \\u00db\\u008c\\u00d8\\u00a7 \\u00d8\\u00a7\\u00d8\\u00b2 \\u00d8\\u00a2\\u00d9\\u0086 \\u00d8\\u00a8\\u00d9\\u0087 \\u00d8\\u00b9\\u00d9\\u0086\\u00d9\\u0088\\u00d8\\u00a7\\u00d9\\u0086 \\u00d9\\u00be\\u00d8\\u00a7\\u00db\\u008c\\u00d9\\u0087 \\u00d9\\u0086\\u00d9\\u0088\\u00d8\\u00b4\\u00db\\u008c\\u00d8\\u00af\\u00d9\\u0086\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00d9\\u0087\\u00d8\\u00a7\\u00db\\u008c \\u00d8\\u00af\\u00db\\u008c\\u00da\\u00af\\u00d8\\u00b1 \\u00d9\\u0085\\u00d8\\u00a7\\u00d9\\u0086\\u00d9\\u0086\\u00d8\\u00af \\u00d9\\u0084\\u00d8\\u00a7\\u00d8\\u00aa\\u00d9\\u0087 \\u00db\\u008c\\u00d8\\u00a7 \\u00da\\u00a9\\u00d8\\u00a7\\u00d9\\u00be\\u00d9\\u0088\\u00da\\u0086\\u00db\\u008c\\u00d9\\u0086\\u00d9\\u0088 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa\\u00d9\\u0081\\u00d8\\u00a7\\u00d8\\u00af\\u00d9\\u0087 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af. \\u00d8\\u00a7\\u00d8\\u00b2 \\u00d8\\u00b7\\u00d8\\u00b9\\u00d9\\u0085 \\u00d9\\u0088 \\u00d8\\u00b9\\u00d8\\u00b7\\u00d8\\u00b1 \\u00d8\\u00a8\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00d9\\u0086\\u00d8\\u00b8\\u00db\\u008c\\u00d8\\u00b1 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d9\\u00be\\u00d8\\u00b1\\u00d8\\u00b3\\u00d9\\u0088\\u00db\\u008c \\u00d8\\u00aa\\u00d8\\u00a7\\u00d8\\u00b2\\u00d9\\u0087 \\u00d9\\u0084\\u00d8\\u00b0\\u00d8\\u00aa \\u00d8\\u00a8\\u00d8\\u00a8\\u00d8\\u00b1\\u00db\\u008c\\u00d8\\u00af!\\\"\\n    }\\n  ]\\n}\"',NULL,'deepseek-local','2026-06-10 11:50:23','2026-06-10 11:21:03','2026-06-10 11:50:33'),(21,'procedure','steps','خرید قسطی کالا',NULL,5,'done','\"{\\n  \\\"title\\\": \\\"\\u00d8\\u00b1\\u00d8\\u00a7\\u00d9\\u0087\\u00d9\\u0086\\u00d9\\u0085\\u00d8\\u00a7\\u00db\\u008c \\u00da\\u00af\\u00d8\\u00a7\\u00d9\\u0085\\u00e2\\u0080\\u008c\\u00d8\\u00a8\\u00d9\\u0087\\u00e2\\u0080\\u008c\\u00da\\u00af\\u00d8\\u00a7\\u00d9\\u0085 \\u00d8\\u00a8\\u00d8\\u00b1\\u00d8\\u00a7\\u00db\\u008c \\u00d8\\u00ad\\u00d9\\u0084 \\u00d9\\u0085\\u00d8\\u00b3\\u00d8\\u00a6\\u00d9\\u0084\\u00d9\\u0087\\\",\\n  \\\"excerpt\\\": \\\"\\u00d8\\u00af\\u00d8\\u00b1 \\u00d8\\u00a7\\u00db\\u008c\\u00d9\\u0086 \\u00d8\\u00b1\\u00d8\\u00a7\\u00d9\\u0087\\u00d9\\u0086\\u00d9\\u0085\\u00d8\\u00a7\\u00d8\\u008c \\u00d8\\u00a8\\u00d8\\u00a7 \\u00db\\u00b5 \\u00da\\u00af\\u00d8\\u00a7\\u00d9\\u0085 \\u00d8\\u00b3\\u00d8\\u00a7\\u00d8\\u00af\\u00d9\\u0087 \\u00d9\\u0088 \\u00d9\\u0085\\u00d8\\u00a4\\u00d8\\u00ab\\u00d8\\u00b1 \\u00d8\\u00a8\\u00d8\\u00b1\\u00d8\\u00a7\\u00db\\u008c \\u00d8\\u00ad\\u00d9\\u0084 \\u00d9\\u0087\\u00d8\\u00b1 \\u00d9\\u0086\\u00d9\\u0088\\u00d8\\u00b9 \\u00d9\\u0085\\u00d8\\u00b3\\u00d8\\u00a6\\u00d9\\u0084\\u00d9\\u0087\\u00e2\\u0080\\u008c\\u00d8\\u00a7\\u00db\\u008c \\u00d8\\u00a2\\u00d8\\u00b4\\u00d9\\u0086\\u00d8\\u00a7 \\u00d9\\u0085\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00d8\\u00b4\\u00d9\\u0088\\u00db\\u008c\\u00d8\\u00af.\\\",\\n  \\\"steps\\\": [\\n    {\\n      \\\"title\\\": \\\"\\u00d8\\u00aa\\u00d8\\u00b9\\u00d8\\u00b1\\u00db\\u008c\\u00d9\\u0081 \\u00d8\\u00af\\u00d9\\u0082\\u00db\\u008c\\u00d9\\u0082 \\u00d9\\u0085\\u00d8\\u00b3\\u00d8\\u00a6\\u00d9\\u0084\\u00d9\\u0087\\\",\\n      \\\"body\\\": \\\"\\u00d9\\u0085\\u00d8\\u00b3\\u00d8\\u00a6\\u00d9\\u0084\\u00d9\\u0087 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d9\\u0087 \\u00d8\\u00b1\\u00d9\\u0088\\u00d8\\u00b4\\u00d9\\u0086\\u00db\\u008c \\u00d9\\u0088 \\u00d8\\u00a8\\u00d8\\u00a7 \\u00d8\\u00ac\\u00d8\\u00b2\\u00d8\\u00a6\\u00db\\u008c\\u00d8\\u00a7\\u00d8\\u00aa \\u00da\\u00a9\\u00d8\\u00a7\\u00d9\\u0085\\u00d9\\u0084 \\u00d8\\u00aa\\u00d8\\u00b9\\u00d8\\u00b1\\u00db\\u008c\\u00d9\\u0081 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af. \\u00d9\\u0085\\u00d8\\u00b4\\u00d8\\u00ae\\u00d8\\u00b5 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af \\u00da\\u00a9\\u00d9\\u0087 \\u00da\\u0086\\u00d9\\u0087 \\u00da\\u0086\\u00db\\u008c\\u00d8\\u00b2\\u00db\\u008c \\u00d8\\u00a8\\u00d8\\u00a7\\u00db\\u008c\\u00d8\\u00af \\u00d8\\u00ad\\u00d9\\u0084 \\u00d8\\u00b4\\u00d9\\u0088\\u00d8\\u00af\\u00d8\\u008c \\u00da\\u0086\\u00d9\\u0087 \\u00d8\\u00b9\\u00d9\\u0088\\u00d8\\u00a7\\u00d9\\u0085\\u00d9\\u0084\\u00db\\u008c \\u00d8\\u00af\\u00d8\\u00b1\\u00da\\u00af\\u00db\\u008c\\u00d8\\u00b1 \\u00d9\\u0087\\u00d8\\u00b3\\u00d8\\u00aa\\u00d9\\u0086\\u00d8\\u00af \\u00d9\\u0088 \\u00d9\\u0087\\u00d8\\u00af\\u00d9\\u0081 \\u00d9\\u0086\\u00d9\\u0087\\u00d8\\u00a7\\u00db\\u008c\\u00db\\u008c \\u00da\\u0086\\u00db\\u008c\\u00d8\\u00b3\\u00d8\\u00aa.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d8\\u00ac\\u00d9\\u0085\\u00d8\\u00b9\\u00e2\\u0080\\u008c\\u00d8\\u00a2\\u00d9\\u0088\\u00d8\\u00b1\\u00db\\u008c \\u00d8\\u00a7\\u00d8\\u00b7\\u00d9\\u0084\\u00d8\\u00a7\\u00d8\\u00b9\\u00d8\\u00a7\\u00d8\\u00aa\\\",\\n      \\\"body\\\": \\\"\\u00d8\\u00aa\\u00d9\\u0085\\u00d8\\u00a7\\u00d9\\u0085 \\u00d8\\u00a7\\u00d8\\u00b7\\u00d9\\u0084\\u00d8\\u00a7\\u00d8\\u00b9\\u00d8\\u00a7\\u00d8\\u00aa \\u00d9\\u0085\\u00d8\\u00b1\\u00d8\\u00aa\\u00d8\\u00a8\\u00d8\\u00b7 \\u00d8\\u00a8\\u00d8\\u00a7 \\u00d9\\u0085\\u00d8\\u00b3\\u00d8\\u00a6\\u00d9\\u0084\\u00d9\\u0087 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00da\\u00af\\u00d8\\u00b1\\u00d8\\u00af\\u00d8\\u00a2\\u00d9\\u0088\\u00d8\\u00b1\\u00db\\u008c \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af. \\u00d8\\u00a7\\u00d8\\u00b2 \\u00d9\\u0085\\u00d9\\u0086\\u00d8\\u00a7\\u00d8\\u00a8\\u00d8\\u00b9 \\u00d9\\u0085\\u00d8\\u00b9\\u00d8\\u00aa\\u00d8\\u00a8\\u00d8\\u00b1 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa\\u00d9\\u0081\\u00d8\\u00a7\\u00d8\\u00af\\u00d9\\u0087 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af \\u00d9\\u0088 \\u00d8\\u00af\\u00d8\\u00a7\\u00d8\\u00af\\u00d9\\u0087\\u00e2\\u0080\\u008c\\u00d9\\u0087\\u00d8\\u00a7\\u00db\\u008c \\u00d9\\u0084\\u00d8\\u00a7\\u00d8\\u00b2\\u00d9\\u0085 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00ab\\u00d8\\u00a8\\u00d8\\u00aa \\u00d9\\u0086\\u00d9\\u0085\\u00d8\\u00a7\\u00db\\u008c\\u00db\\u008c\\u00d8\\u00af.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d8\\u00aa\\u00d9\\u0088\\u00d9\\u0084\\u00db\\u008c\\u00d8\\u00af \\u00da\\u00af\\u00d8\\u00b2\\u00db\\u008c\\u00d9\\u0086\\u00d9\\u0087\\u00e2\\u0080\\u008c\\u00d9\\u0087\\u00d8\\u00a7\\u00db\\u008c \\u00d8\\u00b1\\u00d8\\u00a7\\u00d9\\u0087\\u00e2\\u0080\\u008c\\u00d8\\u00ad\\u00d9\\u0084\\\",\\n      \\\"body\\\": \\\"\\u00d8\\u00aa\\u00d8\\u00a7 \\u00d8\\u00ad\\u00d8\\u00af \\u00d8\\u00a7\\u00d9\\u0085\\u00da\\u00a9\\u00d8\\u00a7\\u00d9\\u0086 \\u00d8\\u00b1\\u00d8\\u00a7\\u00d9\\u0087\\u00e2\\u0080\\u008c\\u00d8\\u00ad\\u00d9\\u0084\\u00e2\\u0080\\u008c\\u00d9\\u0087\\u00d8\\u00a7\\u00db\\u008c \\u00d9\\u0085\\u00d8\\u00ae\\u00d8\\u00aa\\u00d9\\u0084\\u00d9\\u0081 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d9\\u0081\\u00d9\\u0087\\u00d8\\u00b1\\u00d8\\u00b3\\u00d8\\u00aa \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af. \\u00d8\\u00ae\\u00d9\\u0084\\u00d8\\u00a7\\u00d9\\u0082 \\u00d8\\u00a8\\u00d8\\u00a7\\u00d8\\u00b4\\u00db\\u008c\\u00d8\\u00af \\u00d9\\u0088 \\u00d8\\u00a7\\u00d8\\u00b2 \\u00d8\\u00aa\\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00da\\u00a9\\u00e2\\u0080\\u008c\\u00d9\\u0087\\u00d8\\u00a7\\u00db\\u008c\\u00db\\u008c \\u00d9\\u0085\\u00d8\\u00a7\\u00d9\\u0086\\u00d9\\u0086\\u00d8\\u00af \\u00d8\\u00b7\\u00d9\\u0088\\u00d9\\u0081\\u00d8\\u00a7\\u00d9\\u0086 \\u00d9\\u0081\\u00da\\u00a9\\u00d8\\u00b1\\u00db\\u008c \\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa\\u00d9\\u0081\\u00d8\\u00a7\\u00d8\\u00af\\u00d9\\u0087 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d8\\u00a7\\u00d8\\u00b1\\u00d8\\u00b2\\u00db\\u008c\\u00d8\\u00a7\\u00d8\\u00a8\\u00db\\u008c \\u00d9\\u0088 \\u00d8\\u00a7\\u00d9\\u0086\\u00d8\\u00aa\\u00d8\\u00ae\\u00d8\\u00a7\\u00d8\\u00a8 \\u00d8\\u00a8\\u00d9\\u0087\\u00d8\\u00aa\\u00d8\\u00b1\\u00db\\u008c\\u00d9\\u0086 \\u00d8\\u00b1\\u00d8\\u00a7\\u00d9\\u0087\\u00e2\\u0080\\u008c\\u00d8\\u00ad\\u00d9\\u0084\\\",\\n      \\\"body\\\": \\\"\\u00d9\\u0087\\u00d8\\u00b1 \\u00da\\u00af\\u00d8\\u00b2\\u00db\\u008c\\u00d9\\u0086\\u00d9\\u0087 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d8\\u00b1 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00a7\\u00d8\\u00b3 \\u00d9\\u0085\\u00d8\\u00b9\\u00db\\u008c\\u00d8\\u00a7\\u00d8\\u00b1\\u00d9\\u0087\\u00d8\\u00a7\\u00db\\u008c\\u00db\\u008c \\u00d9\\u0085\\u00d8\\u00a7\\u00d9\\u0086\\u00d9\\u0086\\u00d8\\u00af \\u00d9\\u0087\\u00d8\\u00b2\\u00db\\u008c\\u00d9\\u0086\\u00d9\\u0087\\u00d8\\u008c \\u00d8\\u00b2\\u00d9\\u0085\\u00d8\\u00a7\\u00d9\\u0086\\u00d8\\u008c \\u00d9\\u0085\\u00d9\\u0086\\u00d8\\u00a7\\u00d8\\u00a8\\u00d8\\u00b9 \\u00d9\\u0088 \\u00d8\\u00a7\\u00d8\\u00ab\\u00d8\\u00b1\\u00d8\\u00a8\\u00d8\\u00ae\\u00d8\\u00b4\\u00db\\u008c \\u00d8\\u00a7\\u00d8\\u00b1\\u00d8\\u00b2\\u00db\\u008c\\u00d8\\u00a7\\u00d8\\u00a8\\u00db\\u008c \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af. \\u00d8\\u00b3\\u00d9\\u00be\\u00d8\\u00b3 \\u00d8\\u00a8\\u00d9\\u0087\\u00d8\\u00aa\\u00d8\\u00b1\\u00db\\u008c\\u00d9\\u0086 \\u00da\\u00af\\u00d8\\u00b2\\u00db\\u008c\\u00d9\\u0086\\u00d9\\u0087 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a7\\u00d9\\u0086\\u00d8\\u00aa\\u00d8\\u00ae\\u00d8\\u00a7\\u00d8\\u00a8 \\u00d9\\u0086\\u00d9\\u0085\\u00d8\\u00a7\\u00db\\u008c\\u00db\\u008c\\u00d8\\u00af.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d8\\u00a7\\u00d8\\u00ac\\u00d8\\u00b1\\u00d8\\u00a7 \\u00d9\\u0088 \\u00d9\\u00be\\u00db\\u008c\\u00da\\u00af\\u00db\\u008c\\u00d8\\u00b1\\u00db\\u008c\\\",\\n      \\\"body\\\": \\\"\\u00d8\\u00b1\\u00d8\\u00a7\\u00d9\\u0087\\u00e2\\u0080\\u008c\\u00d8\\u00ad\\u00d9\\u0084 \\u00d8\\u00a7\\u00d9\\u0086\\u00d8\\u00aa\\u00d8\\u00ae\\u00d8\\u00a7\\u00d8\\u00a8\\u00e2\\u0080\\u008c\\u00d8\\u00b4\\u00d8\\u00af\\u00d9\\u0087 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d9\\u0087 \\u00d8\\u00a7\\u00d8\\u00ac\\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00af\\u00d8\\u00b1\\u00d8\\u00a2\\u00d9\\u0088\\u00d8\\u00b1\\u00db\\u008c\\u00d8\\u00af. \\u00d9\\u00be\\u00db\\u008c\\u00d8\\u00b4\\u00d8\\u00b1\\u00d9\\u0081\\u00d8\\u00aa \\u00da\\u00a9\\u00d8\\u00a7\\u00d8\\u00b1 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d9\\u00be\\u00d8\\u00a7\\u00db\\u008c\\u00d8\\u00b4 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af \\u00d9\\u0088 \\u00d8\\u00af\\u00d8\\u00b1 \\u00d8\\u00b5\\u00d9\\u0088\\u00d8\\u00b1\\u00d8\\u00aa \\u00d9\\u0084\\u00d8\\u00b2\\u00d9\\u0088\\u00d9\\u0085 \\u00d8\\u00aa\\u00d8\\u00ba\\u00db\\u008c\\u00db\\u008c\\u00d8\\u00b1\\u00d8\\u00a7\\u00d8\\u00aa \\u00d9\\u0084\\u00d8\\u00a7\\u00d8\\u00b2\\u00d9\\u0085 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a7\\u00d8\\u00b9\\u00d9\\u0085\\u00d8\\u00a7\\u00d9\\u0084 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af.\\\"\\n    }\\n  ]\\n}\"',NULL,'deepseek-local','2026-06-10 11:50:23','2026-06-10 11:27:06','2026-06-10 11:50:39'),(22,'procedure','steps','خرید قسطی کالا',NULL,5,'failed',NULL,'test from windows',NULL,'2026-06-10 11:27:58','2026-06-10 11:27:54','2026-06-10 11:43:13'),(23,'procedure','steps','خرید قسطی محصول',NULL,5,'done','\"{\\n  \\\"title\\\": \\\"\\u00d9\\u0086\\u00d8\\u00ad\\u00d9\\u0088\\u00d9\\u0087 \\u00d9\\u00be\\u00d8\\u00ae\\u00d8\\u00aa \\u00d8\\u00a8\\u00d8\\u00b1\\u00d9\\u0086\\u00d8\\u00ac \\u00d8\\u00a7\\u00db\\u008c\\u00d8\\u00b1\\u00d8\\u00a7\\u00d9\\u0086\\u00db\\u008c\\\",\\n  \\\"excerpt\\\": \\\"\\u00d8\\u00b1\\u00d8\\u00a7\\u00d9\\u0087\\u00d9\\u0086\\u00d9\\u0085\\u00d8\\u00a7\\u00db\\u008c \\u00da\\u00af\\u00d8\\u00a7\\u00d9\\u0085 \\u00d8\\u00a8\\u00d9\\u0087 \\u00da\\u00af\\u00d8\\u00a7\\u00d9\\u0085 \\u00d9\\u00be\\u00d8\\u00ae\\u00d8\\u00aa \\u00d8\\u00a8\\u00d8\\u00b1\\u00d9\\u0086\\u00d8\\u00ac \\u00d8\\u00a7\\u00db\\u008c\\u00d8\\u00b1\\u00d8\\u00a7\\u00d9\\u0086\\u00db\\u008c \\u00d8\\u00ae\\u00d9\\u0088\\u00d8\\u00b4\\u00d9\\u0085\\u00d8\\u00b2\\u00d9\\u0087 \\u00d9\\u0088 \\u00d8\\u00af\\u00d9\\u0085\\u00e2\\u0080\\u008c\\u00da\\u00a9\\u00d8\\u00b4\\\",\\n  \\\"steps\\\": [\\n    {\\n      \\\"title\\\": \\\"\\u00d8\\u00a2\\u00d9\\u0085\\u00d8\\u00a7\\u00d8\\u00af\\u00d9\\u0087\\u00e2\\u0080\\u008c\\u00d8\\u00b3\\u00d8\\u00a7\\u00d8\\u00b2\\u00db\\u008c \\u00d8\\u00a8\\u00d8\\u00b1\\u00d9\\u0086\\u00d8\\u00ac\\\",\\n      \\\"body\\\": \\\"\\u00d8\\u00a8\\u00d8\\u00b1\\u00d9\\u0086\\u00d8\\u00ac \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d9\\u0087 \\u00d9\\u0085\\u00d8\\u00af\\u00d8\\u00aa \\u00db\\u00b2 \\u00d8\\u00aa\\u00d8\\u00a7 \\u00db\\u00b3 \\u00d8\\u00b3\\u00d8\\u00a7\\u00d8\\u00b9\\u00d8\\u00aa \\u00d8\\u00af\\u00d8\\u00b1 \\u00d8\\u00a2\\u00d8\\u00a8 \\u00d8\\u00b3\\u00d8\\u00b1\\u00d8\\u00af \\u00d8\\u00ae\\u00db\\u008c\\u00d8\\u00b3 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af. \\u00d8\\u00b3\\u00d9\\u00be\\u00d8\\u00b3 \\u00d8\\u00a2\\u00d8\\u00a8 \\u00d8\\u00a2\\u00d9\\u0086 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00ae\\u00d8\\u00a7\\u00d9\\u0084\\u00db\\u008c \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af \\u00d9\\u0088 \\u00da\\u0086\\u00d9\\u0086\\u00d8\\u00af \\u00d8\\u00a8\\u00d8\\u00a7\\u00d8\\u00b1 \\u00d8\\u00a8\\u00d8\\u00b4\\u00d9\\u0088\\u00db\\u008c\\u00db\\u008c\\u00d8\\u00af \\u00d8\\u00aa\\u00d8\\u00a7 \\u00d8\\u00a2\\u00d8\\u00a8 \\u00d8\\u00b4\\u00d9\\u0081\\u00d8\\u00a7\\u00d9\\u0081 \\u00d8\\u00b4\\u00d9\\u0088\\u00d8\\u00af.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d8\\u00ac\\u00d9\\u0088\\u00d8\\u00b4\\u00d8\\u00a7\\u00d9\\u0086\\u00d8\\u00af\\u00d9\\u0086 \\u00d8\\u00a8\\u00d8\\u00b1\\u00d9\\u0086\\u00d8\\u00ac\\\",\\n      \\\"body\\\": \\\"\\u00d8\\u00af\\u00d8\\u00b1 \\u00db\\u008c\\u00da\\u00a9 \\u00d9\\u0082\\u00d8\\u00a7\\u00d8\\u00a8\\u00d9\\u0084\\u00d9\\u0085\\u00d9\\u0087 \\u00d8\\u00a8\\u00d8\\u00b2\\u00d8\\u00b1\\u00da\\u00af \\u00d8\\u00a2\\u00d8\\u00a8 \\u00d8\\u00a8\\u00d8\\u00b1\\u00db\\u008c\\u00d8\\u00b2\\u00db\\u008c\\u00d8\\u00af \\u00d9\\u0088 \\u00d8\\u00a8\\u00da\\u00af\\u00d8\\u00b0\\u00d8\\u00a7\\u00d8\\u00b1\\u00db\\u008c\\u00d8\\u00af \\u00d8\\u00a8\\u00d9\\u0087 \\u00d8\\u00ac\\u00d9\\u0088\\u00d8\\u00b4 \\u00d8\\u00a2\\u00db\\u008c\\u00d8\\u00af. \\u00d8\\u00b3\\u00d9\\u00be\\u00d8\\u00b3 \\u00d8\\u00a8\\u00d8\\u00b1\\u00d9\\u0086\\u00d8\\u00ac \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a7\\u00d8\\u00b6\\u00d8\\u00a7\\u00d9\\u0081\\u00d9\\u0087 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af \\u00d9\\u0088 \\u00d8\\u00a8\\u00d9\\u0087 \\u00d9\\u0085\\u00d8\\u00af\\u00d8\\u00aa \\u00db\\u00b8 \\u00d8\\u00aa\\u00d8\\u00a7 \\u00db\\u00b1\\u00db\\u00b0 \\u00d8\\u00af\\u00d9\\u0082\\u00db\\u008c\\u00d9\\u0082\\u00d9\\u0087 \\u00d8\\u00a8\\u00d8\\u00ac\\u00d9\\u0088\\u00d8\\u00b4\\u00d8\\u00a7\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af \\u00d8\\u00aa\\u00d8\\u00a7 \\u00d9\\u0086\\u00d8\\u00b1\\u00d9\\u0085 \\u00d8\\u00b4\\u00d9\\u0088\\u00d8\\u00af. \\u00d8\\u00b3\\u00d9\\u00be\\u00d8\\u00b3 \\u00d8\\u00a2\\u00d8\\u00a8\\u00da\\u00a9\\u00d8\\u00b4 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d8\\u00aa\\u00d9\\u0087\\u00db\\u008c\\u00d9\\u0087 \\u00d8\\u00af\\u00d9\\u0085\\u00e2\\u0080\\u008c\\u00da\\u00a9\\u00d8\\u00b4\\\",\\n      \\\"body\\\": \\\"\\u00da\\u00a9\\u00d9\\u0081 \\u00d9\\u0082\\u00d8\\u00a7\\u00d8\\u00a8\\u00d9\\u0084\\u00d9\\u0085\\u00d9\\u0087 \\u00d8\\u00b1\\u00d9\\u0088\\u00d8\\u00ba\\u00d9\\u0086 \\u00d9\\u0088 \\u00db\\u008c\\u00da\\u00a9 \\u00d9\\u0084\\u00d8\\u00a7\\u00db\\u008c\\u00d9\\u0087 \\u00d9\\u0086\\u00d8\\u00a7\\u00d8\\u00b2\\u00da\\u00a9 \\u00d8\\u00a7\\u00d8\\u00b2 \\u00d8\\u00aa\\u00d9\\u0087\\u00e2\\u0080\\u008c\\u00d8\\u00af\\u00db\\u008c\\u00da\\u00af (\\u00d9\\u0085\\u00d8\\u00a7\\u00d9\\u0086\\u00d9\\u0086\\u00d8\\u00af \\u00d8\\u00b3\\u00db\\u008c\\u00d8\\u00a8\\u00e2\\u0080\\u008c\\u00d8\\u00b2\\u00d9\\u0085\\u00db\\u008c\\u00d9\\u0086\\u00db\\u008c \\u00db\\u008c\\u00d8\\u00a7 \\u00d9\\u0086\\u00d8\\u00a7\\u00d9\\u0086) \\u00d8\\u00a8\\u00d8\\u00b1\\u00db\\u008c\\u00d8\\u00b2\\u00db\\u008c\\u00d8\\u00af. \\u00d8\\u00a8\\u00d8\\u00b1\\u00d9\\u0086\\u00d8\\u00ac \\u00d8\\u00a2\\u00d8\\u00a8\\u00da\\u00a9\\u00d8\\u00b4 \\u00d8\\u00b4\\u00d8\\u00af\\u00d9\\u0087 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00b1\\u00d9\\u0088\\u00db\\u008c \\u00d8\\u00a2\\u00d9\\u0086 \\u00d8\\u00a8\\u00d8\\u00b1\\u00db\\u008c\\u00d8\\u00b2\\u00db\\u008c\\u00d8\\u00af \\u00d9\\u0088 \\u00d8\\u00af\\u00d8\\u00b1\\u00d8\\u00a8 \\u00d9\\u0082\\u00d8\\u00a7\\u00d8\\u00a8\\u00d9\\u0084\\u00d9\\u0085\\u00d9\\u0087 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d8\\u00a7 \\u00d8\\u00af\\u00d9\\u0085\\u00e2\\u0080\\u008c\\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c \\u00d8\\u00a8\\u00d9\\u00be\\u00d9\\u0088\\u00d8\\u00b4\\u00d8\\u00a7\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d9\\u00be\\u00d8\\u00ae\\u00d8\\u00aa \\u00d9\\u0086\\u00d9\\u0087\\u00d8\\u00a7\\u00db\\u008c\\u00db\\u008c\\\",\\n      \\\"body\\\": \\\"\\u00d9\\u0082\\u00d8\\u00a7\\u00d8\\u00a8\\u00d9\\u0084\\u00d9\\u0085\\u00d9\\u0087 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00b1\\u00d9\\u0088\\u00db\\u008c \\u00d8\\u00ad\\u00d8\\u00b1\\u00d8\\u00a7\\u00d8\\u00b1\\u00d8\\u00aa \\u00d9\\u0085\\u00d9\\u0084\\u00d8\\u00a7\\u00db\\u008c\\u00d9\\u0085 \\u00d9\\u0082\\u00d8\\u00b1\\u00d8\\u00a7\\u00d8\\u00b1 \\u00d8\\u00af\\u00d9\\u0087\\u00db\\u008c\\u00d8\\u00af \\u00d9\\u0088 \\u00d8\\u00a8\\u00d9\\u0087 \\u00d9\\u0085\\u00d8\\u00af\\u00d8\\u00aa \\u00db\\u00b3\\u00db\\u00b0 \\u00d8\\u00aa\\u00d8\\u00a7 \\u00db\\u00b4\\u00db\\u00b5 \\u00d8\\u00af\\u00d9\\u0082\\u00db\\u008c\\u00d9\\u0082\\u00d9\\u0087 \\u00d8\\u00af\\u00d9\\u0085 \\u00d8\\u00a8\\u00da\\u00a9\\u00d8\\u00b4\\u00d8\\u00af. \\u00d8\\u00a8\\u00d8\\u00b1\\u00d8\\u00a7\\u00db\\u008c \\u00d8\\u00b7\\u00d8\\u00b9\\u00d9\\u0085 \\u00d8\\u00a8\\u00d9\\u0087\\u00d8\\u00aa\\u00d8\\u00b1\\u00d8\\u008c \\u00d9\\u0085\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00d8\\u00aa\\u00d9\\u0088\\u00d8\\u00a7\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af \\u00da\\u00a9\\u00d8\\u00b1\\u00d9\\u0087 \\u00db\\u008c\\u00d8\\u00a7 \\u00d8\\u00b2\\u00d8\\u00b9\\u00d9\\u0081\\u00d8\\u00b1\\u00d8\\u00a7\\u00d9\\u0086 \\u00d8\\u00af\\u00d9\\u0085\\u00e2\\u0080\\u008c\\u00da\\u00a9\\u00d8\\u00b1\\u00d8\\u00af\\u00d9\\u0087 \\u00d8\\u00a7\\u00d8\\u00b6\\u00d8\\u00a7\\u00d9\\u0081\\u00d9\\u0087 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d8\\u00b3\\u00d8\\u00b1\\u00d9\\u0088 \\u00da\\u00a9\\u00d8\\u00b1\\u00d8\\u00af\\u00d9\\u0086\\\",\\n      \\\"body\\\": \\\"\\u00d8\\u00a8\\u00d8\\u00b9\\u00d8\\u00af \\u00d8\\u00a7\\u00d8\\u00b2 \\u00d8\\u00af\\u00d9\\u0085 \\u00da\\u00a9\\u00d8\\u00b4\\u00db\\u008c\\u00d8\\u00af\\u00d9\\u0086\\u00d8\\u008c \\u00d8\\u00a8\\u00d8\\u00b1\\u00d9\\u0086\\u00d8\\u00ac \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d8\\u00a7 \\u00d8\\u00a7\\u00d8\\u00ad\\u00d8\\u00aa\\u00db\\u008c\\u00d8\\u00a7\\u00d8\\u00b7 \\u00d8\\u00a7\\u00d8\\u00b2 \\u00d9\\u0082\\u00d8\\u00a7\\u00d8\\u00a8\\u00d9\\u0084\\u00d9\\u0085\\u00d9\\u0087 \\u00d8\\u00ae\\u00d8\\u00a7\\u00d8\\u00b1\\u00d8\\u00ac \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af \\u00d9\\u0088 \\u00d8\\u00af\\u00d8\\u00b1 \\u00d8\\u00af\\u00db\\u008c\\u00d8\\u00b3 \\u00d8\\u00a8\\u00da\\u00a9\\u00d8\\u00b4\\u00db\\u008c\\u00d8\\u00af. \\u00d8\\u00aa\\u00d9\\u0087\\u00e2\\u0080\\u008c\\u00d8\\u00af\\u00db\\u008c\\u00da\\u00af \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00ac\\u00d8\\u00af\\u00d8\\u00a7 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af \\u00d9\\u0088 \\u00d8\\u00a8\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d8\\u00b1\\u00d9\\u0086\\u00d8\\u00ac \\u00d8\\u00b3\\u00d8\\u00b1\\u00d9\\u0088 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af.\\\"\\n    }\\n  ]\\n}\"',NULL,'deepseek-local','2026-06-10 11:50:23','2026-06-10 11:43:19','2026-06-10 11:50:45'),(24,'procedure','steps','خرید قسطی محصول',NULL,5,'done','\"{\\n  \\\"title\\\": \\\"\\u00d8\\u00b1\\u00d8\\u00a7\\u00d9\\u0087\\u00d9\\u0086\\u00d9\\u0085\\u00d8\\u00a7\\u00db\\u008c \\u00da\\u00af\\u00d8\\u00a7\\u00d9\\u0085\\u00e2\\u0080\\u008c\\u00d8\\u00a8\\u00d9\\u0087\\u00e2\\u0080\\u008c\\u00da\\u00af\\u00d8\\u00a7\\u00d9\\u0085 \\u00d8\\u00a8\\u00d8\\u00b1\\u00d8\\u00a7\\u00db\\u008c \\u00da\\u00a9\\u00d8\\u00a7\\u00d9\\u0087\\u00d8\\u00b4 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa\\u00d8\\u00b1\\u00d8\\u00b3\\\",\\n  \\\"excerpt\\\": \\\"\\u00d8\\u00a7\\u00db\\u008c\\u00d9\\u0086 \\u00d8\\u00b1\\u00d8\\u00a7\\u00d9\\u0087\\u00d9\\u0086\\u00d9\\u0085\\u00d8\\u00a7 \\u00d8\\u00b4\\u00d8\\u00a7\\u00d9\\u0085\\u00d9\\u0084 \\u00db\\u00b5 \\u00da\\u00af\\u00d8\\u00a7\\u00d9\\u0085 \\u00d8\\u00b3\\u00d8\\u00a7\\u00d8\\u00af\\u00d9\\u0087 \\u00d8\\u00a8\\u00d8\\u00b1\\u00d8\\u00a7\\u00db\\u008c \\u00da\\u00a9\\u00d8\\u00a7\\u00d9\\u0087\\u00d8\\u00b4 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa\\u00d8\\u00b1\\u00d8\\u00b3 \\u00d8\\u00b1\\u00d9\\u0088\\u00d8\\u00b2\\u00d8\\u00a7\\u00d9\\u0086\\u00d9\\u0087 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa.\\\",\\n  \\\"steps\\\": [\\n    {\\n      \\\"title\\\": \\\"\\u00d8\\u00b4\\u00d9\\u0086\\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00a7\\u00db\\u008c\\u00db\\u008c \\u00d9\\u0085\\u00d9\\u0086\\u00d8\\u00a7\\u00d8\\u00a8\\u00d8\\u00b9 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa\\u00d8\\u00b1\\u00d8\\u00b3\\\",\\n      \\\"body\\\": \\\"\\u00d8\\u00a7\\u00d8\\u00a8\\u00d8\\u00aa\\u00d8\\u00af\\u00d8\\u00a7 \\u00d8\\u00b9\\u00d9\\u0088\\u00d8\\u00a7\\u00d9\\u0085\\u00d9\\u0084\\u00db\\u008c \\u00da\\u00a9\\u00d9\\u0087 \\u00d8\\u00a8\\u00d8\\u00a7\\u00d8\\u00b9\\u00d8\\u00ab \\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa\\u00d8\\u00b1\\u00d8\\u00b3 \\u00d8\\u00b4\\u00d9\\u0085\\u00d8\\u00a7 \\u00d9\\u0085\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00d8\\u00b4\\u00d9\\u0088\\u00d9\\u0086\\u00d8\\u00af \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00b4\\u00d9\\u0086\\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00a7\\u00db\\u008c\\u00db\\u008c \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af. \\u00db\\u008c\\u00da\\u00a9 \\u00d8\\u00af\\u00d9\\u0081\\u00d8\\u00aa\\u00d8\\u00b1\\u00da\\u0086\\u00d9\\u0087 \\u00db\\u008c\\u00d8\\u00a7\\u00d8\\u00af\\u00d8\\u00af\\u00d8\\u00a7\\u00d8\\u00b4\\u00d8\\u00aa \\u00d8\\u00a8\\u00d8\\u00b1\\u00d8\\u00af\\u00d8\\u00a7\\u00d8\\u00b1\\u00db\\u008c\\u00d8\\u00af \\u00d9\\u0088 \\u00d8\\u00aa\\u00d9\\u0085\\u00d8\\u00a7\\u00d9\\u0085 \\u00d9\\u0085\\u00d9\\u0088\\u00d9\\u0082\\u00d8\\u00b9\\u00db\\u008c\\u00d8\\u00aa\\u00e2\\u0080\\u008c\\u00d9\\u0087\\u00d8\\u00a7\\u00d8\\u008c \\u00d8\\u00a7\\u00d9\\u0081\\u00d8\\u00b1\\u00d8\\u00a7\\u00d8\\u00af \\u00db\\u008c\\u00d8\\u00a7 \\u00d8\\u00a7\\u00d9\\u0081\\u00da\\u00a9\\u00d8\\u00a7\\u00d8\\u00b1\\u00db\\u008c \\u00da\\u00a9\\u00d9\\u0087 \\u00d8\\u00b4\\u00d9\\u0085\\u00d8\\u00a7 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d9\\u0085\\u00d8\\u00b6\\u00d8\\u00b7\\u00d8\\u00b1\\u00d8\\u00a8 \\u00d9\\u0085\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00da\\u00a9\\u00d9\\u0086\\u00d9\\u0086\\u00d8\\u00af\\u00d8\\u008c \\u00d8\\u00a8\\u00d9\\u0086\\u00d9\\u0088\\u00db\\u008c\\u00d8\\u00b3\\u00db\\u008c\\u00d8\\u00af. \\u00d8\\u00a7\\u00db\\u008c\\u00d9\\u0086 \\u00da\\u00a9\\u00d8\\u00a7\\u00d8\\u00b1 \\u00d8\\u00a8\\u00d9\\u0087 \\u00d8\\u00b4\\u00d9\\u0085\\u00d8\\u00a7 \\u00da\\u00a9\\u00d9\\u0085\\u00da\\u00a9 \\u00d9\\u0085\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00da\\u00a9\\u00d9\\u0086\\u00d8\\u00af \\u00d8\\u00aa\\u00d8\\u00a7 \\u00d9\\u0085\\u00d9\\u0086\\u00d8\\u00a8\\u00d8\\u00b9 \\u00d8\\u00a7\\u00d8\\u00b5\\u00d9\\u0084\\u00db\\u008c \\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa\\u00d8\\u00b1\\u00d8\\u00b3 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d9\\u00be\\u00db\\u008c\\u00d8\\u00af\\u00d8\\u00a7 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d8\\u00aa\\u00d9\\u0085\\u00d8\\u00b1\\u00db\\u008c\\u00d9\\u0086 \\u00d8\\u00aa\\u00d9\\u0086\\u00d9\\u0081\\u00d8\\u00b3 \\u00d8\\u00b9\\u00d9\\u0085\\u00db\\u008c\\u00d9\\u0082\\\",\\n      \\\"body\\\": \\\"\\u00d8\\u00af\\u00d8\\u00b1 \\u00db\\u008c\\u00da\\u00a9 \\u00d9\\u0085\\u00da\\u00a9\\u00d8\\u00a7\\u00d9\\u0086 \\u00d8\\u00a2\\u00d8\\u00b1\\u00d8\\u00a7\\u00d9\\u0085 \\u00d8\\u00a8\\u00d9\\u0086\\u00d8\\u00b4\\u00db\\u008c\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af. \\u00da\\u0086\\u00d8\\u00b4\\u00d9\\u0085\\u00d8\\u00a7\\u00d9\\u0086 \\u00d8\\u00ae\\u00d9\\u0088\\u00d8\\u00af \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d8\\u00a8\\u00d9\\u0086\\u00d8\\u00af\\u00db\\u008c\\u00d8\\u00af \\u00d9\\u0088 \\u00d8\\u00a8\\u00d9\\u0087 \\u00d8\\u00a2\\u00d8\\u00b1\\u00d8\\u00a7\\u00d9\\u0085\\u00db\\u008c \\u00d8\\u00a7\\u00d8\\u00b2 \\u00d8\\u00b7\\u00d8\\u00b1\\u00db\\u008c\\u00d9\\u0082 \\u00d8\\u00a8\\u00db\\u008c\\u00d9\\u0086\\u00db\\u008c \\u00d9\\u0086\\u00d9\\u0081\\u00d8\\u00b3 \\u00d8\\u00a8\\u00da\\u00a9\\u00d8\\u00b4\\u00db\\u008c\\u00d8\\u00af \\u00d8\\u00aa\\u00d8\\u00a7 \\u00d8\\u00b4\\u00d9\\u0085\\u00d8\\u00a7\\u00d8\\u00b1\\u00d9\\u0087 \\u00db\\u00b4 \\u00d8\\u00a8\\u00d8\\u00b4\\u00d9\\u0085\\u00d8\\u00a7\\u00d8\\u00b1\\u00db\\u008c\\u00d8\\u00af. \\u00d9\\u0086\\u00d9\\u0081\\u00d8\\u00b3 \\u00d8\\u00ae\\u00d9\\u0088\\u00d8\\u00af \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d9\\u0087 \\u00d9\\u0085\\u00d8\\u00af\\u00d8\\u00aa \\u00db\\u00b4 \\u00d8\\u00b4\\u00d9\\u0085\\u00d8\\u00a7\\u00d8\\u00b1\\u00d9\\u0087 \\u00d8\\u00ad\\u00d8\\u00a8\\u00d8\\u00b3 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af \\u00d9\\u0088 \\u00d8\\u00b3\\u00d9\\u00be\\u00d8\\u00b3 \\u00d8\\u00a8\\u00d9\\u0087 \\u00d8\\u00a2\\u00d8\\u00b1\\u00d8\\u00a7\\u00d9\\u0085\\u00db\\u008c \\u00d8\\u00a7\\u00d8\\u00b2 \\u00d8\\u00b7\\u00d8\\u00b1\\u00db\\u008c\\u00d9\\u0082 \\u00d8\\u00af\\u00d9\\u0087\\u00d8\\u00a7\\u00d9\\u0086 \\u00d8\\u00a8\\u00db\\u008c\\u00d8\\u00b1\\u00d9\\u0088\\u00d9\\u0086 \\u00d8\\u00af\\u00d9\\u0087\\u00db\\u008c\\u00d8\\u00af \\u00d8\\u00aa\\u00d8\\u00a7 \\u00d8\\u00b4\\u00d9\\u0085\\u00d8\\u00a7\\u00d8\\u00b1\\u00d9\\u0087 \\u00db\\u00b6. \\u00d8\\u00a7\\u00db\\u008c\\u00d9\\u0086 \\u00da\\u00a9\\u00d8\\u00a7\\u00d8\\u00b1 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00db\\u00b5 \\u00d8\\u00a8\\u00d8\\u00a7\\u00d8\\u00b1 \\u00d8\\u00aa\\u00da\\u00a9\\u00d8\\u00b1\\u00d8\\u00a7\\u00d8\\u00b1 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af. \\u00d8\\u00a7\\u00db\\u008c\\u00d9\\u0086 \\u00d8\\u00aa\\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00da\\u00a9 \\u00d8\\u00a8\\u00d9\\u0087 \\u00da\\u00a9\\u00d8\\u00a7\\u00d9\\u0087\\u00d8\\u00b4 \\u00d9\\u0081\\u00d9\\u0088\\u00d8\\u00b1\\u00db\\u008c \\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa\\u00d8\\u00b1\\u00d8\\u00b3 \\u00da\\u00a9\\u00d9\\u0085\\u00da\\u00a9 \\u00d9\\u0085\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00da\\u00a9\\u00d9\\u0086\\u00d8\\u00af.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d9\\u0081\\u00d8\\u00b9\\u00d8\\u00a7\\u00d9\\u0084\\u00db\\u008c\\u00d8\\u00aa \\u00d8\\u00a8\\u00d8\\u00af\\u00d9\\u0086\\u00db\\u008c \\u00d9\\u0085\\u00d9\\u0086\\u00d8\\u00b8\\u00d9\\u0085\\\",\\n      \\\"body\\\": \\\"\\u00d8\\u00ad\\u00d8\\u00af\\u00d8\\u00a7\\u00d9\\u0082\\u00d9\\u0084 \\u00db\\u00b3\\u00db\\u00b0 \\u00d8\\u00af\\u00d9\\u0082\\u00db\\u008c\\u00d9\\u0082\\u00d9\\u0087 \\u00d8\\u00af\\u00d8\\u00b1 \\u00d8\\u00b1\\u00d9\\u0088\\u00d8\\u00b2 \\u00d9\\u0081\\u00d8\\u00b9\\u00d8\\u00a7\\u00d9\\u0084\\u00db\\u008c\\u00d8\\u00aa \\u00d8\\u00a8\\u00d8\\u00af\\u00d9\\u0086\\u00db\\u008c \\u00d8\\u00af\\u00d8\\u00a7\\u00d8\\u00b4\\u00d8\\u00aa\\u00d9\\u0087 \\u00d8\\u00a8\\u00d8\\u00a7\\u00d8\\u00b4\\u00db\\u008c\\u00d8\\u00af. \\u00d9\\u0085\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00d8\\u00aa\\u00d9\\u0088\\u00d8\\u00a7\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af \\u00d9\\u00be\\u00db\\u008c\\u00d8\\u00a7\\u00d8\\u00af\\u00d9\\u0087\\u00e2\\u0080\\u008c\\u00d8\\u00b1\\u00d9\\u0088\\u00db\\u008c \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af\\u00d8\\u008c \\u00d8\\u00a8\\u00d8\\u00af\\u00d9\\u0088\\u00db\\u008c\\u00d8\\u00af \\u00db\\u008c\\u00d8\\u00a7 \\u00d9\\u0088\\u00d8\\u00b1\\u00d8\\u00b2\\u00d8\\u00b4\\u00e2\\u0080\\u008c\\u00d9\\u0087\\u00d8\\u00a7\\u00db\\u008c \\u00da\\u00a9\\u00d8\\u00b4\\u00d8\\u00b4\\u00db\\u008c \\u00d8\\u00a7\\u00d9\\u0086\\u00d8\\u00ac\\u00d8\\u00a7\\u00d9\\u0085 \\u00d8\\u00af\\u00d9\\u0087\\u00db\\u008c\\u00d8\\u00af. \\u00d9\\u0081\\u00d8\\u00b9\\u00d8\\u00a7\\u00d9\\u0084\\u00db\\u008c\\u00d8\\u00aa \\u00d8\\u00a8\\u00d8\\u00af\\u00d9\\u0086\\u00db\\u008c \\u00d8\\u00a8\\u00d8\\u00a7\\u00d8\\u00b9\\u00d8\\u00ab \\u00d8\\u00aa\\u00d8\\u00b1\\u00d8\\u00b4\\u00d8\\u00ad \\u00d8\\u00a7\\u00d9\\u0086\\u00d8\\u00af\\u00d9\\u0088\\u00d8\\u00b1\\u00d9\\u0081\\u00db\\u008c\\u00d9\\u0086 \\u00d9\\u0085\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00d8\\u00b4\\u00d9\\u0088\\u00d8\\u00af \\u00da\\u00a9\\u00d9\\u0087 \\u00d8\\u00a8\\u00d9\\u0087 \\u00d8\\u00b9\\u00d9\\u0086\\u00d9\\u0088\\u00d8\\u00a7\\u00d9\\u0086 \\u00d9\\u0085\\u00d8\\u00b3\\u00da\\u00a9\\u00d9\\u0086 \\u00d8\\u00b7\\u00d8\\u00a8\\u00db\\u008c\\u00d8\\u00b9\\u00db\\u008c \\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa\\u00d8\\u00b1\\u00d8\\u00b3 \\u00d8\\u00b9\\u00d9\\u0085\\u00d9\\u0084 \\u00d9\\u0085\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00da\\u00a9\\u00d9\\u0086\\u00d8\\u00af.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d9\\u0085\\u00d8\\u00af\\u00db\\u008c\\u00d8\\u00b1\\u00db\\u008c\\u00d8\\u00aa \\u00d8\\u00b2\\u00d9\\u0085\\u00d8\\u00a7\\u00d9\\u0086\\\",\\n      \\\"body\\\": \\\"\\u00db\\u008c\\u00da\\u00a9 \\u00d8\\u00a8\\u00d8\\u00b1\\u00d9\\u0086\\u00d8\\u00a7\\u00d9\\u0085\\u00d9\\u0087 \\u00d8\\u00b1\\u00d9\\u0088\\u00d8\\u00b2\\u00d8\\u00a7\\u00d9\\u0086\\u00d9\\u0087 \\u00d8\\u00aa\\u00d9\\u0086\\u00d8\\u00b8\\u00db\\u008c\\u00d9\\u0085 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af \\u00d9\\u0088 \\u00d8\\u00a7\\u00d9\\u0088\\u00d9\\u0084\\u00d9\\u0088\\u00db\\u008c\\u00d8\\u00aa\\u00e2\\u0080\\u008c\\u00d9\\u0087\\u00d8\\u00a7\\u00db\\u008c \\u00d8\\u00ae\\u00d9\\u0088\\u00d8\\u00af \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d9\\u0085\\u00d8\\u00b4\\u00d8\\u00ae\\u00d8\\u00b5 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af. \\u00da\\u00a9\\u00d8\\u00a7\\u00d8\\u00b1\\u00d9\\u0087\\u00d8\\u00a7\\u00db\\u008c \\u00d8\\u00a8\\u00d8\\u00b2\\u00d8\\u00b1\\u00da\\u00af \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d9\\u0087 \\u00d8\\u00a8\\u00d8\\u00ae\\u00d8\\u00b4\\u00e2\\u0080\\u008c\\u00d9\\u0087\\u00d8\\u00a7\\u00db\\u008c \\u00da\\u00a9\\u00d9\\u0088\\u00da\\u0086\\u00da\\u00a9\\u00e2\\u0080\\u008c\\u00d8\\u00aa\\u00d8\\u00b1 \\u00d8\\u00aa\\u00d9\\u0082\\u00d8\\u00b3\\u00db\\u008c\\u00d9\\u0085 \\u00da\\u00a9\\u00d8\\u00b1\\u00d8\\u00af\\u00d9\\u0087 \\u00d9\\u0088 \\u00d8\\u00a8\\u00d8\\u00b1\\u00d8\\u00a7\\u00db\\u008c \\u00d9\\u0087\\u00d8\\u00b1 \\u00da\\u00a9\\u00d8\\u00af\\u00d8\\u00a7\\u00d9\\u0085 \\u00d8\\u00b2\\u00d9\\u0085\\u00d8\\u00a7\\u00d9\\u0086 \\u00d9\\u0085\\u00d8\\u00b4\\u00d8\\u00ae\\u00d8\\u00b5\\u00db\\u008c \\u00d8\\u00aa\\u00d8\\u00b9\\u00db\\u008c\\u00db\\u008c\\u00d9\\u0086 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af. \\u00d8\\u00a7\\u00db\\u008c\\u00d9\\u0086 \\u00da\\u00a9\\u00d8\\u00a7\\u00d8\\u00b1 \\u00d8\\u00a7\\u00d8\\u00b2 \\u00d8\\u00a7\\u00d8\\u00ad\\u00d8\\u00b3\\u00d8\\u00a7\\u00d8\\u00b3 overwhelm \\u00d8\\u00b4\\u00d8\\u00af\\u00d9\\u0086 \\u00d8\\u00ac\\u00d9\\u0084\\u00d9\\u0088\\u00da\\u00af\\u00db\\u008c\\u00d8\\u00b1\\u00db\\u008c \\u00d9\\u0085\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00da\\u00a9\\u00d9\\u0086\\u00d8\\u00af.\\\"\\n    },\\n    {\\n      \\\"title\\\": \\\"\\u00d8\\u00a7\\u00db\\u008c\\u00d8\\u00ac\\u00d8\\u00a7\\u00d8\\u00af \\u00d8\\u00b9\\u00d8\\u00a7\\u00d8\\u00af\\u00d8\\u00a7\\u00d8\\u00aa \\u00d8\\u00ae\\u00d9\\u0088\\u00d8\\u00a7\\u00d8\\u00a8 \\u00d8\\u00b3\\u00d8\\u00a7\\u00d9\\u0084\\u00d9\\u0085\\\",\\n      \\\"body\\\": \\\"\\u00d9\\u0087\\u00d8\\u00b1 \\u00d8\\u00b4\\u00d8\\u00a8 \\u00d8\\u00af\\u00d8\\u00b1 \\u00db\\u008c\\u00da\\u00a9 \\u00d8\\u00b3\\u00d8\\u00a7\\u00d8\\u00b9\\u00d8\\u00aa \\u00d9\\u0085\\u00d8\\u00b4\\u00d8\\u00ae\\u00d8\\u00b5 \\u00d8\\u00a8\\u00d9\\u0087 \\u00d8\\u00b1\\u00d8\\u00ae\\u00d8\\u00aa\\u00d8\\u00ae\\u00d9\\u0088\\u00d8\\u00a7\\u00d8\\u00a8 \\u00d8\\u00a8\\u00d8\\u00b1\\u00d9\\u0088\\u00db\\u008c\\u00d8\\u00af \\u00d9\\u0088 \\u00d8\\u00a7\\u00d8\\u00b2 \\u00d9\\u0085\\u00d8\\u00b5\\u00d8\\u00b1\\u00d9\\u0081 \\u00da\\u00a9\\u00d8\\u00a7\\u00d9\\u0081\\u00d8\\u00a6\\u00db\\u008c\\u00d9\\u0086 \\u00d9\\u0088 \\u00d9\\u0088\\u00d8\\u00b3\\u00d8\\u00a7\\u00db\\u008c\\u00d9\\u0084 \\u00d8\\u00a7\\u00d9\\u0084\\u00da\\u00a9\\u00d8\\u00aa\\u00d8\\u00b1\\u00d9\\u0088\\u00d9\\u0086\\u00db\\u008c\\u00da\\u00a9\\u00db\\u008c \\u00d8\\u00ad\\u00d8\\u00af\\u00d8\\u00a7\\u00d9\\u0082\\u00d9\\u0084 \\u00db\\u008c\\u00da\\u00a9 \\u00d8\\u00b3\\u00d8\\u00a7\\u00d8\\u00b9\\u00d8\\u00aa \\u00d9\\u0082\\u00d8\\u00a8\\u00d9\\u0084 \\u00d8\\u00a7\\u00d8\\u00b2 \\u00d8\\u00ae\\u00d9\\u0088\\u00d8\\u00a7\\u00d8\\u00a8 \\u00d8\\u00ae\\u00d9\\u0088\\u00d8\\u00af\\u00d8\\u00af\\u00d8\\u00a7\\u00d8\\u00b1\\u00db\\u008c \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af. \\u00db\\u008c\\u00da\\u00a9 \\u00d8\\u00b1\\u00d9\\u0088\\u00d8\\u00aa\\u00db\\u008c\\u00d9\\u0086 \\u00d8\\u00a2\\u00d8\\u00b1\\u00d8\\u00a7\\u00d9\\u0085\\u00d8\\u00b4\\u00e2\\u0080\\u008c\\u00d8\\u00a8\\u00d8\\u00ae\\u00d8\\u00b4 \\u00d9\\u0082\\u00d8\\u00a8\\u00d9\\u0084 \\u00d8\\u00a7\\u00d8\\u00b2 \\u00d8\\u00ae\\u00d9\\u0088\\u00d8\\u00a7\\u00d8\\u00a8 \\u00d9\\u0085\\u00d8\\u00a7\\u00d9\\u0086\\u00d9\\u0086\\u00d8\\u00af \\u00d9\\u0085\\u00d8\\u00b7\\u00d8\\u00a7\\u00d9\\u0084\\u00d8\\u00b9\\u00d9\\u0087 \\u00db\\u008c\\u00d8\\u00a7 \\u00da\\u00af\\u00d9\\u0088\\u00d8\\u00b4 \\u00d8\\u00af\\u00d8\\u00a7\\u00d8\\u00af\\u00d9\\u0086 \\u00d8\\u00a8\\u00d9\\u0087 \\u00d9\\u0085\\u00d9\\u0088\\u00d8\\u00b3\\u00db\\u008c\\u00d9\\u0082\\u00db\\u008c \\u00d9\\u0085\\u00d9\\u0084\\u00d8\\u00a7\\u00db\\u008c\\u00d9\\u0085 \\u00d8\\u00a7\\u00db\\u008c\\u00d8\\u00ac\\u00d8\\u00a7\\u00d8\\u00af \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af. \\u00d8\\u00ae\\u00d9\\u0088\\u00d8\\u00a7\\u00d8\\u00a8 \\u00da\\u00a9\\u00d8\\u00a7\\u00d9\\u0081\\u00db\\u008c \\u00d8\\u00a8\\u00d9\\u0087 \\u00da\\u00a9\\u00d8\\u00a7\\u00d9\\u0087\\u00d8\\u00b4 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa\\u00d8\\u00b1\\u00d8\\u00b3 \\u00da\\u00a9\\u00d9\\u0085\\u00da\\u00a9 \\u00d8\\u00b4\\u00d8\\u00a7\\u00db\\u008c\\u00d8\\u00a7\\u00d9\\u0086\\u00db\\u008c \\u00d9\\u0085\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00da\\u00a9\\u00d9\\u0086\\u00d8\\u00af.\\\"\\n    }\\n  ]\\n}\"',NULL,'deepseek-local','2026-06-10 12:04:30','2026-06-10 11:55:02','2026-06-10 12:04:38'),(25,'article','full','خرید قسطی',NULL,5,'done','\"\\u00d8\\u00b9\\u00d9\\u0086\\u00d9\\u0088\\u00d8\\u00a7\\u00d9\\u0086: **\\u00d9\\u0082\\u00d8\\u00af\\u00d8\\u00b1\\u00d8\\u00aa \\u00d8\\u00b3\\u00da\\u00a9\\u00d9\\u0088\\u00d8\\u00aa \\u00d8\\u00af\\u00d8\\u00b1 \\u00d8\\u00af\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00a7\\u00db\\u008c \\u00d9\\u00be\\u00d8\\u00b1\\u00d8\\u00b3\\u00d8\\u00b1 \\u00d9\\u0088 \\u00d8\\u00b5\\u00d8\\u00af\\u00d8\\u00a7**  \\n\\n\\u00d8\\u00b3\\u00da\\u00a9\\u00d9\\u0088\\u00d8\\u00aa\\u00d8\\u008c \\u00d8\\u00a8\\u00d8\\u00b1\\u00d8\\u00ae\\u00d9\\u0084\\u00d8\\u00a7\\u00d9\\u0081 \\u00d8\\u00aa\\u00d8\\u00b5\\u00d9\\u0088\\u00d8\\u00b1 \\u00d8\\u00b1\\u00d8\\u00a7\\u00db\\u008c\\u00d8\\u00ac\\u00d8\\u008c \\u00d9\\u0086\\u00d9\\u0087 \\u00d8\\u00a8\\u00d9\\u0087\\u00e2\\u0080\\u008c\\u00d9\\u0085\\u00d8\\u00b9\\u00d9\\u0086\\u00d8\\u00a7\\u00db\\u008c \\u00d8\\u00b6\\u00d8\\u00b9\\u00d9\\u0081 \\u00db\\u008c\\u00d8\\u00a7 \\u00d8\\u00a7\\u00d9\\u0086\\u00d8\\u00b2\\u00d9\\u0088\\u00d8\\u00a7\\u00d8\\u008c \\u00d8\\u00a8\\u00d9\\u0084\\u00da\\u00a9\\u00d9\\u0087 \\u00d9\\u0086\\u00d8\\u00b4\\u00d8\\u00a7\\u00d9\\u0086\\u00d9\\u0087\\u00e2\\u0080\\u008c\\u00d8\\u00a7\\u00db\\u008c \\u00d8\\u00a7\\u00d8\\u00b2 \\u00d9\\u0082\\u00d8\\u00af\\u00d8\\u00b1\\u00d8\\u00aa \\u00d8\\u00af\\u00d8\\u00b1\\u00d9\\u0088\\u00d9\\u0086\\u00db\\u008c \\u00d9\\u0088 \\u00d8\\u00ae\\u00d8\\u00b1\\u00d8\\u00af\\u00d9\\u0085\\u00d9\\u0086\\u00d8\\u00af\\u00db\\u008c \\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa. \\u00d8\\u00af\\u00d8\\u00b1 \\u00d8\\u00af\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00a7\\u00db\\u008c\\u00db\\u008c \\u00da\\u00a9\\u00d9\\u0087 \\u00d9\\u0087\\u00d9\\u0085\\u00d9\\u0087 \\u00d8\\u00af\\u00d8\\u00b1 \\u00d8\\u00aa\\u00d9\\u0084\\u00d8\\u00a7\\u00d8\\u00b4 \\u00d8\\u00a8\\u00d8\\u00b1\\u00d8\\u00a7\\u00db\\u008c \\u00d8\\u00b4\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af\\u00d9\\u0087 \\u00d8\\u00b4\\u00d8\\u00af\\u00d9\\u0086 \\u00d9\\u0088 \\u00d8\\u00a7\\u00d8\\u00b8\\u00d9\\u0087\\u00d8\\u00a7\\u00d8\\u00b1 \\u00d9\\u0086\\u00d8\\u00b8\\u00d8\\u00b1 \\u00d9\\u0087\\u00d8\\u00b3\\u00d8\\u00aa\\u00d9\\u0086\\u00d8\\u00af\\u00d8\\u008c \\u00da\\u00a9\\u00d8\\u00b3\\u00db\\u008c \\u00da\\u00a9\\u00d9\\u0087 \\u00d9\\u0087\\u00d9\\u0086\\u00d8\\u00b1 \\u00d8\\u00b3\\u00da\\u00a9\\u00d9\\u0088\\u00d8\\u00aa \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d9\\u0085\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00d8\\u00af\\u00d8\\u00a7\\u00d9\\u0086\\u00d8\\u00af\\u00d8\\u008c \\u00d8\\u00af\\u00d8\\u00b1 \\u00d8\\u00ad\\u00d9\\u0082\\u00db\\u008c\\u00d9\\u0082\\u00d8\\u00aa \\u00d8\\u00a8\\u00d8\\u00b1 \\u00d8\\u00a7\\u00d8\\u00ad\\u00d8\\u00b3\\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00a7\\u00d8\\u00aa \\u00d9\\u0088 \\u00d8\\u00a7\\u00d9\\u0081\\u00da\\u00a9\\u00d8\\u00a7\\u00d8\\u00b1 \\u00d8\\u00ae\\u00d9\\u0088\\u00d8\\u00af \\u00d9\\u0085\\u00d8\\u00b3\\u00d9\\u0084\\u00d8\\u00b7 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa. \\u00d8\\u00b3\\u00da\\u00a9\\u00d9\\u0088\\u00d8\\u00aa \\u00d8\\u00a8\\u00d9\\u0087 \\u00d9\\u0085\\u00d8\\u00a7 \\u00d9\\u0081\\u00d8\\u00b1\\u00d8\\u00b5\\u00d8\\u00aa \\u00d9\\u0085\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00d8\\u00af\\u00d9\\u0087\\u00d8\\u00af \\u00d9\\u00be\\u00db\\u008c\\u00d8\\u00b4 \\u00d8\\u00a7\\u00d8\\u00b2 \\u00d8\\u00b3\\u00d8\\u00ae\\u00d9\\u0086 \\u00da\\u00af\\u00d9\\u0081\\u00d8\\u00aa\\u00d9\\u0086\\u00d8\\u008c \\u00d8\\u00b9\\u00d9\\u0085\\u00db\\u008c\\u00d9\\u0082\\u00e2\\u0080\\u008c\\u00d8\\u00aa\\u00d8\\u00b1 \\u00d8\\u00a8\\u00db\\u008c\\u00d9\\u0086\\u00d8\\u00af\\u00db\\u008c\\u00d8\\u00b4\\u00db\\u008c\\u00d9\\u0085 \\u00d9\\u0088 \\u00d9\\u0088\\u00d8\\u00a7\\u00da\\u00a9\\u00d9\\u0086\\u00d8\\u00b4\\u00e2\\u0080\\u008c\\u00d9\\u0087\\u00d8\\u00a7\\u00db\\u008c \\u00d8\\u00b9\\u00d8\\u00ac\\u00d9\\u0088\\u00d9\\u0084\\u00d8\\u00a7\\u00d9\\u0086\\u00d9\\u0087 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d9\\u0085\\u00d9\\u0087\\u00d8\\u00a7\\u00d8\\u00b1 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d9\\u0085. \\u00d8\\u00a7\\u00db\\u008c\\u00d9\\u0086 \\u00d8\\u00aa\\u00d9\\u0088\\u00d8\\u00a7\\u00d9\\u0086\\u00d8\\u00a7\\u00db\\u008c\\u00db\\u008c\\u00d8\\u008c \\u00d9\\u0086\\u00d9\\u0087\\u00e2\\u0080\\u008c\\u00d8\\u00aa\\u00d9\\u0086\\u00d9\\u0087\\u00d8\\u00a7 \\u00d8\\u00a7\\u00d8\\u00b2 \\u00d8\\u00a8\\u00d8\\u00b1\\u00d9\\u0088\\u00d8\\u00b2 \\u00d8\\u00aa\\u00d9\\u0086\\u00d8\\u00b4\\u00e2\\u0080\\u008c\\u00d9\\u0087\\u00d8\\u00a7\\u00db\\u008c \\u00d8\\u00a8\\u00db\\u008c\\u00d9\\u0087\\u00d9\\u0088\\u00d8\\u00af\\u00d9\\u0087 \\u00d8\\u00ac\\u00d9\\u0084\\u00d9\\u0088\\u00da\\u00af\\u00db\\u008c\\u00d8\\u00b1\\u00db\\u008c \\u00d9\\u0085\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00da\\u00a9\\u00d9\\u0086\\u00d8\\u00af\\u00d8\\u008c \\u00d8\\u00a8\\u00d9\\u0084\\u00da\\u00a9\\u00d9\\u0087 \\u00d8\\u00a8\\u00d9\\u0087 \\u00d8\\u00af\\u00db\\u008c\\u00da\\u00af\\u00d8\\u00b1\\u00d8\\u00a7\\u00d9\\u0086 \\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00b2 \\u00d9\\u0086\\u00d8\\u00b4\\u00d8\\u00a7\\u00d9\\u0086 \\u00d9\\u0085\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00d8\\u00af\\u00d9\\u0087\\u00d8\\u00af \\u00da\\u00a9\\u00d9\\u0087 \\u00d8\\u00a7\\u00d8\\u00b1\\u00d8\\u00b2\\u00d8\\u00b4 \\u00d8\\u00ad\\u00d8\\u00b1\\u00d9\\u0081 \\u00d8\\u00b2\\u00d8\\u00af\\u00d9\\u0086 \\u00d8\\u00af\\u00d8\\u00b1 \\u00d8\\u00b2\\u00d9\\u0085\\u00d8\\u00a7\\u00d9\\u0086 \\u00d9\\u0085\\u00d9\\u0086\\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00a8 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d9\\u0085\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00d8\\u00af\\u00d8\\u00a7\\u00d9\\u0086\\u00db\\u008c\\u00d9\\u0085.  \\n\\n\\u00d8\\u00a7\\u00d8\\u00b2 \\u00d8\\u00b3\\u00d9\\u0088\\u00db\\u008c \\u00d8\\u00af\\u00db\\u008c\\u00da\\u00af\\u00d8\\u00b1\\u00d8\\u008c \\u00d8\\u00b3\\u00da\\u00a9\\u00d9\\u0088\\u00d8\\u00aa \\u00d9\\u0081\\u00d8\\u00b6\\u00d8\\u00a7\\u00db\\u008c\\u00db\\u008c \\u00d8\\u00a8\\u00d8\\u00b1\\u00d8\\u00a7\\u00db\\u008c \\u00d8\\u00b4\\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00af\\u00d9\\u0086 \\u00d9\\u0088\\u00d8\\u00a7\\u00d9\\u0082\\u00d8\\u00b9\\u00db\\u008c \\u00d9\\u0081\\u00d8\\u00b1\\u00d8\\u00a7\\u00d9\\u0087\\u00d9\\u0085 \\u00d9\\u0085\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00da\\u00a9\\u00d9\\u0086\\u00d8\\u00af. \\u00d8\\u00a8\\u00d8\\u00b3\\u00db\\u008c\\u00d8\\u00a7\\u00d8\\u00b1\\u00db\\u008c \\u00d8\\u00a7\\u00d8\\u00b2 \\u00d9\\u0085\\u00d8\\u00a7 \\u00d8\\u00a2\\u00d9\\u0086\\u00d9\\u0082\\u00d8\\u00af\\u00d8\\u00b1 \\u00d8\\u00af\\u00d8\\u00b1\\u00da\\u00af\\u00db\\u008c\\u00d8\\u00b1 \\u00d9\\u00be\\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00ae \\u00d8\\u00af\\u00d8\\u00a7\\u00d8\\u00af\\u00d9\\u0086 \\u00d9\\u0087\\u00d8\\u00b3\\u00d8\\u00aa\\u00db\\u008c\\u00d9\\u0085 \\u00da\\u00a9\\u00d9\\u0087 \\u00d9\\u0081\\u00d8\\u00b1\\u00d8\\u00a7\\u00d9\\u0085\\u00d9\\u0088\\u00d8\\u00b4 \\u00d9\\u0085\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d9\\u0085 \\u00da\\u00af\\u00d9\\u0088\\u00d8\\u00b4 \\u00d8\\u00af\\u00d8\\u00a7\\u00d8\\u00af\\u00d9\\u0086 \\u00db\\u008c\\u00da\\u00a9\\u00db\\u008c \\u00d8\\u00a7\\u00d8\\u00b2 \\u00d8\\u00a8\\u00d8\\u00b2\\u00d8\\u00b1\\u00da\\u00af\\u00e2\\u0080\\u008c\\u00d8\\u00aa\\u00d8\\u00b1\\u00db\\u008c\\u00d9\\u0086 \\u00d9\\u0087\\u00d9\\u0086\\u00d8\\u00b1\\u00d9\\u0087\\u00d8\\u00a7\\u00db\\u008c \\u00d8\\u00a7\\u00d8\\u00b1\\u00d8\\u00aa\\u00d8\\u00a8\\u00d8\\u00a7\\u00d8\\u00b7\\u00db\\u008c \\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa. \\u00d8\\u00af\\u00d8\\u00b1 \\u00d8\\u00b3\\u00da\\u00a9\\u00d9\\u0088\\u00d8\\u00aa\\u00d8\\u008c \\u00d9\\u0085\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00d8\\u00aa\\u00d9\\u0088\\u00d8\\u00a7\\u00d9\\u0086\\u00db\\u008c\\u00d9\\u0085 \\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00a7\\u00d8\\u00b2\\u00d9\\u0087\\u00d8\\u00a7\\u00d8\\u008c \\u00d9\\u0086\\u00da\\u00af\\u00d8\\u00b1\\u00d8\\u00a7\\u00d9\\u0086\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00d9\\u0087\\u00d8\\u00a7 \\u00d9\\u0088 \\u00d8\\u00a7\\u00d8\\u00ad\\u00d8\\u00b3\\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00a7\\u00d8\\u00aa \\u00d8\\u00af\\u00db\\u008c\\u00da\\u00af\\u00d8\\u00b1\\u00d8\\u00a7\\u00d9\\u0086 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d9\\u0087\\u00d8\\u00aa\\u00d8\\u00b1 \\u00d8\\u00af\\u00d8\\u00b1\\u00da\\u00a9 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d9\\u0085 \\u00d9\\u0088 \\u00d9\\u0087\\u00d9\\u0085\\u00d8\\u00af\\u00d9\\u0084\\u00db\\u008c \\u00d9\\u0088\\u00d8\\u00a7\\u00d9\\u0082\\u00d8\\u00b9\\u00db\\u008c \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00aa\\u00d8\\u00ac\\u00d8\\u00b1\\u00d8\\u00a8\\u00d9\\u0087 \\u00d9\\u0086\\u00d9\\u0085\\u00d8\\u00a7\\u00db\\u008c\\u00db\\u008c\\u00d9\\u0085. \\u00d8\\u00a7\\u00db\\u008c\\u00d9\\u0086 \\u00d9\\u0086\\u00d9\\u0088\\u00d8\\u00b9 \\u00d8\\u00a7\\u00d8\\u00b2 \\u00d8\\u00b3\\u00da\\u00a9\\u00d9\\u0088\\u00d8\\u00aa\\u00d8\\u008c \\u00d9\\u00be\\u00d9\\u0084\\u00db\\u008c \\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa \\u00d8\\u00a8\\u00d8\\u00b1\\u00d8\\u00a7\\u00db\\u008c \\u00d8\\u00a7\\u00db\\u008c\\u00d8\\u00ac\\u00d8\\u00a7\\u00d8\\u00af \\u00d8\\u00b1\\u00d9\\u0088\\u00d8\\u00a7\\u00d8\\u00a8\\u00d8\\u00b7 \\u00d8\\u00b9\\u00d9\\u0085\\u00db\\u008c\\u00d9\\u0082\\u00e2\\u0080\\u008c\\u00d8\\u00aa\\u00d8\\u00b1 \\u00d9\\u0088 \\u00d9\\u00be\\u00d8\\u00a7\\u00db\\u008c\\u00d8\\u00af\\u00d8\\u00a7\\u00d8\\u00b1\\u00d8\\u00aa\\u00d8\\u00b1\\u00d8\\u008c \\u00da\\u0086\\u00d9\\u0087 \\u00d8\\u00af\\u00d8\\u00b1 \\u00d9\\u0085\\u00d8\\u00ad\\u00db\\u008c\\u00d8\\u00b7 \\u00da\\u00a9\\u00d8\\u00a7\\u00d8\\u00b1\\u00d8\\u008c \\u00da\\u0086\\u00d9\\u0087 \\u00d8\\u00af\\u00d8\\u00b1 \\u00d8\\u00ae\\u00d8\\u00a7\\u00d9\\u0086\\u00d9\\u0088\\u00d8\\u00a7\\u00d8\\u00af\\u00d9\\u0087 \\u00d9\\u0088 \\u00da\\u0086\\u00d9\\u0087 \\u00d8\\u00af\\u00d8\\u00b1 \\u00d8\\u00af\\u00d9\\u0088\\u00d8\\u00b3\\u00d8\\u00aa\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00d9\\u0087\\u00d8\\u00a7.  \\n\\n\\u00d8\\u00af\\u00d8\\u00b1 \\u00d9\\u0086\\u00d9\\u0087\\u00d8\\u00a7\\u00db\\u008c\\u00d8\\u00aa\\u00d8\\u008c \\u00d8\\u00b3\\u00da\\u00a9\\u00d9\\u0088\\u00d8\\u00aa \\u00d9\\u0086\\u00d9\\u0087 \\u00db\\u008c\\u00da\\u00a9 \\u00d8\\u00ba\\u00db\\u008c\\u00d8\\u00a8\\u00d8\\u00aa\\u00d8\\u008c \\u00d8\\u00a8\\u00d9\\u0084\\u00da\\u00a9\\u00d9\\u0087 \\u00db\\u008c\\u00da\\u00a9 \\u00d8\\u00ad\\u00d8\\u00b6\\u00d9\\u0088\\u00d8\\u00b1 \\u00d8\\u00a2\\u00da\\u00af\\u00d8\\u00a7\\u00d9\\u0087\\u00d8\\u00a7\\u00d9\\u0086\\u00d9\\u0087 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa. \\u00d8\\u00a7\\u00db\\u008c\\u00d9\\u0086 \\u00d8\\u00a7\\u00d9\\u0086\\u00d8\\u00aa\\u00d8\\u00ae\\u00d8\\u00a7\\u00d8\\u00a8 \\u00d9\\u0087\\u00d9\\u0088\\u00d8\\u00b4\\u00d9\\u0085\\u00d9\\u0086\\u00d8\\u00af\\u00d8\\u00a7\\u00d9\\u0086\\u00d9\\u0087 \\u00d8\\u00a8\\u00d9\\u0087 \\u00d9\\u0085\\u00d8\\u00a7 \\u00db\\u008c\\u00d8\\u00a7\\u00d8\\u00af\\u00d8\\u00a2\\u00d9\\u0088\\u00d8\\u00b1\\u00db\\u008c \\u00d9\\u0085\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00da\\u00a9\\u00d9\\u0086\\u00d8\\u00af \\u00da\\u00a9\\u00d9\\u0087 \\u00d9\\u0087\\u00d9\\u0085\\u00db\\u008c\\u00d8\\u00b4\\u00d9\\u0087 \\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00a7\\u00d8\\u00b2\\u00db\\u008c \\u00d8\\u00a8\\u00d9\\u0087 \\u00d9\\u00be\\u00d8\\u00b1 \\u00da\\u00a9\\u00d8\\u00b1\\u00d8\\u00af\\u00d9\\u0086 \\u00d8\\u00ae\\u00d9\\u0084\\u00d8\\u00a3\\u00d9\\u0087\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d8\\u00a7 \\u00da\\u00a9\\u00d9\\u0084\\u00d9\\u0085\\u00d8\\u00a7\\u00d8\\u00aa \\u00d9\\u0086\\u00db\\u008c\\u00d8\\u00b3\\u00d8\\u00aa. \\u00da\\u00af\\u00d8\\u00a7\\u00d9\\u0087\\u00db\\u008c \\u00d8\\u00a8\\u00d9\\u0087\\u00d8\\u00aa\\u00d8\\u00b1\\u00db\\u008c\\u00d9\\u0086 \\u00d9\\u00be\\u00db\\u008c\\u00d8\\u00a7\\u00d9\\u0085 \\u00d8\\u00af\\u00d8\\u00b1 \\u00d8\\u00b3\\u00da\\u00a9\\u00d9\\u0088\\u00d8\\u00aa \\u00d9\\u00be\\u00d9\\u0086\\u00d9\\u0087\\u00d8\\u00a7\\u00d9\\u0086 \\u00d8\\u00a7\\u00d8\\u00b3\\u00d8\\u00aa\\u00d8\\u009b \\u00d9\\u00be\\u00db\\u008c\\u00d8\\u00a7\\u00d9\\u0085\\u00db\\u008c \\u00da\\u00a9\\u00d9\\u0087 \\u00d8\\u00af\\u00db\\u008c\\u00da\\u00af\\u00d8\\u00b1\\u00d8\\u00a7\\u00d9\\u0086 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00a8\\u00d9\\u0087 \\u00d8\\u00aa\\u00d9\\u0081\\u00da\\u00a9\\u00d8\\u00b1 \\u00d9\\u0088\\u00d8\\u00a7\\u00d9\\u0085\\u00db\\u008c\\u00d8\\u00af\\u00d8\\u00a7\\u00d8\\u00b1\\u00d8\\u00af \\u00d9\\u0088 \\u00d8\\u00a7\\u00d8\\u00ad\\u00d8\\u00aa\\u00d8\\u00b1\\u00d8\\u00a7\\u00d9\\u0085 \\u00d9\\u0085\\u00d8\\u00aa\\u00d9\\u0082\\u00d8\\u00a7\\u00d8\\u00a8\\u00d9\\u0084 \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00aa\\u00d9\\u0082\\u00d9\\u0088\\u00db\\u008c\\u00d8\\u00aa \\u00d9\\u0085\\u00db\\u008c\\u00e2\\u0080\\u008c\\u00da\\u00a9\\u00d9\\u0086\\u00d8\\u00af. \\u00d9\\u00be\\u00d8\\u00b3 \\u00d8\\u00a8\\u00db\\u008c\\u00d8\\u00a7\\u00db\\u008c\\u00db\\u008c\\u00d8\\u00af \\u00da\\u00af\\u00d8\\u00a7\\u00d9\\u0087\\u00db\\u008c \\u00d8\\u00a7\\u00d8\\u00b2 \\u00d9\\u0087\\u00db\\u008c\\u00d8\\u00a7\\u00d9\\u0087\\u00d9\\u0088\\u00db\\u008c \\u00d8\\u00b1\\u00d9\\u0088\\u00d8\\u00b2\\u00d9\\u0085\\u00d8\\u00b1\\u00d9\\u0087 \\u00d9\\u0081\\u00d8\\u00a7\\u00d8\\u00b5\\u00d9\\u0084\\u00d9\\u0087 \\u00d8\\u00a8\\u00da\\u00af\\u00db\\u008c\\u00d8\\u00b1\\u00db\\u008c\\u00d9\\u0085 \\u00d9\\u0088 \\u00d9\\u0082\\u00d8\\u00af\\u00d8\\u00b1\\u00d8\\u00aa \\u00d8\\u00aa\\u00d8\\u00ad\\u00d9\\u0088\\u00d9\\u0084\\u00e2\\u0080\\u008c\\u00d8\\u00a2\\u00d9\\u0081\\u00d8\\u00b1\\u00db\\u008c\\u00d9\\u0086 \\u00d8\\u00b3\\u00da\\u00a9\\u00d9\\u0088\\u00d8\\u00aa \\u00d8\\u00b1\\u00d8\\u00a7 \\u00d8\\u00af\\u00d8\\u00b1 \\u00d8\\u00b2\\u00d9\\u0086\\u00d8\\u00af\\u00da\\u00af\\u00db\\u008c \\u00d8\\u00ae\\u00d9\\u0088\\u00d8\\u00af \\u00d8\\u00aa\\u00d8\\u00ac\\u00d8\\u00b1\\u00d8\\u00a8\\u00d9\\u0087 \\u00da\\u00a9\\u00d9\\u0086\\u00db\\u008c\\u00d9\\u0085.\"',NULL,'deepseek-local','2026-06-10 12:04:30','2026-06-10 11:57:53','2026-06-10 12:04:47');
/*!40000 ALTER TABLE `ai_generation_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `analytics_page_views`
--

DROP TABLE IF EXISTS `analytics_page_views`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `analytics_page_views` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `path` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `page_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referrer` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `session_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` bigint unsigned DEFAULT NULL,
  `country` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `visited_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `analytics_page_views_path_visited_at_index` (`path`,`visited_at`),
  KEY `analytics_page_views_session_id_index` (`session_id`),
  KEY `analytics_page_views_customer_id_index` (`customer_id`),
  KEY `analytics_page_views_visited_at_index` (`visited_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3021 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `analytics_page_views`
--

LOCK TABLES `analytics_page_views` WRITE;
/*!40000 ALTER TABLE `analytics_page_views` DISABLE KEYS */;
INSERT INTO `analytics_page_views` VALUES (1,'/',NULL,NULL,'V2DVYPe0TNo3fWOUMoNIG4M3x6tY6bA2M43bYLM7',NULL,NULL,'desktop','Other','2026-06-19 06:31:37'),(2,'/',NULL,NULL,'1LBzEvbwg079AkgE6QRPLKqNd5reDnqQekVjmEtR',NULL,NULL,'desktop','Other','2026-06-19 06:31:58'),(3,'/',NULL,NULL,'oWlsF49d8SQT8cU3nionj9lXicOc79UWiVSUBpc6',NULL,NULL,'desktop','Other','2026-06-19 06:31:58'),(4,'/',NULL,NULL,'M3bkF4VlFcFh5iDTkyau1PaIbW5wlSgCUwF6hrbc',NULL,NULL,'desktop','Other','2026-06-19 06:31:58'),(5,'/',NULL,NULL,'DbZbA7YuRssRPQ1t3225uMPpnt2xk4ImBm2wYpyK',NULL,NULL,'desktop','Other','2026-06-19 06:31:58'),(6,'/',NULL,'https://safhenokhost.ir/','b2sBEY2QHo5q1VwyPTToQoYiQnsidojkehoJbORq',NULL,NULL,'desktop','Firefox','2026-06-19 06:36:58'),(7,'login',NULL,NULL,'b2sBEY2QHo5q1VwyPTToQoYiQnsidojkehoJbORq',NULL,NULL,'desktop','Firefox','2026-06-19 06:37:25'),(8,'login',NULL,'https://safhenokhost.ir/admin/dashboard','FlHtb0XYWvHCeM0IwwOEoUHf8VoAAAhPiH1YiN3l',1,NULL,'desktop','Firefox','2026-06-19 06:37:35'),(9,'/',NULL,NULL,'rHjuMWw4D1QdIRCLYuwlWz2ck3rEA5mwOUERO46R',NULL,NULL,'desktop','Chrome','2026-06-19 06:40:17'),(10,'/',NULL,NULL,'MJTMdF5laEiBwDZs7Kz5cLCl416ECaQD6Jis5n5b',NULL,NULL,'desktop','Other','2026-06-19 06:43:56'),(11,'/',NULL,NULL,'BdxQPJJlecjTb4sx8Hl9dyKM4SVHTApDA16IRroz',NULL,NULL,'desktop','Chrome','2026-06-19 06:52:30'),(12,'/',NULL,NULL,'q4UFQipoxA6BA9KZ0ismeZZHnqQICD17qM7j2Ks4',NULL,NULL,'desktop','Chrome','2026-06-19 06:52:31'),(13,'/',NULL,NULL,'nKl3bUJkeQ0lfEEapYdio1AbHLY5uazb3EVztCfo',NULL,NULL,'desktop','Chrome','2026-06-19 06:52:37'),(14,'blog',NULL,NULL,'nKl3bUJkeQ0lfEEapYdio1AbHLY5uazb3EVztCfo',NULL,NULL,'desktop','Chrome','2026-06-19 06:53:02'),(15,'register',NULL,NULL,'nKl3bUJkeQ0lfEEapYdio1AbHLY5uazb3EVztCfo',NULL,NULL,'desktop','Chrome','2026-06-19 06:53:02'),(16,'login',NULL,NULL,'nKl3bUJkeQ0lfEEapYdio1AbHLY5uazb3EVztCfo',NULL,NULL,'desktop','Chrome','2026-06-19 06:53:02'),(17,'contact',NULL,NULL,'nKl3bUJkeQ0lfEEapYdio1AbHLY5uazb3EVztCfo',NULL,NULL,'desktop','Chrome','2026-06-19 06:53:02'),(18,'courses',NULL,NULL,'nKl3bUJkeQ0lfEEapYdio1AbHLY5uazb3EVztCfo',NULL,NULL,'desktop','Chrome','2026-06-19 06:53:03'),(19,'shop',NULL,NULL,'nKl3bUJkeQ0lfEEapYdio1AbHLY5uazb3EVztCfo',NULL,NULL,'desktop','Chrome','2026-06-19 06:53:03'),(20,'/',NULL,NULL,'owYuCN2IGXzii0yHHxYgzpCaSPsoT5EMK2MI1U0y',NULL,NULL,'desktop','Other','2026-06-19 06:54:53'),(21,'/',NULL,NULL,'Z6E7Zo9Ksobd0qSxU1ojPdrBnuZ8p2c6njV65PJH',NULL,NULL,'desktop','Other','2026-06-19 07:15:41'),(22,'/',NULL,NULL,'FCcDTOrVCdxG6iuQjLwlW9TVRjfszKlrGKjxapfj',NULL,NULL,'desktop','Other','2026-06-19 07:19:01'),(23,'/',NULL,'https://safhenokhost.ir/','FlHtb0XYWvHCeM0IwwOEoUHf8VoAAAhPiH1YiN3l',1,NULL,'desktop','Firefox','2026-06-19 07:20:20'),(24,'/',NULL,NULL,'9KIubhnTSvBJ2a8c3XcyCLbxf98bIZIzxhwMzCIj',NULL,NULL,'desktop','Other','2026-06-19 07:20:54'),(25,'login',NULL,'https://safhenokhost.ir/admin/dashboard','FlHtb0XYWvHCeM0IwwOEoUHf8VoAAAhPiH1YiN3l',1,NULL,'desktop','Firefox','2026-06-19 07:21:09'),(26,'/',NULL,NULL,'vw4pB51GoJqcScqBsUWvd7rxcwLJ0RDFwvJzqinz',NULL,NULL,'desktop','Chrome','2026-06-19 07:23:14'),(27,'/',NULL,'https://safhenokhost.ir','HGkTVRSJ0xQpd5IsJ84cPtqmcNhZOAlh7Pcnxbun',NULL,NULL,'mobile','Safari','2026-06-19 07:29:48'),(28,'/',NULL,NULL,'i6sDFAuceyu3NsQ7GEnMApdR2CFfJdmV22QVtDCo',NULL,NULL,'desktop','Chrome','2026-06-19 07:39:33'),(29,'/',NULL,NULL,'VZWp31j5ftskqbfuPB27PsLuodxuR3WXVMrV8Lr4',NULL,NULL,'desktop','Chrome','2026-06-19 07:39:36'),(30,'/',NULL,NULL,'KVhpm2zh8Ct4qg78bJrhCG95aTtLNbcAdQzaoPmQ',NULL,NULL,'desktop','Firefox','2026-06-19 07:40:15'),(31,'/',NULL,NULL,'oITXPGItC0pX8tjhgagpHj2XyDUPz7w8StrxRmwU',NULL,NULL,'desktop','Chrome','2026-06-19 07:41:30'),(32,'/',NULL,NULL,'QzarG1Y9ItMDBCGKVfZxTwdbalmO2gJ5twIzyYxz',NULL,NULL,'desktop','Chrome','2026-06-19 07:47:25'),(33,'/',NULL,NULL,'Oh69IWEAOQJICWLLMeev1sRUVv188CveIRzWqRNU',NULL,NULL,'desktop','Chrome','2026-06-19 07:47:36'),(34,'blog',NULL,NULL,'Oh69IWEAOQJICWLLMeev1sRUVv188CveIRzWqRNU',NULL,NULL,'desktop','Chrome','2026-06-19 07:47:37'),(35,'contact',NULL,NULL,'Oh69IWEAOQJICWLLMeev1sRUVv188CveIRzWqRNU',NULL,NULL,'desktop','Chrome','2026-06-19 07:47:38'),(36,'register',NULL,NULL,'Oh69IWEAOQJICWLLMeev1sRUVv188CveIRzWqRNU',NULL,NULL,'desktop','Chrome','2026-06-19 07:47:39'),(37,'shop',NULL,NULL,'Oh69IWEAOQJICWLLMeev1sRUVv188CveIRzWqRNU',NULL,NULL,'desktop','Chrome','2026-06-19 07:47:41'),(38,'courses',NULL,NULL,'Oh69IWEAOQJICWLLMeev1sRUVv188CveIRzWqRNU',NULL,NULL,'desktop','Chrome','2026-06-19 07:47:42'),(39,'login',NULL,NULL,'Oh69IWEAOQJICWLLMeev1sRUVv188CveIRzWqRNU',NULL,NULL,'desktop','Chrome','2026-06-19 07:47:42'),(40,'blog/category/mhtoa',NULL,NULL,'Oh69IWEAOQJICWLLMeev1sRUVv188CveIRzWqRNU',NULL,NULL,'desktop','Chrome','2026-06-19 07:47:43'),(41,'shop/wishlist',NULL,NULL,'Oh69IWEAOQJICWLLMeev1sRUVv188CveIRzWqRNU',NULL,NULL,'desktop','Chrome','2026-06-19 07:47:43'),(42,'shop/compare',NULL,NULL,'Oh69IWEAOQJICWLLMeev1sRUVv188CveIRzWqRNU',NULL,NULL,'desktop','Chrome','2026-06-19 07:47:43'),(43,'shop/cart',NULL,NULL,'Oh69IWEAOQJICWLLMeev1sRUVv188CveIRzWqRNU',NULL,NULL,'desktop','Chrome','2026-06-19 07:47:44'),(44,'courses/amozsh-mhtoa-noysy',NULL,NULL,'Oh69IWEAOQJICWLLMeev1sRUVv188CveIRzWqRNU',NULL,NULL,'desktop','Chrome','2026-06-19 07:47:44'),(45,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'Oh69IWEAOQJICWLLMeev1sRUVv188CveIRzWqRNU',NULL,NULL,'desktop','Chrome','2026-06-19 07:47:44'),(46,'/',NULL,NULL,'nzGpaBxp5lYY9gQh6Wj0Qqp7ovgFl4HzhRkdgJ36',NULL,NULL,'mobile','Chrome','2026-06-19 09:58:45'),(47,'login',NULL,NULL,'nzGpaBxp5lYY9gQh6Wj0Qqp7ovgFl4HzhRkdgJ36',NULL,NULL,'mobile','Chrome','2026-06-19 09:58:58'),(48,'login',NULL,'https://safhenokhost.ir/admin/dashboard','f0P2d0qhEAVfrCO1GTbbXd44e8PPR3ndQMBksmSx',1,NULL,'mobile','Chrome','2026-06-19 10:00:19'),(49,'login',NULL,'https://safhenokhost.ir/login','9Wbzg7En6KXVHg5HVftrZTHKz2VGVufFQPXd2Fh8',NULL,NULL,'mobile','Chrome','2026-06-19 10:00:31'),(50,'login',NULL,'https://safhenokhost.ir/admin/dashboard','yOlUjHWM4hkbS33Szs9mTYOcbXFukommpBOLR66q',1,NULL,'mobile','Chrome','2026-06-19 10:00:39'),(51,'page/blog',NULL,'https://safhenokhost.ir/admin/pages','yOlUjHWM4hkbS33Szs9mTYOcbXFukommpBOLR66q',1,NULL,'mobile','Chrome','2026-06-19 10:01:26'),(52,'builder/page/2/edit',NULL,'https://safhenokhost.ir/page/blog','yOlUjHWM4hkbS33Szs9mTYOcbXFukommpBOLR66q',1,NULL,'mobile','Chrome','2026-06-19 10:01:29'),(53,'/',NULL,NULL,'4rs4ReRICu5LxKcWmJbbCL9CQ6cmzaMGJg40YdQG',NULL,NULL,'mobile','Safari','2026-06-19 10:02:08'),(54,'login',NULL,NULL,'FlHtb0XYWvHCeM0IwwOEoUHf8VoAAAhPiH1YiN3l',NULL,NULL,'desktop','Firefox','2026-06-19 10:21:32'),(55,'login',NULL,'https://safhenokhost.ir/admin/dashboard','kLH8lF7cBb9b6tErQOdr8TCyZJa8EUrzQt8RGGlr',1,NULL,'desktop','Firefox','2026-06-19 10:21:55'),(56,'/',NULL,NULL,'0oU8tyKeDdp8BZFedPWdipPZWh5aVjon6Rc7z2hu',NULL,NULL,'desktop','Chrome','2026-06-19 10:26:10'),(57,'/',NULL,'https://safhenokhost.ir/','dgbOTd6fzs00pC0CGjpNhs3SvCmD3AB6wag2Cn2Y',NULL,NULL,'desktop','Firefox','2026-06-19 10:27:15'),(58,'login',NULL,NULL,'dgbOTd6fzs00pC0CGjpNhs3SvCmD3AB6wag2Cn2Y',NULL,NULL,'desktop','Firefox','2026-06-19 10:27:21'),(59,'account',NULL,'https://safhenokhost.ir/login','vwI9UHYVKo5QRBy4eOdC9mfRZToKQoQY4gLg8D3R',2,NULL,'desktop','Firefox','2026-06-19 10:27:33'),(60,'login',NULL,'https://safhenokhost.ir/account','vwI9UHYVKo5QRBy4eOdC9mfRZToKQoQY4gLg8D3R',2,NULL,'desktop','Firefox','2026-06-19 10:27:44'),(61,'account/installments',NULL,'https://safhenokhost.ir/account','vwI9UHYVKo5QRBy4eOdC9mfRZToKQoQY4gLg8D3R',2,NULL,'desktop','Firefox','2026-06-19 10:27:57'),(62,'/',NULL,'https://safhenokhost.ir/account/installments','vwI9UHYVKo5QRBy4eOdC9mfRZToKQoQY4gLg8D3R',2,NULL,'desktop','Firefox','2026-06-19 10:28:00'),(63,'/',NULL,NULL,'VFyUcbgEdT9jsmFqMtZVlceNZmIKdgoRfNxwIzKK',NULL,NULL,'mobile','Chrome','2026-06-19 10:42:42'),(64,'/',NULL,'https://safhenokhost.ir/product-tag/%D9%BE%D8%B4%D8%AA%DB%8C%D8%A8%D8%A7%D9%86%DB%8C-%D9%88%D8%B1%D8%AF%D9%BE%D8%B1%D8%B3','1SmP5gxl0BZ89LeEsjcv9Xf0f19Uj00wWCSIJqKn',NULL,NULL,'desktop','Chrome','2026-06-19 10:53:59'),(65,'login',NULL,NULL,'1SmP5gxl0BZ89LeEsjcv9Xf0f19Uj00wWCSIJqKn',NULL,NULL,'desktop','Chrome','2026-06-19 10:54:10'),(66,'login',NULL,'https://safhenokhost.ir/admin/dashboard','Irzyo595fZBUqv6f9vlJs3nfs4CpJEm6nTbUs1Fg',1,NULL,'desktop','Chrome','2026-06-19 10:54:49'),(67,'/',NULL,'android-app://com.google.android.googlequicksearchbox/','V1ZkKAW67RYoAXPmTDuX1iKkeFbndNGGXUxobdDl',NULL,NULL,'mobile','Chrome','2026-06-19 10:56:43'),(68,'login',NULL,NULL,'V1ZkKAW67RYoAXPmTDuX1iKkeFbndNGGXUxobdDl',NULL,NULL,'mobile','Chrome','2026-06-19 10:57:17'),(69,'login',NULL,'https://safhenokhost.ir/admin/dashboard','bINSOTiqY3fZlSS6SA61kQbrwOMpSlZaoqotFjQI',1,NULL,'mobile','Chrome','2026-06-19 10:57:58'),(70,'account',NULL,'https://safhenokhost.ir/login','vwI9UHYVKo5QRBy4eOdC9mfRZToKQoQY4gLg8D3R',2,NULL,'desktop','Firefox','2026-06-19 11:15:53'),(71,'login',NULL,'https://safhenokhost.ir/account','vwI9UHYVKo5QRBy4eOdC9mfRZToKQoQY4gLg8D3R',2,NULL,'desktop','Firefox','2026-06-19 11:15:58'),(72,'/',NULL,NULL,'a5pOmAioeaKOjQMRyt8A8YS0PSo9TOHSlSKzN6Bq',NULL,NULL,'desktop','Other','2026-06-19 11:40:00'),(73,'login',NULL,'https://safhenokhost.ir/admin/products','kLH8lF7cBb9b6tErQOdr8TCyZJa8EUrzQt8RGGlr',1,NULL,'desktop','Firefox','2026-06-19 12:06:51'),(74,'page/blog',NULL,'https://safhenokhost.ir/admin/pages','kLH8lF7cBb9b6tErQOdr8TCyZJa8EUrzQt8RGGlr',1,NULL,'desktop','Firefox','2026-06-19 12:07:28'),(75,'builder/page/2/edit',NULL,'https://safhenokhost.ir/page/blog','kLH8lF7cBb9b6tErQOdr8TCyZJa8EUrzQt8RGGlr',1,NULL,'desktop','Firefox','2026-06-19 12:07:31'),(76,'login',NULL,NULL,'cI7Bd9ATd3xiPfF5glTO0jpOZpdwcJuIXhIO4vAd',NULL,NULL,'desktop','Chrome','2026-06-19 12:28:13'),(77,'login',NULL,'https://safhenokhost.ir/admin/dashboard','4U8A6DIQzZKE0o9ZTy5gmRjY2bUqe8FuJuX7DvLB',1,NULL,'desktop','Chrome','2026-06-19 12:28:20'),(78,'login',NULL,'https://safhenokhost.ir/admin/dashboard','spuE8nZx26ECrRdAbtyzezGDvsfgOStf960s4RWe',1,NULL,'mobile','Chrome','2026-06-19 12:29:01'),(79,'/',NULL,NULL,'wC5mgJ2fVupGsoPw5KxVs2K5lw0gQ0xAKhXh3jh7',NULL,NULL,'desktop','Chrome','2026-06-19 12:30:29'),(80,'/',NULL,NULL,'spuE8nZx26ECrRdAbtyzezGDvsfgOStf960s4RWe',1,NULL,'mobile','Chrome','2026-06-19 12:49:42'),(81,'/',NULL,NULL,'HIOTa3408mmH2MNpx0YO9XDpI1KJxbYrMqnmVvTo',NULL,NULL,'desktop','Other','2026-06-19 14:14:38'),(82,'login',NULL,'https://safhenokhost.ir/admin/dashboard','Irzyo595fZBUqv6f9vlJs3nfs4CpJEm6nTbUs1Fg',1,NULL,'desktop','Chrome','2026-06-19 14:32:56'),(83,'/',NULL,'https://safhenokhost.ir/admin/dashboard','sX8nF635z3QuRfwo9bumJMNjfNIDn1VraPf01Edw',NULL,NULL,'desktop','Chrome','2026-06-19 14:33:05'),(84,'login',NULL,'https://safhenokhost.ir/admin/dashboard','kLH8lF7cBb9b6tErQOdr8TCyZJa8EUrzQt8RGGlr',1,NULL,'desktop','Firefox','2026-06-19 14:33:20'),(85,'/',NULL,NULL,'kLH8lF7cBb9b6tErQOdr8TCyZJa8EUrzQt8RGGlr',1,NULL,'desktop','Firefox','2026-06-19 16:38:42'),(86,'login',NULL,NULL,'9LypVlP0rvXYUGOGBe8MyvjbDjPgP2zlIDsjg7Jf',NULL,NULL,'mobile','Chrome','2026-06-19 16:55:42'),(87,'login',NULL,'https://safhenokhost.ir/admin/dashboard','VVN9b3fIsO3mSKCAastisD8874RILT07uuitIKD6',1,NULL,'mobile','Chrome','2026-06-19 16:55:49'),(88,'login',NULL,'https://safhenokhost.ir/admin/dashboard','VVN9b3fIsO3mSKCAastisD8874RILT07uuitIKD6',1,NULL,'mobile','Chrome','2026-06-19 17:34:00'),(89,'login',NULL,'https://safhenokhost.ir/admin/dashboard','VVN9b3fIsO3mSKCAastisD8874RILT07uuitIKD6',1,NULL,'mobile','Chrome','2026-06-19 19:08:54'),(90,'search',NULL,'https://safhenokhost.ir/admin/modules/advanced_search','VVN9b3fIsO3mSKCAastisD8874RILT07uuitIKD6',1,NULL,'mobile','Chrome','2026-06-19 19:13:17'),(91,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,'https://safhenokhost.ir/search','VVN9b3fIsO3mSKCAastisD8874RILT07uuitIKD6',1,NULL,'mobile','Chrome','2026-06-19 19:13:31'),(92,'blog',NULL,'https://safhenokhost.ir/blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd','VVN9b3fIsO3mSKCAastisD8874RILT07uuitIKD6',1,NULL,'mobile','Chrome','2026-06-19 19:13:35'),(93,'login',NULL,'https://safhenokhost.ir/admin/dashboard','VVN9b3fIsO3mSKCAastisD8874RILT07uuitIKD6',1,NULL,'mobile','Chrome','2026-06-19 20:21:45'),(94,'page/products',NULL,'https://safhenokhost.ir/admin/pages','VVN9b3fIsO3mSKCAastisD8874RILT07uuitIKD6',1,NULL,'mobile','Chrome','2026-06-19 20:22:26'),(95,'builder/page/8/edit',NULL,'https://safhenokhost.ir/page/products','VVN9b3fIsO3mSKCAastisD8874RILT07uuitIKD6',1,NULL,'mobile','Chrome','2026-06-19 20:22:29'),(96,'/',NULL,NULL,'6igsgIZXjHOVoHflNEvx66W6khnao2ekT25llwcg',NULL,NULL,'desktop','Chrome','2026-06-19 20:23:52'),(97,'login',NULL,'https://safhenokhost.ir/admin/settings','RpNiejVhJJoigKYqORkbH5Vp4zOeJSbBN8zMyPlW',NULL,NULL,'mobile','Chrome','2026-06-19 20:42:36'),(98,'login',NULL,'https://safhenokhost.ir/admin/dashboard','hAlrCTbvy88pGXVGWsm7rMm3kATaCZuMREs6B6ci',1,NULL,'mobile','Chrome','2026-06-19 20:42:44'),(99,'login',NULL,'https://safhenokhost.ir/login','vwI9UHYVKo5QRBy4eOdC9mfRZToKQoQY4gLg8D3R',NULL,NULL,'desktop','Firefox','2026-06-19 20:43:57'),(100,'account',NULL,'https://safhenokhost.ir/login','zdEvgcCh7ShPQ7AbegdvE5iUUGGMb6O24SDly81w',2,NULL,'desktop','Firefox','2026-06-19 20:44:18'),(101,'login',NULL,'https://safhenokhost.ir/account','zdEvgcCh7ShPQ7AbegdvE5iUUGGMb6O24SDly81w',2,NULL,'desktop','Firefox','2026-06-19 20:44:19'),(102,'login',NULL,'https://safhenokhost.ir/admin/pages','kLH8lF7cBb9b6tErQOdr8TCyZJa8EUrzQt8RGGlr',NULL,NULL,'desktop','Firefox','2026-06-19 20:44:25'),(103,'login',NULL,'https://safhenokhost.ir/admin/dashboard','rCGTQG8M5nYdR1XKVhnSMB2X12MwKrOK003GhU4c',1,NULL,'desktop','Firefox','2026-06-19 20:44:33'),(104,'login',NULL,'https://safhenokhost.ir/admin/dashboard','hAlrCTbvy88pGXVGWsm7rMm3kATaCZuMREs6B6ci',1,NULL,'mobile','Chrome','2026-06-19 20:55:00'),(105,'login',NULL,'https://safhenokhost.ir/admin/dashboard','rCGTQG8M5nYdR1XKVhnSMB2X12MwKrOK003GhU4c',1,NULL,'mobile','Chrome','2026-06-19 20:58:30'),(106,'/',NULL,'https://safhenokhost.ir/admin/notification-center?tab=banners','BegDjBOiruv6ZSeaKZ3XgBLSjXEmJTxyUfclFFHp',NULL,NULL,'mobile','Chrome','2026-06-19 21:05:44'),(107,'login',NULL,NULL,'BegDjBOiruv6ZSeaKZ3XgBLSjXEmJTxyUfclFFHp',NULL,NULL,'mobile','Chrome','2026-06-19 21:05:56'),(108,'account',NULL,'https://safhenokhost.ir/login','0dpEKOTk3B2N2TMsahkShbPuulidhKIx38OyY07F',2,NULL,'mobile','Chrome','2026-06-19 21:06:10'),(109,'login',NULL,'https://safhenokhost.ir/account','0dpEKOTk3B2N2TMsahkShbPuulidhKIx38OyY07F',2,NULL,'mobile','Chrome','2026-06-19 21:06:12'),(110,'account/notifications',NULL,'https://safhenokhost.ir/account','0dpEKOTk3B2N2TMsahkShbPuulidhKIx38OyY07F',2,NULL,'mobile','Chrome','2026-06-19 21:06:33'),(111,'account/tickets',NULL,'https://safhenokhost.ir/account/notifications','0dpEKOTk3B2N2TMsahkShbPuulidhKIx38OyY07F',2,NULL,'mobile','Chrome','2026-06-19 21:06:38'),(112,'account/tickets/1',NULL,'https://safhenokhost.ir/account/tickets','0dpEKOTk3B2N2TMsahkShbPuulidhKIx38OyY07F',2,NULL,'mobile','Chrome','2026-06-19 21:06:51'),(113,'login',NULL,NULL,'0dpEKOTk3B2N2TMsahkShbPuulidhKIx38OyY07F',2,NULL,'mobile','Chrome','2026-06-19 21:16:51'),(114,'account',NULL,'https://safhenokhost.ir/login','kaajmRDygCK6qcu8Fa4vY3E3caHRBpxLH9mniuBu',2,NULL,'mobile','Chrome','2026-06-19 21:16:55'),(115,'login',NULL,'https://safhenokhost.ir/account','kaajmRDygCK6qcu8Fa4vY3E3caHRBpxLH9mniuBu',2,NULL,'mobile','Chrome','2026-06-19 21:16:56'),(116,'/',NULL,NULL,'HLKqTLsXKfZILRC0eANgIq53JCX6N8ASLxEK4yJA',NULL,NULL,'desktop','Other','2026-06-19 21:23:09'),(117,'login',NULL,'https://safhenokhost.ir/admin/theme-design','rCGTQG8M5nYdR1XKVhnSMB2X12MwKrOK003GhU4c',1,NULL,'desktop','Firefox','2026-06-19 21:55:38'),(118,'/',NULL,NULL,'rCGTQG8M5nYdR1XKVhnSMB2X12MwKrOK003GhU4c',1,NULL,'desktop','Firefox','2026-06-19 21:58:08'),(119,'login',NULL,'https://safhenokhost.ir/admin/theme-design','rCGTQG8M5nYdR1XKVhnSMB2X12MwKrOK003GhU4c',1,NULL,'desktop','Firefox','2026-06-19 22:27:21'),(120,'login',NULL,'https://safhenokhost.ir/admin/theme-design','rCGTQG8M5nYdR1XKVhnSMB2X12MwKrOK003GhU4c',1,NULL,'desktop','Firefox','2026-06-19 22:29:41'),(121,'/',NULL,NULL,'rCGTQG8M5nYdR1XKVhnSMB2X12MwKrOK003GhU4c',1,NULL,'desktop','Firefox','2026-06-19 22:29:41'),(122,'builder/page/3/edit',NULL,'https://safhenokhost.ir/','rCGTQG8M5nYdR1XKVhnSMB2X12MwKrOK003GhU4c',1,NULL,'desktop','Firefox','2026-06-19 22:29:54'),(123,'login',NULL,'https://safhenokhost.ir/admin/inbox','rCGTQG8M5nYdR1XKVhnSMB2X12MwKrOK003GhU4c',1,NULL,'desktop','Firefox','2026-06-19 23:05:09'),(124,'/',NULL,'http://safhenokhost.ir/','q00ejerWAWp2GPWOCYTko28burDyC1bmQyTELe3k',NULL,NULL,'desktop','Firefox','2026-06-20 01:15:22'),(125,'/',NULL,'http://safhenokhost.ir','KaETPfMVBwC9mRPVkQXXKUojfP4txVySGpyZbalt',NULL,NULL,'desktop','Other','2026-06-20 01:43:46'),(126,'/',NULL,NULL,'DJd8NFpEhCQ6pObfpPItgrb4bavUGDHU242aE2k5',NULL,NULL,'desktop','Chrome','2026-06-20 03:50:40'),(127,'login',NULL,'https://safhenokhost.ir/admin/modules/advanced_search','rCGTQG8M5nYdR1XKVhnSMB2X12MwKrOK003GhU4c',NULL,NULL,'desktop','Firefox','2026-06-20 05:32:11'),(128,'/',NULL,'https://safhenokhost.ir/','hbYtR5CdpNn4bS59wVTX8z6aKS6FMgNvFHYsmxs6',1,NULL,'desktop','Firefox','2026-06-20 05:32:18'),(129,'login',NULL,'https://safhenokhost.ir/admin/posts','hbYtR5CdpNn4bS59wVTX8z6aKS6FMgNvFHYsmxs6',1,NULL,'desktop','Firefox','2026-06-20 05:32:18'),(130,'/',NULL,NULL,'Cub9kKRTaikNqZ9lqVCR1MOySAj173hap4eSuBjE',NULL,NULL,'desktop','Chrome','2026-06-20 06:00:45'),(131,'login',NULL,'https://safhenokhost.ir/admin/pages','hbYtR5CdpNn4bS59wVTX8z6aKS6FMgNvFHYsmxs6',1,NULL,'desktop','Firefox','2026-06-20 06:13:59'),(132,'/',NULL,NULL,'DmcZ853B9CwA2vuNUL1CzG52ZSks1UFj8zevrcij',NULL,NULL,'desktop','Chrome','2026-06-20 06:32:04'),(133,'login',NULL,'https://safhenokhost.ir/admin/pages','hbYtR5CdpNn4bS59wVTX8z6aKS6FMgNvFHYsmxs6',NULL,NULL,'desktop','Firefox','2026-06-20 10:32:42'),(134,'login',NULL,'https://safhenokhost.ir/admin/pages','Er72xUGWD16F7EueQS9RaJJ29ZQm2FpeIJxjUmqx',1,NULL,'desktop','Firefox','2026-06-20 10:32:52'),(135,'/',NULL,'https://safhenokhost.ir/','Er72xUGWD16F7EueQS9RaJJ29ZQm2FpeIJxjUmqx',1,NULL,'desktop','Firefox','2026-06-20 10:33:11'),(136,'shop',NULL,'https://safhenokhost.ir/','Er72xUGWD16F7EueQS9RaJJ29ZQm2FpeIJxjUmqx',1,NULL,'desktop','Firefox','2026-06-20 10:33:13'),(137,'contact',NULL,'https://safhenokhost.ir/','Er72xUGWD16F7EueQS9RaJJ29ZQm2FpeIJxjUmqx',1,NULL,'desktop','Firefox','2026-06-20 10:33:17'),(138,'blog',NULL,'https://safhenokhost.ir/','Er72xUGWD16F7EueQS9RaJJ29ZQm2FpeIJxjUmqx',1,NULL,'desktop','Firefox','2026-06-20 10:33:23'),(139,'login',NULL,'https://safhenokhost.ir/login','zdEvgcCh7ShPQ7AbegdvE5iUUGGMb6O24SDly81w',NULL,NULL,'desktop','Firefox','2026-06-20 10:47:06'),(140,'account',NULL,'https://safhenokhost.ir/login','ODS08KcStqoDB0V3W5Kg3E6UWcPMN2fhzu1ZXIfz',2,NULL,'desktop','Firefox','2026-06-20 10:47:17'),(141,'login',NULL,'https://safhenokhost.ir/account','ODS08KcStqoDB0V3W5Kg3E6UWcPMN2fhzu1ZXIfz',2,NULL,'desktop','Firefox','2026-06-20 10:47:21'),(142,'login',NULL,'https://safhenokhost.ir/admin/pages','Er72xUGWD16F7EueQS9RaJJ29ZQm2FpeIJxjUmqx',1,NULL,'desktop','Firefox','2026-06-20 11:05:06'),(143,'page/home-1',NULL,'https://safhenokhost.ir/admin/pages','Er72xUGWD16F7EueQS9RaJJ29ZQm2FpeIJxjUmqx',1,NULL,'desktop','Firefox','2026-06-20 11:05:08'),(144,'builder/edit/9',NULL,'https://safhenokhost.ir/page/home-1','Er72xUGWD16F7EueQS9RaJJ29ZQm2FpeIJxjUmqx',1,NULL,'desktop','Firefox','2026-06-20 11:05:11'),(145,'/',NULL,'https://safhenokhost.ir/blog','Er72xUGWD16F7EueQS9RaJJ29ZQm2FpeIJxjUmqx',1,NULL,'desktop','Firefox','2026-06-20 11:05:45'),(146,'/',NULL,NULL,'ODS08KcStqoDB0V3W5Kg3E6UWcPMN2fhzu1ZXIfz',2,NULL,'desktop','Firefox','2026-06-20 11:10:56'),(147,'login',NULL,NULL,'Mop85BWv8qvtLvC9k4azNbrx3goKZMzj9ifJtLcQ',NULL,NULL,'desktop','Firefox','2026-06-20 11:11:28'),(148,'account/notifications',NULL,'https://safhenokhost.ir/account','ODS08KcStqoDB0V3W5Kg3E6UWcPMN2fhzu1ZXIfz',2,NULL,'desktop','Firefox','2026-06-20 11:14:13'),(149,'login',NULL,'https://safhenokhost.ir/admin/notifications','Er72xUGWD16F7EueQS9RaJJ29ZQm2FpeIJxjUmqx',1,NULL,'desktop','Firefox','2026-06-20 11:39:38'),(150,'/',NULL,'https://safhenokhost.ir/admin/notifications/1/edit','Er72xUGWD16F7EueQS9RaJJ29ZQm2FpeIJxjUmqx',1,NULL,'desktop','Firefox','2026-06-20 11:48:05'),(151,'login',NULL,'https://safhenokhost.ir/admin/notifications','Er72xUGWD16F7EueQS9RaJJ29ZQm2FpeIJxjUmqx',1,NULL,'desktop','Firefox','2026-06-20 11:48:28'),(152,'/',NULL,'https://safhenokhost.ir/account','ODS08KcStqoDB0V3W5Kg3E6UWcPMN2fhzu1ZXIfz',2,NULL,'desktop','Firefox','2026-06-20 11:48:38'),(153,'login',NULL,NULL,'ODS08KcStqoDB0V3W5Kg3E6UWcPMN2fhzu1ZXIfz',2,NULL,'desktop','Firefox','2026-06-20 11:48:49'),(154,'account',NULL,NULL,'yb4y8TZOD9ghjfylHOAOGKGkTBqB4WumLcbYIxcV',2,NULL,'desktop','Firefox','2026-06-20 12:11:28'),(155,'login',NULL,'https://safhenokhost.ir/account','yb4y8TZOD9ghjfylHOAOGKGkTBqB4WumLcbYIxcV',2,NULL,'desktop','Firefox','2026-06-20 12:11:32'),(156,'account/profile',NULL,'https://safhenokhost.ir/account','yb4y8TZOD9ghjfylHOAOGKGkTBqB4WumLcbYIxcV',2,NULL,'desktop','Firefox','2026-06-20 12:11:54'),(157,'account',NULL,'https://safhenokhost.ir/account/profile','yb4y8TZOD9ghjfylHOAOGKGkTBqB4WumLcbYIxcV',2,NULL,'desktop','Firefox','2026-06-20 13:11:42'),(158,'login',NULL,'https://safhenokhost.ir/account','yb4y8TZOD9ghjfylHOAOGKGkTBqB4WumLcbYIxcV',2,NULL,'desktop','Firefox','2026-06-20 13:11:43'),(159,'login',NULL,'https://safhenokhost.ir/admin/notifications/1/edit','Er72xUGWD16F7EueQS9RaJJ29ZQm2FpeIJxjUmqx',1,NULL,'desktop','Firefox','2026-06-20 13:13:35'),(160,'/',NULL,NULL,'OAzYx2EsMjK5V2HPjVcfweWQaWQYhJGk5pp9pm7K',NULL,NULL,'desktop','Edge','2026-06-20 13:14:26'),(161,'/',NULL,NULL,'z1cDdBTo8jVRLOwHV1SbbVDaxWjmhcWAiF8nxiFQ',NULL,NULL,'desktop','Firefox','2026-06-20 13:33:51'),(162,'login',NULL,NULL,'qM2RFdPcXAdEc3cgDalLvARVQqEYgghCv92tY2WQ',NULL,NULL,'mobile','Chrome','2026-06-20 14:39:22'),(163,'login',NULL,'https://safhenokhost.ir/admin/dashboard','EERmAjuNxKSUUwNx4dncQpaWTeL05QvcuZFjM8S9',1,NULL,'mobile','Chrome','2026-06-20 14:39:29'),(164,'/',NULL,'https://safhenokhost.ir/admin/modules','TD5JeXOrcA99sW2XU3TbPrgah4qV0PkWiuy7OkPj',NULL,NULL,'mobile','Chrome','2026-06-20 14:39:57'),(165,'shop',NULL,'https://safhenokhost.ir/','TD5JeXOrcA99sW2XU3TbPrgah4qV0PkWiuy7OkPj',NULL,NULL,'mobile','Chrome','2026-06-20 14:40:04'),(166,'blog',NULL,'https://safhenokhost.ir/','TD5JeXOrcA99sW2XU3TbPrgah4qV0PkWiuy7OkPj',NULL,NULL,'mobile','Chrome','2026-06-20 14:40:10'),(167,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,'https://safhenokhost.ir/blog','TD5JeXOrcA99sW2XU3TbPrgah4qV0PkWiuy7OkPj',NULL,NULL,'mobile','Chrome','2026-06-20 14:40:14'),(168,'/',NULL,NULL,'Eih6ZL3gaazZMuIcEgUxsrPftVCqZ0spqEJguVBN',NULL,NULL,'desktop','Other','2026-06-20 15:21:39'),(169,'/',NULL,NULL,'mbXeJs5VauKEtEIh7UMDBcyPdoh9snKWGynitmro',NULL,NULL,'desktop','Other','2026-06-20 15:21:41'),(170,'login',NULL,'https://safhenokhost.ir/admin/dashboard','Er72xUGWD16F7EueQS9RaJJ29ZQm2FpeIJxjUmqx',1,NULL,'desktop','Firefox','2026-06-20 16:00:30'),(171,'login',NULL,'https://safhenokhost.ir/admin/dashboard','Er72xUGWD16F7EueQS9RaJJ29ZQm2FpeIJxjUmqx',1,NULL,'desktop','Firefox','2026-06-20 16:29:43'),(172,'login',NULL,'https://safhenokhost.ir/admin/module-store','Er72xUGWD16F7EueQS9RaJJ29ZQm2FpeIJxjUmqx',1,NULL,'desktop','Firefox','2026-06-20 16:38:38'),(173,'login',NULL,'https://safhenokhost.ir/admin/modules','Er72xUGWD16F7EueQS9RaJJ29ZQm2FpeIJxjUmqx',1,NULL,'desktop','Firefox','2026-06-20 17:09:52'),(174,'login',NULL,'https://safhenokhost.ir/admin/dashboard','Er72xUGWD16F7EueQS9RaJJ29ZQm2FpeIJxjUmqx',1,NULL,'desktop','Firefox','2026-06-20 17:40:26'),(175,'/',NULL,NULL,'8HaieGgYaX4AISyMPniAoyxLiLVFXJ4L1VNo5Rkb',NULL,NULL,'desktop','Chrome','2026-06-20 17:47:22'),(176,'/',NULL,NULL,'amf8TNYpCofst0RWQOW39Md65kMVuQarXLiKSkgb',NULL,NULL,'desktop','Chrome','2026-06-20 17:47:26'),(177,'/',NULL,NULL,'Er72xUGWD16F7EueQS9RaJJ29ZQm2FpeIJxjUmqx',1,NULL,'desktop','Firefox','2026-06-20 18:06:29'),(178,'/',NULL,NULL,'pMeD3wJKWqEAwP4r9HcpmxeQYXlBFcQIGktqKpq6',NULL,NULL,'desktop','Chrome','2026-06-20 19:49:10'),(179,'login',NULL,NULL,'B4LNVa5Tx5qxlacDI9q1pI2rcqIrm0Up6KaZ2eH5',NULL,NULL,'mobile','Chrome','2026-06-20 20:58:50'),(180,'/',NULL,NULL,'B4LNVa5Tx5qxlacDI9q1pI2rcqIrm0Up6KaZ2eH5',NULL,NULL,'mobile','Chrome','2026-06-20 20:58:58'),(181,'blog',NULL,'https://safhenokhost.ir/','B4LNVa5Tx5qxlacDI9q1pI2rcqIrm0Up6KaZ2eH5',NULL,NULL,'mobile','Chrome','2026-06-20 20:59:19'),(182,'shop',NULL,'https://safhenokhost.ir/','B4LNVa5Tx5qxlacDI9q1pI2rcqIrm0Up6KaZ2eH5',NULL,NULL,'mobile','Chrome','2026-06-20 20:59:25'),(183,'/',NULL,NULL,'Er72xUGWD16F7EueQS9RaJJ29ZQm2FpeIJxjUmqx',NULL,NULL,'desktop','Firefox','2026-06-21 05:07:23'),(184,'login',NULL,NULL,'Er72xUGWD16F7EueQS9RaJJ29ZQm2FpeIJxjUmqx',NULL,NULL,'desktop','Firefox','2026-06-21 05:07:34'),(185,'login',NULL,'https://safhenokhost.ir/admin/dashboard','Z0Y3gNqDuwU0RR0zhLvI2pgDsvOqa9YTIEmUGQAy',1,NULL,'desktop','Firefox','2026-06-21 05:07:41'),(186,'/',NULL,NULL,'vzgFRrqCBzSKzDFH31GkdaFw1nu40w6017iW8D8w',NULL,NULL,'desktop','Other','2026-06-21 05:40:17'),(187,'login',NULL,'https://safhenokhost.ir/account/profile','yb4y8TZOD9ghjfylHOAOGKGkTBqB4WumLcbYIxcV',NULL,NULL,'desktop','Firefox','2026-06-21 05:55:14'),(188,'account',NULL,'https://safhenokhost.ir/login','W8PG7ZaW4baQbamiocVyzLwyiRIsZjhQsDZwdNlh',2,NULL,'desktop','Firefox','2026-06-21 05:55:22'),(189,'login',NULL,'https://safhenokhost.ir/account','W8PG7ZaW4baQbamiocVyzLwyiRIsZjhQsDZwdNlh',2,NULL,'desktop','Firefox','2026-06-21 05:55:23'),(190,'/',NULL,NULL,'QrPsuTkKkC17m4qkzkD4d52einUcIksd7ZmuJGvx',NULL,NULL,'desktop','Firefox','2026-06-21 07:34:13'),(191,'blog',NULL,'https://safhenokhost.ir/','QrPsuTkKkC17m4qkzkD4d52einUcIksd7ZmuJGvx',NULL,NULL,'desktop','Firefox','2026-06-21 07:34:20'),(192,'blog/sayt-hmh-karh',NULL,'https://safhenokhost.ir/blog','QrPsuTkKkC17m4qkzkD4d52einUcIksd7ZmuJGvx',NULL,NULL,'desktop','Firefox','2026-06-21 07:34:23'),(193,'login',NULL,NULL,'QrPsuTkKkC17m4qkzkD4d52einUcIksd7ZmuJGvx',NULL,NULL,'desktop','Firefox','2026-06-21 07:34:32'),(194,'login',NULL,'https://safhenokhost.ir/admin/dashboard','ZVS95JiIdlJGjTTT6EusW7GS2M2nUdlHUeAWKM9L',1,NULL,'desktop','Firefox','2026-06-21 07:35:04'),(195,'/',NULL,'https://safhenokhost.ir/admin/pages','ZVS95JiIdlJGjTTT6EusW7GS2M2nUdlHUeAWKM9L',1,NULL,'desktop','Firefox','2026-06-21 07:36:46'),(196,'/',NULL,'https://safhenokhost.ir/admin/analytics','AAn8kt6N2tfZcz95xu4gKhWUfoRv8G0MqB6SZ476',NULL,NULL,'desktop','Firefox','2026-06-21 07:39:59'),(197,'/',NULL,'http://safhenokhost.ir/','zqX2IIqC8lpqr8YYqtQ7GTbb4SDEZF6hcP3I2RM4',NULL,NULL,'desktop','Firefox','2026-06-21 08:35:04'),(198,'/',NULL,NULL,'P6QpBgMglj3HTiPMTChbxPIScRMsGkHvY4FRleck',NULL,NULL,'desktop','Other','2026-06-21 10:20:42'),(199,'/',NULL,NULL,'UaHKSy0kKx7fTE1iXvaQqghE6VTH9cczxPmwicOz',NULL,NULL,'desktop','Firefox','2026-06-21 10:55:30'),(200,'/',NULL,'http://safhenokhost.ir/','RGxSdizH9uvg2HBYHZrXzCpSb2El2SP0lTx5P26Q',NULL,NULL,'desktop','Safari','2026-06-21 10:56:21'),(201,'login',NULL,'https://safhenokhost.ir/login','Z0Y3gNqDuwU0RR0zhLvI2pgDsvOqa9YTIEmUGQAy',NULL,NULL,'desktop','Firefox','2026-06-21 11:16:54'),(202,'login',NULL,'https://safhenokhost.ir/admin/dashboard','Q146GBBGvlSnUvnZRTIGoGfxRz1JEPBDaG24qKyc',1,NULL,'desktop','Firefox','2026-06-21 11:17:01'),(203,'login',NULL,'https://safhenokhost.ir/login','W8PG7ZaW4baQbamiocVyzLwyiRIsZjhQsDZwdNlh',NULL,NULL,'desktop','Firefox','2026-06-21 11:17:03'),(204,'account',NULL,'https://safhenokhost.ir/login','xvfrpPTXZM4NS8uY4zpMNAuBbYOk5mVMq0UQC50P',2,NULL,'desktop','Firefox','2026-06-21 11:17:14'),(205,'login',NULL,'https://safhenokhost.ir/account','xvfrpPTXZM4NS8uY4zpMNAuBbYOk5mVMq0UQC50P',2,NULL,'desktop','Firefox','2026-06-21 11:17:15'),(206,'/',NULL,'https://safhenokhost.ir/admin/theme-design/canvas','Q146GBBGvlSnUvnZRTIGoGfxRz1JEPBDaG24qKyc',1,NULL,'desktop','Firefox','2026-06-21 11:45:06'),(207,'login',NULL,'https://safhenokhost.ir/admin/theme-design','Q146GBBGvlSnUvnZRTIGoGfxRz1JEPBDaG24qKyc',1,NULL,'desktop','Firefox','2026-06-21 11:47:21'),(208,'login',NULL,'https://safhenokhost.ir/admin/pages','Q146GBBGvlSnUvnZRTIGoGfxRz1JEPBDaG24qKyc',1,NULL,'desktop','Firefox','2026-06-21 12:00:45'),(209,'page/home-1',NULL,'https://safhenokhost.ir/admin/pages','Q146GBBGvlSnUvnZRTIGoGfxRz1JEPBDaG24qKyc',1,NULL,'desktop','Firefox','2026-06-21 12:00:58'),(210,'page/product',NULL,'https://safhenokhost.ir/admin/pages','Q146GBBGvlSnUvnZRTIGoGfxRz1JEPBDaG24qKyc',1,NULL,'desktop','Firefox','2026-06-21 12:01:07'),(211,'page/home',NULL,'https://safhenokhost.ir/admin/pages','Q146GBBGvlSnUvnZRTIGoGfxRz1JEPBDaG24qKyc',1,NULL,'desktop','Firefox','2026-06-21 12:01:14'),(212,'builder/edit/12',NULL,'https://safhenokhost.ir/page/home','Q146GBBGvlSnUvnZRTIGoGfxRz1JEPBDaG24qKyc',1,NULL,'desktop','Firefox','2026-06-21 12:01:16'),(213,'/',NULL,'https://safhenokhost.ir/admin/theme-design/canvas','Q146GBBGvlSnUvnZRTIGoGfxRz1JEPBDaG24qKyc',1,NULL,'desktop','Firefox','2026-06-21 12:02:13'),(214,'shop',NULL,'https://safhenokhost.ir/','Q146GBBGvlSnUvnZRTIGoGfxRz1JEPBDaG24qKyc',1,NULL,'desktop','Firefox','2026-06-21 12:02:21'),(215,'login',NULL,'https://safhenokhost.ir/admin/theme-marketplace','Q146GBBGvlSnUvnZRTIGoGfxRz1JEPBDaG24qKyc',1,NULL,'desktop','Firefox','2026-06-21 12:08:54'),(216,'/',NULL,'https://safhenokhost.ir/admin/theme-design/canvas','Q146GBBGvlSnUvnZRTIGoGfxRz1JEPBDaG24qKyc',1,NULL,'desktop','Firefox','2026-06-21 12:09:14'),(217,'shop',NULL,'https://safhenokhost.ir/','Q146GBBGvlSnUvnZRTIGoGfxRz1JEPBDaG24qKyc',1,NULL,'desktop','Firefox','2026-06-21 12:09:17'),(218,'/',NULL,NULL,'BquQHiI859nqdesSulXvLXb1p6lLTQrpNsndiluw',NULL,NULL,'desktop','Chrome','2026-06-21 13:27:04'),(219,'blog',NULL,NULL,'FqM7g1YE1dY1m2NJCbTxQJrh7Byl0qW3agI6dsnO',NULL,NULL,'desktop','Chrome','2026-06-21 13:27:06'),(220,'shop',NULL,NULL,'Ldd4g99uQ8iX7viiS9zlBEgzL6l8HZilQ3JpXT1S',NULL,NULL,'desktop','Chrome','2026-06-21 13:27:07'),(221,'login',NULL,NULL,'UMppDTjGr9LUImKGgyFdwfuquPEtHW3UdVKhacKq',NULL,NULL,'desktop','Chrome','2026-06-21 13:27:08'),(222,'contact',NULL,NULL,'V66uhOsN6xXHhsckJ6J1L9VwaWPHkvHsqo6ARHlr',NULL,NULL,'desktop','Chrome','2026-06-21 13:27:09'),(223,'register',NULL,NULL,'dK6PjsdrqcQzZJlmV1ta5w0hehqBkL8m9h00s7Lt',NULL,NULL,'desktop','Chrome','2026-06-21 13:27:09'),(224,'login',NULL,'https://safhenokhost.ir/admin/dashboard','Q146GBBGvlSnUvnZRTIGoGfxRz1JEPBDaG24qKyc',1,NULL,'desktop','Firefox','2026-06-21 16:03:03'),(225,'account',NULL,'https://safhenokhost.ir/login','xvfrpPTXZM4NS8uY4zpMNAuBbYOk5mVMq0UQC50P',2,NULL,'desktop','Firefox','2026-06-21 16:03:04'),(226,'login',NULL,'https://safhenokhost.ir/account','xvfrpPTXZM4NS8uY4zpMNAuBbYOk5mVMq0UQC50P',2,NULL,'desktop','Firefox','2026-06-21 16:03:13'),(227,'login',NULL,'https://safhenokhost.ir/admin/theme-design/canvas','Q146GBBGvlSnUvnZRTIGoGfxRz1JEPBDaG24qKyc',1,NULL,'desktop','Firefox','2026-06-21 16:37:51'),(228,'/',NULL,'https://safhenokhost.ir/admin/theme-design/canvas','Q146GBBGvlSnUvnZRTIGoGfxRz1JEPBDaG24qKyc',1,NULL,'desktop','Firefox','2026-06-21 16:38:00'),(229,'login',NULL,'https://safhenokhost.ir/admin/theme-design','Q146GBBGvlSnUvnZRTIGoGfxRz1JEPBDaG24qKyc',1,NULL,'desktop','Firefox','2026-06-21 16:52:07'),(230,'/',NULL,NULL,'Q146GBBGvlSnUvnZRTIGoGfxRz1JEPBDaG24qKyc',1,NULL,'desktop','Firefox','2026-06-21 16:58:08'),(231,'login',NULL,'https://safhenokhost.ir/admin/theme-design/canvas','toO11c1Rzg0Fl3Kzenm3jY1Epgld7XmukY27YLOn',NULL,NULL,'desktop','Firefox','2026-06-21 21:26:20'),(232,'/',NULL,'https://safhenokhost.ir/','r50EA9jiKbdlspOWQRM065X3zHH3PgNF3sNmurOK',1,NULL,'desktop','Firefox','2026-06-21 21:26:28'),(233,'login',NULL,'https://safhenokhost.ir/admin/dashboard','r50EA9jiKbdlspOWQRM065X3zHH3PgNF3sNmurOK',1,NULL,'desktop','Firefox','2026-06-21 21:27:00'),(234,'page/landing',NULL,'https://safhenokhost.ir/admin/pages','r50EA9jiKbdlspOWQRM065X3zHH3PgNF3sNmurOK',1,NULL,'desktop','Firefox','2026-06-21 21:27:35'),(235,'login',NULL,'https://safhenokhost.ir/admin/theme-marketplace','oAjhvYOu9LPeB6GKnK3AmH5HgxOQGDwgutMjW3UU',NULL,NULL,'desktop','Firefox','2026-06-22 06:52:03'),(236,'/',NULL,'https://safhenokhost.ir/','itptAe9d7ScvOX295JbnOT1nnBjPQNbvc7mffOgI',1,NULL,'desktop','Firefox','2026-06-22 06:52:12'),(237,'login',NULL,'https://safhenokhost.ir/admin/theme-marketplace/my-licenses','itptAe9d7ScvOX295JbnOT1nnBjPQNbvc7mffOgI',1,NULL,'desktop','Firefox','2026-06-22 06:52:12'),(238,'login',NULL,'https://safhenokhost.ir/login','X4YPb9Tz4iew297jxHaWYOkH7rkIVwD22DRqWjsj',NULL,NULL,'desktop','Firefox','2026-06-22 07:09:05'),(239,'account',NULL,'https://safhenokhost.ir/login','RhQOImeYcrKJEcIqEw0iC0HZlgZYFGjrqtjwZYsw',2,NULL,'desktop','Firefox','2026-06-22 07:09:14'),(240,'login',NULL,'https://safhenokhost.ir/account','RhQOImeYcrKJEcIqEw0iC0HZlgZYFGjrqtjwZYsw',2,NULL,'desktop','Firefox','2026-06-22 07:09:15'),(241,'account/tickets',NULL,'https://safhenokhost.ir/account','RhQOImeYcrKJEcIqEw0iC0HZlgZYFGjrqtjwZYsw',2,NULL,'desktop','Firefox','2026-06-22 07:09:19'),(242,'account/tickets/1',NULL,'https://safhenokhost.ir/account/tickets','RhQOImeYcrKJEcIqEw0iC0HZlgZYFGjrqtjwZYsw',2,NULL,'desktop','Firefox','2026-06-22 07:09:25'),(243,'/',NULL,NULL,'M7DTZR0mi20JKbLxRu7SIcwcDnzIIk4siHIrTUCR',NULL,NULL,'desktop','Chrome','2026-06-22 07:15:13'),(244,'/',NULL,NULL,'qUxNoclcybM1cHMcrKPFbcQUUxZMptTHQbQTl6Z1',NULL,NULL,'desktop','Firefox','2026-06-22 08:10:23'),(245,'shop',NULL,'https://safhenokhost.ir/','qUxNoclcybM1cHMcrKPFbcQUUxZMptTHQbQTl6Z1',NULL,NULL,'desktop','Firefox','2026-06-22 08:10:31'),(246,'shop/cart',NULL,'https://safhenokhost.ir/shop','qUxNoclcybM1cHMcrKPFbcQUUxZMptTHQbQTl6Z1',NULL,NULL,'desktop','Firefox','2026-06-22 08:10:37'),(247,'contact',NULL,'https://safhenokhost.ir/','qUxNoclcybM1cHMcrKPFbcQUUxZMptTHQbQTl6Z1',NULL,NULL,'desktop','Firefox','2026-06-22 08:11:00'),(248,'/',NULL,NULL,'PPEVSDEAp13fCFZNUhKa0SRokTmvFK8nmixxsfGw',NULL,NULL,'mobile','Chrome','2026-06-22 09:17:31'),(249,'/',NULL,NULL,'wBN0uAAdVD9Z6JRiWnEky8zKR4a3MbavypJFPBPR',NULL,NULL,'mobile','Chrome','2026-06-22 09:36:50'),(250,'/',NULL,NULL,'tDlMVm30YWq61YnVA2Yx1WKe89M4jBPoWhJi7YvW',NULL,NULL,'desktop','Other','2026-06-22 09:36:57'),(251,'/',NULL,NULL,'L4JUghP4MXjqUJ1Nj0PJkp1PY097nC3hozkxP4IF',NULL,NULL,'desktop','Other','2026-06-22 10:50:07'),(252,'/',NULL,NULL,'wfJHTXHkLSs3OPQXB4kLuZOULEukpq9yubsP94pG',NULL,NULL,'desktop','Safari','2026-06-22 11:15:36'),(253,'login',NULL,'https://safhenokhost.ir/account/tickets/1','0PFGnjeQ3vKvHzvXXWJ53bfgrAdAKRLEPq6UT4Ak',NULL,NULL,'desktop','Firefox','2026-06-22 11:18:17'),(254,'account',NULL,'https://safhenokhost.ir/login','xF32Gb8MfxGEBGpd4J9FHBKU3ICluVOeCs5PQn8T',2,NULL,'desktop','Firefox','2026-06-22 11:18:28'),(255,'login',NULL,'https://safhenokhost.ir/account','xF32Gb8MfxGEBGpd4J9FHBKU3ICluVOeCs5PQn8T',2,NULL,'desktop','Firefox','2026-06-22 11:18:29'),(256,'login',NULL,'https://safhenokhost.ir/admin/inbox/user/1','9yK6fi1vQEqBR0XIHs87xswjerpwqVh6dpP3kQPg',NULL,NULL,'desktop','Firefox','2026-06-22 11:18:36'),(257,'login',NULL,'https://safhenokhost.ir/admin/dashboard','8VuF3KkyZGN03TEqnbBZT6vLQEtnzKHB8v21CLIG',1,NULL,'desktop','Firefox','2026-06-22 11:18:43'),(258,'/',NULL,'https://safhenokhost.ir/','8VuF3KkyZGN03TEqnbBZT6vLQEtnzKHB8v21CLIG',1,NULL,'desktop','Firefox','2026-06-22 11:44:05'),(259,'login',NULL,'https://safhenokhost.ir/admin/theme-design','8VuF3KkyZGN03TEqnbBZT6vLQEtnzKHB8v21CLIG',1,NULL,'desktop','Firefox','2026-06-22 11:48:58'),(260,'/',NULL,'https://safhenokhost.ir/','8VuF3KkyZGN03TEqnbBZT6vLQEtnzKHB8v21CLIG',1,NULL,'desktop','Firefox','2026-06-22 12:17:28'),(261,'login',NULL,'https://safhenokhost.ir/admin/dashboard','8VuF3KkyZGN03TEqnbBZT6vLQEtnzKHB8v21CLIG',1,NULL,'desktop','Firefox','2026-06-22 12:21:03'),(262,'login',NULL,'https://safhenokhost.ir/admin/dashboard','8VuF3KkyZGN03TEqnbBZT6vLQEtnzKHB8v21CLIG',1,NULL,'desktop','Firefox','2026-06-22 12:54:49'),(263,'/',NULL,NULL,'IWWFQ8Tm7LXAQLySU92BHQR5HTWLATojGNHV0jQX',NULL,NULL,'desktop','Safari','2026-06-22 15:46:33'),(264,'login',NULL,'https://safhenokhost.ir/admin/theme-design','Wclso0rpX3iVjg4qLa5PBZbYlOorDl1f4CMlixLI',NULL,NULL,'desktop','Firefox','2026-06-22 16:00:10'),(265,'/',NULL,'https://safhenokhost.ir/','Wclso0rpX3iVjg4qLa5PBZbYlOorDl1f4CMlixLI',NULL,NULL,'desktop','Firefox','2026-06-22 16:00:29'),(266,'login',NULL,'https://safhenokhost.ir/admin/dashboard','IZJ0NgdoceHHmc9Py359pezPbwB6hELPf0jHwyJw',1,NULL,'desktop','Firefox','2026-06-22 16:00:49'),(267,'/',NULL,'https://safhenokhost.ir/admin/dashboard','IZJ0NgdoceHHmc9Py359pezPbwB6hELPf0jHwyJw',1,NULL,'desktop','Firefox','2026-06-22 16:00:55'),(268,'/',NULL,NULL,'xE3C0f5aPD7VrYMSi8jwKXpN5ruKvOhVuKoXWWCe',NULL,NULL,'desktop','Chrome','2026-06-22 16:27:12'),(269,'login',NULL,'https://safhenokhost.ir/login','1wJxXkr61MUZh4ImFhl6txStpd26BdP66RZCzUoH',NULL,NULL,'desktop','Firefox','2026-06-22 16:30:43'),(270,'account',NULL,'https://safhenokhost.ir/login','NqbR23n2LJmxFmz6doCOE9zbiWVJTNJ3wdW82Z7x',2,NULL,'desktop','Firefox','2026-06-22 16:30:53'),(271,'login',NULL,'https://safhenokhost.ir/account','NqbR23n2LJmxFmz6doCOE9zbiWVJTNJ3wdW82Z7x',2,NULL,'desktop','Firefox','2026-06-22 16:30:57'),(272,'account/notifications',NULL,'https://safhenokhost.ir/account','NqbR23n2LJmxFmz6doCOE9zbiWVJTNJ3wdW82Z7x',2,NULL,'desktop','Firefox','2026-06-22 16:31:01'),(273,'login',NULL,'https://safhenokhost.ir/admin/dashboard','IZJ0NgdoceHHmc9Py359pezPbwB6hELPf0jHwyJw',1,NULL,'desktop','Firefox','2026-06-22 16:31:50'),(274,'/',NULL,'https://safhenokhost.ir/admin/dashboard','IZJ0NgdoceHHmc9Py359pezPbwB6hELPf0jHwyJw',1,NULL,'desktop','Firefox','2026-06-22 16:32:10'),(275,'account/resources',NULL,'https://safhenokhost.ir/admin/dashboard','IZJ0NgdoceHHmc9Py359pezPbwB6hELPf0jHwyJw',1,NULL,'desktop','Firefox','2026-06-22 16:45:31'),(276,'contact',NULL,'https://safhenokhost.ir/account/resources','IZJ0NgdoceHHmc9Py359pezPbwB6hELPf0jHwyJw',1,NULL,'desktop','Firefox','2026-06-22 16:45:40'),(277,'login',NULL,'https://safhenokhost.ir/admin/theme-design','IZJ0NgdoceHHmc9Py359pezPbwB6hELPf0jHwyJw',1,NULL,'desktop','Firefox','2026-06-22 17:02:54'),(278,'/',NULL,'https://safhenokhost.ir/admin/dashboard','IZJ0NgdoceHHmc9Py359pezPbwB6hELPf0jHwyJw',1,NULL,'desktop','Firefox','2026-06-22 17:05:35'),(279,'page/blog',NULL,'https://safhenokhost.ir/admin/pages','IZJ0NgdoceHHmc9Py359pezPbwB6hELPf0jHwyJw',1,NULL,'desktop','Firefox','2026-06-22 17:16:17'),(280,'page/404',NULL,'https://safhenokhost.ir/admin/pages','IZJ0NgdoceHHmc9Py359pezPbwB6hELPf0jHwyJw',1,NULL,'desktop','Firefox','2026-06-22 17:16:29'),(281,'contact',NULL,'https://safhenokhost.ir/','IZJ0NgdoceHHmc9Py359pezPbwB6hELPf0jHwyJw',1,NULL,'desktop','Firefox','2026-06-22 17:33:28'),(282,'blog',NULL,'https://safhenokhost.ir/','IZJ0NgdoceHHmc9Py359pezPbwB6hELPf0jHwyJw',1,NULL,'desktop','Firefox','2026-06-22 17:33:34'),(283,'contact',NULL,NULL,'ZvrXIWOBMnAUUsLOGwIQCE5dHAYo33EfWFYFcwYh',NULL,NULL,'desktop','Firefox','2026-06-22 17:33:44'),(284,'login',NULL,'https://safhenokhost.ir/admin/theme-marketplace/my-licenses','IZJ0NgdoceHHmc9Py359pezPbwB6hELPf0jHwyJw',1,NULL,'desktop','Firefox','2026-06-22 17:34:11'),(285,'/',NULL,'https://safhenokhost.ir/','IZJ0NgdoceHHmc9Py359pezPbwB6hELPf0jHwyJw',1,NULL,'desktop','Firefox','2026-06-22 17:36:12'),(286,'/',NULL,NULL,'Pn2I9DcgqVtPTgLfb24rTC8j80NhFEOOlgtI5bTH',NULL,NULL,'mobile','Chrome','2026-06-22 20:06:04'),(287,'blog',NULL,'https://safhenokhost.ir/','Pn2I9DcgqVtPTgLfb24rTC8j80NhFEOOlgtI5bTH',NULL,NULL,'mobile','Chrome','2026-06-22 20:06:15'),(288,'login',NULL,NULL,'Pn2I9DcgqVtPTgLfb24rTC8j80NhFEOOlgtI5bTH',NULL,NULL,'mobile','Chrome','2026-06-22 20:06:26'),(289,'login',NULL,'https://safhenokhost.ir/admin/dashboard','D8eg8UzDJhbBEqKC3claqzhVseJTy26BmpGBAESN',1,NULL,'mobile','Chrome','2026-06-22 20:06:32'),(290,'/',NULL,NULL,'jCunoEoewZpRF0sZPtn5bWVzZu58hs8sRlwxCr4z',NULL,NULL,'desktop','Chrome','2026-06-22 22:15:13'),(291,'/',NULL,'http://safhenokhost.ir/index.php','7UVnFqVA0u7kmE7Fs74kZ6mqiWc2VPpkI7nqOC2b',NULL,NULL,'desktop','Chrome','2026-06-23 00:34:22'),(292,'/',NULL,'https://www.google.com/','HEyNk29xIuCHc5zMFfWrgCZeSBsrrkBDUvatLwLG',NULL,NULL,'mobile','Chrome','2026-06-23 06:22:51'),(293,'/',NULL,NULL,'raQlsd09szkakukmwSzcY1s1TJVlP3axpXqFqJsa',NULL,NULL,'desktop','Chrome','2026-06-23 06:45:55'),(294,'login',NULL,'https://safhenokhost.ir/admin/dashboard','n9221jFeaoXR7DBLVOOSZOPCCAIsU4zsb5HMTNf2',NULL,NULL,'desktop','Firefox','2026-06-23 06:52:44'),(295,'/',NULL,'https://safhenokhost.ir/admin/dashboard','3QTEVd1x01ivufmUa4CUOoasNpIUVXzTE7FFy0p7',1,NULL,'desktop','Firefox','2026-06-23 06:53:05'),(296,'login',NULL,'https://safhenokhost.ir/admin/theme-design','3QTEVd1x01ivufmUa4CUOoasNpIUVXzTE7FFy0p7',1,NULL,'desktop','Firefox','2026-06-23 06:55:16'),(297,'login',NULL,'https://safhenokhost.ir/admin/dashboard','3QTEVd1x01ivufmUa4CUOoasNpIUVXzTE7FFy0p7',1,NULL,'desktop','Firefox','2026-06-23 07:32:29'),(298,'page/services',NULL,'https://safhenokhost.ir/admin/pages','3QTEVd1x01ivufmUa4CUOoasNpIUVXzTE7FFy0p7',1,NULL,'desktop','Firefox','2026-06-23 07:34:46'),(299,'/',NULL,'https://safhenokhost.ir/','3QTEVd1x01ivufmUa4CUOoasNpIUVXzTE7FFy0p7',1,NULL,'desktop','Firefox','2026-06-23 07:35:49'),(300,'page/home',NULL,'https://safhenokhost.ir/admin/pages','3QTEVd1x01ivufmUa4CUOoasNpIUVXzTE7FFy0p7',1,NULL,'desktop','Firefox','2026-06-23 07:40:35'),(301,'builder/edit/130',NULL,'https://safhenokhost.ir/page/home','3QTEVd1x01ivufmUa4CUOoasNpIUVXzTE7FFy0p7',1,NULL,'desktop','Firefox','2026-06-23 07:40:37'),(302,'login',NULL,'https://safhenokhost.ir/admin/pages','3QTEVd1x01ivufmUa4CUOoasNpIUVXzTE7FFy0p7',1,NULL,'desktop','Firefox','2026-06-23 08:08:20'),(303,'builder/edit/130',NULL,'https://safhenokhost.ir/page/home','3QTEVd1x01ivufmUa4CUOoasNpIUVXzTE7FFy0p7',1,NULL,'desktop','Firefox','2026-06-23 08:12:42'),(304,'page/home',NULL,'https://safhenokhost.ir/builder/edit/130','3QTEVd1x01ivufmUa4CUOoasNpIUVXzTE7FFy0p7',1,NULL,'desktop','Firefox','2026-06-23 08:38:07'),(305,'login',NULL,'https://safhenokhost.ir/admin/dashboard','3QTEVd1x01ivufmUa4CUOoasNpIUVXzTE7FFy0p7',1,NULL,'desktop','Firefox','2026-06-23 08:39:50'),(306,'/',NULL,NULL,'8nWC0kkdr0rLqOi8jH8Y0nKKpFcJVhXBp5ByplIp',NULL,NULL,'desktop','Other','2026-06-23 09:44:04'),(307,'/',NULL,NULL,'znU67YMHbT9dAafsMpqQB15GApWqgd1GfFEk7RmG',NULL,NULL,'desktop','Other','2026-06-23 09:48:49'),(308,'/',NULL,NULL,'VD3yxFQgA88z45TWLHtgs3n1HDWDLdXhGeMgartA',NULL,NULL,'desktop','Other','2026-06-23 10:08:05'),(309,'login',NULL,'https://safhenokhost.ir/login','8EmQZOlIlhh3qHvYT1cJFRipDk27WkmYYp6SfOOH',NULL,NULL,'desktop','Firefox','2026-06-23 11:49:37'),(310,'account',NULL,'https://safhenokhost.ir/login','9ZHd1NFbQpFMS8DBfJVuEmTAy5nyOuN2qm5TvJf5',2,NULL,'desktop','Firefox','2026-06-23 11:49:55'),(311,'login',NULL,'https://safhenokhost.ir/account','9ZHd1NFbQpFMS8DBfJVuEmTAy5nyOuN2qm5TvJf5',2,NULL,'desktop','Firefox','2026-06-23 11:50:01'),(312,'login',NULL,'https://safhenokhost.ir/admin/license','3QTEVd1x01ivufmUa4CUOoasNpIUVXzTE7FFy0p7',1,NULL,'desktop','Firefox','2026-06-23 11:50:29'),(313,'builder/edit/130',NULL,'https://safhenokhost.ir/page/home','3QTEVd1x01ivufmUa4CUOoasNpIUVXzTE7FFy0p7',1,NULL,'desktop','Firefox','2026-06-23 11:51:16'),(314,'page/home',NULL,'https://safhenokhost.ir/builder/edit/130','3QTEVd1x01ivufmUa4CUOoasNpIUVXzTE7FFy0p7',1,NULL,'desktop','Firefox','2026-06-23 11:51:27'),(315,'login',NULL,'https://safhenokhost.ir/admin/dashboard','3QTEVd1x01ivufmUa4CUOoasNpIUVXzTE7FFy0p7',1,NULL,'desktop','Firefox','2026-06-23 13:17:30'),(316,'page/home',NULL,'https://safhenokhost.ir/admin/pages','3QTEVd1x01ivufmUa4CUOoasNpIUVXzTE7FFy0p7',1,NULL,'desktop','Firefox','2026-06-23 13:37:18'),(317,'/',NULL,NULL,'3QTEVd1x01ivufmUa4CUOoasNpIUVXzTE7FFy0p7',1,NULL,'desktop','Firefox','2026-06-23 13:37:24'),(318,'builder/page/130/edit',NULL,'https://safhenokhost.ir/','3QTEVd1x01ivufmUa4CUOoasNpIUVXzTE7FFy0p7',1,NULL,'desktop','Firefox','2026-06-23 13:37:46'),(319,'page/faq',NULL,'https://safhenokhost.ir/admin/pages','3QTEVd1x01ivufmUa4CUOoasNpIUVXzTE7FFy0p7',1,NULL,'desktop','Firefox','2026-06-23 13:38:20'),(320,'contact',NULL,'https://safhenokhost.ir/page/faq','3QTEVd1x01ivufmUa4CUOoasNpIUVXzTE7FFy0p7',1,NULL,'desktop','Firefox','2026-06-23 13:38:36'),(321,'builder/page/128/edit',NULL,'https://safhenokhost.ir/page/faq','3QTEVd1x01ivufmUa4CUOoasNpIUVXzTE7FFy0p7',1,NULL,'desktop','Firefox','2026-06-23 13:41:28'),(322,'/',NULL,NULL,'VgxK4YlHWgTeslONvkwLkzuXYrxSsKdjhnzfW8fG',NULL,NULL,'desktop','Chrome','2026-06-24 02:08:29'),(323,'/',NULL,NULL,'1GG3eKHo0YjwNShNstqlnoWIrynHvwoEsEtOb3ZB',NULL,NULL,'desktop','Other','2026-06-24 02:18:18'),(324,'/',NULL,NULL,'jGXuIo2rQzJkFVcRa9hZkRERCgf6HTVi3OAwk45y',NULL,NULL,'mobile','Chrome','2026-06-24 05:01:38'),(325,'login',NULL,NULL,'jGXuIo2rQzJkFVcRa9hZkRERCgf6HTVi3OAwk45y',NULL,NULL,'mobile','Chrome','2026-06-24 05:02:50'),(326,'login',NULL,'https://safhenokhost.ir/admin/dashboard','kg783UbBvpfFvs8LzgrS1Uz0TNfXcpSmndzy5xnI',1,NULL,'mobile','Chrome','2026-06-24 05:03:05'),(327,'/',NULL,NULL,'kg783UbBvpfFvs8LzgrS1Uz0TNfXcpSmndzy5xnI',1,NULL,'mobile','Chrome','2026-06-24 05:04:03'),(328,'/',NULL,NULL,'CDu78sgGkGHCUzr4bBE0InEuLdZWCS1AeEGeTzyC',NULL,NULL,'desktop','Chrome','2026-06-24 05:44:21'),(329,'login',NULL,'https://safhenokhost.ir/admin/license','ERmix0RrLwzT0FnZQMSprGmo9W759O6UIesNV5WU',NULL,NULL,'desktop','Firefox','2026-06-24 07:11:30'),(330,'login',NULL,'https://safhenokhost.ir/admin/dashboard','1YefhuUzOBDaTRrKOeLYdhYKNFpi70Nb7LUufP1k',1,NULL,'desktop','Firefox','2026-06-24 07:11:42'),(331,'login',NULL,'https://safhenokhost.ir/login','7PSN6vtk9S15iKkcBcuO3pub4o3gksHMvYeGZ0RE',NULL,NULL,'desktop','Firefox','2026-06-24 07:12:33'),(332,'account',NULL,'https://safhenokhost.ir/login','EWOC98RCvCz5YsrfBUnPIxgEbuW2YoLhnxZQCQ8K',2,NULL,'desktop','Firefox','2026-06-24 07:12:44'),(333,'login',NULL,'https://safhenokhost.ir/account','EWOC98RCvCz5YsrfBUnPIxgEbuW2YoLhnxZQCQ8K',2,NULL,'desktop','Firefox','2026-06-24 07:12:45'),(334,'account/profile',NULL,'https://safhenokhost.ir/account','EWOC98RCvCz5YsrfBUnPIxgEbuW2YoLhnxZQCQ8K',2,NULL,'desktop','Firefox','2026-06-24 07:12:50'),(335,'account/tickets',NULL,'https://safhenokhost.ir/account','EWOC98RCvCz5YsrfBUnPIxgEbuW2YoLhnxZQCQ8K',2,NULL,'desktop','Firefox','2026-06-24 07:12:59'),(336,'/',NULL,NULL,'nF7PWdh0GJs8T6FvT3VDmU4Xm1qTDcOQxmuBoXLK',NULL,NULL,'desktop','Other','2026-06-24 07:21:14'),(337,'account/tickets/1',NULL,'https://safhenokhost.ir/account/tickets','EWOC98RCvCz5YsrfBUnPIxgEbuW2YoLhnxZQCQ8K',2,NULL,'desktop','Firefox','2026-06-24 08:04:27'),(338,'login',NULL,'https://safhenokhost.ir/account/tickets/1','EWOC98RCvCz5YsrfBUnPIxgEbuW2YoLhnxZQCQ8K',2,NULL,'desktop','Firefox','2026-06-24 08:04:30'),(339,'login',NULL,'https://safhenokhost.ir/admin/license','1YefhuUzOBDaTRrKOeLYdhYKNFpi70Nb7LUufP1k',1,NULL,'desktop','Firefox','2026-06-24 08:10:11'),(340,'/',NULL,NULL,'gSuNkHvrFYPdoXBwJl0qKnY2gUBzLAGD18COT0yt',NULL,NULL,'desktop','Safari','2026-06-24 09:44:28'),(341,'/',NULL,NULL,'iVE1CHK8tdbkZy1Cm9kaPaTWMVqX7RJSjWi31dnk',NULL,NULL,'desktop','Firefox','2026-06-24 09:59:11'),(342,'/',NULL,NULL,'xFgQwMKRN8h2nzqQxOMVdS90PuiHN61HW0lygATF',NULL,NULL,'desktop','Other','2026-06-24 13:23:34'),(343,'login',NULL,'https://safhenokhost.ir/admin/license','uIWFnrFsmBY7Z5TBcksVyUWPBKcHiMLfvJKA3Lcq',NULL,NULL,'desktop','Firefox','2026-06-24 16:19:26'),(344,'login',NULL,'https://safhenokhost.ir/admin/dashboard','1I3uhe7PFQjOGOap932H4fd2Vxex5kzKuXyJCm1q',1,NULL,'desktop','Firefox','2026-06-24 16:19:38'),(345,'login',NULL,'https://safhenokhost.ir/admin/license','1I3uhe7PFQjOGOap932H4fd2Vxex5kzKuXyJCm1q',1,NULL,'desktop','Firefox','2026-06-24 17:08:24'),(346,'/',NULL,'http://safhenokhost.ir/index.php','IsR8XJMtLgWbp35uT6Hlv81VRJWgubC9Rue1mt5e',NULL,NULL,'desktop','Firefox','2026-06-24 23:09:44'),(347,'/',NULL,NULL,'NYuIitifnqu0M6D0Ux1rEBybBuT2jBPJAVnbjAXI',NULL,NULL,'desktop','Chrome','2026-06-25 00:18:57'),(348,'login',NULL,'https://safhenokhost.ir/admin/pages','41cMnTWBNWIRwIfM5oO421CvKw0dVc9Np0MXmaKS',NULL,NULL,'desktop','Firefox','2026-06-25 06:48:07'),(349,'login',NULL,'https://safhenokhost.ir/admin/license','gWgImAbuXkOlDElzdJ0lsMl9ANjXMK3OE5xY9w8U',1,NULL,'desktop','Firefox','2026-06-25 06:48:47'),(350,'login',NULL,'https://safhenokhost.ir/account/tickets/1','ptuWYhpxGh8Lm6wMobWDdKkhaqCrkrvHRYC5bXpf',NULL,NULL,'desktop','Firefox','2026-06-25 06:49:40'),(351,'account',NULL,'https://safhenokhost.ir/login','AGEBQRufKle3CoHXYauXSIaoIk7hXfJU1YJBajJa',2,NULL,'desktop','Firefox','2026-06-25 06:49:50'),(352,'login',NULL,'https://safhenokhost.ir/account','AGEBQRufKle3CoHXYauXSIaoIk7hXfJU1YJBajJa',2,NULL,'desktop','Firefox','2026-06-25 06:49:52'),(353,'/',NULL,NULL,'a3YtU80xHic51Mkazhu7V46LRH21OGbWwneUHMHo',NULL,NULL,'desktop','Other','2026-06-25 06:59:47'),(354,'login',NULL,'https://safhenokhost.ir/admin/license','gWgImAbuXkOlDElzdJ0lsMl9ANjXMK3OE5xY9w8U',1,NULL,'desktop','Firefox','2026-06-25 08:03:20'),(355,'login',NULL,'https://safhenokhost.ir/admin/dashboard','gWgImAbuXkOlDElzdJ0lsMl9ANjXMK3OE5xY9w8U',1,NULL,'desktop','Firefox','2026-06-25 08:50:36'),(356,'account/resources',NULL,'https://safhenokhost.ir/admin/dashboard','gWgImAbuXkOlDElzdJ0lsMl9ANjXMK3OE5xY9w8U',1,NULL,'desktop','Firefox','2026-06-25 09:02:21'),(357,'login',NULL,'https://safhenokhost.ir/admin/dashboard','gWgImAbuXkOlDElzdJ0lsMl9ANjXMK3OE5xY9w8U',1,NULL,'desktop','Firefox','2026-06-25 09:26:19'),(358,'login',NULL,'https://safhenokhost.ir/admin/dashboard','gWgImAbuXkOlDElzdJ0lsMl9ANjXMK3OE5xY9w8U',1,NULL,'desktop','Firefox','2026-06-25 10:05:38'),(359,'account/resources',NULL,'https://safhenokhost.ir/admin/dashboard','gWgImAbuXkOlDElzdJ0lsMl9ANjXMK3OE5xY9w8U',1,NULL,'desktop','Firefox','2026-06-25 10:09:51'),(360,'/',NULL,NULL,'ByZreQyaMqhCxY1xE36mHn62fkCsmXmrmGjvpWSR',NULL,NULL,'desktop','Other','2026-06-25 10:10:04'),(361,'/',NULL,NULL,'8a9XfbSgJFkPbrDPulMZMywQuRX13Dos9lychAEZ',NULL,NULL,'mobile','Chrome','2026-06-25 12:23:09'),(362,'/',NULL,NULL,'T4q6iBiaFgFMIjCwEVSsc9XqAC3FzBHKvWRiPpBS',NULL,NULL,'desktop','Other','2026-06-25 12:23:14'),(363,'shop',NULL,'https://safhenokhost.ir/','8a9XfbSgJFkPbrDPulMZMywQuRX13Dos9lychAEZ',NULL,NULL,'mobile','Chrome','2026-06-25 12:23:24'),(364,'login',NULL,NULL,'8a9XfbSgJFkPbrDPulMZMywQuRX13Dos9lychAEZ',NULL,NULL,'mobile','Chrome','2026-06-25 12:23:38'),(365,'login',NULL,'https://safhenokhost.ir/admin/dashboard','vnpi4i644kn4BsLeniotXWMNKyO0np1GMDanEodb',1,NULL,'mobile','Chrome','2026-06-25 12:23:48'),(366,'/',NULL,NULL,'g9KIWs47aU6nljNE5TVHXmwykPMkrBjw4YMBEpZB',NULL,NULL,'desktop','Firefox','2026-06-25 12:26:53'),(367,'login',NULL,NULL,'g9KIWs47aU6nljNE5TVHXmwykPMkrBjw4YMBEpZB',NULL,NULL,'desktop','Firefox','2026-06-25 12:27:44'),(368,'login',NULL,'https://safhenokhost.ir/admin/dashboard','pzeqfuEuGYKj8N0HWo7kzbvnA83utR1OOZpt3eod',1,NULL,'desktop','Firefox','2026-06-25 12:28:05'),(369,'/',NULL,NULL,'oQkq0f7c7qp5dmhU2yKNTMtPWK56I0uBiaDS5lY9',NULL,NULL,'desktop','Other','2026-06-25 12:34:13'),(370,'/',NULL,NULL,'7lYwRbUiRBbUK999TCpeGNOoneiYFaur1aB1EYYn',NULL,NULL,'desktop','Other','2026-06-25 12:36:04'),(371,'/',NULL,NULL,'ZWvC9L2eYYHsi6gMUaTdu0UcCHRhaEsNehyTxymG',NULL,NULL,'desktop','Other','2026-06-25 12:41:42'),(372,'login',NULL,'https://safhenokhost.ir/admin/dashboard','pzeqfuEuGYKj8N0HWo7kzbvnA83utR1OOZpt3eod',1,NULL,'desktop','Firefox','2026-06-25 14:00:13'),(373,'/',NULL,'http://safhenokhost.ir/index.php','JegwwXdAfrjh14lsfiPgindTodcKDt2TqKBQ0gAm',NULL,NULL,'desktop','Chrome','2026-06-25 14:06:51'),(374,'login',NULL,NULL,'wvDF45K81SVkILwcqkEW26uktvW2AlJhRKojgtSf',NULL,NULL,'desktop','Chrome','2026-06-25 14:49:31'),(375,'login',NULL,NULL,'J3zJVUsvujViMUMlJB6NhwciIN1XvRqlRMmvoMxb',NULL,NULL,'desktop','Chrome','2026-06-25 14:49:32'),(376,'login',NULL,'https://safhenokhost.ir/admin/sms','pzeqfuEuGYKj8N0HWo7kzbvnA83utR1OOZpt3eod',1,NULL,'desktop','Firefox','2026-06-25 14:55:22'),(377,'/',NULL,NULL,'4oa4N0Mr6zvGGHXKcegQR5WSjBCgOtpxD1ghHEzX',NULL,NULL,'desktop','Firefox','2026-06-25 15:08:26'),(378,'/',NULL,NULL,'jXioNs81Fc1OYQQLDGaG4sO3AcZuQ6JG8XV2i2z3',NULL,NULL,'mobile','Chrome','2026-06-25 15:13:19'),(379,'/',NULL,NULL,'Ua7rvkYuScAUmLzc4ssBlx7stIx8Ts3D0lY81CMp',NULL,NULL,'mobile','Chrome','2026-06-25 15:49:49'),(380,'/',NULL,NULL,'zy6ceflJuK8lDSqylyyKOQDR8VQ1cKaKsvJDxnX7',NULL,NULL,'desktop','Other','2026-06-25 15:50:11'),(381,'login',NULL,'https://safhenokhost.ir/admin/dashboard','pzeqfuEuGYKj8N0HWo7kzbvnA83utR1OOZpt3eod',1,NULL,'desktop','Firefox','2026-06-25 17:02:57'),(382,'/',NULL,NULL,'iFQ3dbFBT1p2o4wW9DIRk7k6aoNxDbg3VIhHzNcr',NULL,NULL,'desktop','Other','2026-06-25 17:04:53'),(383,'/',NULL,NULL,'B3MLgZwIMZuWJXIkmD0kr4eDtAWkbcNle4Nw68yr',NULL,NULL,'mobile','Chrome','2026-06-25 17:37:56'),(384,'login',NULL,NULL,'pzeqfuEuGYKj8N0HWo7kzbvnA83utR1OOZpt3eod',1,NULL,'desktop','Firefox','2026-06-25 17:41:02'),(385,'login',NULL,NULL,'N45CDFfMByJqnsMBRyCiPiUzfGhPpi1P4HjmnRdM',NULL,NULL,'desktop','Chrome','2026-06-25 17:42:44'),(386,'login',NULL,'https://safhenokhost.ir/admin/dashboard','7MZSX1zWZoWL7Re024moj32CuUjHzztWaXCuttz9',1,NULL,'desktop','Firefox','2026-06-25 17:55:33'),(387,'login',NULL,'https://safhenokhost.ir/admin/dashboard','7MZSX1zWZoWL7Re024moj32CuUjHzztWaXCuttz9',1,NULL,'desktop','Firefox','2026-06-25 18:26:31'),(388,'login',NULL,'https://safhenokhost.ir/admin/dashboard','7MZSX1zWZoWL7Re024moj32CuUjHzztWaXCuttz9',1,NULL,'desktop','Firefox','2026-06-25 19:59:59'),(389,'account/resources',NULL,'https://safhenokhost.ir/admin/dashboard','7MZSX1zWZoWL7Re024moj32CuUjHzztWaXCuttz9',1,NULL,'desktop','Firefox','2026-06-25 20:11:05'),(390,'/',NULL,NULL,'7rrbQ1IKAQBn321miGgZSjWcSiw2uC8fkjvCkUL9',NULL,NULL,'mobile','Chrome','2026-06-25 20:44:33'),(391,'/',NULL,NULL,'JUdeHcAUDLKF9rI6BK3et8yZVKChGIyz18VTWBag',NULL,NULL,'desktop','Other','2026-06-25 20:53:06'),(392,'/',NULL,NULL,'7rrbQ1IKAQBn321miGgZSjWcSiw2uC8fkjvCkUL9',NULL,NULL,'mobile','Chrome','2026-06-25 21:20:51'),(393,'login',NULL,NULL,'7rrbQ1IKAQBn321miGgZSjWcSiw2uC8fkjvCkUL9',NULL,NULL,'mobile','Chrome','2026-06-25 21:21:04'),(394,'login',NULL,'https://safhenokhost.ir/admin/dashboard','CvoHexWZEEvY2c5YD4CeNYMVfoDRWnetS5tbTWbR',1,NULL,'mobile','Chrome','2026-06-25 21:21:20'),(395,'login',NULL,'https://safhenokhost.ir/admin/dashboard','7MZSX1zWZoWL7Re024moj32CuUjHzztWaXCuttz9',1,NULL,'desktop','Firefox','2026-06-25 22:21:32'),(396,'login',NULL,NULL,'CvoHexWZEEvY2c5YD4CeNYMVfoDRWnetS5tbTWbR',1,NULL,'mobile','Chrome','2026-06-25 22:55:10'),(397,'login',NULL,'https://safhenokhost.ir/admin/dashboard','M4atV7sWmKwfgaJ6ezCOSDZN4YrpQVYXIp6cdqc1',1,NULL,'mobile','Chrome','2026-06-25 22:55:17'),(398,'login',NULL,'https://safhenokhost.ir/admin/dashboard','RFWUOmRugj2szrPznWH8ywQdhj8XdrBVDgWA3rgB',1,NULL,'desktop','Chrome','2026-06-25 22:55:53'),(399,'/',NULL,NULL,'x2iY1FCPwE0LmDIevgYRUtAqrRaeHf8uheaKNySp',NULL,NULL,'desktop','Chrome','2026-06-25 23:23:53'),(400,'login',NULL,'https://safhenokhost.ir/admin/inbox/create','7vmeXxm5gZyir1ULpjnHWrAly3ezOKv4hHXSSDQx',NULL,NULL,'desktop','Firefox','2026-06-26 03:40:45'),(401,'login',NULL,'https://safhenokhost.ir/admin/dashboard','3763hMEupygSDzaXXL02A6FAdtnHk88RWyx2WpqA',1,NULL,'desktop','Firefox','2026-06-26 03:40:53'),(402,'login',NULL,'https://safhenokhost.ir/admin/theme-design','3763hMEupygSDzaXXL02A6FAdtnHk88RWyx2WpqA',1,NULL,'desktop','Firefox','2026-06-26 04:11:52'),(403,'/',NULL,NULL,'phhScphUQoGkyRNDVbnPUw0dp2uqVrDKZ9LWwoWN',NULL,NULL,'desktop','Chrome','2026-06-26 04:22:26'),(404,'/',NULL,NULL,'S6smLxpa9IRZoM2eAf2qR46O3cf5NQL8tdlOotqw',NULL,NULL,'desktop','Chrome','2026-06-26 04:22:27'),(405,'login',NULL,NULL,'S6smLxpa9IRZoM2eAf2qR46O3cf5NQL8tdlOotqw',NULL,NULL,'desktop','Chrome','2026-06-26 04:22:38'),(406,'/',NULL,NULL,'jpAgUHRBvnp5twbVf9RPNKwMiYIUyCFM2yr3PrCI',2,NULL,'desktop','Chrome','2026-06-26 04:23:09'),(407,'account',NULL,NULL,'jpAgUHRBvnp5twbVf9RPNKwMiYIUyCFM2yr3PrCI',2,NULL,'desktop','Chrome','2026-06-26 04:23:21'),(408,'login',NULL,'https://safhenokhost.ir/account','jpAgUHRBvnp5twbVf9RPNKwMiYIUyCFM2yr3PrCI',2,NULL,'desktop','Chrome','2026-06-26 04:23:40'),(409,'account/tickets/1',NULL,'https://safhenokhost.ir/account','jpAgUHRBvnp5twbVf9RPNKwMiYIUyCFM2yr3PrCI',2,NULL,'desktop','Chrome','2026-06-26 04:23:59'),(410,'account/tickets',NULL,'https://safhenokhost.ir/account','jpAgUHRBvnp5twbVf9RPNKwMiYIUyCFM2yr3PrCI',2,NULL,'desktop','Chrome','2026-06-26 04:24:14'),(411,'login',NULL,'https://safhenokhost.ir/admin/theme-design','3763hMEupygSDzaXXL02A6FAdtnHk88RWyx2WpqA',1,NULL,'desktop','Firefox','2026-06-26 04:43:08'),(412,'/',NULL,NULL,'3763hMEupygSDzaXXL02A6FAdtnHk88RWyx2WpqA',1,NULL,'desktop','Firefox','2026-06-26 04:45:15'),(413,'account',NULL,'https://safhenokhost.ir/account/tickets/1','jpAgUHRBvnp5twbVf9RPNKwMiYIUyCFM2yr3PrCI',2,NULL,'desktop','Chrome','2026-06-26 04:53:41'),(414,'login',NULL,'https://safhenokhost.ir/account','jpAgUHRBvnp5twbVf9RPNKwMiYIUyCFM2yr3PrCI',2,NULL,'desktop','Chrome','2026-06-26 04:53:44'),(415,'/',NULL,'https://safhenokhost.ir/account','jpAgUHRBvnp5twbVf9RPNKwMiYIUyCFM2yr3PrCI',2,NULL,'desktop','Chrome','2026-06-26 04:53:53'),(416,'account/installments',NULL,'https://safhenokhost.ir/account','jpAgUHRBvnp5twbVf9RPNKwMiYIUyCFM2yr3PrCI',2,NULL,'desktop','Chrome','2026-06-26 04:54:06'),(417,'account/tickets/1',NULL,'https://safhenokhost.ir/account','jpAgUHRBvnp5twbVf9RPNKwMiYIUyCFM2yr3PrCI',2,NULL,'desktop','Chrome','2026-06-26 04:54:28'),(418,'login',NULL,'https://safhenokhost.ir/admin/dashboard','3763hMEupygSDzaXXL02A6FAdtnHk88RWyx2WpqA',1,NULL,'desktop','Firefox','2026-06-26 05:13:36'),(419,'/',NULL,NULL,'3763hMEupygSDzaXXL02A6FAdtnHk88RWyx2WpqA',1,NULL,'desktop','Firefox','2026-06-26 05:22:01'),(420,'blog',NULL,'https://safhenokhost.ir/','3763hMEupygSDzaXXL02A6FAdtnHk88RWyx2WpqA',1,NULL,'desktop','Firefox','2026-06-26 05:22:07'),(421,'blog/sayt-hmh-karh',NULL,'https://safhenokhost.ir/blog','3763hMEupygSDzaXXL02A6FAdtnHk88RWyx2WpqA',1,NULL,'desktop','Firefox','2026-06-26 05:22:16'),(422,'/',NULL,NULL,'t7WvTTFbRYIh6OOkRTyDBMXgU9pt55jDRR2wLCLz',NULL,NULL,'desktop','Chrome','2026-06-26 05:31:29'),(423,'login',NULL,NULL,'t7WvTTFbRYIh6OOkRTyDBMXgU9pt55jDRR2wLCLz',NULL,NULL,'mobile','Chrome','2026-06-26 05:31:46'),(424,'login',NULL,'https://safhenokhost.ir/admin/dashboard','s0eprichjaUcDWSe52aCiH0M15DOYZhz54eVAWXx',1,NULL,'mobile','Chrome','2026-06-26 05:32:16'),(425,'/',NULL,'https://safhenokhost.ir/admin/dashboard','H72Yu9oLcQbaPml9GbGdd5rCz9A0ORIzilU9p1Bd',NULL,NULL,'mobile','Chrome','2026-06-26 05:33:16'),(426,'account',NULL,'https://safhenokhost.ir/account/tickets/1','jpAgUHRBvnp5twbVf9RPNKwMiYIUyCFM2yr3PrCI',2,NULL,'desktop','Chrome','2026-06-26 05:35:29'),(427,'login',NULL,'https://safhenokhost.ir/account','jpAgUHRBvnp5twbVf9RPNKwMiYIUyCFM2yr3PrCI',2,NULL,'desktop','Chrome','2026-06-26 05:35:33'),(428,'account/tickets/1',NULL,'https://safhenokhost.ir/account','jpAgUHRBvnp5twbVf9RPNKwMiYIUyCFM2yr3PrCI',2,NULL,'desktop','Chrome','2026-06-26 05:44:22'),(429,'account/security',NULL,'https://safhenokhost.ir/account','jpAgUHRBvnp5twbVf9RPNKwMiYIUyCFM2yr3PrCI',2,NULL,'desktop','Chrome','2026-06-26 05:45:05'),(430,'login',NULL,'https://safhenokhost.ir/admin/dashboard','3763hMEupygSDzaXXL02A6FAdtnHk88RWyx2WpqA',1,NULL,'desktop','Firefox','2026-06-26 05:45:44'),(431,'/',NULL,NULL,'jpAgUHRBvnp5twbVf9RPNKwMiYIUyCFM2yr3PrCI',2,NULL,'desktop','Chrome','2026-06-26 05:56:29'),(432,'/',NULL,'https://safhenokhost.ir/admin/dashboard','3763hMEupygSDzaXXL02A6FAdtnHk88RWyx2WpqA',1,NULL,'desktop','Firefox','2026-06-26 09:18:12'),(433,'login',NULL,'https://safhenokhost.ir/admin/dashboard','3763hMEupygSDzaXXL02A6FAdtnHk88RWyx2WpqA',1,NULL,'desktop','Firefox','2026-06-26 09:18:30'),(434,'login',NULL,NULL,'Pwre6IQAVasWE199VMP93figxLjyz2Q9GOI5amxc',NULL,NULL,'desktop','Chrome','2026-06-26 09:18:32'),(435,'/',NULL,NULL,'WwNXgnm0MnmPVajTwR9ilNz1a3yHRpqZtbA7zuat',NULL,NULL,'desktop','Other','2026-06-26 09:19:27'),(436,'account',NULL,'https://safhenokhost.ir/login','0v9hafAdnuc8IuOktU44VtpLLqk7beiD74BVQgco',2,NULL,'desktop','Chrome','2026-06-26 09:21:17'),(437,'login',NULL,'https://safhenokhost.ir/account','0v9hafAdnuc8IuOktU44VtpLLqk7beiD74BVQgco',2,NULL,'desktop','Chrome','2026-06-26 09:21:23'),(438,'login',NULL,'https://safhenokhost.ir/admin/settings','3763hMEupygSDzaXXL02A6FAdtnHk88RWyx2WpqA',1,NULL,'desktop','Firefox','2026-06-26 09:48:46'),(439,'account/orders',NULL,'https://safhenokhost.ir/account','0v9hafAdnuc8IuOktU44VtpLLqk7beiD74BVQgco',2,NULL,'desktop','Chrome','2026-06-26 09:51:55'),(440,'login',NULL,'https://safhenokhost.ir/account/orders','0v9hafAdnuc8IuOktU44VtpLLqk7beiD74BVQgco',2,NULL,'desktop','Chrome','2026-06-26 09:51:57'),(441,'account/installments',NULL,'https://safhenokhost.ir/account','0v9hafAdnuc8IuOktU44VtpLLqk7beiD74BVQgco',2,NULL,'desktop','Chrome','2026-06-26 09:52:01'),(442,'/',NULL,'https://safhenokhost.ir/account','0v9hafAdnuc8IuOktU44VtpLLqk7beiD74BVQgco',2,NULL,'desktop','Chrome','2026-06-26 09:52:08'),(443,'/',NULL,NULL,'3763hMEupygSDzaXXL02A6FAdtnHk88RWyx2WpqA',1,NULL,'desktop','Firefox','2026-06-26 09:52:44'),(444,'blog/sayt-hmh-karh',NULL,'https://safhenokhost.ir/','3763hMEupygSDzaXXL02A6FAdtnHk88RWyx2WpqA',1,NULL,'desktop','Firefox','2026-06-26 09:52:50'),(445,'/',NULL,NULL,'FnFfdVdWwvVEiBxoMd4T7wJsP7ghXFyqRsCUTMmX',NULL,NULL,'mobile','Chrome','2026-06-26 11:24:50'),(446,'/',NULL,NULL,'uU6I9OjA1W5Cp26E5OWJE2g9V357nCo7H9ZTP5Iw',NULL,NULL,'desktop','Other','2026-06-26 13:01:24'),(447,'/',NULL,NULL,'FnFfdVdWwvVEiBxoMd4T7wJsP7ghXFyqRsCUTMmX',NULL,NULL,'mobile','Chrome','2026-06-26 13:17:16'),(448,'/',NULL,NULL,'HjTBI1cNDZ28WXn7EmnOb1rqugDZZ71W6r9xauUJ',NULL,NULL,'desktop','Other','2026-06-26 13:31:55'),(449,'/',NULL,NULL,'IeLCibGLR6nr8ZwcsrqGLl3NPCSARAdYbQP2c4t5',NULL,NULL,'desktop','Other','2026-06-26 13:52:46'),(450,'login',NULL,'https://safhenokhost.ir/admin/theme-design','hUGZC6GQr4YjGLbSlwlRv0o5RElBehRvA6ywFnWo',NULL,NULL,'desktop','Firefox','2026-06-26 14:29:32'),(451,'login',NULL,'https://safhenokhost.ir/admin/theme-design','cd4GaF7Cf4DFIb4AcrPaU8xw0aNyqDqVbetFF3d4',1,NULL,'desktop','Firefox','2026-06-26 14:29:50'),(452,'/',NULL,NULL,'cd4GaF7Cf4DFIb4AcrPaU8xw0aNyqDqVbetFF3d4',1,NULL,'desktop','Firefox','2026-06-26 14:30:25'),(453,'login',NULL,'https://safhenokhost.ir/admin/theme-design','cd4GaF7Cf4DFIb4AcrPaU8xw0aNyqDqVbetFF3d4',1,NULL,'desktop','Firefox','2026-06-26 15:08:21'),(454,'/',NULL,NULL,'cd4GaF7Cf4DFIb4AcrPaU8xw0aNyqDqVbetFF3d4',1,NULL,'desktop','Firefox','2026-06-26 15:35:22'),(455,'/',NULL,NULL,'3eug0sEjkII9qmcDPviAdIBxhpQpEn6tC1GHix95',NULL,NULL,'desktop','Other','2026-06-26 15:53:29'),(456,'/',NULL,NULL,'FDkbTkORg5R77Vl3pRIHKl8ld21lZk7uOiyl7fx3',NULL,NULL,'desktop','Firefox','2026-06-26 15:55:58'),(457,'/',NULL,NULL,'yNtqKlpn6Urf4pAaneSJ3F7E6Z3F34J6lYgaXfkk',NULL,NULL,'desktop','Chrome','2026-06-26 15:56:00'),(458,'/',NULL,NULL,'5G1bPkxx5I8E5fr2oaCIdqjEWVMaYJ7sUiZ3Eq1b',NULL,NULL,'desktop','Other','2026-06-26 16:44:15'),(459,'/',NULL,NULL,'VXNhPJG9ks53Ipl1iYPqIFNsGw9ccR17zNHGAKW9',NULL,NULL,'desktop','Other','2026-06-26 16:44:15'),(460,'/',NULL,NULL,'JGGdqnulLcTZofJvJ9WiKFiAOHTuVYTBwKTlFt37',NULL,NULL,'desktop','Other','2026-06-26 16:44:16'),(461,'/',NULL,NULL,'CvkaJzux0IV1KY88THC4Gmj5ge2jrxio0M6FbaA1',NULL,NULL,'desktop','Other','2026-06-26 16:44:21'),(462,'/',NULL,NULL,'CBrXoB8WnkHCgl1HUJj98OiuySuhSQZ8GlX4MpNv',NULL,NULL,'desktop','Other','2026-06-26 16:44:26'),(463,'/',NULL,NULL,'OoQGX2DSJaZM9FeD3hJvI9JvYxlpXZ1UbszdHNN8',NULL,NULL,'desktop','Firefox','2026-06-26 16:44:33'),(464,'/',NULL,NULL,'amCq9UjvnmfXtKHocxkZToRY70AXlAngpzFu5C4Q',NULL,NULL,'desktop','Firefox','2026-06-26 16:44:43'),(465,'/',NULL,NULL,'mbpo42NayyNrJ8dKB5F8yeVZmVzfq0yzBqCLU8PM',NULL,NULL,'desktop','Firefox','2026-06-26 16:44:55'),(466,'contact',NULL,NULL,'VO1IFi8W8gvHhbW5VLLLHiv1djYa5q28DYE1HrM3',NULL,NULL,'desktop','Firefox','2026-06-26 16:44:55'),(467,'blog',NULL,NULL,'SXBUwxJQHJ5roq8j8Zwfno5XdUFtcOhJz4kLyVT7',NULL,NULL,'desktop','Firefox','2026-06-26 16:44:56'),(468,'blog/sayt-hmh-karh',NULL,NULL,'MqE5Mq3dNjvt6mxR1TC2ATNI9Sr6I268xcjSgTiZ',NULL,NULL,'desktop','Firefox','2026-06-26 16:44:56'),(469,'shop',NULL,NULL,'Uk4MBOkk298dga7QB4pjt5BrDFuXYgneGQ9df3Td',NULL,NULL,'desktop','Firefox','2026-06-26 16:44:56'),(470,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'y9niUuJqe8dOeayTBeyBgD0ndIZBOUtqtNxMKvk3',NULL,NULL,'desktop','Firefox','2026-06-26 16:44:56'),(471,'contact',NULL,NULL,'Aqv5x3MFCuztJxkGFy0Zut0F0roHTpWvIZQuBzie',NULL,NULL,'desktop','Firefox','2026-06-26 16:44:59'),(472,'blog/sayt-hmh-karh',NULL,NULL,'lViZMAb8ffQnvG90jou1ls0VWkZqOuPWQxjt7us0',NULL,NULL,'desktop','Firefox','2026-06-26 16:44:59'),(473,'blog',NULL,NULL,'IhV9VNmAx7gO8S6PJDLNG0quIZblmUjdqwQYpqXi',NULL,NULL,'desktop','Firefox','2026-06-26 16:45:01'),(474,'blog',NULL,NULL,'TXgwtmt96nGxyoTcWhlC4J7iVbleZbDyw7C1iZRw',NULL,NULL,'desktop','Firefox','2026-06-26 16:45:01'),(475,'blog',NULL,NULL,'hEVODtGnmDnS5KXiqztQjcRsF0GT1sWnG7ODjLYT',NULL,NULL,'desktop','Firefox','2026-06-26 16:45:01'),(476,'blog',NULL,NULL,'HlaZh6bmdq0Y0wKgrjjuizrA0KMtkFklcqesUboY',NULL,NULL,'desktop','Firefox','2026-06-26 16:45:01'),(477,'blog',NULL,NULL,'5aCjrn1ga8mzMeyKWRZVHWhuuczCAK0DlfZNoPjr',NULL,NULL,'desktop','Firefox','2026-06-26 16:45:03'),(478,'blog',NULL,NULL,'qk7mHTRmxd1ApMAwR8CCBhAt6inXLIkYwwFks3dO',NULL,NULL,'desktop','Firefox','2026-06-26 16:45:03'),(479,'blog',NULL,NULL,'6GuGAISJ3l9zpGwtDFViykp0YgslAlyPN1QCnI7T',NULL,NULL,'desktop','Firefox','2026-06-26 16:45:04'),(480,'blog',NULL,NULL,'OxpOWXZ0UpNSwpryN04B0pdnNxNJy7iDPbnNkFoJ',NULL,NULL,'desktop','Firefox','2026-06-26 16:45:04'),(481,'blog',NULL,NULL,'l9JPUiK7djUuhxtQIIl2UPgFsPN5mwaTFmoGnxN1',NULL,NULL,'desktop','Firefox','2026-06-26 16:45:04'),(482,'blog',NULL,NULL,'koO2dKvIydzXGv33RbKAsGiVOMpL52SsWTJFjRvm',NULL,NULL,'desktop','Firefox','2026-06-26 16:45:05'),(483,'blog',NULL,NULL,'zz2mrMs2y6Ve5gcvP5ZqcRcApXbsQMmnu9l5DqCX',NULL,NULL,'desktop','Firefox','2026-06-26 16:45:06'),(484,'blog',NULL,NULL,'rdTn6I55nTNPF0XNB1uHic4LmXRn7YJSDHHzznnp',NULL,NULL,'desktop','Firefox','2026-06-26 16:45:06'),(485,'blog',NULL,NULL,'tOFo8bWY5G9c5JhgCVpElcDYnq2BlknlXO2n3IQH',NULL,NULL,'desktop','Firefox','2026-06-26 16:45:06'),(486,'blog',NULL,NULL,'FEecWb70b9bZAavSGICO298QVAPvspVzZc4grNia',NULL,NULL,'desktop','Firefox','2026-06-26 16:45:15'),(487,'blog',NULL,NULL,'PROQDPU8tP7DU4TDWtsYV21MB2TgEl3jYzcbbYgp',NULL,NULL,'desktop','Firefox','2026-06-26 16:45:16'),(488,'blog',NULL,NULL,'llQZe7IYNS6X3MSN04iGtCRbkSOhWHhNNU3pC3Hj',NULL,NULL,'desktop','Firefox','2026-06-26 16:45:16'),(489,'blog',NULL,NULL,'dZntUSL6dCDLQHdR5GaQeHDOBDgkrAdZmwq4N4zK',NULL,NULL,'desktop','Firefox','2026-06-26 16:45:18'),(490,'blog',NULL,NULL,'ZdJTm8rpPRHjFy1zuqFaVxFWgpJ1XINwH9A5Vbpu',NULL,NULL,'desktop','Firefox','2026-06-26 16:45:18'),(491,'blog',NULL,NULL,'4bAqRwDbBb4HrzUtwVy9IwrcZ025qX7kwTkVBEH3',NULL,NULL,'desktop','Firefox','2026-06-26 16:45:18'),(492,'blog',NULL,NULL,'JuxvKf4wQ8qTMn7VyhaJli2mZxjMrnGmdb4kUScP',NULL,NULL,'desktop','Firefox','2026-06-26 16:45:26'),(493,'blog',NULL,NULL,'RjenYJ6YX1ebN2bXAuwPB1AMoQtl560TTA7tV8UX',NULL,NULL,'desktop','Firefox','2026-06-26 16:45:30'),(494,'blog',NULL,NULL,'TWgTtBEccJpryyoamMyQZw4bjcZmqSmYjVg2v6mG',NULL,NULL,'desktop','Firefox','2026-06-26 16:45:30'),(495,'blog',NULL,NULL,'mHEP8OPbz7BYV1NrmPMDSIEB9gLpH2aRTb62aDqZ',NULL,NULL,'desktop','Firefox','2026-06-26 16:45:30'),(496,'blog',NULL,NULL,'gPzQ6EGR4oMhdfGu5LIJsR50j0b4w5XQgy4oDd5p',NULL,NULL,'desktop','Firefox','2026-06-26 16:45:39'),(497,'blog',NULL,NULL,'9TQLaG2otlAggGcHV6lPSWmsyZ4qbHryGzOttoTK',NULL,NULL,'desktop','Firefox','2026-06-26 16:45:39'),(498,'/',NULL,NULL,'bVCbNFtKqa03JdFZs00U5kYIXJP4iR9CsCNvYcrR',NULL,NULL,'mobile','Chrome','2026-06-26 17:21:06'),(499,'login',NULL,NULL,'bVCbNFtKqa03JdFZs00U5kYIXJP4iR9CsCNvYcrR',NULL,NULL,'mobile','Chrome','2026-06-26 17:21:06'),(500,'login',NULL,'https://safhenokhost.ir/login','cwgWftaC6uKLfdWoppGwMpvbzyT9Mie5Eie4xvA4',NULL,NULL,'desktop','Chrome','2026-06-26 19:13:27'),(501,'account',NULL,'https://safhenokhost.ir/login','x42KEcRUl8rPcfmYuV6sEMnHnSn90VwmxjyvkJCH',2,NULL,'desktop','Chrome','2026-06-26 19:13:40'),(502,'login',NULL,'https://safhenokhost.ir/admin/theme-design','prij31jPB5e3dTE7uZX95sxds7uviuMrWcVOxtoQ',NULL,NULL,'desktop','Firefox','2026-06-26 19:14:01'),(503,'/',NULL,NULL,'G1Aj81hKfYhFeY1pUf0VFLZh8l1eGBijV74HeZd4',1,NULL,'desktop','Firefox','2026-06-26 19:25:30'),(504,'login',NULL,'https://safhenokhost.ir/admin/inventory','G1Aj81hKfYhFeY1pUf0VFLZh8l1eGBijV74HeZd4',1,NULL,'desktop','Firefox','2026-06-26 19:52:22'),(505,'login',NULL,NULL,'fJOAylOlHvIM1xga0z1b6ragVoGgPM0pUAqn9Nhj',NULL,NULL,'desktop','Firefox','2026-06-26 19:55:49'),(506,'/',NULL,'https://safhenokhost.ir/admin/dashboard','G1Aj81hKfYhFeY1pUf0VFLZh8l1eGBijV74HeZd4',1,NULL,'desktop','Firefox','2026-06-26 19:56:11'),(507,'login',NULL,'https://safhenokhost.ir/admin/settings','G1Aj81hKfYhFeY1pUf0VFLZh8l1eGBijV74HeZd4',1,NULL,'desktop','Firefox','2026-06-26 20:23:56'),(508,'/',NULL,'https://safhenokhost.ir/admin/dashboard','G1Aj81hKfYhFeY1pUf0VFLZh8l1eGBijV74HeZd4',1,NULL,'desktop','Firefox','2026-06-26 20:29:50'),(509,'blog',NULL,'https://safhenokhost.ir/','G1Aj81hKfYhFeY1pUf0VFLZh8l1eGBijV74HeZd4',1,NULL,'desktop','Firefox','2026-06-26 20:30:38'),(510,'login',NULL,NULL,'9NRcbZk8aE6KWBrAqpOsmAvZNZI9LZLp7mGyDiq7',NULL,NULL,'mobile','Chrome','2026-06-26 21:12:51'),(511,'login',NULL,'https://safhenokhost.ir/admin/dashboard','SccQb5lkd5ZCbvP5V37XjWzSN7zcinsGtXparUKt',1,NULL,'mobile','Chrome','2026-06-26 21:13:18'),(512,'/',NULL,NULL,'3uQnxyTtQXOkkCpUZNBVu5Lkl8qvMkd1zfwevjZU',NULL,NULL,'desktop','Chrome','2026-06-27 02:41:09'),(513,'login',NULL,'https://safhenokhost.ir/admin/theme-design','gAprjir9YNaJn3UXByZzAA91CHazYY3kqN0uFriz',NULL,NULL,'desktop','Firefox','2026-06-27 04:02:00'),(514,'login',NULL,'https://safhenokhost.ir/admin/invoices','mh8Ykqq8Os3CWVqhHacveqZ6wrDGAgnytoGIZEne',1,NULL,'desktop','Firefox','2026-06-27 04:02:08'),(515,'/',NULL,'https://safhenokhost.ir/admin/dashboard','mh8Ykqq8Os3CWVqhHacveqZ6wrDGAgnytoGIZEne',1,NULL,'desktop','Firefox','2026-06-27 04:03:09'),(516,'login',NULL,'https://safhenokhost.ir/admin/inventory/warehouses','mh8Ykqq8Os3CWVqhHacveqZ6wrDGAgnytoGIZEne',1,NULL,'desktop','Firefox','2026-06-27 04:37:56'),(517,'/',NULL,'https://safhenokhost.ir/admin/dashboard','mh8Ykqq8Os3CWVqhHacveqZ6wrDGAgnytoGIZEne',1,NULL,'desktop','Firefox','2026-06-27 04:45:31'),(518,'login',NULL,'https://safhenokhost.ir/admin/theme-design','mh8Ykqq8Os3CWVqhHacveqZ6wrDGAgnytoGIZEne',1,NULL,'desktop','Firefox','2026-06-27 05:15:12'),(519,'blog',NULL,'https://safhenokhost.ir/','mh8Ykqq8Os3CWVqhHacveqZ6wrDGAgnytoGIZEne',1,NULL,'desktop','Firefox','2026-06-27 05:15:29'),(520,'/',NULL,'https://safhenokhost.ir/admin/dashboard','mh8Ykqq8Os3CWVqhHacveqZ6wrDGAgnytoGIZEne',1,NULL,'desktop','Firefox','2026-06-27 05:30:22'),(521,'blog/sayt-hmh-karh',NULL,'https://safhenokhost.ir/','mh8Ykqq8Os3CWVqhHacveqZ6wrDGAgnytoGIZEne',1,NULL,'desktop','Firefox','2026-06-27 05:30:30'),(522,'login',NULL,'https://safhenokhost.ir/admin/theme-design','mh8Ykqq8Os3CWVqhHacveqZ6wrDGAgnytoGIZEne',1,NULL,'desktop','Firefox','2026-06-27 05:33:39'),(523,'contact',NULL,'https://safhenokhost.ir/','mh8Ykqq8Os3CWVqhHacveqZ6wrDGAgnytoGIZEne',1,NULL,'desktop','Firefox','2026-06-27 05:33:49'),(524,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,'https://safhenokhost.ir/','mh8Ykqq8Os3CWVqhHacveqZ6wrDGAgnytoGIZEne',1,NULL,'desktop','Firefox','2026-06-27 05:38:59'),(525,'/',NULL,NULL,'2niI2vvakwuhwg519x6G5z4RyjHoTnYL790K9WJL',NULL,NULL,'mobile','Chrome','2026-06-27 07:10:47'),(526,'blog',NULL,'https://safhenokhost.ir/','2niI2vvakwuhwg519x6G5z4RyjHoTnYL790K9WJL',NULL,NULL,'mobile','Chrome','2026-06-27 07:10:59'),(527,'/',NULL,'http://safhenokhost.ir/','ZBCYNcoXHzM0IjNX7pS4dvZDYuzsQq6lYpdqf5mg',NULL,NULL,'desktop','Chrome','2026-06-27 07:23:55'),(528,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'gvytJXjErDCiI49uFe6cVgILzjwjx6hMAQBQLqeC',NULL,NULL,'desktop','Chrome','2026-06-27 07:23:56'),(529,'blog/sayt-hmh-karh',NULL,NULL,'kSK3X3cJUJI9nunOCJJVCTDs7PdizjLx33RemxVK',NULL,NULL,'desktop','Chrome','2026-06-27 07:23:56'),(530,'blog',NULL,NULL,'KlBKCbwQg8IZzdQTBQDqTVLnh9AhFBe0vNGakVah',NULL,NULL,'desktop','Chrome','2026-06-27 07:23:57'),(531,'/',NULL,NULL,'bp53VwuL7VGGRqzY4gBloYkImOQDic3t3PTIuqVg',NULL,NULL,'desktop','Firefox','2026-06-27 08:59:49'),(532,'/',NULL,NULL,'zfAu3Gev03wb9XsQ1Z4qNr3JmRjvmZN76MV9Gd1V',NULL,NULL,'mobile','Chrome','2026-06-27 09:20:31'),(533,'login',NULL,NULL,'zfAu3Gev03wb9XsQ1Z4qNr3JmRjvmZN76MV9Gd1V',NULL,NULL,'mobile','Chrome','2026-06-27 09:20:36'),(534,'login',NULL,'https://safhenokhost.ir/admin/dashboard','mVBUB0tzfYQc8EfzuOjnXsVsNgRa6tNGjZPmJPgA',1,NULL,'mobile','Chrome','2026-06-27 09:20:46'),(535,'login',NULL,'https://safhenokhost.ir/admin/theme-design','KKE57tr0Gela8T05TuvHqT9upecJPFVlfh7GXYMW',NULL,NULL,'desktop','Firefox','2026-06-27 10:58:32'),(536,'login',NULL,'https://safhenokhost.ir/admin/theme-design','ARJexLkyojyfHqCeTphO1Fl379zaKRRTtmaoGE4p',1,NULL,'desktop','Firefox','2026-06-27 10:59:08'),(537,'/',NULL,NULL,'tC2QionU2JQqVMBsOVPxlUMuv6FSHKGHdoypkpTT',NULL,NULL,'desktop','Chrome','2026-06-27 11:06:33'),(538,'login',NULL,NULL,'tC2QionU2JQqVMBsOVPxlUMuv6FSHKGHdoypkpTT',NULL,NULL,'desktop','Chrome','2026-06-27 11:06:39'),(539,'login',NULL,'https://safhenokhost.ir/admin/dashboard','SGYciVnieohSsdFonTKM2EN5U1ApogUjdZ3Av1ko',1,NULL,'desktop','Chrome','2026-06-27 11:07:05'),(540,'/',NULL,'https://safhenokhost.ir/admin/settings','FRtUAMWHVWKTMs24inHW4OUJRG0DtTblbdLtY8QJ',NULL,NULL,'desktop','Chrome','2026-06-27 11:07:28'),(541,'login',NULL,NULL,'FRtUAMWHVWKTMs24inHW4OUJRG0DtTblbdLtY8QJ',NULL,NULL,'desktop','Chrome','2026-06-27 11:07:33'),(542,'account',NULL,'https://safhenokhost.ir/login','frp0QqXj1u7oEtgdSWkFbl5H2cWdO7wfY9QhJi3O',2,NULL,'desktop','Chrome','2026-06-27 11:07:43'),(543,'login',NULL,'https://safhenokhost.ir/account','frp0QqXj1u7oEtgdSWkFbl5H2cWdO7wfY9QhJi3O',2,NULL,'desktop','Chrome','2026-06-27 11:07:45'),(544,'/',NULL,'https://safhenokhost.ir/account','LblJS5pM7ZbvLEYrsm6yHiEOuMugrgQHNK1Py04s',NULL,NULL,'desktop','Chrome','2026-06-27 11:07:46'),(545,'login',NULL,NULL,'LblJS5pM7ZbvLEYrsm6yHiEOuMugrgQHNK1Py04s',NULL,NULL,'desktop','Chrome','2026-06-27 11:07:52'),(546,'account',NULL,'https://safhenokhost.ir/login','psQgfyEfeYm7V4Sg4tL6qD4NE5g2HEGS9yfvG5uJ',2,NULL,'desktop','Chrome','2026-06-27 11:08:00'),(547,'login',NULL,'https://safhenokhost.ir/account','psQgfyEfeYm7V4Sg4tL6qD4NE5g2HEGS9yfvG5uJ',2,NULL,'desktop','Chrome','2026-06-27 11:08:02'),(548,'/',NULL,NULL,'ARJexLkyojyfHqCeTphO1Fl379zaKRRTtmaoGE4p',1,NULL,'desktop','Firefox','2026-06-27 11:09:42'),(549,'blog',NULL,'https://safhenokhost.ir/','ARJexLkyojyfHqCeTphO1Fl379zaKRRTtmaoGE4p',1,NULL,'desktop','Firefox','2026-06-27 11:09:48'),(550,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,'https://safhenokhost.ir/blog','ARJexLkyojyfHqCeTphO1Fl379zaKRRTtmaoGE4p',1,NULL,'desktop','Firefox','2026-06-27 11:09:54'),(551,'login',NULL,'https://safhenokhost.ir/admin/settings','ARJexLkyojyfHqCeTphO1Fl379zaKRRTtmaoGE4p',1,NULL,'desktop','Firefox','2026-06-27 11:49:04'),(552,'/',NULL,NULL,'ARJexLkyojyfHqCeTphO1Fl379zaKRRTtmaoGE4p',1,NULL,'desktop','Firefox','2026-06-27 12:08:12'),(553,'login',NULL,'https://safhenokhost.ir/admin/settings','ARJexLkyojyfHqCeTphO1Fl379zaKRRTtmaoGE4p',1,NULL,'desktop','Firefox','2026-06-27 12:27:31'),(554,'/',NULL,'https://safhenokhost.ir/admin/settings','PRUKc3ngcrvkq64EClJo2iyYNZtv0hz11ZdC9BB6',NULL,NULL,'desktop','Firefox','2026-06-27 12:30:04'),(555,'login',NULL,NULL,'PRUKc3ngcrvkq64EClJo2iyYNZtv0hz11ZdC9BB6',NULL,NULL,'desktop','Firefox','2026-06-27 12:30:13'),(556,'login',NULL,'https://safhenokhost.ir/admin/dashboard','SOD4tqRd0EmjohOWsqe0HLI6ybjHGvGlav4GK5DK',1,NULL,'desktop','Firefox','2026-06-27 12:30:24'),(557,'account',NULL,'https://safhenokhost.ir/login','psQgfyEfeYm7V4Sg4tL6qD4NE5g2HEGS9yfvG5uJ',2,NULL,'desktop','Chrome','2026-06-27 12:31:42'),(558,'login',NULL,'https://safhenokhost.ir/account','psQgfyEfeYm7V4Sg4tL6qD4NE5g2HEGS9yfvG5uJ',2,NULL,'desktop','Chrome','2026-06-27 12:31:44'),(559,'account/subscriptions',NULL,'https://safhenokhost.ir/account','psQgfyEfeYm7V4Sg4tL6qD4NE5g2HEGS9yfvG5uJ',2,NULL,'desktop','Chrome','2026-06-27 12:31:51'),(560,'account/subscriptions/plans',NULL,'https://safhenokhost.ir/account/subscriptions','psQgfyEfeYm7V4Sg4tL6qD4NE5g2HEGS9yfvG5uJ',2,NULL,'desktop','Chrome','2026-06-27 12:31:53'),(561,'account/orders',NULL,'https://safhenokhost.ir/account/subscriptions/plans','psQgfyEfeYm7V4Sg4tL6qD4NE5g2HEGS9yfvG5uJ',2,NULL,'desktop','Chrome','2026-06-27 12:31:55'),(562,'shop',NULL,'https://safhenokhost.ir/account/orders','psQgfyEfeYm7V4Sg4tL6qD4NE5g2HEGS9yfvG5uJ',2,NULL,'desktop','Chrome','2026-06-27 12:31:57'),(563,'account/tickets',NULL,'https://safhenokhost.ir/account','psQgfyEfeYm7V4Sg4tL6qD4NE5g2HEGS9yfvG5uJ',2,NULL,'desktop','Chrome','2026-06-27 12:32:07'),(564,'account/tickets/1',NULL,'https://safhenokhost.ir/account/tickets','psQgfyEfeYm7V4Sg4tL6qD4NE5g2HEGS9yfvG5uJ',2,NULL,'desktop','Chrome','2026-06-27 12:32:12'),(565,'account/security',NULL,'https://safhenokhost.ir/account/tickets/1','psQgfyEfeYm7V4Sg4tL6qD4NE5g2HEGS9yfvG5uJ',2,NULL,'desktop','Chrome','2026-06-27 12:32:37'),(566,'account/profile',NULL,'https://safhenokhost.ir/account/subscriptions','psQgfyEfeYm7V4Sg4tL6qD4NE5g2HEGS9yfvG5uJ',2,NULL,'desktop','Chrome','2026-06-27 12:32:43'),(567,'account/resources',NULL,'https://safhenokhost.ir/admin/dashboard','SOD4tqRd0EmjohOWsqe0HLI6ybjHGvGlav4GK5DK',1,NULL,'desktop','Firefox','2026-06-27 13:28:12'),(568,'login',NULL,'https://safhenokhost.ir/account/resources','SOD4tqRd0EmjohOWsqe0HLI6ybjHGvGlav4GK5DK',1,NULL,'desktop','Firefox','2026-06-27 13:28:13'),(569,'/',NULL,'https://www.google.com','S3qSzsLWy5BeOEKqoZMBVHrY3R9LTTKJIdneoZwK',NULL,NULL,'desktop','Edge','2026-06-27 15:02:45'),(570,'/',NULL,NULL,'HtggJGFUW35ramyohy1EZtM2lk5Mu7G7CtD6uVZf',NULL,NULL,'desktop','Chrome','2026-06-27 15:11:03'),(571,'login',NULL,'https://safhenokhost.ir/admin/dashboard','SOD4tqRd0EmjohOWsqe0HLI6ybjHGvGlav4GK5DK',1,NULL,'desktop','Firefox','2026-06-27 15:41:26'),(572,'/',NULL,NULL,'SOD4tqRd0EmjohOWsqe0HLI6ybjHGvGlav4GK5DK',1,NULL,'desktop','Firefox','2026-06-27 15:41:34'),(573,'shop',NULL,'https://safhenokhost.ir/','SOD4tqRd0EmjohOWsqe0HLI6ybjHGvGlav4GK5DK',1,NULL,'desktop','Firefox','2026-06-27 15:41:53'),(574,'contact',NULL,'https://safhenokhost.ir/','SOD4tqRd0EmjohOWsqe0HLI6ybjHGvGlav4GK5DK',1,NULL,'desktop','Firefox','2026-06-27 15:41:56'),(575,'/',NULL,NULL,'CxiFmQk9NzwtCsZAWQ324Y5tUpSA76BYXmYGPhvz',NULL,NULL,'mobile','Chrome','2026-06-27 20:31:40'),(576,'shop',NULL,'https://safhenokhost.ir/','CxiFmQk9NzwtCsZAWQ324Y5tUpSA76BYXmYGPhvz',NULL,NULL,'mobile','Chrome','2026-06-27 20:42:55'),(577,'blog/sayt-hmh-karh',NULL,'https://safhenokhost.ir/','CxiFmQk9NzwtCsZAWQ324Y5tUpSA76BYXmYGPhvz',NULL,NULL,'mobile','Chrome','2026-06-27 20:43:06'),(578,'blog',NULL,'https://safhenokhost.ir/blog/sayt-hmh-karh','CxiFmQk9NzwtCsZAWQ324Y5tUpSA76BYXmYGPhvz',NULL,NULL,'mobile','Chrome','2026-06-27 20:43:10'),(579,'/',NULL,NULL,'HUJlRhrd8gFuhThPewnGWPAH6tKV5cYEtIqAdCnU',NULL,NULL,'desktop','Other','2026-06-27 21:49:31'),(580,'/',NULL,NULL,'7lJ8jZTNQLsAEWsSYPBPR0QuUCFqy12ZIJnQZ2wP',NULL,NULL,'desktop','Chrome','2026-06-27 23:18:26'),(581,'contact',NULL,NULL,'GR3fWwnagFBjQCCW0xdpVz87pVh83VMz6grXTxuw',NULL,NULL,'desktop','Chrome','2026-06-27 23:18:26'),(582,'/',NULL,NULL,'jSYJmLchTgAz8g5BxRmXUbAGGVxCcfc3MD9J8ZiN',NULL,NULL,'desktop','Chrome','2026-06-28 05:28:53'),(583,'login',NULL,'https://safhenokhost.ir/admin/subscriptions/create','RXq4yIvlPAOOtZ0IKhxzlSXNiLCx2PLl5prSu7fY',NULL,NULL,'desktop','Firefox','2026-06-28 05:55:41'),(584,'login',NULL,'https://safhenokhost.ir/admin/dashboard','JxHHDREo1ZcH90wU16t9GazLhr1ahC0azKFyR5Ke',1,NULL,'desktop','Firefox','2026-06-28 05:55:53'),(585,'/',NULL,NULL,'f7NxrcisadfiFLJ42VpVDrkS32lu1qjdalIe49ya',NULL,NULL,'desktop','Other','2026-06-28 10:16:07'),(586,'/',NULL,'http://safhenokhost.ir/','KBUvGkSFxRXLOTfdG2GvjwJ2LWLFawI9nGsu2kWQ',NULL,NULL,'desktop','Chrome','2026-06-28 10:16:12'),(587,'/',NULL,'https://www.google.com/','s4L5qsHvxHy2jHNQuXI02VZryXRryd0sZIlL2siJ',NULL,NULL,'mobile','Chrome','2026-06-28 12:57:32'),(588,'login',NULL,'https://safhenokhost.ir/','s4L5qsHvxHy2jHNQuXI02VZryXRryd0sZIlL2siJ',NULL,NULL,'mobile','Chrome','2026-06-28 12:57:48'),(589,'blog',NULL,'https://safhenokhost.ir/','s4L5qsHvxHy2jHNQuXI02VZryXRryd0sZIlL2siJ',NULL,NULL,'mobile','Chrome','2026-06-28 12:57:59'),(590,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,'https://safhenokhost.ir/blog','s4L5qsHvxHy2jHNQuXI02VZryXRryd0sZIlL2siJ',NULL,NULL,'mobile','Chrome','2026-06-28 12:58:06'),(591,'blog/sayt-hmh-karh',NULL,'https://safhenokhost.ir/blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd','s4L5qsHvxHy2jHNQuXI02VZryXRryd0sZIlL2siJ',NULL,NULL,'mobile','Chrome','2026-06-28 12:58:15'),(592,'/',NULL,NULL,'cy5EaahVgCV4EJydBCZ9wJ6u3myLxRbCGitIkx5W',NULL,NULL,'mobile','Chrome','2026-06-28 12:59:35'),(593,'contact',NULL,'https://tenent.safhenokhost.ir/','cy5EaahVgCV4EJydBCZ9wJ6u3myLxRbCGitIkx5W',NULL,NULL,'mobile','Chrome','2026-06-28 12:59:43'),(594,'login',NULL,'https://safhenokhost.ir/admin/dashboard','Afc1vYs0omhMyZskDXvVQgY9XjGkOJdurTvOH9if',1,NULL,'mobile','Chrome','2026-06-28 13:00:26'),(595,'/',NULL,'https://safhenokhost.ir/admin/dashboard','iS3kGqqtN0Sw7RUS92NGKbNrhCkKNwjnFPhbQiDo',NULL,NULL,'mobile','Chrome','2026-06-28 13:01:04'),(596,'login',NULL,'https://tenent.safhenokhost.ir/','cy5EaahVgCV4EJydBCZ9wJ6u3myLxRbCGitIkx5W',NULL,NULL,'mobile','Chrome','2026-06-28 13:01:26'),(597,'/',NULL,NULL,'KngZI7Sacji4jUHrxB5EYCj2GXuXr5e7IorY1Xip',NULL,NULL,'desktop','Chrome','2026-06-28 13:19:34'),(598,'login',NULL,'https://tenent.safhenokhost.ir/','KngZI7Sacji4jUHrxB5EYCj2GXuXr5e7IorY1Xip',NULL,NULL,'desktop','Chrome','2026-06-28 13:20:08'),(599,'login',NULL,'https://tenent.safhenokhost.ir/admin/license','SJA7264ijd64XqkzP0nefGUjsaFjkDKlLTjEEzUo',1,NULL,'desktop','Chrome','2026-06-28 13:20:37'),(600,'login',NULL,'https://safhenokhost.ir/login','3PeSR7Q7WiETr4Yb2gzODKkcquVnVkfEA8Qb3p3u',NULL,NULL,'desktop','Firefox','2026-06-28 13:23:25'),(601,'login',NULL,'https://safhenokhost.ir/admin/license','REv69pyYOcaqz4H2DuDQGWLBtpUxYvv3cbRuaHbw',1,NULL,'desktop','Firefox','2026-06-28 13:23:36'),(602,'/',NULL,'https://tenent.safhenokhost.ir/admin/license','Jfix1GttXPTYyY3Vf04dGzl9VitnNvilhs2UPBsC',NULL,NULL,'desktop','Chrome','2026-06-28 13:27:54'),(603,'login',NULL,'https://tenent.safhenokhost.ir/','Jfix1GttXPTYyY3Vf04dGzl9VitnNvilhs2UPBsC',NULL,NULL,'desktop','Chrome','2026-06-28 13:27:56'),(604,'account',NULL,'https://tenent.safhenokhost.ir/login','KjE5fuBsNzEUD1SBeMCZ6Vb7GVrwUDfNzSwVt3Hb',2,NULL,'desktop','Chrome','2026-06-28 13:28:13'),(605,'login',NULL,'https://tenent.safhenokhost.ir/account','KjE5fuBsNzEUD1SBeMCZ6Vb7GVrwUDfNzSwVt3Hb',2,NULL,'desktop','Chrome','2026-06-28 13:28:14'),(606,'/',NULL,'https://tenent.safhenokhost.ir/account','U1cKVKHzJkywGxYPXBwnMJqvIBM3FLH8efrWhu4x',NULL,NULL,'desktop','Chrome','2026-06-28 13:28:24'),(607,'login',NULL,'https://tenent.safhenokhost.ir/','U1cKVKHzJkywGxYPXBwnMJqvIBM3FLH8efrWhu4x',NULL,NULL,'desktop','Chrome','2026-06-28 13:29:47'),(608,'account',NULL,'https://tenent.safhenokhost.ir/login','sHT10a2OdA4LXE1okp7nTIiYQ03WVnru6HxTZa9U',2,NULL,'desktop','Chrome','2026-06-28 13:29:54'),(609,'login',NULL,'https://tenent.safhenokhost.ir/account','sHT10a2OdA4LXE1okp7nTIiYQ03WVnru6HxTZa9U',2,NULL,'desktop','Chrome','2026-06-28 13:29:54'),(610,'/',NULL,NULL,'l1BDB1oKSXu1mDGp7wfLScysKGJggwJYmFfMBpt0',NULL,NULL,'desktop','Chrome','2026-06-28 13:34:19'),(611,'account',NULL,'https://tenent.safhenokhost.ir/login','sHT10a2OdA4LXE1okp7nTIiYQ03WVnru6HxTZa9U',2,NULL,'desktop','Chrome','2026-06-28 14:28:59'),(612,'login',NULL,'https://tenent.safhenokhost.ir/account','sHT10a2OdA4LXE1okp7nTIiYQ03WVnru6HxTZa9U',2,NULL,'desktop','Chrome','2026-06-28 14:29:00'),(613,'/',NULL,NULL,'sIq9Fuje7dwgmvG5exqRwcIRBA0o1YZpTavFQ9TB',NULL,NULL,'mobile','Chrome','2026-06-28 15:53:50'),(614,'/',NULL,NULL,'9EPitb4I5j7g4x0pY7zlicbxzX8okd8x79lCFltB',NULL,NULL,'desktop','Other','2026-06-28 15:54:32'),(615,'/',NULL,NULL,'iz5yWz5E19cl0z6djYuOPVLNuj2t8EQ1FmEASCsY',NULL,NULL,'mobile','Chrome','2026-06-28 15:54:34'),(616,'account',NULL,'https://tenent.safhenokhost.ir/login','sHT10a2OdA4LXE1okp7nTIiYQ03WVnru6HxTZa9U',2,NULL,'desktop','Chrome','2026-06-28 16:30:44'),(617,'login',NULL,'https://tenent.safhenokhost.ir/account','sHT10a2OdA4LXE1okp7nTIiYQ03WVnru6HxTZa9U',2,NULL,'desktop','Chrome','2026-06-28 16:30:45'),(618,'/',NULL,NULL,'Q1TXeStnCjFeRjM10HXiSBg4efRJ1OFmtwt5RVTe',NULL,NULL,'desktop','Edge','2026-06-28 17:04:18'),(619,'blog/sayt-hmh-karh',NULL,NULL,'TP2eZuwSrwtgKpPGP4nX3sqQhEoqPvugLFZ1pB2H',NULL,NULL,'desktop','Chrome','2026-06-28 17:04:23'),(620,'blog',NULL,NULL,'3Ny3oHJByI1mTX5qFdZP71uAA3aZyRxIu5lR5WCl',NULL,NULL,'desktop','Chrome','2026-06-28 17:04:23'),(621,'contact',NULL,NULL,'tgDzSgRPmLvKMHhA6W9JN6FM9VCAtQLbqliwLwS1',NULL,NULL,'desktop','Edge','2026-06-28 17:04:23'),(622,'shop',NULL,NULL,'9whwSfU82BIXTEYvMBLGdffW4waGnq3E6g6o1SAl',NULL,NULL,'desktop','Firefox','2026-06-28 17:04:23'),(623,'login',NULL,NULL,'SvOikNwftc6AFtFsL7coFjyDKKffpohYpnUwskJg',NULL,NULL,'desktop','Chrome','2026-06-28 17:04:24'),(624,'shop/cart',NULL,NULL,'k3mvVOqrngfO3y3ZWuQWOMNBm5thquXJ1MC6CpbL',NULL,NULL,'desktop','Safari','2026-06-28 17:04:24'),(625,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'SJ37fQu65qhX9WAAyI9hzl53pweOTOENhtKMJOou',NULL,NULL,'desktop','Edge','2026-06-28 17:04:24'),(626,'/',NULL,'https://safhenokhost.ir/lang/en','mhWGPHHvhnjzBszovwdGt7HSuZ7bCahZcEiLFouE',NULL,NULL,'desktop','Firefox','2026-06-28 17:04:25'),(627,'/',NULL,'https://safhenokhost.ir/lang/fa','tOu0UcvqHdS2Ku7xBA6TrjTCbflYy19FitowHXkS',NULL,NULL,'desktop','Firefox','2026-06-28 17:04:25'),(628,'/',NULL,'https://safhenokhost.ir/lang/ar','90spcGRqHVvceCJrHVJP32qy8s9qtOL1pqK2Yivo',NULL,NULL,'desktop','Firefox','2026-06-28 17:04:25'),(629,'blog/series/syo',NULL,NULL,'GQDoCtTowzhM3oOfnK3xQmmRdT4OSOEWc0QXTXtM',NULL,NULL,'desktop','Chrome','2026-06-28 17:04:30'),(630,'blog',NULL,NULL,'Mu4vjxETbLDQoBXl5uR5mopYLm1U9u2r2qB93t5V',NULL,NULL,'desktop','Chrome','2026-06-28 17:04:30'),(631,'blog/category/mhtoa',NULL,NULL,'Jpi8DJgVFVAHr9RBe142EnuRxwBiZnkP31F8R1o4',NULL,NULL,'desktop','Safari','2026-06-28 17:04:30'),(632,'register',NULL,NULL,'7luVuF949Nkq6RtI4KG9JWhxkhtLEtDCUmLgY5Hs',NULL,NULL,'desktop','Chrome','2026-06-28 17:04:30'),(633,'blog',NULL,NULL,'Q3BgP9iz5shqcjtuRslbz2p4KELV8FdRH6GpEaEy',NULL,NULL,'desktop','Edge','2026-06-28 17:04:30'),(634,'blog',NULL,NULL,'fIvSSXOQcxtCkIhRcF7YioIqUyqxvvpium1ATJqv',NULL,NULL,'desktop','Edge','2026-06-28 17:04:30'),(635,'blog',NULL,NULL,'h0VIGKT0HMDd7n6kNPK1P6cSUwbWt5LmciFIKG6v',NULL,NULL,'desktop','Chrome','2026-06-28 17:04:30'),(636,'blog',NULL,NULL,'qgHoqY6nfkqG2bC9zW7800QFaHXi5fvcsFekMGb8',NULL,NULL,'desktop','Chrome','2026-06-28 17:04:31'),(637,'shop/wishlist',NULL,NULL,'JbAx9GMh43x40Kgm94y1s35ueSCs7pOTuTcNAPMB',NULL,NULL,'desktop','Chrome','2026-06-28 17:04:31'),(638,'blog',NULL,NULL,'CiCV2Wd4ZyD1UVaaXoC74cLhpUUealYGx2BCMYZA',NULL,NULL,'desktop','Chrome','2026-06-28 17:04:31'),(639,'blog',NULL,NULL,'2437wXSxZe67YSdW6KOLjzuyHLRo14m7jIVGm6Rp',NULL,NULL,'desktop','Chrome','2026-06-28 17:04:31'),(640,'shop/compare',NULL,NULL,'FDBu8QuSCQyACnoui82tOjNaRSMOTIJoJlOEACde',NULL,NULL,'desktop','Chrome','2026-06-28 17:04:31'),(641,'blog',NULL,NULL,'XafFkAaMgdg8qqF6VFab7biu6IX2fZQgDJTe8TAO',NULL,NULL,'desktop','Chrome','2026-06-28 17:04:31'),(642,'blog',NULL,NULL,'YuYiT2q7xaXeZJyBag03uNfCVysULTDCZjd9sKUg',NULL,NULL,'desktop','Safari','2026-06-28 17:04:31'),(643,'blog',NULL,NULL,'FLeUuOWfanDc9lJDMQZjRl5TJCNMPApHxagTJHYT',NULL,NULL,'desktop','Firefox','2026-06-28 17:04:31'),(644,'/',NULL,NULL,'92mwBI8E4ALWqKg7qBTUsgeoQScSylPq9r5hXHDC',NULL,NULL,'desktop','Firefox','2026-06-28 18:48:41'),(645,'contact',NULL,'https://tenent.safhenokhost.ir/','92mwBI8E4ALWqKg7qBTUsgeoQScSylPq9r5hXHDC',NULL,NULL,'desktop','Firefox','2026-06-28 18:53:42'),(646,'login',NULL,'https://tenent.safhenokhost.ir/','92mwBI8E4ALWqKg7qBTUsgeoQScSylPq9r5hXHDC',NULL,NULL,'desktop','Firefox','2026-06-28 18:53:45'),(647,'account',NULL,'https://tenent.safhenokhost.ir/login','TYRwhz250WqgEeBJpBKbC3fi50lJK8UCyZAVBpWH',2,NULL,'desktop','Firefox','2026-06-28 18:54:04'),(648,'/',NULL,'https://tenent.safhenokhost.ir/account','H4eNGFXGdatmnG30icLd7K32jEzU1GipzU1nh70J',NULL,NULL,'desktop','Firefox','2026-06-28 18:54:06'),(649,'login',NULL,'https://tenent.safhenokhost.ir/','H4eNGFXGdatmnG30icLd7K32jEzU1GipzU1nh70J',NULL,NULL,'desktop','Firefox','2026-06-28 18:54:09'),(650,'/',NULL,'https://tenent.safhenokhost.ir/admin/license','xx43xvEfHfRLedW3QZ4sOgQr2JFfMGipTRP8X8RA',NULL,NULL,'desktop','Firefox','2026-06-28 18:54:23'),(651,'/',NULL,NULL,'QIn9Lu2I09YRxr0MMUntBtszNUiCd3nn4QpXcAZI',NULL,NULL,'mobile','Chrome','2026-06-28 19:36:11'),(652,'/',NULL,NULL,'mlWwYxQ6gUNrH3Tpp9hKnh6rDPdPRtlijQrkHOcz',NULL,NULL,'mobile','Chrome','2026-06-28 20:35:36'),(653,'/',NULL,NULL,'mj2nOWRqg8H1tBHYMw5XuxeKzKQkO3rD0NKlCktm',NULL,NULL,'mobile','Chrome','2026-06-28 20:35:51'),(654,'login',NULL,'https://tenent.safhenokhost.ir/','mj2nOWRqg8H1tBHYMw5XuxeKzKQkO3rD0NKlCktm',NULL,NULL,'mobile','Chrome','2026-06-28 20:36:03'),(655,'/',NULL,NULL,'ZH10gETylP83wWBQEcmhbceHHoyEWRUVaOFUu8Ui',NULL,NULL,'desktop','Other','2026-06-28 21:36:33'),(656,'/',NULL,NULL,'6f1BXwwXSJxUizq5D7dGuqdUkT1Adu33p9xWbdQo',NULL,NULL,'desktop','Other','2026-06-28 21:36:34'),(657,'/',NULL,NULL,'kVKOWaBMn1g7HJ1jqOiy30eoXTedoJyllo1HEojt',NULL,NULL,'desktop','Other','2026-06-28 21:36:34'),(658,'/',NULL,NULL,'tNMApI3H2o4xZjNE6G73mCG2BxSpNesEyyEfeYx6',NULL,NULL,'desktop','Other','2026-06-28 21:36:34'),(659,'/',NULL,NULL,'nTy1nZVKZUqqm9AWXqOi8lWwv1acQ9NSCnVf0NqJ',NULL,NULL,'desktop','Other','2026-06-28 21:36:40'),(660,'/',NULL,NULL,'QvBEicdF774I8ddpgrWVxcYY78HUuLHTCXM7GSzT',NULL,NULL,'desktop','Other','2026-06-28 21:36:41'),(661,'/',NULL,NULL,'S2t5xPNvdzUQVboRMmaEor0Khf7r7TPPu7xrxkRb',NULL,NULL,'desktop','Other','2026-06-28 21:36:42'),(662,'/',NULL,NULL,'SNgqPaugzyjyUHCEzzI6acmgiCRp4JuhZx4SXVaD',NULL,NULL,'desktop','Other','2026-06-28 21:36:43'),(663,'/',NULL,NULL,'O4bIDbwjbk3wnkaOlo0GpHz08kPmTQpyPLPPe0hP',NULL,NULL,'desktop','Other','2026-06-28 21:37:03'),(664,'/',NULL,NULL,'XK4cQHesI2ktd2tueWvhAajVbZVhEGyaSMfnnTxE',NULL,NULL,'desktop','Other','2026-06-28 21:37:04'),(665,'/',NULL,NULL,'melLFJRauxCyNe4xWMqkhq0Vp4sUmr1poTbb6G84',NULL,NULL,'desktop','Other','2026-06-28 21:37:06'),(666,'/',NULL,NULL,'Vyhkeh5eczRmhb72fTb8Rosb8DQB2sgKNJ0Ywjon',NULL,NULL,'desktop','Other','2026-06-28 21:37:27'),(667,'/',NULL,NULL,'7kut2g9Eoa3hdSOLH3ErLSGVKo8tywk9XYzhf1hg',NULL,NULL,'desktop','Chrome','2026-06-28 21:39:48'),(668,'/',NULL,NULL,'6kKFrkexvZyPrxeRyZdqqetIHI8bg4wI7N0k8vFN',NULL,NULL,'mobile','Chrome','2026-06-29 01:24:37'),(669,'/',NULL,NULL,'v91wrTJkgIhZgQqJVfg9sDdXVYLGDJ2OEFOzREqx',NULL,NULL,'desktop','Chrome','2026-06-29 03:54:39'),(670,'/',NULL,NULL,'eeIE5OERjLGs4QfwApig4QhXxjeGh6ve5uSaY6NC',NULL,NULL,'mobile','Chrome','2026-06-29 04:37:48'),(671,'login',NULL,'https://safhenokhost.ir/admin/license','uHykYRsZFgnRBfi8rZ4HVZj5Z8m8XpLyG4yqlikL',NULL,NULL,'desktop','Firefox','2026-06-29 06:28:21'),(672,'login',NULL,'https://safhenokhost.ir/admin/dashboard','z0U0SwTqJ6EbN4uKSyg1LdaLVNN0qWeoVGrcuviO',1,NULL,'desktop','Firefox','2026-06-29 06:28:30'),(673,'/',NULL,NULL,'mdlWY5BrZafAZfR44PDKec95PqkZOZPFKBEwi6el',NULL,NULL,'desktop','Chrome','2026-06-29 07:25:52'),(674,'/',NULL,NULL,'8fkSr7AclhgXXsq23smgfn9XBIEg0E4J82XlpZ8e',NULL,NULL,'desktop','Chrome','2026-06-29 07:26:04'),(675,'/',NULL,NULL,'xc3pgy9Qv0467poYe1fwxKJup2vnDeBLt0ugoyo5',NULL,NULL,'desktop','Firefox','2026-06-29 12:40:53'),(676,'/',NULL,'http://safhenokhost.ir/','aYAyllCuPqJ6Umc2HhYCSqnqrMPV8BXTpw8OdsV4',NULL,NULL,'desktop','Chrome','2026-06-29 12:40:53'),(677,'/',NULL,NULL,'TOtfb5HqviC8bUhp6LXqIpwuSbCNWTDJJeJ4zVmY',NULL,NULL,'desktop','Edge','2026-06-29 12:41:09'),(678,'/',NULL,NULL,'vBTHA9ScXgkcOfV75RIzZOcZAwj0y3spQNfVk87W',NULL,NULL,'desktop','Edge','2026-06-29 12:41:27'),(679,'/',NULL,'https://www.google.com/','fo1oGhjoulYT5kSGRWq9wQ5WtlWySoAFJa4HUfaL',NULL,NULL,'mobile','Chrome','2026-06-29 13:29:58'),(680,'/',NULL,'https://www.reddit.com/','HAgEPrFqnh2ulfBY0Xj6JU0zUklm6Q6reAxQV0DQ',NULL,NULL,'desktop','Chrome','2026-06-29 15:47:30'),(681,'/',NULL,'http://safhenokhost.ir?_=h5zr08pp&v=vwte5','OR7EuL30HDni5KLXBdtb1CXeTwMDCj6sEdWotANl',NULL,NULL,'desktop','Firefox','2026-06-29 15:54:48'),(682,'/',NULL,'https://twitter.com/','LMHQuUCx4yYxkfyfGpiRjuvSA8OT59W7RGjiY1PY',NULL,NULL,'desktop','Firefox','2026-06-29 16:05:35'),(683,'/',NULL,'https://twitter.com/','c0sZe6GQMoxj48nUdaoV8TMjnLxTIBUpb2PwyHlX',NULL,NULL,'desktop','Edge','2026-06-29 16:05:37'),(684,'/',NULL,'https://duckduckgo.com/?q=nx806','Se9316t8E1o9VcQTIS4yTSgh6PsyuLqJcYIJrK7H',NULL,NULL,'desktop','Firefox','2026-06-29 16:05:41'),(685,'/',NULL,'https://www.reddit.com/','NzCnaFC1xxfmGmo0AG5F0UeigEqsW1iP49TpQkqB',NULL,NULL,'desktop','Chrome','2026-06-29 16:05:51'),(686,'/',NULL,'https://www.facebook.com/','xl17jelRE2qzg9cRlL7TA64RFoP0C5ZeKd9pCN8G',NULL,NULL,'desktop','Chrome','2026-06-29 16:05:57'),(687,'/',NULL,'https://twitter.com/','zuqb7q0Fxh0GodJwb4hx8XQnCSl9t0ErQuAC96Ei',NULL,NULL,'desktop','Chrome','2026-06-29 16:05:58'),(688,'/',NULL,'https://www.google.com/','63ON2CsgsH28oH8HtXCFunkUafCK8wPecMZZat9x',NULL,NULL,'desktop','Firefox','2026-06-29 16:06:02'),(689,'/',NULL,'https://www.google.com/','13ZuTGz6Wq66Zt9ZwLuolsscvkKBz64jpHSUW7yX',NULL,NULL,'mobile','Chrome','2026-06-29 16:06:15'),(690,'login',NULL,'https://twitter.com/','IicZdkpCRDzJ1iDAt75FlySJojXmPDPOnoGMNE0S',NULL,NULL,'mobile','Chrome','2026-06-29 16:06:25'),(691,'blog',NULL,'https://duckduckgo.com/?q=g21ol','Vorr2njnNJJrJCiAqwV87t2aAw8PEqEKxydpU7RV',NULL,NULL,'desktop','Firefox','2026-06-29 16:06:26'),(692,'/',NULL,'https://www.facebook.com/','W5lUkyp6MnFQzCmySK34GxyrzUooGEm34sFyvY7k',NULL,NULL,'desktop','Firefox','2026-06-29 16:06:26'),(693,'/',NULL,'http://safhenokhost.ir/?_=ydgjhh83&v=iwm4u','wu42QzUMPEDDwE0jcVrPg1cKOV3sjJX5Tb7jgMIS',NULL,NULL,'mobile','Safari','2026-06-29 16:06:30'),(694,'/',NULL,'https://www.google.com/search?q=uvkazn','kfgc8cm9xyUq8cTkOWqdRN8V6spjxqnwtPVee5ai',NULL,NULL,'desktop','Chrome','2026-06-29 16:06:32'),(695,'blog',NULL,'https://www.bing.com/search?q=viphkg','M7jy6LvSM8feINHureaDqfrRL3xHgteeS1oQoxJV',NULL,NULL,'mobile','Chrome','2026-06-29 16:06:34'),(696,'blog',NULL,'https://duckduckgo.com/?q=rbrln','fj68bBzPqF319pBwZeahwPyR5E7zCYxjpodPbWp0',NULL,NULL,'desktop','Chrome','2026-06-29 16:06:44'),(697,'/',NULL,'https://www.facebook.com/','7SsZQc0yh46QEZ1SBJlqKxdMvwN2X7IoPHBQuSO0',NULL,NULL,'mobile','Safari','2026-06-29 16:07:30'),(698,'/',NULL,'https://www.reddit.com/','N9VE8dpogbV3UrBlxjqjr64i9p3cqwlGmCu5ywxw',NULL,NULL,'desktop','Firefox','2026-06-29 16:07:34'),(699,'/',NULL,'http://safhenokhost.ir/','ANR0C0Q83fLu3ZFm7Nu1sIneiA84HORF298IhkV3',NULL,NULL,'desktop','Firefox','2026-06-29 16:27:59'),(700,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'2glErsaQW8fw3a7GBHBL19ujciPfyhrbN1YdK0Fy',NULL,NULL,'desktop','Firefox','2026-06-29 16:28:06'),(701,'blog/sayt-hmh-karh',NULL,NULL,'fhj5a2mqpA0xXaF7YRcBuyUG6AxjWbmE88wRZlkT',NULL,NULL,'desktop','Firefox','2026-06-29 16:28:09'),(702,'blog',NULL,NULL,'3cd3jD3H12j0XbGCG0VXlc3sN3gKJgOwP2fXe2yy',NULL,NULL,'desktop','Firefox','2026-06-29 16:28:10'),(703,'/',NULL,'https://www.google.com/','0bwhlerKe68TASzj24pzdrcRYPEci1OTotIqKZ4X',NULL,NULL,'mobile','Chrome','2026-06-29 16:55:52'),(704,'login',NULL,'https://safhenokhost.ir/login','js20gGIHB0iI4qBWj8FCEEGWlOiXPrZJhCAI33th',NULL,NULL,'desktop','Firefox','2026-06-29 18:39:08'),(705,'login',NULL,'https://safhenokhost.ir/admin/dashboard','XJaHKFRQJ3oGjsoi1eBShvAPBS6ZNKLcEPuB0o94',1,NULL,'desktop','Firefox','2026-06-29 18:39:25'),(706,'login',NULL,'https://safhenokhost.ir/admin/modules/advanced_search','XJaHKFRQJ3oGjsoi1eBShvAPBS6ZNKLcEPuB0o94',1,NULL,'desktop','Firefox','2026-06-29 20:02:10'),(707,'/',NULL,NULL,'hJqdfpYNnGwo6zC1eyatPuHsm0va9Nzzy1U80VTw',NULL,NULL,'desktop','Edge','2026-06-29 20:11:51'),(708,'/',NULL,NULL,'Ji1OwYB4tEnzw6qkUXSRODETQqO5fTCRN8fIZd5m',NULL,NULL,'desktop','Chrome','2026-06-29 21:59:32'),(709,'/',NULL,NULL,'3ISQ5UrZ2wTxa3br823iClHe84WzMDNgoJY1afZk',NULL,NULL,'desktop','Other','2026-06-30 02:45:37'),(710,'login',NULL,'https://tenent.safhenokhost.ir/','HEcGexEM5Uhc2tChn9pygwNUkQakg0UU7u8gFS16',NULL,NULL,'desktop','Chrome','2026-06-30 02:57:09'),(711,'/',NULL,NULL,'HEcGexEM5Uhc2tChn9pygwNUkQakg0UU7u8gFS16',NULL,NULL,'desktop','Chrome','2026-06-30 02:57:13'),(712,'/',NULL,NULL,'hGQzjHKvttVp7npdNdNO21yZaD3692C6ly9Suw6Q',NULL,NULL,'desktop','Chrome','2026-06-30 03:13:13'),(713,'/',NULL,'https://tenent.safhenokhost.ir/','HEcGexEM5Uhc2tChn9pygwNUkQakg0UU7u8gFS16',NULL,NULL,'desktop','Chrome','2026-06-30 03:47:57'),(714,'/',NULL,NULL,'KzJpUOjs455i6scfi8CU6r6U5IBBPoDGYQviC9Th',NULL,NULL,'desktop','Firefox','2026-06-30 06:06:34'),(715,'/',NULL,NULL,'bhdaeizvoplvfJseLVWASDiPwxWtqfnxVyaU0Z9L',NULL,NULL,'desktop','Firefox','2026-06-30 06:06:39'),(716,'login',NULL,'https://safhenokhost.ir/','bhdaeizvoplvfJseLVWASDiPwxWtqfnxVyaU0Z9L',NULL,NULL,'desktop','Firefox','2026-06-30 06:07:09'),(717,'login',NULL,'https://safhenokhost.ir/admin/modules/advanced_search','jWnV6yfUwXpMdK6IRiEvypRHbHv86tPpyJolLYlm',NULL,NULL,'desktop','Firefox','2026-06-30 12:02:44'),(718,'login',NULL,'https://safhenokhost.ir/admin/translations','o9gXQtwx1zaaEIPyyahJyzg8q5i1uETYgQQ1OFtB',1,NULL,'desktop','Firefox','2026-06-30 12:02:59'),(719,'login',NULL,'https://safhenokhost.ir/admin/dashboard','o9gXQtwx1zaaEIPyyahJyzg8q5i1uETYgQQ1OFtB',1,NULL,'desktop','Firefox','2026-06-30 12:48:45'),(720,'/',NULL,NULL,'QfHZ0jEKEJvQYaGSmnQhYEFICidGfJlVpBZ1h8A4',NULL,NULL,'desktop','Chrome','2026-06-30 13:12:56'),(721,'/',NULL,NULL,'AQLDiGkSh28OaJPGBTMV0WK9URYzqdlSUqf2LwHZ',NULL,NULL,'desktop','Chrome','2026-06-30 13:12:57'),(722,'/',NULL,NULL,'t2ROnX3FMA80uLMvYePHjgxBItrXtvdKvrgudsPb',NULL,NULL,'desktop','Chrome','2026-06-30 13:13:02'),(723,'/',NULL,NULL,'qdk5hnoxV0XtnxXUUyGeAd8QHLEgIoL32fgcmtCp',NULL,NULL,'desktop','Other','2026-06-30 13:15:47'),(724,'/',NULL,NULL,'aWPG2j5PzFgyZX3uwUlBAyUumvIQCjH9Ly89AJk5',NULL,NULL,'desktop','Other','2026-06-30 13:15:47'),(725,'/',NULL,NULL,'UXwquGjBVR2Y3Qb7ixaoAiHGEThjN9J903TOtpNG',NULL,NULL,'desktop','Other','2026-06-30 13:17:05'),(726,'/',NULL,NULL,'t80QpuK60pugLmq9GKv0noqIsPHgxGFuR7wJbu3R',NULL,NULL,'desktop','Other','2026-06-30 13:17:05'),(727,'/',NULL,NULL,'tm4doGPTodniyeGv3TNMbvi8xylSvg8I9q9AZ0to',NULL,NULL,'desktop','Other','2026-06-30 13:19:56'),(728,'/',NULL,NULL,'aEG4syV3YABjR7UWVEtWG0FOTAOuzJHk2l6iWK24',NULL,NULL,'desktop','Other','2026-06-30 13:20:20'),(729,'login',NULL,'https://safhenokhost.ir/admin/dashboard','o9gXQtwx1zaaEIPyyahJyzg8q5i1uETYgQQ1OFtB',1,NULL,'desktop','Firefox','2026-06-30 13:26:05'),(730,'/',NULL,NULL,'AQLDiGkSh28OaJPGBTMV0WK9URYzqdlSUqf2LwHZ',NULL,NULL,'desktop','Chrome','2026-06-30 13:43:17'),(731,'login',NULL,'https://safhenokhost.ir/admin/dashboard','o9gXQtwx1zaaEIPyyahJyzg8q5i1uETYgQQ1OFtB',1,NULL,'desktop','Firefox','2026-06-30 17:25:41'),(732,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,'https://safhenokhost.ir/admin/pages','o9gXQtwx1zaaEIPyyahJyzg8q5i1uETYgQQ1OFtB',1,NULL,'desktop','Firefox','2026-06-30 17:26:44'),(733,'builder/edit/139',NULL,'https://safhenokhost.ir/page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma','o9gXQtwx1zaaEIPyyahJyzg8q5i1uETYgQQ1OFtB',1,NULL,'desktop','Firefox','2026-06-30 17:26:47'),(734,'/',NULL,NULL,'o9gXQtwx1zaaEIPyyahJyzg8q5i1uETYgQQ1OFtB',1,NULL,'desktop','Firefox','2026-06-30 17:28:34'),(735,'builder/page/139/edit',NULL,'https://safhenokhost.ir/builder/edit/139','o9gXQtwx1zaaEIPyyahJyzg8q5i1uETYgQQ1OFtB',1,NULL,'desktop','Firefox','2026-06-30 17:30:02'),(736,'blog/sayt-hmh-karh',NULL,'https://safhenokhost.ir/page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma','o9gXQtwx1zaaEIPyyahJyzg8q5i1uETYgQQ1OFtB',1,NULL,'desktop','Firefox','2026-06-30 17:33:30'),(737,'blog',NULL,'https://safhenokhost.ir/blog/sayt-hmh-karh','o9gXQtwx1zaaEIPyyahJyzg8q5i1uETYgQQ1OFtB',1,NULL,'desktop','Firefox','2026-06-30 17:33:33'),(738,'/',NULL,NULL,'PgyraytNAoCCqN433krDUBKzKzheBTAu2vJTcmyQ',NULL,NULL,'desktop','Other','2026-06-30 22:29:41'),(739,'login',NULL,NULL,'PgyraytNAoCCqN433krDUBKzKzheBTAu2vJTcmyQ',NULL,NULL,'desktop','Other','2026-06-30 22:29:50'),(740,'/',NULL,NULL,'FvCAUdJNY5PJkW43HrdNaHCKTfBmMkDtdYRoixfN',NULL,NULL,'mobile','Chrome','2026-07-01 00:49:06'),(741,'/',NULL,NULL,'sjRmBDddCz48WyzuJqNrZ8BwYy7j0ZZII3KRCMhM',NULL,NULL,'desktop','Firefox','2026-07-01 04:29:59'),(742,'login',NULL,'https://safhenokhost.ir/admin/pages','kg3HrDjdrvukMbRegeo2LlG9iV3J74Ggii50UO1d',NULL,NULL,'desktop','Firefox','2026-07-01 05:05:35'),(743,'login',NULL,'https://safhenokhost.ir/admin/dashboard','EzCHlFePUCQZQoZHVaTQUC16oApWCpefTHesnlOB',1,NULL,'desktop','Firefox','2026-07-01 05:05:43'),(744,'/',NULL,NULL,'NmQlhAvkwirfcA9nu3Q4CqHzFUrPkMgeWfLy5oNn',NULL,NULL,'mobile','Chrome','2026-07-01 08:29:37'),(745,'/',NULL,'http://safhenokhost.ir/','zEq4ipqO8rj99YzBS04OtUwSUrJxj9qcrdJz6bkF',NULL,NULL,'mobile','Firefox','2026-07-01 09:04:44'),(746,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'zQTba1eZmMNHG9ife64PPvTFz4a7HXjcOeT8v7bX',NULL,NULL,'mobile','Firefox','2026-07-01 09:04:45'),(747,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'ltKzlkrpf2v9IeY1PLQULsoFFK45GGNSQ1XqSVgM',NULL,NULL,'mobile','Firefox','2026-07-01 09:04:46'),(748,'blog/sayt-hmh-karh',NULL,NULL,'rF0tJbUDfqHNEnYTp0G8JUm6muKuLCn4rVvJMvWa',NULL,NULL,'mobile','Firefox','2026-07-01 09:04:46'),(749,'/',NULL,NULL,'JcIFD9VY9JWt1DxbXcunuXHMBsJXP8u1PoGdkrNe',NULL,NULL,'desktop','Chrome','2026-07-02 01:40:31'),(750,'/',NULL,NULL,'1zecqKyt727SqXkoXImc8qpqj9eOtp2v6Sg6uREr',NULL,NULL,'desktop','Firefox','2026-07-02 04:09:58'),(751,'/',NULL,NULL,'GpMdvjyGkKsd8Q4LflSwLPzlFwJITggyZ37JHNUH',NULL,NULL,'desktop','Chrome','2026-07-02 04:24:56'),(752,'/',NULL,NULL,'xsp7vEA2efRVZwD7pXS9IhgtKgbyv99DL5hnz0LI',NULL,NULL,'desktop','Chrome','2026-07-02 06:15:37'),(753,'/',NULL,NULL,'xpjfq0L2ziZDZKUgdnNoDyoLjQZLMzNMbGjoW5Bp',NULL,NULL,'desktop','Chrome','2026-07-02 08:34:48'),(754,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'xpjfq0L2ziZDZKUgdnNoDyoLjQZLMzNMbGjoW5Bp',NULL,NULL,'desktop','Chrome','2026-07-02 08:34:53'),(755,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'xpjfq0L2ziZDZKUgdnNoDyoLjQZLMzNMbGjoW5Bp',NULL,NULL,'desktop','Chrome','2026-07-02 08:34:56'),(756,'contact',NULL,NULL,'xpjfq0L2ziZDZKUgdnNoDyoLjQZLMzNMbGjoW5Bp',NULL,NULL,'desktop','Chrome','2026-07-02 08:35:04'),(757,'/',NULL,NULL,'o9whhBRmvNEhGeShSAde4Sp9bIgZIOh1hFxkBxPV',NULL,NULL,'desktop','Chrome','2026-07-02 09:43:34'),(758,'login',NULL,'https://safhenokhost.ir/admin/inbox','bnERJxcFlQUaZPRa9I5RDNBn0iw0aIAIx2tyELPi',NULL,NULL,'desktop','Firefox','2026-07-02 14:05:39'),(759,'login',NULL,'https://safhenokhost.ir/admin/inbox','H9yFkH0fCD3jQGV8nf7g95vp3V3TmUqsHreKdk6I',1,NULL,'desktop','Firefox','2026-07-02 14:05:49'),(760,'login',NULL,'https://safhenokhost.ir/admin/dashboard','H9yFkH0fCD3jQGV8nf7g95vp3V3TmUqsHreKdk6I',1,NULL,'desktop','Firefox','2026-07-02 14:35:59'),(761,'login',NULL,'https://safhenokhost.ir/admin/dashboard','H9yFkH0fCD3jQGV8nf7g95vp3V3TmUqsHreKdk6I',1,NULL,'desktop','Firefox','2026-07-02 17:38:25'),(762,'/',NULL,NULL,'0lgedHbRQciryDvcvaQOhDz59fXpKtVUjaF13jIv',NULL,NULL,'desktop','Other','2026-07-02 18:22:03'),(763,'sitemap.xml',NULL,NULL,'9YcvOzbKJsDcmXAAUS1c6rqD1lVnKTuyViCylvnx',NULL,NULL,'desktop','Other','2026-07-02 18:24:12'),(764,'/',NULL,NULL,'wwBCcgItcjSaLGe5jGxXk1U6kHPOaOUdT8ExMMvT',NULL,NULL,'desktop','Other','2026-07-02 18:24:13'),(765,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'dWlT64WbnTyBB4U9c0lemSGRBBL6f5msJXiiKzGm',NULL,NULL,'desktop','Other','2026-07-02 18:24:13'),(766,'blog',NULL,NULL,'VC95oWmlCvpljjzJC4mlOnSQxpzlDule91BHrgE3',NULL,NULL,'desktop','Other','2026-07-02 18:24:14'),(767,'forms',NULL,NULL,'05XzWUo4ewQr0hTZlPNzHMprYMe1IsiCZ3kCYSER',NULL,NULL,'desktop','Other','2026-07-02 18:24:14'),(768,'contact',NULL,NULL,'yYmfIkNNYs1AWEa9C0va5hhK3XzzDvDv634VkwJs',NULL,NULL,'desktop','Other','2026-07-02 18:24:15'),(769,'/',NULL,NULL,'iNgYnOTUIhsgU5LDt4l7I5rP0w8uSjiEcRy0nCZQ',NULL,NULL,'desktop','Other','2026-07-02 18:26:13'),(770,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'V1FnqjPAzWeWFpBgyQ26vULCnH8tt0uxDaenpJnv',NULL,NULL,'desktop','Other','2026-07-02 18:26:13'),(771,'blog',NULL,NULL,'dvMl3dqoabIVCfbKuQtY9LcxgzRKVZKM0YfbiFn5',NULL,NULL,'desktop','Other','2026-07-02 18:26:13'),(772,'forms',NULL,NULL,'764cfb2kcL23a1M8BmCRbvSdxL19lM16AfHG9T5M',NULL,NULL,'desktop','Other','2026-07-02 18:26:14'),(773,'/',NULL,NULL,'GzagrOHkB2OJdFzoKTl44lc1nZaYkRBKG6Whtzco',NULL,NULL,'desktop','Other','2026-07-02 18:26:15'),(774,'search',NULL,NULL,'pY9m37SxthfwcnHArBEpuHLo3NgV9yCL20spTFsz',NULL,NULL,'desktop','Other','2026-07-02 18:26:15'),(775,'/',NULL,NULL,'AwuISufOlxhUkpXVqhZlWOJ1ody7X8FOdM3pFxUJ',NULL,NULL,'desktop','Other','2026-07-02 18:26:16'),(776,'/',NULL,NULL,'h68mRbpe6DajEkkQmrlnTMi4uObvhvI8so4AdyFj',NULL,NULL,'desktop','Other','2026-07-02 18:26:17'),(777,'/',NULL,NULL,'IziAM9Py2q0a7XVg6SeHkJMWb20kWFK3NYMXTa15',NULL,NULL,'desktop','Other','2026-07-02 18:26:17'),(778,'blog',NULL,NULL,'GSZ2h8Dg404AhdTPIoYBjXtWH1t8vCK5ygowKJH1',NULL,NULL,'desktop','Other','2026-07-02 18:26:18'),(779,'blog',NULL,NULL,'1ByFoMuVY07j6bBdBHVGIZT3tGt2vH9C3KBkRmee',NULL,NULL,'desktop','Other','2026-07-02 18:26:18'),(780,'blog',NULL,NULL,'HT2jZoQAl0GYhMd2RE3RIHcKEQ1bV5Sjq49hSLx3',NULL,NULL,'desktop','Other','2026-07-02 18:26:18'),(781,'blog',NULL,NULL,'rY6UTVicNCAktZaCSQgOVaAL2ElCk8uq5ZKHWmBu',NULL,NULL,'desktop','Other','2026-07-02 18:26:19'),(782,'blog',NULL,NULL,'s3oxEDuzB2ORnY7BuRgQZL4LolXUhEiLdARBJq0f',NULL,NULL,'desktop','Other','2026-07-02 18:26:19'),(783,'blog',NULL,NULL,'YNvMvCdX96TDy2SfyOnAUADOf8grageQc87CYXBt',NULL,NULL,'desktop','Other','2026-07-02 18:26:19'),(784,'blog',NULL,NULL,'8vdtdgcaEUvc4GPCYT4eer2IgwjmeBVl3aEwhk4h',NULL,NULL,'desktop','Other','2026-07-02 18:26:19'),(785,'blog',NULL,NULL,'Xzmg0zrKBySEOlXbbqrSdMncF3XoeGlGnoCUBvzF',NULL,NULL,'desktop','Other','2026-07-02 18:26:20'),(786,'blog',NULL,NULL,'wmi5zal8uGS1K1JMMRBp7eBVHA64XlrpWEQOisTX',NULL,NULL,'desktop','Other','2026-07-02 18:26:20'),(787,'blog',NULL,NULL,'A2GveZWF5aiLnS98LXvQp1oWHaEqzKbpQ85rvQHi',NULL,NULL,'desktop','Other','2026-07-02 18:26:21'),(788,'/',NULL,NULL,'KUVzpnUvp4w4iSnIgQuS6Un15EL0vB0jHa5tinRb',NULL,NULL,'desktop','Other','2026-07-02 18:54:08'),(789,'/',NULL,NULL,'vzNjqxSEy5ujekjej7N88SxHVpJWDb9gUjcLd7Wh',NULL,NULL,'desktop','Other','2026-07-02 18:54:08'),(790,'/',NULL,NULL,'xyr37jY5st6Pzdvvx3UzdFzBK0Ds9n9ecKy97L7z',NULL,NULL,'mobile','Chrome','2026-07-02 19:18:08'),(791,'sitemap.xml',NULL,NULL,'Iq2WHCIc4DJYh08pmt4IQJBFa1ndUSanwzN2zKqN',NULL,NULL,'desktop','Other','2026-07-02 23:38:07'),(792,'/',NULL,NULL,'kl7IO07mAFgTDQZJBXvmA5NUKkAiHiBa1i45qcsB',NULL,NULL,'desktop','Other','2026-07-02 23:38:08'),(793,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'xNrRYzJ77xFbzFrjrPdqVJWAWNUlWDPOdq7Lv94B',NULL,NULL,'desktop','Other','2026-07-02 23:38:09'),(794,'blog',NULL,NULL,'S0rqOpYk3FfP3cztWECp2r1uPXK9ZWqsnmHKGLvB',NULL,NULL,'desktop','Other','2026-07-02 23:38:09'),(795,'blog/category/mhtoa',NULL,NULL,'818yLJdcikweD2Ag14pEVOLMBDyfTz2mxbtS83kk',NULL,NULL,'desktop','Other','2026-07-02 23:38:10'),(796,'blog/sayt-hmh-karh',NULL,NULL,'MauWNOgfyKNRNwqOF4hlRjpxkoR6yTHB1lRr5MuN',NULL,NULL,'desktop','Other','2026-07-02 23:38:10'),(797,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'Hnyrr33rS4s6PLEYs4KXeKY7TtbQfNdnBtjhnfU5',NULL,NULL,'desktop','Other','2026-07-02 23:38:11'),(798,'forms',NULL,NULL,'78xA1j8fuTudY23EIYXmPC8OtpxOMG7CYAMk8pfu',NULL,NULL,'desktop','Other','2026-07-02 23:38:11'),(799,'shop',NULL,NULL,'FTJzeiL1yvRGHw1QbwW873IQcjxfa4Ypw1P8krHI',NULL,NULL,'desktop','Other','2026-07-02 23:38:11'),(800,'shop/cart',NULL,NULL,'kVIw7VhLIj6w6VBCOEO61fBSuKoKwMnHhJfuvkrp',NULL,NULL,'desktop','Other','2026-07-02 23:38:12'),(801,'search',NULL,NULL,'GMOD3jAHI16ZeWbgauI7PESDOPtn9kpl3V1LDOVB',NULL,NULL,'desktop','Other','2026-07-02 23:38:12'),(802,'contact',NULL,NULL,'LqluoazOUiKixG8Av6y2kZXxLF2jtS6jooeTdXHa',NULL,NULL,'desktop','Other','2026-07-02 23:38:13'),(803,'login',NULL,NULL,'zgfKCcdhm4l1Exoxxz2cWAiRhGYMGqa3zU2bdnf7',NULL,NULL,'desktop','Other','2026-07-02 23:38:13'),(804,'/',NULL,NULL,'yXuF6xbTV9jPAiyo3POLzhGXi3hJV9ueVGh8BUZj',NULL,NULL,'desktop','Other','2026-07-02 23:38:13'),(805,'/',NULL,NULL,'QM7pd6TyBHpSuycUcbavnNuSoTCEzUYsV2jHZ8v5',NULL,NULL,'desktop','Other','2026-07-02 23:38:14'),(806,'/',NULL,NULL,'sQmkuRWFOCIeAgPUNHzgUVTlAjwgf9nhM3J97tXZ',NULL,NULL,'desktop','Other','2026-07-02 23:38:15'),(807,'/',NULL,NULL,'1ZBKpnoz3IF9n36YLCMecpU61bTJQo4y25pv1Tfp',NULL,NULL,'desktop','Other','2026-07-02 23:38:15'),(808,'blog',NULL,NULL,'8bay2vq8VPQ0bBk6bCB0ZFtMxdcIRBOi41yvy7mO',NULL,NULL,'desktop','Other','2026-07-02 23:38:15'),(809,'blog',NULL,NULL,'H2rHhbImxxPr6Czfz1KGYl2HldD27WC5cuXsnfaE',NULL,NULL,'desktop','Other','2026-07-02 23:38:16'),(810,'shop/wishlist',NULL,NULL,'bPX7V6nEES2PB8ac8QjUl0Fd6zKk53y9Pky4hNd1',NULL,NULL,'desktop','Other','2026-07-02 23:38:16'),(811,'register',NULL,NULL,'cMXYEbC03l0OfqTNZbRpOHmhbLK17GtZDwmLJ2Vp',NULL,NULL,'desktop','Other','2026-07-02 23:38:17'),(812,'/',NULL,NULL,'YUrFApdU7bM8YrmONXMdebB1egdbBug4AxmpX7B4',NULL,NULL,'desktop','Other','2026-07-03 02:19:28'),(813,'login',NULL,'https://safhenokhost.ir/admin/inbox','teJnF482e940kpsiDIhBl2tLgxMPL1BxWxC9knX4',NULL,NULL,'desktop','Firefox','2026-07-03 02:31:15'),(814,'login',NULL,'https://safhenokhost.ir/admin/dashboard','MrUuxOoDj1EYqiH0cCeyWisB3y7MzgIFgzwybKr1',1,NULL,'desktop','Firefox','2026-07-03 02:31:25'),(815,'account/resources',NULL,'https://safhenokhost.ir/admin/dashboard','MrUuxOoDj1EYqiH0cCeyWisB3y7MzgIFgzwybKr1',1,NULL,'desktop','Firefox','2026-07-03 03:07:54'),(816,'login',NULL,'https://safhenokhost.ir/account/resources','MrUuxOoDj1EYqiH0cCeyWisB3y7MzgIFgzwybKr1',1,NULL,'desktop','Firefox','2026-07-03 03:07:55'),(817,'/',NULL,NULL,'hNSjWImMfIp4GUOyWb0G6n94R3Rcn41anS0seDb3',NULL,NULL,'desktop','Chrome','2026-07-03 04:20:43'),(818,'login',NULL,'https://safhenokhost.ir/admin/payment-gateways/create','MrUuxOoDj1EYqiH0cCeyWisB3y7MzgIFgzwybKr1',1,NULL,'desktop','Firefox','2026-07-03 05:28:10'),(819,'/',NULL,NULL,'GTEMuw1Ovjo8Z4U6BDOElbQK6onZW1vxbd7cj3o7',NULL,NULL,'desktop','Chrome','2026-07-03 07:36:20'),(820,'/',NULL,'http://safhenokhost.ir/','OwtbJ8t9sqdP662DVCnVL75yNWK6LPyjVWRJ6g0O',NULL,NULL,'desktop','Firefox','2026-07-03 07:45:47'),(821,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'D899yc1pbVaSMs2EA3O6Om3LOpd7TIDhZXven9LS',NULL,NULL,'desktop','Firefox','2026-07-03 07:45:48'),(822,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'VhZ7bJrGlVpYgKbtV7XxpZNN4ERQzEzRQn5raf3H',NULL,NULL,'desktop','Firefox','2026-07-03 07:45:48'),(823,'blog/sayt-hmh-karh',NULL,NULL,'6HKll6zInztCt5BPItLVm9LB4FL78huAyLDQ2a2c',NULL,NULL,'desktop','Firefox','2026-07-03 07:45:49'),(824,'/',NULL,NULL,'r7AVixSp1OsDCUfrH4AdasQLZCkvJw6mXe52VDG4',NULL,NULL,'desktop','Other','2026-07-03 09:33:31'),(825,'/',NULL,NULL,'MrUuxOoDj1EYqiH0cCeyWisB3y7MzgIFgzwybKr1',1,NULL,'desktop','Firefox','2026-07-03 09:38:30'),(826,'shop',NULL,'https://safhenokhost.ir/','MrUuxOoDj1EYqiH0cCeyWisB3y7MzgIFgzwybKr1',1,NULL,'desktop','Firefox','2026-07-03 09:38:36'),(827,'login',NULL,'https://safhenokhost.ir/admin/products','MrUuxOoDj1EYqiH0cCeyWisB3y7MzgIFgzwybKr1',1,NULL,'desktop','Firefox','2026-07-03 09:38:55'),(828,'/',NULL,NULL,'dcI03z8774QBV7bfOoWiyHeJldJi3dNIBRV0f7nn',NULL,NULL,'mobile','Chrome','2026-07-03 10:42:23'),(829,'login',NULL,'https://safhenokhost.ir/admin/products','MrUuxOoDj1EYqiH0cCeyWisB3y7MzgIFgzwybKr1',1,NULL,'desktop','Firefox','2026-07-03 12:37:32'),(830,'login',NULL,'https://safhenokhost.ir/admin/products/create','MrUuxOoDj1EYqiH0cCeyWisB3y7MzgIFgzwybKr1',1,NULL,'desktop','Firefox','2026-07-03 13:53:29'),(831,'login',NULL,'https://safhenokhost.ir/admin/dashboard','MrUuxOoDj1EYqiH0cCeyWisB3y7MzgIFgzwybKr1',1,NULL,'desktop','Firefox','2026-07-03 15:23:11'),(832,'/',NULL,NULL,'MrUuxOoDj1EYqiH0cCeyWisB3y7MzgIFgzwybKr1',1,NULL,'desktop','Firefox','2026-07-03 15:23:19'),(833,'/',NULL,NULL,'DRisPFd3bgxtEeKQXsXVZ0G06sy485Z9qQpZiFhV',NULL,NULL,'desktop','Safari','2026-07-03 17:17:50'),(834,'blog/sayt-hmh-karh',NULL,NULL,'Tsx2tlPRUQxdCmecGXlqjvyZpTajNJEmOjgrR8nv',NULL,NULL,'desktop','Safari','2026-07-03 17:18:03'),(835,'shop',NULL,NULL,'3OAflGEFC96VZAQM9mHyj4NFRixZup7Y1UWzmGTQ',NULL,NULL,'desktop','Edge','2026-07-03 17:18:04'),(836,'shop/cart',NULL,NULL,'0TxxoU873deKXW53L6T5vVFkTzBfiLLUpyibXDPM',NULL,NULL,'desktop','Chrome','2026-07-03 17:18:04'),(837,'blog',NULL,NULL,'PgWs8SQS8HVbGl8PSUGg0Ci9yMVA5WivQZrWRq7j',NULL,NULL,'desktop','Safari','2026-07-03 17:18:04'),(838,'search',NULL,NULL,'ELPtHVe0sHj0emkyNPyJhVR6xEc875H4MJlWGEBU',NULL,NULL,'desktop','Safari','2026-07-03 17:18:04'),(839,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'4wAt2EXlnCWm1q3DCjmo6DZa7aITahSj04BxVu6f',NULL,NULL,'desktop','Safari','2026-07-03 17:18:04'),(840,'login',NULL,NULL,'fjXKVuTFngK6eHUJHEiPGiM4iNM2ZiHMdlZBA2Eg',NULL,NULL,'desktop','Chrome','2026-07-03 17:18:04'),(841,'contact',NULL,NULL,'0ABJjCJFkx4gzTJet93pUPPq2TiSeWIYRXrO3WdZ',NULL,NULL,'desktop','Chrome','2026-07-03 17:18:04'),(842,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'9MabdEwZinhccup8PgNT7R2ubhmmoe4lYNYLoNMC',NULL,NULL,'desktop','Firefox','2026-07-03 17:18:04'),(843,'/',NULL,'https://safhenokhost.ir/lang/fa','Us9rMWh2RfItRIRbkCMbaXL43zy50LZGGRgbY4ga',NULL,NULL,'desktop','Safari','2026-07-03 17:18:05'),(844,'/',NULL,'https://safhenokhost.ir/lang/ar','YXrPJ7IrsmjnUfApuPELO9We5bT5zcJcW24oc81R',NULL,NULL,'desktop','Firefox','2026-07-03 17:18:05'),(845,'/',NULL,'https://safhenokhost.ir/lang/en','Z5kIX3UFQxx48pHMweFDgWgcLTctUagJcimtzGU5',NULL,NULL,'desktop','Firefox','2026-07-03 17:18:05'),(846,'blog/series/syo',NULL,NULL,'LtSz5t9yKWY5IywhPNablPl3NNAlMyfq4GXnbMjE',NULL,NULL,'desktop','Chrome','2026-07-03 17:18:09'),(847,'blog',NULL,NULL,'IiSTORA3YMRmLe2v77KSGutjAXZ7YeaQre9Hevfr',NULL,NULL,'desktop','Chrome','2026-07-03 17:18:09'),(848,'blog',NULL,NULL,'48zaGl8IWQ5FZK6chSvNtqS4X0GtYe901um9QZQg',NULL,NULL,'desktop','Chrome','2026-07-03 17:18:09'),(849,'blog',NULL,NULL,'WjuFms0TaIqCK2ZQM620PRnQoOcFrsB2bgQMpUPH',NULL,NULL,'desktop','Safari','2026-07-03 17:18:09'),(850,'blog',NULL,NULL,'yZycuL9kmiEqZueMFQm49nJj1EtjjiQlx4mktpZ9',NULL,NULL,'desktop','Safari','2026-07-03 17:18:10'),(851,'blog',NULL,NULL,'VxTKliw14W6EXUKvaT8DN2KsXbxyRalp3zfwKbJB',NULL,NULL,'desktop','Chrome','2026-07-03 17:18:10'),(852,'blog',NULL,NULL,'6r3L2xtzQ0ytmcHTGmTXJARDKJyvQ4kseTVQn7hX',NULL,NULL,'desktop','Firefox','2026-07-03 17:18:10'),(853,'blog/category/mhtoa',NULL,NULL,'8aXWuUgmcQb0uHikqO7aCkuS8cP0UMGK7F2xvOD3',NULL,NULL,'desktop','Chrome','2026-07-03 17:18:10'),(854,'shop/wishlist',NULL,NULL,'DRWiOUSe2Ek8YZyogt2KTZPf77IxCJt7gdFp2F9p',NULL,NULL,'desktop','Chrome','2026-07-03 17:18:10'),(855,'blog',NULL,NULL,'7ZHQWZtN0EtKgNddYDoRPLnwYfnIIe6xCyfgivKh',NULL,NULL,'desktop','Firefox','2026-07-03 17:18:10'),(856,'blog',NULL,NULL,'SRb88hr93Xr4utqkdDa30msIDw5fznAyzjGxhUeE',NULL,NULL,'desktop','Chrome','2026-07-03 17:18:10'),(857,'blog',NULL,NULL,'rkOfL3BNjfUvDvPuEOwB1VEs2R4QzX8rY1qHp1w5',NULL,NULL,'desktop','Chrome','2026-07-03 17:18:10'),(858,'register',NULL,NULL,'YR82VTH34ECaIW0ML39vgmicLQEoJqyYRXBOCm9i',NULL,NULL,'desktop','Edge','2026-07-03 17:18:11'),(859,'shop/compare',NULL,NULL,'4CK1W7pOuJj4Ebmr5t5spHWgbaVIqARX2MsMOOwx',NULL,NULL,'desktop','Firefox','2026-07-03 17:18:11'),(860,'blog',NULL,NULL,'iQZtp4EDImwBAwsa4n7RdalddPyvFboFHLhjv4iy',NULL,NULL,'desktop','Safari','2026-07-03 17:18:11'),(861,'/',NULL,'http://safhenokhost.ir/','AgnQNrIYAqdK3pJHabERfC0sxexMsx44dFSDjsHW',NULL,NULL,'desktop','Safari','2026-07-03 17:18:11'),(862,'/',NULL,NULL,'Iq0ttEuYHeqnCToi0uJiQbJyU2aWUukA232ykmfJ',NULL,NULL,'desktop','Firefox','2026-07-03 19:34:39'),(863,'login',NULL,'https://safhenokhost.ir/admin/dashboard','MrUuxOoDj1EYqiH0cCeyWisB3y7MzgIFgzwybKr1',1,NULL,'desktop','Firefox','2026-07-03 19:43:53'),(864,'/',NULL,NULL,'kQd4Y4P7ENgBjdCoG9YsxzmWISpnWpKz4jWZlgl2',NULL,NULL,'mobile','Chrome','2026-07-03 19:49:28'),(865,'/',NULL,NULL,'Cwv7bGIMVW9QwGImaXvsFEpAIf7BsKn4psqyCKfi',NULL,NULL,'mobile','Chrome','2026-07-03 23:53:29'),(866,'/',NULL,NULL,'S8I5YiCIxBJr6j8zOHlmY9GTjwtsAsLFIE2AY6rm',NULL,NULL,'desktop','Chrome','2026-07-04 00:51:05'),(867,'/',NULL,NULL,'5vsTH9hBsfbcdF0cLoPCMvPW2omVpBpA9vbDmS3m',NULL,NULL,'desktop','Chrome','2026-07-04 00:51:07'),(868,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'S8I5YiCIxBJr6j8zOHlmY9GTjwtsAsLFIE2AY6rm',NULL,NULL,'desktop','Chrome','2026-07-04 00:51:07'),(869,'contact',NULL,NULL,'S8I5YiCIxBJr6j8zOHlmY9GTjwtsAsLFIE2AY6rm',NULL,NULL,'desktop','Chrome','2026-07-04 00:51:08'),(870,'/',NULL,NULL,'2oYHKDLMdR86MS2ni0vDMmU0ClsR9g5CdeDPk0in',NULL,NULL,'mobile','Chrome','2026-07-04 03:29:18'),(871,'login',NULL,'https://safhenokhost.ir/admin/dashboard','cWLabbfERjnFPBcK5pwiCSJoI3H8JBA2uiN0oRSz',NULL,NULL,'desktop','Firefox','2026-07-04 04:22:32'),(872,'login',NULL,'https://safhenokhost.ir/admin/dashboard','wJbKKiRvowG648IEyudAJa7o7rJZH1RuAe3MqliN',1,NULL,'desktop','Firefox','2026-07-04 04:22:52'),(873,'/',NULL,NULL,'252RwolUhmBC46ZBKqPuRKGaWcvPfBfz35gp11AF',NULL,NULL,'desktop','Chrome','2026-07-04 10:34:30'),(874,'login',NULL,'https://safhenokhost.ir/login','Xw9sGylF4WPrYHt7OTrjQ19Mddnst3T2hs7znQhF',NULL,NULL,'desktop','Firefox','2026-07-04 11:06:11'),(875,'login',NULL,'https://safhenokhost.ir/admin/dashboard','1ysS8Lr8SnCllBBl6L8Rf1laumoJ3AqzqAzoSFXo',1,NULL,'desktop','Firefox','2026-07-04 11:06:28'),(876,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'49aE141hi9TNOOtZOsezWM8niSBMAW7zymtVe1aj',NULL,NULL,'mobile','Chrome','2026-07-04 21:26:10'),(877,'/',NULL,'http://safhenokhost.ir/','E30FxZQZTgvGXVy6AeOqvE0rqEaSQktczy84ioFY',NULL,NULL,'mobile','Safari','2026-07-04 23:07:29'),(878,'/',NULL,NULL,'NX5PyI0N0wN0ZiVypKBsIJIWniU42rw0W56r1txY',NULL,NULL,'desktop','Chrome','2026-07-05 02:36:31'),(879,'/',NULL,NULL,'vHVB0Mf9h1h5X9HlwpHkLjsa7qiaXvNq3H1xnoXn',NULL,NULL,'desktop','Chrome','2026-07-05 02:54:41'),(880,'login',NULL,NULL,'vHVB0Mf9h1h5X9HlwpHkLjsa7qiaXvNq3H1xnoXn',NULL,NULL,'mobile','Chrome','2026-07-05 02:55:04'),(881,'/',NULL,'http://safhenokhost.ir/','JPFIxl87LdwZWUWJTJGhUmiJGHm6EuAz4MbKYWnw',NULL,NULL,'mobile','Chrome','2026-07-05 02:55:36'),(882,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'ZnxADaTHOJXyHioB57ylBjM6zme1oB9nhMmBQClT',NULL,NULL,'mobile','Chrome','2026-07-05 02:55:46'),(883,'blog/sayt-hmh-karh',NULL,NULL,'EazEPy36fBHDyQF2PkuySyWd6WShHZV2hQvDzKop',NULL,NULL,'mobile','Chrome','2026-07-05 02:55:47'),(884,'/',NULL,NULL,'kX79r274zhb9KafxKNBCSV5rqjz0t9Ky1XiuKBMC',NULL,NULL,'desktop','Firefox','2026-07-05 07:43:13'),(885,'login',NULL,'https://safhenokhost.ir/','kX79r274zhb9KafxKNBCSV5rqjz0t9Ky1XiuKBMC',NULL,NULL,'desktop','Firefox','2026-07-05 07:43:31'),(886,'/',NULL,NULL,'Edyd1ftS5uCihRAhwDeUJgWP8xiXMzgWG7hAKGXR',1,NULL,'desktop','Firefox','2026-07-05 07:43:55'),(887,'login',NULL,'https://safhenokhost.ir/login','habVDsCKraiQ1Yob5Ks5jNI5e8t8vnJTCOpNRjlT',NULL,NULL,'desktop','Firefox','2026-07-05 13:30:03'),(888,'login',NULL,'https://safhenokhost.ir/admin/dashboard','SwzKdSfGQNUJkXgxPi4t6160oBdLOEknDr8KSE3V',1,NULL,'desktop','Firefox','2026-07-05 13:30:19'),(889,'/',NULL,NULL,'3anmB5hqFdzEXc4FiA1zDHNn4sMZoi9W5mEf0PPw',NULL,NULL,'mobile','Chrome','2026-07-05 14:31:33'),(890,'sitemap.xml',NULL,NULL,'gTBhILbOCG0s7W2Nh9W8D8eHFf2t0irCjWjWwaaQ',NULL,NULL,'desktop','Other','2026-07-05 16:10:26'),(891,'/',NULL,NULL,'xxpIGIMGpKUL7fniztLPUdLACUynOE1VSL3kH4MN',NULL,NULL,'desktop','Other','2026-07-05 16:10:27'),(892,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'Tjy7h191bU2CyUqNWh11lOVd5rO4SVeQJuqeQ61f',NULL,NULL,'desktop','Other','2026-07-05 16:10:27'),(893,'blog',NULL,NULL,'feNlkxyHQKGzuiz1qygWJK8vDiHaRgXU3ckoYmcc',NULL,NULL,'desktop','Other','2026-07-05 16:10:27'),(894,'blog/category/mhtoa',NULL,NULL,'ZGJAH87OwsY1AawzErZhg2Tw116HGDt4f8bGiuUS',NULL,NULL,'desktop','Other','2026-07-05 16:10:28'),(895,'blog/sayt-hmh-karh',NULL,NULL,'HHZzviDSW2fgyrpjAPdMPdI0NVmZKGTVZ3e3fWe2',NULL,NULL,'desktop','Other','2026-07-05 16:10:28'),(896,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'e2LlQqkliVidmhph4jpC7SVkmR1lKvTyQwll28TN',NULL,NULL,'desktop','Other','2026-07-05 16:10:28'),(897,'forms',NULL,NULL,'pZniPD38XFIS5SYgKg3ad76opIWnQsXDaediYiXd',NULL,NULL,'desktop','Other','2026-07-05 16:10:29'),(898,'shop',NULL,NULL,'zpICK1P2luo1oyQbBqP8zQB8PyNIW2P2egNSGE7x',NULL,NULL,'desktop','Other','2026-07-05 16:10:29'),(899,'/',NULL,NULL,'Cjyn7OEgvoIiNefMy48yD13RM7hG68mUIQSU3POb',NULL,NULL,'desktop','Other','2026-07-05 16:10:29'),(900,'/',NULL,NULL,'M9sLuB2NVfczc68EWmYnV3z6fd3SgiDTNC2GZVW2',NULL,NULL,'mobile','Chrome','2026-07-05 17:50:55'),(901,'/',NULL,NULL,'ggofRuKng8IMxACyMWnmhtisiPH3UzNsBET6dD6N',NULL,NULL,'desktop','Other','2026-07-05 18:58:54'),(902,'/',NULL,NULL,'aLCkkqe7ZdEKqlvjid5gcSgyC56gySR1YlLsqWJA',NULL,NULL,'desktop','Chrome','2026-07-06 00:25:28'),(903,'/',NULL,NULL,'GHGRnIWmibq5IYwz0JdIYiGYSXMXZATg91PaArYB',NULL,NULL,'mobile','Chrome','2026-07-06 01:04:35'),(904,'/',NULL,NULL,'ctwlsF63Y1W2laJh6l03VUCZK9zqYsT40HP2wEj2',NULL,NULL,'desktop','Chrome','2026-07-06 03:03:19'),(905,'login',NULL,'https://safhenokhost.ir/login','odloU3jIXrImmnj2msQ3IikPQK5nJuTuhSGNG2lI',NULL,NULL,'desktop','Firefox','2026-07-06 04:34:38'),(906,'/',NULL,NULL,'AenDEvgUJSPmAPEaYqO22D2I2TSLONHaHhttVs5n',NULL,NULL,'desktop','Other','2026-07-06 06:09:51'),(907,'login',NULL,'https://safhenokhost.ir/admin/dashboard','Np24OSHgW4DVSZ7JxFdxbXka6d1j7x7dKSc6V0Vl',1,NULL,'desktop','Firefox','2026-07-06 09:41:08'),(908,'/',NULL,NULL,'dqULeoRDmjCQttS0JetXBjti9cmZKNbCe9Y73VHU',NULL,NULL,'desktop','Chrome','2026-07-06 10:15:15'),(909,'login',NULL,'https://safhenokhost.ir/login','Np24OSHgW4DVSZ7JxFdxbXka6d1j7x7dKSc6V0Vl',NULL,NULL,'desktop','Firefox','2026-07-06 15:31:01'),(910,'login',NULL,'https://safhenokhost.ir/admin/dashboard','7XZSoypn3yXafEUr7yF4gZIYLxIJJEy2YSeao0J5',1,NULL,'desktop','Firefox','2026-07-06 15:31:10'),(911,'/',NULL,NULL,'7XZSoypn3yXafEUr7yF4gZIYLxIJJEy2YSeao0J5',1,NULL,'desktop','Firefox','2026-07-06 15:50:27'),(912,'/',NULL,NULL,'ceCwY31inH0o0aQ0qRF9WUF5WqbNqzuWRvFcFn6N',NULL,NULL,'mobile','Chrome','2026-07-06 18:28:27'),(913,'/',NULL,NULL,'f9U5r8ZVW019wDRn7Q4NWKvKvVKyvtJKZbtlwDRQ',NULL,NULL,'desktop','Firefox','2026-07-07 01:18:19'),(914,'/',NULL,'http://safhenokhost.ir/','tR8ocToYGEVkPzls4Cf2pAZxFNfWrSdherb4FWU7',NULL,NULL,'desktop','Safari','2026-07-07 01:31:36'),(915,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'zuNcAmprVOnD7zAoA1fX1I3idPfzZzSiYK2Kl1Ld',NULL,NULL,'desktop','Safari','2026-07-07 01:31:37'),(916,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'XYwQm3A5bHv7UFzrmFnakb6QO2opJ5A1cY28yTx7',NULL,NULL,'desktop','Safari','2026-07-07 01:31:38'),(917,'blog/sayt-hmh-karh',NULL,NULL,'Np8oKs4pX7ZhYRiCfmn09pz0S0CTzKA6imynErya',NULL,NULL,'desktop','Safari','2026-07-07 01:31:38'),(918,'/',NULL,NULL,'O8OKSoC0cLgBM5AIEJ9mnAOOKLsLoPXFSRV59OTC',NULL,NULL,'desktop','Other','2026-07-07 02:52:11'),(919,'/',NULL,NULL,'9FQRj5dzo8Qe7s1EhbnZRoELpVGLnCt1t9wCbaTw',NULL,NULL,'desktop','Other','2026-07-07 05:09:57'),(920,'login',NULL,NULL,'DExPNDTS5ajp9oroLvmLVXrDQGyxKxBNlX1Uflmk',NULL,NULL,'desktop','Firefox','2026-07-07 12:22:09'),(921,'login',NULL,'https://safhenokhost.ir/admin/dashboard','PYzpwLZ5K4V6aDHKcEKfESYFdfW4juLbZ0dQgsZT',1,NULL,'desktop','Firefox','2026-07-07 12:26:47'),(922,'login',NULL,'https://safhenokhost.ir/admin/dashboard','PYzpwLZ5K4V6aDHKcEKfESYFdfW4juLbZ0dQgsZT',1,NULL,'desktop','Firefox','2026-07-07 13:31:59'),(923,'/',NULL,NULL,'dQKVUaogtBfCVfZtBofVb7wGfmHsPcvNArcGW0yE',NULL,NULL,'desktop','Firefox','2026-07-07 19:32:15'),(924,'/',NULL,NULL,'8SypuAW94O49G7JjJfGpKimgnxPI9mj3lRU4h3xO',NULL,NULL,'desktop','Other','2026-07-08 02:02:19'),(925,'/',NULL,NULL,'z14v6fw65QMbCEBlzAi07SpXma3sNkOjBQn0pi7u',NULL,NULL,'desktop','Other','2026-07-08 02:02:19'),(926,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'LSmtQZEtGxVHfG5wC5QqQHHqx8zvDcocnnq6dsZy',NULL,NULL,'desktop','Other','2026-07-08 02:02:20'),(927,'blog',NULL,NULL,'u8vqDGeDgvJyQnBh1KsJi2MwfEXBgq3zQxRM0DkA',NULL,NULL,'desktop','Other','2026-07-08 02:02:20'),(928,'shop',NULL,NULL,'UMAA67KzdAOFHlK8ExWfiKFaWCzxVkW3u5T9eDww',NULL,NULL,'desktop','Other','2026-07-08 02:02:21'),(929,'shop/cart',NULL,NULL,'2QTHKC4wrwPgJW7mLuUEPkR8hI21pKJWnGOz3nIX',NULL,NULL,'desktop','Other','2026-07-08 02:02:21'),(930,'search',NULL,NULL,'mkRZ8ViX6l13VxxnlWs65B9oC5ev8CdbiXa2roL9',NULL,NULL,'desktop','Other','2026-07-08 02:02:22'),(931,'contact',NULL,NULL,'IPeBe34EYNBtptvX08QKP4Xjzr3VBwJORfQeArsE',NULL,NULL,'desktop','Other','2026-07-08 02:02:23'),(932,'login',NULL,NULL,'sK9Wm3ldAUgCuUF1FBD6mw4UCiLUjnlHXWs11nc1',NULL,NULL,'desktop','Other','2026-07-08 02:02:23'),(933,'login',NULL,'http://safhenokhost.ir/login','5vcZRMPjQzQyXwG8EGaoYA5P6G3C6hE2zCxPXLkr',NULL,NULL,'desktop','Other','2026-07-08 02:02:24'),(934,'blog/sayt-hmh-karh',NULL,'http://safhenokhost.ir/blog/sayt-hmh-karh','Yul1LIFbwX3yQ2sswrxqdBANQka7SW5KYdFAfzup',NULL,NULL,'desktop','Other','2026-07-08 02:02:24'),(935,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,'http://safhenokhost.ir/blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd','t6WYWAfR2Sk8CHlbVtDJ4zqdiIRlo4psENQGSlAs',NULL,NULL,'desktop','Other','2026-07-08 02:02:24'),(936,'blog/category/mhtoa',NULL,NULL,'DF83uyrcJCqxyTZExPZ1zrsjH1aX3OEyb2GWErEI',NULL,NULL,'desktop','Other','2026-07-08 02:02:25'),(937,'blog',NULL,NULL,'UKgf57t0zdSnkMU40880UH8OJpgZFQ1sjrNlMJGW',NULL,NULL,'desktop','Other','2026-07-08 02:02:25'),(938,'blog',NULL,NULL,'sLBSxCfmWpngc7v0p7qoKNmpIUPYZgA2qpkwnyWS',NULL,NULL,'desktop','Other','2026-07-08 02:02:25'),(939,'blog',NULL,NULL,'ptXWeXQee7UDeiLqXFWS3XcLyu56n6AEIknXqq3l',NULL,NULL,'desktop','Other','2026-07-08 02:02:26'),(940,'blog',NULL,NULL,'ywwwYYH33vSLH8G29TaSxahObVYQ2aYJFIAicScp',NULL,NULL,'desktop','Other','2026-07-08 02:02:26'),(941,'blog',NULL,NULL,'UBbuc38a3aUcx5AMKkszEseywoefvYgdV0FjLrqM',NULL,NULL,'desktop','Other','2026-07-08 02:02:26'),(942,'shop',NULL,NULL,'gXc3lkuHjvyr7XFo6caQgvg3svYAKvguuFAS9ZsG',NULL,NULL,'desktop','Other','2026-07-08 02:02:26'),(943,'blog',NULL,NULL,'ZmYhvXmU9z4D2DUFu2bIZ9O762sKJN8aatwKgmVU',NULL,NULL,'desktop','Other','2026-07-08 02:02:26'),(944,'blog',NULL,NULL,'gi49u96AQbCZTRxqznNVBmIfjzPEuOgomDf0Uxdh',NULL,NULL,'desktop','Other','2026-07-08 02:02:26'),(945,'blog',NULL,NULL,'ecqqlWKqGMTDRb4llJCcDnbZ3jaqKkFT2Uip1Oae',NULL,NULL,'desktop','Other','2026-07-08 02:02:26'),(946,'blog',NULL,NULL,'6G4e8vT7X6Ld4NsHdkL1TsgkeCAu17IM0zalPd8e',NULL,NULL,'desktop','Other','2026-07-08 02:02:27'),(947,'shop/wishlist',NULL,NULL,'AJfn76NNFGPUw3hd2DowZqEiuUO0d4ReLOf9RyEt',NULL,NULL,'desktop','Other','2026-07-08 02:02:27'),(948,'blog',NULL,NULL,'5OlIo9G9pRuHwfi2Yj5Qn7NfmdCSzIcqKZg4LoQ6',NULL,NULL,'desktop','Other','2026-07-08 02:02:27'),(949,'blog',NULL,NULL,'wfBSSi7xiz6lKBDcsnnDUBx6I80DRBanlq2cQ419',NULL,NULL,'desktop','Other','2026-07-08 02:02:27'),(950,'shop/cart',NULL,NULL,'KOM1zW6dF5l76p9MxJVjLXk2AYpZ35MnmS6GyUqB',NULL,NULL,'desktop','Other','2026-07-08 02:02:27'),(951,'shop/compare',NULL,NULL,'WVny5fMTC7Z8It7Sf47krAeSW7hzvdoIacqaBJBH',NULL,NULL,'desktop','Other','2026-07-08 02:02:27'),(952,'/',NULL,'http://safhenokhost.ir/','gTDt4PsF9vkyjLJc7h4Eq2zALtLVen8wbu07Knmu',NULL,NULL,'desktop','Other','2026-07-08 02:02:27'),(953,'search',NULL,NULL,'yu2a1EaabrtA6qAvjBLQwjRLStO067HGSeI4WIGS',NULL,NULL,'desktop','Other','2026-07-08 02:02:27'),(954,'contact',NULL,NULL,'vjV33vTCxlXjnU9ygKtiIEb5iIOQeDdQLFm4GzQc',NULL,NULL,'desktop','Other','2026-07-08 02:02:27'),(955,'register',NULL,NULL,'1mNvsc781Caqpxz43Ail4eSnSiFW8HkbnJAoAHek',NULL,NULL,'desktop','Other','2026-07-08 02:02:28'),(956,'blog/sayt-hmh-karh',NULL,NULL,'VACdi649kMV4PxJkPO00V8fIkL5CEJxgaAJlwNO5',NULL,NULL,'desktop','Other','2026-07-08 02:02:28'),(957,'blog/series/syo',NULL,NULL,'EVW2zKu7nFkDgZOHEToIAkAhm8S9BSJLrXx7ciWz',NULL,NULL,'desktop','Other','2026-07-08 02:02:28'),(958,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'Nw9KO2FdQkVcpTkXyEwW3IDfMAEt22EyGfpuS7uw',NULL,NULL,'desktop','Other','2026-07-08 02:02:28'),(959,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,'http://safhenokhost.ir/page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma','7DPfvvUrojFoCj1hMwCYO9FmSb2AQiGu6IZEBjje',NULL,NULL,'desktop','Other','2026-07-08 02:02:29'),(960,'blog/category/mhtoa',NULL,NULL,'Zu1HgPjGNnShCkqM3gTj2vdhbwwtVukNnTsvpkWO',NULL,NULL,'desktop','Other','2026-07-08 02:02:30'),(961,'blog',NULL,NULL,'sEy1S5MRFFfUFWagznmUxBqI7U4tx2P0oXiVEYzN',NULL,NULL,'desktop','Other','2026-07-08 02:02:30'),(962,'blog/series/syo',NULL,NULL,'q2dv99VqUUH72kK1TaZheYiYbyHBbJd1U908uamf',NULL,NULL,'desktop','Other','2026-07-08 02:02:30'),(963,'blog',NULL,NULL,'zo6w5WTgDJ5pT3HFZN3D7Hg3TbpozC7KwelaO0Xq',NULL,NULL,'desktop','Other','2026-07-08 02:02:30'),(964,'shop/wishlist',NULL,NULL,'kQ77XjP4biQZM4cVSmSa4bMPOCpmOSOH1551I3GG',NULL,NULL,'desktop','Other','2026-07-08 02:02:31'),(965,'shop/compare',NULL,NULL,'Oj9t1gq6lW0Emx2ORwd1fBEG6T5ii1hK9VFxIpDu',NULL,NULL,'desktop','Other','2026-07-08 02:02:31'),(966,'blog',NULL,NULL,'f2EMWWM7wl7pUBHTUhaFL1G9LFxmoGaMO4aDbh21',NULL,NULL,'desktop','Other','2026-07-08 02:02:31'),(967,'blog',NULL,NULL,'88WIFcZcGo51BHe2xhM7ymkRzgdFbAE6EnLbuNVn',NULL,NULL,'desktop','Other','2026-07-08 02:02:31'),(968,'blog',NULL,NULL,'T6YDzEbmnJnD4BLuqhEfb55PGtf4Z86dpZfp5pxx',NULL,NULL,'desktop','Other','2026-07-08 02:02:31'),(969,'blog',NULL,NULL,'Hn9KxrHKD6MdArSJudVkOmjkNHlrR4RRpIWmjpUD',NULL,NULL,'desktop','Other','2026-07-08 02:02:31'),(970,'blog',NULL,NULL,'8F5reHEw6LoWyVix4mFDILLth1W8QP91a7CYvUX3',NULL,NULL,'desktop','Other','2026-07-08 02:02:31'),(971,'blog',NULL,NULL,'eC57oV0QvudB5kasd0JpRCKADqfszKHh4SrDi2xF',NULL,NULL,'desktop','Other','2026-07-08 02:02:31'),(972,'blog',NULL,NULL,'tOQeDFWmLnJZUgETOENqcwOO3ih2HcdPOU2dQpvx',NULL,NULL,'desktop','Other','2026-07-08 02:02:32'),(973,'blog',NULL,NULL,'w6gGa492twndlO8drkN6yqNdndn6k6O9F4gCX8vf',NULL,NULL,'desktop','Other','2026-07-08 02:02:32'),(974,'login',NULL,'https://safhenokhost.ir/login','j47ayV3wwmOB2Krm7H6jDe36arOuE5tfb3rvRrvy',NULL,NULL,'desktop','Firefox','2026-07-08 03:08:58'),(975,'login',NULL,'https://safhenokhost.ir/admin/dashboard','wPFv4peb35fiJitMJX3KDVUvMggnKNzXAlg55TIr',1,NULL,'desktop','Firefox','2026-07-08 03:10:02'),(976,'login',NULL,'https://safhenokhost.ir/admin/dashboard','wPFv4peb35fiJitMJX3KDVUvMggnKNzXAlg55TIr',1,NULL,'desktop','Firefox','2026-07-08 04:27:52'),(977,'/',NULL,NULL,'CgBdE3o3QArD7re4FItroOgXWaSXRFypuuRzMw7E',NULL,NULL,'mobile','Chrome','2026-07-08 04:40:48'),(978,'login',NULL,'https://safhenokhost.ir/admin/dashboard','wPFv4peb35fiJitMJX3KDVUvMggnKNzXAlg55TIr',1,NULL,'desktop','Firefox','2026-07-08 09:27:11'),(979,'/',NULL,NULL,'K7IOtyvswYeQiZbw6sanHOixR8oc7EvpUJOp7QqU',NULL,NULL,'mobile','Chrome','2026-07-08 10:09:02'),(980,'/',NULL,NULL,'Qqzv29Gp09Pj5nAHp0Z8XWLl7CrozwDyWJXtLOZT',NULL,NULL,'desktop','Chrome','2026-07-08 10:59:28'),(981,'/',NULL,NULL,'dvdPZeCC9CzBZ0KKLdTNzviyh9e3iEe2ZKsO4jEg',NULL,NULL,'desktop','Other','2026-07-08 12:58:03'),(982,'login',NULL,'https://safhenokhost.ir/admin/inbox','wPFv4peb35fiJitMJX3KDVUvMggnKNzXAlg55TIr',1,NULL,'desktop','Firefox','2026-07-08 13:01:33'),(983,'account/resources',NULL,'https://safhenokhost.ir/admin/dashboard','wPFv4peb35fiJitMJX3KDVUvMggnKNzXAlg55TIr',1,NULL,'desktop','Firefox','2026-07-08 13:02:04'),(984,'/',NULL,NULL,'ALf5gugb1REjkBqNhgO7RIjrnWxmyxRJOvhoXLaN',NULL,NULL,'desktop','Other','2026-07-08 15:53:48'),(985,'login',NULL,'https://safhenokhost.ir/account/resources','wPFv4peb35fiJitMJX3KDVUvMggnKNzXAlg55TIr',1,NULL,'desktop','Firefox','2026-07-08 17:00:55'),(986,'/',NULL,NULL,'EakB4uR0YZVhlFdk39ulNj8fNvzK52VuwIgU2Avt',NULL,NULL,'mobile','Chrome','2026-07-08 19:05:59'),(987,'/',NULL,NULL,'6eo8IeaQNvy4LFSTSyBdrfwJ20WQicejM8ldZ9u9',NULL,NULL,'mobile','Chrome','2026-07-08 19:06:25'),(988,'/',NULL,NULL,'DLuRnW9SNU8YuXa08nVEPrKdqnybxprLDGvFeG77',NULL,NULL,'desktop','Other','2026-07-08 19:06:26'),(989,'/',NULL,NULL,'NxUmqhq4hefpOlcFUxImvms2fWP1UpP1sIb0KSLP',NULL,NULL,'mobile','Chrome','2026-07-08 20:20:59'),(990,'/',NULL,NULL,'4VptyaKf9YoSF5Do9xZJRU8nY8Zv1bI2PEcxFwlT',NULL,NULL,'desktop','Other','2026-07-08 23:41:00'),(991,'login',NULL,'https://safhenokhost.ir/account/resources','enaCkUwF90Lu5ARIfXVZHez2Z8mCmV5j4hrRaPLK',NULL,NULL,'desktop','Firefox','2026-07-09 00:13:29'),(992,'login',NULL,'https://safhenokhost.ir/admin/dashboard','wKMyc9kYB9hXUcC2PkhUgr4rPv7mtrKLSpFJ1GXx',1,NULL,'desktop','Firefox','2026-07-09 00:13:45'),(993,'login',NULL,'https://safhenokhost.ir/admin/invoices','wKMyc9kYB9hXUcC2PkhUgr4rPv7mtrKLSpFJ1GXx',1,NULL,'desktop','Firefox','2026-07-09 07:16:59'),(994,'/',NULL,NULL,'eBC0aM13fCzAwZAP8xUy0zpvUUHRV96367MFGlEl',NULL,NULL,'mobile','Chrome','2026-07-09 07:27:09'),(995,'shop',NULL,'https://safhenokhost.ir/','eBC0aM13fCzAwZAP8xUy0zpvUUHRV96367MFGlEl',NULL,NULL,'mobile','Chrome','2026-07-09 07:27:25'),(996,'login',NULL,'https://safhenokhost.ir/admin/invoices','rBa1EuJ8piIFhIBXJkukh9za16wy1Qk6RsLlDrBP',NULL,NULL,'desktop','Firefox','2026-07-09 11:32:33'),(997,'login',NULL,'https://safhenokhost.ir/admin/sms','2cRUrO3YrnR337i28bFDqVLdLWzLhjJbKZZYh2Ai',1,NULL,'desktop','Firefox','2026-07-09 11:32:47'),(998,'login',NULL,'https://safhenokhost.ir/admin/dashboard','2cRUrO3YrnR337i28bFDqVLdLWzLhjJbKZZYh2Ai',1,NULL,'desktop','Firefox','2026-07-09 13:39:19'),(999,'login',NULL,'https://safhenokhost.ir/admin/settings','2cRUrO3YrnR337i28bFDqVLdLWzLhjJbKZZYh2Ai',1,NULL,'desktop','Firefox','2026-07-09 17:10:01'),(1000,'login',NULL,'https://safhenokhost.ir/admin/sms','dAp5uXPy3l4jqEkOwXShUvJFnhyMFUA36ZuTnrlr',NULL,NULL,'desktop','Firefox','2026-07-10 04:03:47'),(1001,'login',NULL,'https://safhenokhost.ir/admin/dashboard','nimZIilJTjx0E9WWWxJ5MWEkh8uu7BKWcXughxrJ',1,NULL,'desktop','Firefox','2026-07-10 04:04:07'),(1002,'/',NULL,NULL,'1iH21yvQCvaIKOIblGP2IyG3qSjhxlzrCmkfzPzY',NULL,NULL,'desktop','Edge','2026-07-10 05:50:33'),(1003,'login',NULL,'https://safhenokhost.ir/admin/dashboard','nimZIilJTjx0E9WWWxJ5MWEkh8uu7BKWcXughxrJ',1,NULL,'desktop','Firefox','2026-07-10 06:38:55'),(1004,'/',NULL,NULL,'nimZIilJTjx0E9WWWxJ5MWEkh8uu7BKWcXughxrJ',1,NULL,'desktop','Firefox','2026-07-10 07:33:12'),(1005,'/',NULL,NULL,'J5nbp4OMNNS1XIZCtACuFKdGj5oKsQScT1itWCnz',NULL,NULL,'desktop','Chrome','2026-07-10 09:39:16'),(1006,'/',NULL,NULL,'CB8WKX8quH0lKohcE3kZsuV2pZ8MT8iTOJT3n7s9',NULL,NULL,'desktop','Chrome','2026-07-10 11:22:43'),(1007,'login',NULL,NULL,'rA8ohN3CaaAxaToKRTsF36HXfVJHYgLuvNAQ9XFp',NULL,NULL,'desktop','Firefox','2026-07-10 15:27:02'),(1008,'login',NULL,'https://safhenokhost.ir/admin/dashboard','BJFTJeeWMF5W4a53N4vDCA9q2swCAQeW8ULBtQaM',1,NULL,'desktop','Firefox','2026-07-10 15:27:16'),(1009,'/',NULL,'http://safhenokhost.ir/','BUdDRMq5JgU19qlr3ojPcrHzZdZe33P3vRrYQjMW',NULL,NULL,'desktop','Firefox','2026-07-10 21:00:25'),(1010,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'EDRb9qeGKIyMb1xUL1WOW5LbNONyxSHbZxyZS6wX',NULL,NULL,'desktop','Firefox','2026-07-10 21:00:26'),(1011,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'8Yb1fYZLLYZCP8DRKIW9nuGZpZyLG2w9QlFI6D7k',NULL,NULL,'desktop','Firefox','2026-07-10 21:00:27'),(1012,'blog/sayt-hmh-karh',NULL,NULL,'Ay8a8qelyLBFOiySHGuS4dfNo81hKsKlI4qYjpHo',NULL,NULL,'desktop','Firefox','2026-07-10 21:00:27'),(1013,'/',NULL,'http://safhenokhost.ir','8sNyNE5fZ9Zt99UhSHhlpOFyKzAg9DPi4v9ZmVM2',NULL,NULL,'desktop','Safari','2026-07-11 00:54:04'),(1014,'/',NULL,'http://safhenokhost.ir','XnxOk2cjYU6Ci1sSUchYCp76wX9yiWscKFA16ujT',NULL,NULL,'desktop','Chrome','2026-07-11 01:19:49'),(1015,'/',NULL,NULL,'sFqCF1fW9xTq9Wy7EFRJIXHRxn0PHMlc9eabKBJe',NULL,NULL,'mobile','Chrome','2026-07-11 02:26:44'),(1016,'login',NULL,'https://safhenokhost.ir/login','WkklciJwwtCdMXQ90lVGiKcyg5gj7mv2JteSaNvj',NULL,NULL,'desktop','Firefox','2026-07-11 02:36:10'),(1017,'login',NULL,'https://safhenokhost.ir/login','FK10o9aMsdrP5fGTBzbFHALYAP86HGZQ1i50ffnX',NULL,NULL,'desktop','Firefox','2026-07-11 08:25:11'),(1018,'/',NULL,NULL,'UtT7zRzC2iFhaP5DVAuly4Ucm7KZUuBctDlxQPrx',NULL,NULL,'desktop','Chrome','2026-07-11 08:34:47'),(1019,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'UtT7zRzC2iFhaP5DVAuly4Ucm7KZUuBctDlxQPrx',NULL,NULL,'desktop','Chrome','2026-07-11 08:34:48'),(1020,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'UtT7zRzC2iFhaP5DVAuly4Ucm7KZUuBctDlxQPrx',NULL,NULL,'desktop','Chrome','2026-07-11 08:34:48'),(1021,'contact',NULL,NULL,'UtT7zRzC2iFhaP5DVAuly4Ucm7KZUuBctDlxQPrx',NULL,NULL,'desktop','Chrome','2026-07-11 08:34:50'),(1022,'login',NULL,NULL,'s2sn7IQ50y8WwtNMdnAHQYb4aNFtY4ARIU29UD2Y',NULL,NULL,'desktop','Firefox','2026-07-11 11:10:40'),(1023,'login',NULL,'https://safhenokhost.ir/admin/dashboard','8T6jutdCe9ZTaS5yf7s04V1BKCCR7r6iKUeTp7ZW',1,NULL,'desktop','Firefox','2026-07-11 11:13:41'),(1024,'/',NULL,NULL,'SYadQUxMKBIvxS5ZSuaqGDucqxxgnzTKZW6YDeaU',NULL,NULL,'mobile','Chrome','2026-07-11 16:38:04'),(1025,'/',NULL,NULL,'C9fMeLvlwFyjovV3dAay6COasLKBHQxUMvDjz8P3',NULL,NULL,'mobile','Chrome','2026-07-11 18:05:20'),(1026,'blog',NULL,'https://safhenokhost.ir/','C9fMeLvlwFyjovV3dAay6COasLKBHQxUMvDjz8P3',NULL,NULL,'mobile','Chrome','2026-07-11 18:05:34'),(1027,'blog/category/mhtoa',NULL,'https://safhenokhost.ir/blog','C9fMeLvlwFyjovV3dAay6COasLKBHQxUMvDjz8P3',NULL,NULL,'mobile','Chrome','2026-07-11 18:05:37'),(1028,'blog/sayt-hmh-karh',NULL,'https://safhenokhost.ir/blog/category/mhtoa','C9fMeLvlwFyjovV3dAay6COasLKBHQxUMvDjz8P3',NULL,NULL,'mobile','Chrome','2026-07-11 18:05:40'),(1029,'/',NULL,'http://safhenokhost.ir/','kxb0CFnlv0G70NfPNx390BiAOjo8ys6GyDmq4ZVw',NULL,NULL,'desktop','Chrome','2026-07-12 00:01:07'),(1030,'/',NULL,NULL,'KXWWza6QYHqdK0n9AaiOwbQxGtBNu1pXFHxfklop',NULL,NULL,'desktop','Chrome','2026-07-12 16:10:47'),(1031,'/',NULL,'http://safhenokhost.ir/','IFTfcoyme8JG5qj4MZIRTuOJdjSj4cdjx6qWXTAN',NULL,NULL,'mobile','Safari','2026-07-12 16:11:14'),(1032,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'ZOYnGBlbyPcOAurqe7zltGhlUXJJx8Zo6Wr8ez5q',NULL,NULL,'mobile','Safari','2026-07-12 16:11:14'),(1033,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'fuK4QNwZmaJ0YEEvW0MBQOWBJlvnee4ggjSGFfra',NULL,NULL,'mobile','Safari','2026-07-12 16:11:15'),(1034,'blog/sayt-hmh-karh',NULL,NULL,'rEsj7WACr7Yh9IGEnR528cxoe9XgqGtX1Q2NzPhi',NULL,NULL,'mobile','Safari','2026-07-12 16:11:16'),(1035,'/',NULL,NULL,'20cVW0OmXqoHUa8CfjvzHJWWGVCA1zMtuS8f1fvV',NULL,NULL,'desktop','Firefox','2026-07-12 17:10:36'),(1036,'login',NULL,'https://safhenokhost.ir/','20cVW0OmXqoHUa8CfjvzHJWWGVCA1zMtuS8f1fvV',NULL,NULL,'desktop','Firefox','2026-07-12 17:10:49'),(1037,'login',NULL,'https://safhenokhost.ir/admin/dashboard','aNbITA4O6j9EdTubcWjbpAH5jwdDKm3nTISK9fbd',1,NULL,'desktop','Firefox','2026-07-12 17:11:11'),(1038,'/',NULL,NULL,'udze8Qzowiec7WcxXW2pUDsBG8Pdj0nsGv0Tr155',NULL,NULL,'mobile','Chrome','2026-07-12 20:36:04'),(1039,'/',NULL,NULL,'iAU2DfW0J7X60b6udUBULOAHvG8lT47emvaZvM5N',NULL,NULL,'mobile','Chrome','2026-07-12 21:51:04'),(1040,'/',NULL,NULL,'m81JkS470xTe1qPTg0n1KZDzyNW7zIHqJTIlXV69',NULL,NULL,'desktop','Other','2026-07-13 01:12:15'),(1041,'/',NULL,NULL,'MP1oAvsRPbSOWi1iTzzTweZ4kudANYuHD3pv9MoC',NULL,NULL,'desktop','Chrome','2026-07-13 04:08:03'),(1042,'/',NULL,NULL,'Oxr2KI9NvVvWJbnsvC6ARd3nPAsmj9jy5W63X11Z',NULL,NULL,'desktop','Firefox','2026-07-13 05:21:47'),(1043,'blog',NULL,'https://safhenokhost.ir/','Oxr2KI9NvVvWJbnsvC6ARd3nPAsmj9jy5W63X11Z',NULL,NULL,'desktop','Firefox','2026-07-13 05:21:54'),(1044,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,'https://safhenokhost.ir/blog','Oxr2KI9NvVvWJbnsvC6ARd3nPAsmj9jy5W63X11Z',NULL,NULL,'desktop','Firefox','2026-07-13 05:21:59'),(1045,'blog/sayt-hmh-karh',NULL,'https://safhenokhost.ir/blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd','Oxr2KI9NvVvWJbnsvC6ARd3nPAsmj9jy5W63X11Z',NULL,NULL,'desktop','Firefox','2026-07-13 05:22:04'),(1046,'shop',NULL,'https://safhenokhost.ir/','Oxr2KI9NvVvWJbnsvC6ARd3nPAsmj9jy5W63X11Z',NULL,NULL,'desktop','Firefox','2026-07-13 05:23:27'),(1047,'/',NULL,NULL,'9MFrMq1iZIdn7hZ0rQK2Nomeuf2xHfGq7EUm7vAc',NULL,NULL,'desktop','Other','2026-07-13 05:51:53'),(1048,'/',NULL,NULL,'Bh9r7xGcuYV4PXZxDpDJ52Sxg4eBf1nZwhXRxWQn',NULL,NULL,'desktop','Chrome','2026-07-13 05:58:55'),(1049,'/',NULL,NULL,'Oxr2KI9NvVvWJbnsvC6ARd3nPAsmj9jy5W63X11Z',NULL,NULL,'desktop','Firefox','2026-07-13 06:10:51'),(1050,'/',NULL,NULL,'2zQj4tBu8IeSwDACzctGEQSAZ3qMM1UE0IPp8kfy',NULL,NULL,'mobile','Chrome','2026-07-13 08:14:24'),(1051,'/',NULL,NULL,'7BDr7Cy10ei8N9s4xOjq2EKz8mQBqMXXbtRUYFxY',NULL,NULL,'desktop','Chrome','2026-07-13 10:37:04'),(1052,'/',NULL,NULL,'FSKK7w4vt0iMMnmhLMAmhn8Ugrqipk136QiN5tvf',NULL,NULL,'mobile','Chrome','2026-07-13 11:25:25'),(1053,'login',NULL,'https://safhenokhost.ir/admin/currency-reform','U5DavBrR5hhiP2Do2gYD0oNDp1Qax0wyr6WvRxfO',NULL,NULL,'desktop','Firefox','2026-07-13 12:03:55'),(1054,'login',NULL,'https://safhenokhost.ir/admin/dashboard','gKjlup65jg2yXotO0ou7k0TG865e9Y1sgt0RAjKJ',1,NULL,'desktop','Firefox','2026-07-13 12:59:37'),(1055,'/',NULL,NULL,'dDtYXFI7wEvQ1frj2WwDxwTeT8cIwIUPHSGURRsf',NULL,NULL,'mobile','Chrome','2026-07-13 21:46:41'),(1056,'/',NULL,NULL,'LZ9VUrzYZ3VEXJcKcnBusho9Dyv0b9e7qahRWrk5',NULL,NULL,'mobile','Chrome','2026-07-13 23:01:41'),(1057,'/',NULL,'https://duckduckgo.com/','RZ8OiFZ3blOSPMVHRzx5a9P5uUWGK4e1HwCm4qxo',NULL,NULL,'desktop','Chrome','2026-07-13 23:05:38'),(1058,'/',NULL,NULL,'sANeUSXgnbYHvRPYH2zHoBnHuYxvu2SYQEnjGf7I',NULL,NULL,'mobile','Safari','2026-07-13 23:07:49'),(1059,'login',NULL,'https://safhenokhost.ir/login','H40ISNQ98CrQzqQ4JFT9c2MXI65lFDJkcST5aOAr',NULL,NULL,'desktop','Firefox','2026-07-14 00:23:24'),(1060,'login',NULL,'https://safhenokhost.ir/admin/dashboard','a3wmW6SGx8N19sh7l4cYiL8mxTTeBl8PPUzKEX8L',1,NULL,'desktop','Firefox','2026-07-14 00:24:04'),(1061,'/',NULL,NULL,'raJT4HBMdNu1m3chf7ORFOgYnL2agob5km0cSLb1',NULL,NULL,'desktop','Firefox','2026-07-14 00:58:15'),(1062,'/',NULL,NULL,'wathSItzBhnl9xeNCWv3XQrQSRl07oFraemFU3ky',NULL,NULL,'desktop','Firefox','2026-07-14 04:59:46'),(1063,'/',NULL,NULL,'JwvRn64Z1S8Nez3Al9h4JIkY4WookvRszUXU5WQk',NULL,NULL,'desktop','Chrome','2026-07-14 05:12:25'),(1064,'/',NULL,NULL,'LZENHZxSDEt6xmuwe7ie2JHsdOexkKD6VHo9MNe1',NULL,NULL,'desktop','Chrome','2026-07-14 05:27:40'),(1065,'/',NULL,NULL,'zdTxiTqTTy592axFguh5Er6Beaqx15kc8O1A2kAu',NULL,NULL,'desktop','Firefox','2026-07-14 05:42:42'),(1066,'/',NULL,NULL,'tICdxHjR13FtYrqhG2QgwgK2TKuuFTqYjEDCXyKv',NULL,NULL,'desktop','Firefox','2026-07-14 09:16:05'),(1067,'/',NULL,NULL,'ehLZlfIlM9CE9ww8MPeAn3tSH8MtRJDQK7gCvFfz',NULL,NULL,'desktop','Chrome','2026-07-14 09:16:06'),(1068,'/',NULL,NULL,'yLFN5OuHkulvzyUKNVEEpRSu03fFFReITqLuAzVY',NULL,NULL,'desktop','Chrome','2026-07-14 09:32:19'),(1069,'/',NULL,NULL,'WJyOWdD0mnCHk7ZbewKAtpypTu1sDOtVbaCT9NGf',NULL,NULL,'desktop','Chrome','2026-07-14 11:02:17'),(1070,'/',NULL,NULL,'S11ZGpxb61nZ3RpxQYOFr5W4o5o4jOR4sgSAcKnB',NULL,NULL,'desktop','Chrome','2026-07-14 11:02:20'),(1071,'/',NULL,NULL,'B52VAqyI6CDokv37BgQm3YV8QkgfZBdrzUfkSyDi',NULL,NULL,'desktop','Chrome','2026-07-14 11:02:22'),(1072,'/',NULL,'http://safhenokhost.ir/','yd2xrSIrGmH8cWtWota9Ja28Ivb5tWP5inAJn2Eu',NULL,NULL,'mobile','Safari','2026-07-14 13:22:40'),(1073,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'KFXUvkXtDHlgur2vsIZaRyzw4YelB0tPaeI0DodX',NULL,NULL,'mobile','Safari','2026-07-14 13:22:41'),(1074,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'zA67ZIJ8c55yqTN5BZMHYe8xC2GKJqwOxQkKtHWq',NULL,NULL,'mobile','Safari','2026-07-14 13:22:42'),(1075,'blog/sayt-hmh-karh',NULL,NULL,'lXrL90TiLCWCZiyLpQuN7wmsSUShHLGWhZxkKAGR',NULL,NULL,'mobile','Safari','2026-07-14 13:22:42'),(1076,'/',NULL,NULL,'0a9Yxw24yThvW8BJjVMx9wFJoMnMfmPTQ8wCdq59',NULL,NULL,'desktop','Other','2026-07-14 14:05:38'),(1077,'/',NULL,NULL,'FuXL49GQaU5csNFwb9yoq6Av2qEnRbTKImVU9aQt',NULL,NULL,'desktop','Other','2026-07-14 14:05:43'),(1078,'login',NULL,'https://safhenokhost.ir/admin','V9EtbQyA0l2oL0ONzch3D3FYuEEyjafp1eFoy0Pn',NULL,NULL,'desktop','Other','2026-07-14 14:05:44'),(1079,'login',NULL,NULL,'pDJjN1042VrsMgXdMvqeFeIWBWLCAqXRSkC4ENFq',NULL,NULL,'desktop','Other','2026-07-14 14:05:44'),(1080,'sitemap.xml',NULL,NULL,'DJcQcTDTcoZx42K59cS5OIV4q9C5dKPfuvk72GkD',NULL,NULL,'desktop','Other','2026-07-14 14:05:46'),(1081,'/',NULL,NULL,'lzSck3Io6kWPhG9sGAQZ4EOrd5VPwNSEozx5uycv',NULL,NULL,'mobile','Chrome','2026-07-14 14:29:40'),(1082,'/',NULL,NULL,'GRTsiwb28z8qP0ZyUuFNllnBOjRdiRD5kBtnsNhE',NULL,NULL,'desktop','Chrome','2026-07-14 15:36:57'),(1083,'/',NULL,NULL,'ofBnE1mGquharl1MGe4LYC2Gj1nqdHaDDkBQS731',NULL,NULL,'desktop','Chrome','2026-07-14 15:36:58'),(1084,'/',NULL,NULL,'ZNY7XLrRyO6SjqFk9muA5HqFOJReEjaruCHvSsah',NULL,NULL,'mobile','Chrome','2026-07-14 17:48:36'),(1085,'/',NULL,NULL,'jz3xtVI36ejMKlf3eDzk7KCdMVFSGFwmGYPuC51N',NULL,NULL,'desktop','Chrome','2026-07-14 18:19:44'),(1086,'/',NULL,NULL,'pgzl45DrPE5LywrZhelBOdWON7B87xs6lvWOtZzY',NULL,NULL,'desktop','Chrome','2026-07-14 19:27:16'),(1087,'/',NULL,NULL,'WmEn7rsd2h0Yd8k2aV80OxBF8ZAsPwD9BGPImJZZ',NULL,NULL,'desktop','Firefox','2026-07-14 19:32:09'),(1088,'/',NULL,NULL,'98jOWTqdopz3hUTRUm0t2TQHRUL4eczvNCxNIzsC',NULL,NULL,'desktop','Chrome','2026-07-14 22:31:29'),(1089,'/',NULL,NULL,'QpxZ4Cbsuo72rqRKxN9CImzoTRvXGglCDC4sUkMR',NULL,NULL,'desktop','Chrome','2026-07-15 01:09:38'),(1090,'/',NULL,NULL,'aN9WeOCtHvoK0a6VUV79hY3Jn7oVffGG7o276y3A',NULL,NULL,'desktop','Firefox','2026-07-15 01:25:24'),(1091,'/',NULL,NULL,'HCqvdKmK1gUf4QVAkEg4HbXJzFYobRXmbcxvFVyv',NULL,NULL,'desktop','Firefox','2026-07-15 04:49:05'),(1092,'shop',NULL,'https://safhenokhost.ir/','HCqvdKmK1gUf4QVAkEg4HbXJzFYobRXmbcxvFVyv',NULL,NULL,'desktop','Firefox','2026-07-15 04:54:06'),(1093,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,'https://safhenokhost.ir/','HCqvdKmK1gUf4QVAkEg4HbXJzFYobRXmbcxvFVyv',NULL,NULL,'desktop','Firefox','2026-07-15 04:54:15'),(1094,'blog/sayt-hmh-karh',NULL,'https://safhenokhost.ir/page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma','HCqvdKmK1gUf4QVAkEg4HbXJzFYobRXmbcxvFVyv',NULL,NULL,'desktop','Firefox','2026-07-15 04:54:18'),(1095,'blog',NULL,'https://safhenokhost.ir/blog/sayt-hmh-karh','HCqvdKmK1gUf4QVAkEg4HbXJzFYobRXmbcxvFVyv',NULL,NULL,'desktop','Firefox','2026-07-15 04:54:32'),(1096,'/',NULL,NULL,'ys8ORCchux2fw21wuE1Dxhmb27cNOAZBr7qNnCIQ',NULL,NULL,'desktop','Chrome','2026-07-15 08:08:59'),(1097,'/',NULL,NULL,'8WINIH8fci9nIdcVhVG5Lf8FBkA0hjpVrN7RAaMb',NULL,NULL,'desktop','Chrome','2026-07-15 08:55:43'),(1098,'login',NULL,NULL,'2dE8TvdagciuZP2VgDDSrAUBjonlniKo0XRnIlOC',NULL,NULL,'desktop','Firefox','2026-07-15 15:57:12'),(1099,'login',NULL,'https://safhenokhost.ir/admin/dashboard','wk2jcjXTtxyPKevMuwLEE0pTQdDPtADv6ophd2Q5',1,NULL,'desktop','Firefox','2026-07-15 15:57:44'),(1100,'/',NULL,NULL,'kMLs595sJ6B3DCK2xHfhBbL7f8rPuOYRVSMEmRUz',NULL,NULL,'desktop','Chrome','2026-07-15 18:08:50'),(1101,'/',NULL,NULL,'KtvBlhuZaypkxIakGiyJZOSPNE3uPgZiB0AqtoFB',NULL,NULL,'desktop','Other','2026-07-15 20:07:13'),(1102,'contact',NULL,NULL,'KtvBlhuZaypkxIakGiyJZOSPNE3uPgZiB0AqtoFB',NULL,NULL,'desktop','Other','2026-07-15 20:07:13'),(1103,'/',NULL,NULL,'SxvIiEpPoSpiygg2vQT0pBIcWsh6wwqiAFaw03xY',NULL,NULL,'desktop','Other','2026-07-15 21:50:25'),(1104,'/',NULL,NULL,'btOef2jIdKHHnXvl8cZzUhS1VAdeNLePz4ldbqHr',NULL,NULL,'desktop','Other','2026-07-15 21:50:28'),(1105,'/',NULL,NULL,'pqojxV6py0izTzYMJJFkuEYriljgVJpioZR2S3Gp',NULL,NULL,'desktop','Other','2026-07-15 21:50:32'),(1106,'/',NULL,NULL,'DZXXCuSAa61g3FQpbegtFGXtToqNd6i9fAOf3CRq',NULL,NULL,'desktop','Other','2026-07-16 03:46:58'),(1107,'/',NULL,NULL,'3sYK57258cEmBR2fUrxVSvp1e4fQbPEToFdJLWWK',NULL,NULL,'desktop','Other','2026-07-16 04:26:57'),(1108,'/',NULL,NULL,'upSLfXqahnGWQN8f5bmz1cgT7xjiOTqlfnjhimma',NULL,NULL,'desktop','Other','2026-07-16 05:11:48'),(1109,'/',NULL,NULL,'y1oYTl0HdglfGUprPY0Aygcewxk95ZEEbsxj6A0s',NULL,NULL,'desktop','Other','2026-07-16 05:55:33'),(1110,'/',NULL,NULL,'iLX6U3SoiO5iaFFoFSKHiJhdtZEM4OFUp6fm5yBm',NULL,NULL,'desktop','Other','2026-07-16 06:38:25'),(1111,'/',NULL,NULL,'fg8Q9BkaKx5MNTWMG2Hu8h1ru6mru9Erl8AZYHY6',NULL,NULL,'desktop','Other','2026-07-16 07:21:42'),(1112,'/',NULL,NULL,'nMgqLe5rCPj1L7SbI3lqwADswRAjbxrXOxKkXdjo',NULL,NULL,'desktop','Other','2026-07-16 08:04:42'),(1113,'/',NULL,NULL,'3ntwJwwibKSMeX8ZLSqLxuNBmEiKx9SQBf3pH4h2',NULL,NULL,'desktop','Other','2026-07-16 08:47:16'),(1114,'/',NULL,NULL,'UjT95hJKZRsZNmFuY4tMqAt8F2nVd5lTrHUHXPPV',NULL,NULL,'desktop','Other','2026-07-16 09:29:51'),(1115,'/',NULL,'http://safhenokhost.ir/','EWaABKdHV1yDROImCT0iVqPIhezf7bEMavFp9bHm',NULL,NULL,'desktop','Chrome','2026-07-16 10:10:26'),(1116,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'bA5hbKrGb3ulM7ScIByhh432e8fMageBZ5kHOhaY',NULL,NULL,'desktop','Chrome','2026-07-16 10:10:37'),(1117,'blog/sayt-hmh-karh',NULL,NULL,'zbsGIEMd2V9nRcEkytHLjef1ZPMQlVx6cU2oTkMq',NULL,NULL,'desktop','Chrome','2026-07-16 10:10:38'),(1118,'/',NULL,NULL,'rHgeh6kBrbhFE3SYLZcyH7j9hPj8u3zJyFBfhJyH',NULL,NULL,'desktop','Other','2026-07-16 10:12:43'),(1119,'/',NULL,NULL,'RPRoMNiklgk272d4yHS0HBm3pMWyYihxB1ncRGAD',NULL,NULL,'desktop','Other','2026-07-16 10:55:56'),(1120,'/',NULL,NULL,'zHycxP3CtTSm2h9P56ypfsDE4dOFVbEuos9N01SE',NULL,NULL,'mobile','Chrome','2026-07-16 11:36:29'),(1121,'/',NULL,NULL,'vaMf7HiSUG23RTBhRyUOpgLoYaWKWwcSV9hewWMZ',NULL,NULL,'desktop','Other','2026-07-16 11:38:25'),(1122,'/',NULL,NULL,'4oCmeTo4vYyN6lh3t6Rv5Gi9IGpeoE6fmNypUkS0',NULL,NULL,'desktop','Firefox','2026-07-16 12:11:00'),(1123,'login',NULL,NULL,'4oCmeTo4vYyN6lh3t6Rv5Gi9IGpeoE6fmNypUkS0',NULL,NULL,'desktop','Firefox','2026-07-16 12:11:26'),(1124,'login',NULL,'https://safhenokhost.ir/admin/dashboard','wUzjsSslsUpquP6HJcwasY7bA1s50obSGiO3aLlx',1,NULL,'desktop','Firefox','2026-07-16 12:11:45'),(1125,'/',NULL,NULL,'sbdVexXJ7rwQCoJyRltqBFP8GDd2yrJTKSer5FXP',NULL,NULL,'desktop','Other','2026-07-16 12:21:49'),(1126,'/',NULL,NULL,'d7teBh3oOze9rwLyV9tpYAOmBSTaeG87ycxnMO5y',NULL,NULL,'desktop','Other','2026-07-16 13:06:24'),(1127,'/',NULL,NULL,'kaxM4D1PcEzmsrTlRHrCTMXw6on1Cojc8EoKjlHd',NULL,NULL,'desktop','Other','2026-07-16 13:49:21'),(1128,'login',NULL,'https://safhenokhost.ir/admin/inbox','wUzjsSslsUpquP6HJcwasY7bA1s50obSGiO3aLlx',1,NULL,'desktop','Firefox','2026-07-16 14:21:57'),(1129,'/',NULL,NULL,'LucBbNO6RwGzPDk7ggfMHkiKQD2FMIoqvKWI4AV9',NULL,NULL,'desktop','Other','2026-07-16 14:32:48'),(1130,'/',NULL,NULL,'DoR35Moa0Y8nYGpIWlhrVIpGRKhc9ZcabH5tYHmI',NULL,NULL,'desktop','Other','2026-07-16 15:16:31'),(1131,'/',NULL,NULL,'ET3uEiElpZd80jc4txsrIWObyrykC99RmKvOAeNB',NULL,NULL,'desktop','Other','2026-07-16 16:01:01'),(1132,'/',NULL,NULL,'qfQ1WeLJW5xF6UG9thyqHxN1qOQCDi6IU0Es1BZ6',NULL,NULL,'desktop','Other','2026-07-16 16:46:29'),(1133,'/',NULL,NULL,'wDXNS01X4jV0NIyxZHshEESPGchhVsU1MVqLBM2Y',NULL,NULL,'desktop','Other','2026-07-16 17:34:00'),(1134,'/',NULL,NULL,'SGcOgYxfv6agzHH4bJgjtJCC6swx3c0xyB0dso0b',NULL,NULL,'desktop','Chrome','2026-07-16 17:43:50'),(1135,'contact',NULL,NULL,'SGcOgYxfv6agzHH4bJgjtJCC6swx3c0xyB0dso0b',NULL,NULL,'desktop','Chrome','2026-07-16 17:43:50'),(1136,'/',NULL,NULL,'QPgi6VWPU5kZes55AuZ9X6hND5zNjDxHTOYfFj6C',NULL,NULL,'desktop','Other','2026-07-16 18:19:47'),(1137,'/',NULL,NULL,'WOTrFnjlFUs4LDesXDTEqr5ZZCCBL7MX6i0bJ1pT',NULL,NULL,'desktop','Other','2026-07-16 19:04:49'),(1138,'/',NULL,NULL,'WXUQMnD3xGyYOmqTyluiwgPRex7ktNFuyebJcMls',NULL,NULL,'desktop','Other','2026-07-16 19:48:30'),(1139,'/',NULL,NULL,'7TrX2pnpbtYzMWUOMyFEZlAd9pPmwoW7RBXiMbZB',NULL,NULL,'desktop','Other','2026-07-16 20:32:42'),(1140,'/',NULL,NULL,'zeJGI19yoExTAG0Niu5e9kgtmRiHokLo29Hg3S7N',NULL,NULL,'desktop','Other','2026-07-16 21:17:03'),(1141,'/',NULL,NULL,'FUijO3wsBagrGWw5d1ycbZEqZVro9N2hLnWODkZf',NULL,NULL,'desktop','Other','2026-07-16 21:59:49'),(1142,'/',NULL,NULL,'0ApIzl9yHPhIpct1ULjIwAx7IXxrBt0T9zrV4OvI',NULL,NULL,'desktop','Other','2026-07-16 22:42:07'),(1143,'/',NULL,NULL,'2JPix6u8PHyUK84UUozu1B6YQ5lRD8eOOduZ54Of',NULL,NULL,'desktop','Other','2026-07-16 23:25:11'),(1144,'/',NULL,NULL,'iOifnlMOGHNcai6rddVIpEIoJPCIpRHAQWoYZfny',NULL,NULL,'desktop','Other','2026-07-17 00:08:49'),(1145,'/',NULL,NULL,'a1WHa7S7WUfbl9J3hOv3u8SVhzZ4M0mOU2rWdBcx',NULL,NULL,'desktop','Other','2026-07-17 00:50:33'),(1146,'/',NULL,NULL,'QDXdb4pvttXRXADE26B4gup1CTW5wHeCDnP30NZ2',NULL,NULL,'desktop','Other','2026-07-17 01:34:41'),(1147,'/',NULL,NULL,'XqBCBKVndQikyMsKNjoJ8BIHErbQ4dyMtB6cRNRf',NULL,NULL,'desktop','Chrome','2026-07-17 01:36:28'),(1148,'/',NULL,NULL,'ue0zP2ZgJYY0dC5P6zYk1zNEBlmfa9cgKDVsMjK8',NULL,NULL,'desktop','Other','2026-07-17 02:18:39'),(1149,'/',NULL,NULL,'jgU16BY9cNWt0b4RfSgixfNl8Y33nE9wWYhrI9AO',NULL,NULL,'desktop','Other','2026-07-17 03:02:22'),(1150,'login',NULL,'https://safhenokhost.ir/admin/license','guwkexyHvTdVaBbYqCjV1xvyVw95Y6hW5HxKGqTQ',NULL,NULL,'desktop','Firefox','2026-07-17 03:31:32'),(1151,'login',NULL,'https://safhenokhost.ir/admin/dashboard','pDfJ9KDC4JCMd17hoCXyHfmBQGiPOGhHEio8ojeS',1,NULL,'desktop','Firefox','2026-07-17 03:31:53'),(1152,'/',NULL,NULL,'Fy82udn70cRIWSlQAqIZMwuL8TAXwr5xuXZSZ64J',NULL,NULL,'desktop','Other','2026-07-17 03:44:51'),(1153,'/',NULL,NULL,'1uocrXE6hNrKzFk8ybIBVNjVoPeYGnPaIQNbiFDJ',NULL,NULL,'desktop','Other','2026-07-17 04:28:21'),(1154,'/',NULL,NULL,'AV9Dpu8TVdk6KOu6jb1Df92PndnaxYGkHQ6irRTg',NULL,NULL,'desktop','Other','2026-07-17 05:12:21'),(1155,'/',NULL,NULL,'SHk4Cl2Wua8aW8PQ5UY81yAD5VtQ8DdcQ2hz5dx3',NULL,NULL,'desktop','Other','2026-07-17 05:55:36'),(1156,'/',NULL,NULL,'4xnDyxqfjJhXrozDCXgBAYycL39eEaFVsx8tWs3K',NULL,NULL,'desktop','Other','2026-07-17 06:38:54'),(1157,'/',NULL,NULL,'76czcncHTpGJzZJstqJJVs34mhskgvDzTQtRzUyx',NULL,NULL,'desktop','Other','2026-07-17 07:23:25'),(1158,'/',NULL,NULL,'WCUkrArN7nzuEXdHNqZ6mI6dVenJ15Piwn1KksCZ',NULL,NULL,'desktop','Other','2026-07-17 08:07:44'),(1159,'/',NULL,NULL,'MxSI7DuNh2zE3D3tyu8PHrfcP1w8r3RNOSHnWM0v',NULL,NULL,'desktop','Other','2026-07-17 08:51:03'),(1160,'/',NULL,NULL,'QhmWthL8QWGvUhbzVQRXsT6gvYxcGyFLDVllyyVA',NULL,NULL,'desktop','Other','2026-07-17 09:34:41'),(1161,'/',NULL,NULL,'PdEykkcZdQWFjIsGSV5mBIf3UWk1sMEsE2bgHjfE',NULL,NULL,'desktop','Other','2026-07-17 10:19:28'),(1162,'/',NULL,NULL,'N4aIXh8xBfeZhybj7sevEOiRwp3oQ2TZMrFHoaeh',NULL,NULL,'desktop','Other','2026-07-17 11:04:07'),(1163,'/',NULL,NULL,'4dyHsLt3V6SrTxesCJjSU6tqOm4gxO2wA8fyTq9Q',NULL,NULL,'desktop','Other','2026-07-17 11:46:32'),(1164,'/',NULL,NULL,'KN8PAJOzowrpCO0LKU7K3ITxA2sedgvfPLpo2meo',NULL,NULL,'desktop','Other','2026-07-17 12:29:07'),(1165,'/',NULL,NULL,'1T1ipEGvTUKOCjtgplG9xkQZMaIPFVJuczt2eBpo',NULL,NULL,'desktop','Other','2026-07-17 13:13:13'),(1166,'login',NULL,NULL,'aegQJYHcP7hnOhDhbqkMkDCh5O7ngBiLwMyPuX7m',NULL,NULL,'desktop','Firefox','2026-07-17 14:00:28'),(1167,'login',NULL,'https://safhenokhost.ir/admin/dashboard','2SlzKLJ0eleJ9JGlndLuGDNbiBLcyAdEpxeLMRgW',1,NULL,'desktop','Firefox','2026-07-17 14:20:33'),(1168,'/',NULL,NULL,'GuT1quKRJL7BC03lmTSUUADPNsXqlsg4fm7X8LPI',NULL,NULL,'desktop','Other','2026-07-17 14:42:03'),(1169,'/',NULL,NULL,'aTfRF0xClvJCfsHbeJXHrfsEEU6jaMIcWZLZIGdw',NULL,NULL,'desktop','Other','2026-07-17 15:27:24'),(1170,'/',NULL,NULL,'Eik7zIxD4xZpjZCRVVcXlIKLH7DaRIxZtYuHzWM4',NULL,NULL,'desktop','Other','2026-07-17 16:11:55'),(1171,'/',NULL,NULL,'1mVG2CxRelV8gCbDGjeHMEiP8jyjJnoOwEd4KwAH',NULL,NULL,'desktop','Other','2026-07-17 16:56:26'),(1172,'login',NULL,'https://safhenokhost.ir/admin/dashboard','2SlzKLJ0eleJ9JGlndLuGDNbiBLcyAdEpxeLMRgW',1,NULL,'desktop','Firefox','2026-07-17 17:37:52'),(1173,'/',NULL,NULL,'J8y2skwRkDIuX9uuKIWBlpXyMFVaJO6mX5Rdeq2U',NULL,NULL,'desktop','Other','2026-07-17 17:41:23'),(1174,'/',NULL,NULL,'nwfnIET8R2mQBWwYHTnE436HqywswmGjmlgIZlQt',NULL,NULL,'desktop','Other','2026-07-17 18:26:03'),(1175,'/',NULL,NULL,'FqG0sHTJvujH6XPN3nmMEGAJw5SucCJNnlujQNgZ',NULL,NULL,'desktop','Other','2026-07-17 19:10:04'),(1176,'/',NULL,NULL,'IfkeyXQ1xF76f6hUXKTLUE3zrR1NaKrnLZzHg54u',NULL,NULL,'desktop','Chrome','2026-07-17 19:10:41'),(1177,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'IfkeyXQ1xF76f6hUXKTLUE3zrR1NaKrnLZzHg54u',NULL,NULL,'desktop','Chrome','2026-07-17 19:10:54'),(1178,'blog',NULL,NULL,'IfkeyXQ1xF76f6hUXKTLUE3zrR1NaKrnLZzHg54u',NULL,NULL,'desktop','Firefox','2026-07-17 19:11:00'),(1179,'shop/cart',NULL,NULL,'IfkeyXQ1xF76f6hUXKTLUE3zrR1NaKrnLZzHg54u',NULL,NULL,'desktop','Firefox','2026-07-17 19:11:12'),(1180,'search',NULL,NULL,'IfkeyXQ1xF76f6hUXKTLUE3zrR1NaKrnLZzHg54u',NULL,NULL,'mobile','Chrome','2026-07-17 19:11:17'),(1181,'login',NULL,NULL,'IfkeyXQ1xF76f6hUXKTLUE3zrR1NaKrnLZzHg54u',NULL,NULL,'desktop','Chrome','2026-07-17 19:11:19'),(1182,'/',NULL,'https://www.google.com/search?q=safhenokhost','VImFEygDsuPl2zPnNt2dNhriy2oL4qxUH7FBoG0N',NULL,NULL,'desktop','Edge','2026-07-17 19:21:44'),(1183,'/',NULL,NULL,'kPJiC4gaLAGpiQlcefuIshRx54rNTMGbRDRp36Wq',NULL,NULL,'desktop','Firefox','2026-07-17 19:35:06'),(1184,'/',NULL,NULL,'sdWRQQmaiDbpTg6xyXVhbD3ndoWmjlSqXStyjI9t',NULL,NULL,'desktop','Other','2026-07-17 19:53:03'),(1185,'/',NULL,NULL,'HUnjGVPfoHXbUj2mlvptfcVb2s4myeLYOVuQ9Br1',NULL,NULL,'desktop','Other','2026-07-17 20:37:05'),(1186,'/',NULL,NULL,'9xhQzgyalC7fVOpNp0Ehvx14wA2XisrI6U3WrVMy',NULL,NULL,'desktop','Chrome','2026-07-17 21:07:14'),(1187,'/',NULL,NULL,'PWLhXcxzJCLefiwvBjt8lkXArRfMv1FdbrdsFwGK',NULL,NULL,'desktop','Chrome','2026-07-17 21:07:22'),(1188,'/',NULL,NULL,'YkTdj93v4WtI1YEeY0pmRNWveS95CuN632MxChFU',NULL,NULL,'mobile','Chrome','2026-07-17 21:15:17'),(1189,'/',NULL,NULL,'XnvaZS4d6uyxwhIGofh6l76b8Y63qrcPlUINsa7o',NULL,NULL,'desktop','Other','2026-07-17 21:20:50'),(1190,'/',NULL,NULL,'gjF1uxeno8PoOxvSMxEy05U9i69J6Pt1t8iUxyFt',NULL,NULL,'desktop','Edge','2026-07-17 21:57:26'),(1191,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'gjF1uxeno8PoOxvSMxEy05U9i69J6Pt1t8iUxyFt',NULL,NULL,'mobile','Chrome','2026-07-17 21:57:41'),(1192,'blog',NULL,NULL,'gjF1uxeno8PoOxvSMxEy05U9i69J6Pt1t8iUxyFt',NULL,NULL,'desktop','Edge','2026-07-17 21:57:44'),(1193,'shop',NULL,NULL,'gjF1uxeno8PoOxvSMxEy05U9i69J6Pt1t8iUxyFt',NULL,NULL,'mobile','Chrome','2026-07-17 21:57:49'),(1194,'shop/cart',NULL,NULL,'gjF1uxeno8PoOxvSMxEy05U9i69J6Pt1t8iUxyFt',NULL,NULL,'desktop','Firefox','2026-07-17 21:57:51'),(1195,'search',NULL,NULL,'gjF1uxeno8PoOxvSMxEy05U9i69J6Pt1t8iUxyFt',NULL,NULL,'mobile','Safari','2026-07-17 21:57:55'),(1196,'login',NULL,NULL,'gjF1uxeno8PoOxvSMxEy05U9i69J6Pt1t8iUxyFt',NULL,NULL,'desktop','Firefox','2026-07-17 21:58:00'),(1197,'/',NULL,NULL,'AI20GOrNeqksqlvDAjYHD0wMI6U7yHxCYtQSV3TR',NULL,NULL,'desktop','Other','2026-07-17 22:03:33'),(1198,'/',NULL,NULL,'q6gNlwjJnWSrzOi4YKBdCmwFql6kGcQBpwjNmkcJ',NULL,NULL,'desktop','Other','2026-07-17 22:46:29'),(1199,'/',NULL,NULL,'8Jur6H71A8oMXWbMWWlQkPe4PZtzNi4u6N97lb9Q',NULL,NULL,'desktop','Other','2026-07-17 22:49:06'),(1200,'sitemap.xml',NULL,NULL,'8Jur6H71A8oMXWbMWWlQkPe4PZtzNi4u6N97lb9Q',NULL,NULL,'desktop','Other','2026-07-17 22:49:07'),(1201,'/',NULL,NULL,'CRPhO499OEqIxGGkI8BH9Xpi0SpVbP5hrt9W7dgr',NULL,NULL,'desktop','Other','2026-07-17 22:49:08'),(1202,'contact',NULL,NULL,'8Jur6H71A8oMXWbMWWlQkPe4PZtzNi4u6N97lb9Q',NULL,NULL,'desktop','Other','2026-07-17 22:49:09'),(1203,'shop/cart',NULL,NULL,'8Jur6H71A8oMXWbMWWlQkPe4PZtzNi4u6N97lb9Q',NULL,NULL,'desktop','Other','2026-07-17 22:49:10'),(1204,'login',NULL,NULL,'8Jur6H71A8oMXWbMWWlQkPe4PZtzNi4u6N97lb9Q',NULL,NULL,'desktop','Other','2026-07-17 22:49:11'),(1205,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'8Jur6H71A8oMXWbMWWlQkPe4PZtzNi4u6N97lb9Q',NULL,NULL,'desktop','Other','2026-07-17 22:49:12'),(1206,'blog',NULL,NULL,'8Jur6H71A8oMXWbMWWlQkPe4PZtzNi4u6N97lb9Q',NULL,NULL,'desktop','Other','2026-07-17 22:49:13'),(1207,'search',NULL,NULL,'8Jur6H71A8oMXWbMWWlQkPe4PZtzNi4u6N97lb9Q',NULL,NULL,'desktop','Other','2026-07-17 22:49:29'),(1208,'/',NULL,NULL,'GOaO4QPZ9eSrS6VmlGSwKh4Y0LIcmeD8PYYwoXpG',NULL,NULL,'desktop','Other','2026-07-17 23:29:34'),(1209,'/',NULL,'http://safhenokhost.ir/','MFKDHclxaRDGLXxyhXaltrgMjCCBeoBNFwN0ObMZ',NULL,NULL,'desktop','Chrome','2026-07-17 23:55:20'),(1210,'/',NULL,NULL,'XQMutUdbi41ccN29YTAhvAl1Xxa9Rp7nH9noraIg',NULL,NULL,'desktop','Other','2026-07-18 00:12:34'),(1211,'/',NULL,NULL,'5rUNcsUMJxLuFgDa8x4Q6CczZiblX34FytNX1ADO',NULL,NULL,'desktop','Other','2026-07-18 00:54:49'),(1212,'/',NULL,NULL,'vMaYW7TO6Sber77v4CYVLWaGNhgvnTLZIGqkY1qV',NULL,NULL,'desktop','Other','2026-07-18 01:38:43'),(1213,'/',NULL,NULL,'hxx54eAcvVewe6aLMyn8L3ZKVEGAPEYfvbIGW76t',NULL,NULL,'desktop','Other','2026-07-18 02:23:04'),(1214,'/',NULL,NULL,'iVMCqwXEqqvebqUtne5yD6wM7ueXKTx3IsFfgYQn',NULL,NULL,'desktop','Other','2026-07-18 03:06:01'),(1215,'/',NULL,NULL,'FVJyPXAXDOz4baUoRchPq9ubFAX3pkZcgflFANUs',NULL,NULL,'desktop','Other','2026-07-18 03:49:12'),(1216,'/',NULL,NULL,'UroKIoYXCllTUJnBfUDnu4EjerAYWoPKczmqN0xE',NULL,NULL,'desktop','Other','2026-07-18 04:32:42'),(1217,'/',NULL,NULL,'eHwBwzhj6FJ7SOn29xkhGQsiXYcdMz3ibGACCJtj',NULL,NULL,'desktop','Firefox','2026-07-18 04:38:51'),(1218,'/',NULL,NULL,'Y4eFlPhqhMnPsfJk6XXhlI9FY08BOCi1v2MeCKGF',NULL,NULL,'desktop','Firefox','2026-07-18 04:38:51'),(1219,'/',NULL,NULL,'BeYaNUH8zi1ljhTdYrBqrjRfYX8X4GUkHa8yTBAE',NULL,NULL,'desktop','Other','2026-07-18 05:17:50'),(1220,'/',NULL,NULL,'j0JgoWBzqcEhIiTLHGmaJUJGADj2G23kjkDZRe1Q',NULL,NULL,'desktop','Other','2026-07-18 06:01:41'),(1221,'login',NULL,'https://safhenokhost.ir/admin/dashboard','k1vx55U9FtQhO0ZbIgFrvWggoWDtJt5061mFymMn',NULL,NULL,'desktop','Firefox','2026-07-18 06:28:57'),(1222,'/',NULL,NULL,'0HjPOc8fLx509BIxMQ33vjoErHHnGdQ5os9IBFpw',NULL,NULL,'desktop','Other','2026-07-18 06:45:07'),(1223,'/',NULL,NULL,'kJh3Xm4ppHAdDsuwXPIOVNfdBWNd12ffcOtj2viq',NULL,NULL,'desktop','Other','2026-07-18 07:29:23'),(1224,'login',NULL,'https://safhenokhost.ir/admin/dashboard','o9yobDdOHxxj4lHcpR0PbnG8SJRG5o6E9zjwf5qZ',1,NULL,'desktop','Firefox','2026-07-18 08:05:50'),(1225,'/',NULL,NULL,'qEdm1mQr9HHtoxihdRKREeIvxsNzO6PepDtUbnvA',NULL,NULL,'desktop','Other','2026-07-18 08:12:52'),(1226,'/',NULL,'http://safhenokhost.ir/','SQvhkUDEmyl8tO3H9Jz0CjFiR9gjCRDO7JyQGL65',NULL,NULL,'mobile','Safari','2026-07-18 08:38:35'),(1227,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'9k0BRuXkeb4pGRgV5Bkk3m3xzLPfpi648FgGozar',NULL,NULL,'mobile','Safari','2026-07-18 08:38:40'),(1228,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'J8AKtg6yScS8OqtsKX5Re1HJ5xc3PfZe6t0OnqJu',NULL,NULL,'mobile','Safari','2026-07-18 08:38:40'),(1229,'blog/sayt-hmh-karh',NULL,NULL,'kJEaEE9NcnxVZIKE6m7yDUlgCMPN8jy6NTVWqFwx',NULL,NULL,'mobile','Safari','2026-07-18 08:38:43'),(1230,'/',NULL,NULL,'OKeYQIuJODRKJIRkUEm7rG5zQNWNTEczQiIXIeqg',NULL,NULL,'desktop','Other','2026-07-18 08:55:47'),(1231,'/',NULL,NULL,'8yqUdcHVKkZYIc2v6kw4f8gkstjTMa5xcaTeGANo',NULL,NULL,'desktop','Safari','2026-07-18 09:36:31'),(1232,'/',NULL,NULL,'Fn9Q9ATePVZ8nM0rgaLY9FtomOBrcxvi5SNRz4nU',NULL,NULL,'desktop','Other','2026-07-18 09:38:53'),(1233,'/',NULL,NULL,'blifpY1kJ9zS186nCVoSmRC6U0x1HXV2JUWnJ270',NULL,NULL,'desktop','Other','2026-07-18 10:22:19'),(1234,'/',NULL,NULL,'2u1Wjf5dXSjvA4fInmoKFZbNZX0NAeVLIUZnHm7m',NULL,NULL,'desktop','Other','2026-07-18 11:04:56'),(1235,'/',NULL,NULL,'0p8bev8M1dn6u6V2q4cbVOB2DJpgtgKzzzEL9RqG',NULL,NULL,'desktop','Other','2026-07-18 11:47:20'),(1236,'/',NULL,NULL,'TCmf4bWtKjJcyynQaJmRwNN7dCuuzGdQv1TnHmaD',NULL,NULL,'desktop','Other','2026-07-18 12:29:44'),(1237,'/',NULL,NULL,'0EtbgeTWpD91Xw1O40Q0cC1rearNGN2ItV02sVVp',NULL,NULL,'desktop','Other','2026-07-18 13:12:07'),(1238,'/',NULL,NULL,'RZTTrIl0A5rHdnX26uZnKlkYD11arupbBjw3y6Zw',NULL,NULL,'desktop','Other','2026-07-18 13:54:34'),(1239,'/',NULL,NULL,'8OkxG7TwExtdVB2kWpw3hU8ewl9VgzYBApHniYX8',NULL,NULL,'desktop','Other','2026-07-18 14:37:08'),(1240,'/',NULL,NULL,'sUMPWeQKvAmPm5zs821AF0FmjmGysMRbc98gMzHm',NULL,NULL,'mobile','Chrome','2026-07-18 15:09:44'),(1241,'/',NULL,NULL,'myp0PeRkYYQUXJh0Rrg1fH1dRWe4RQ1Pe26Sb3v6',NULL,NULL,'desktop','Other','2026-07-18 15:19:33'),(1242,'/',NULL,NULL,'312sRQSkp6411k79Rx1WqMk8MgmY6NDYuKt2CKOW',NULL,NULL,'desktop','Other','2026-07-18 16:02:58'),(1243,'/',NULL,NULL,'TrGVcNOp2JkWX9nO0AQuhFdKZWbfHAVqID8sHw9N',NULL,NULL,'desktop','Other','2026-07-18 16:45:25'),(1244,'/',NULL,NULL,'8Xb0lyhdxPNJ9m0PisqUzGqNbedvW0CO20BlRswa',NULL,NULL,'desktop','Other','2026-07-18 17:29:23'),(1245,'/',NULL,NULL,'QQ0tJ6W8scMFXql5iiajQPdCBRRNiEsFPe7Jx5VT',NULL,NULL,'desktop','Other','2026-07-18 21:43:04'),(1246,'/',NULL,NULL,'RsZmDxHnomV6HMW1IzT8rl8yT9ykvSNQt6yYhi7p',NULL,NULL,'desktop','Other','2026-07-18 22:24:38'),(1247,'/',NULL,NULL,'9j2ef6gGxIYlLNb1hcTJ8SmhCe5c7DDElwQ40ATZ',NULL,NULL,'desktop','Other','2026-07-18 23:06:48'),(1248,'/',NULL,NULL,'MS6kNEVaat48AhPI17VDThTuntoMhkb4BKmWR6eh',NULL,NULL,'desktop','Other','2026-07-18 23:49:52'),(1249,'/',NULL,NULL,'CkNG1TMGUMD8D3jZjKhY0mqdpgsnn84loAFPNjaY',NULL,NULL,'desktop','Other','2026-07-18 21:01:12'),(1250,'/',NULL,NULL,'QsqLk3qWt3R77Dm47NzbwxDn8c3phS2sG5vLNZwI',NULL,NULL,'desktop','Other','2026-07-18 21:43:38'),(1251,'/',NULL,NULL,'D4tZquH8F8lPaXFGklYOGmErpKYmVtDIwXU7Orqv',NULL,NULL,'desktop','Other','2026-07-18 22:26:04'),(1252,'/',NULL,NULL,'w2wVPwP4hisbfoCjRZY9A6cnSNAThvjMlEZxeTwg',NULL,NULL,'desktop','Other','2026-07-18 23:07:14'),(1253,'/',NULL,NULL,'5Pyrl2Vzi3QFuXI6tQIrXDmu4Zvh62W9OYZPDgVO',NULL,NULL,'desktop','Other','2026-07-18 23:48:54'),(1254,'/',NULL,NULL,'kbR9jDyntPK1sfyh3CSZprtmPDTaLTH73SUE4Zml',NULL,NULL,'desktop','Other','2026-07-19 00:31:19'),(1255,'/',NULL,NULL,'cgGJ9TC9FImHz8FbRSWHxkWAJSYYgUeTQzrIoChy',NULL,NULL,'desktop','Chrome','2026-07-19 01:03:12'),(1256,'/',NULL,NULL,'uvxBavsEAXwChghdkszD0yDpZLFrbXe1BAC470iH',NULL,NULL,'desktop','Other','2026-07-19 01:14:02'),(1257,'/',NULL,NULL,'rVxbfpVuUtLxsK6aJAZkfFZLfpU1ctwge239Jfjn',NULL,NULL,'desktop','Other','2026-07-19 01:56:18'),(1258,'/',NULL,'https://safhenokhost.ir/','MRggAGVu9IUQ0sruplwjZMz7ktY29qUhZ2lTPP7y',NULL,NULL,'desktop','Other','2026-07-19 01:57:17'),(1259,'/',NULL,'https://safhenokhost.ir/?rest_route=%2Fjetpack%2Fv4%2Fconnection%2F&_for=jetpack&token=uThbNbe%21qJyhj8YyhV13%28O%26uLR3Ka6%28f%3A1%3A0&timestamp=1784438850&nonce=gjyXbl7oSP&body-hash&signature=tZmjY0n1cfgNT5SrdgGHHr0a2j0%3D','mBsCDa9qCwZXrWSjNT24qRImBw8liuujhlYYlt3S',NULL,NULL,'desktop','Other','2026-07-19 01:57:25'),(1260,'/',NULL,'https://safhenokhost.ir/?rest_route=/','RMXbihFn2xadGDbfakpq30H0wFxE1m6XcIjEDB7Z',NULL,NULL,'desktop','Other','2026-07-19 01:57:27'),(1261,'/',NULL,'https://safhenokhost.ir/','6jtVc3NnLjlyH3tYatMlTEsNEdbklfTZLbxyltwv',NULL,NULL,'desktop','Other','2026-07-19 01:57:34'),(1262,'/',NULL,NULL,'sSonN9dKeKzyTq0WWcKropTX8Iqh0uVIADef7RNr',NULL,NULL,'desktop','Safari','2026-07-19 02:00:35'),(1263,'/',NULL,NULL,'7NIZQyooXtwLgI3mdLbA8kcO3QqdoOmnR32Lgu1B',NULL,NULL,'desktop','Other','2026-07-19 02:39:17'),(1264,'/',NULL,NULL,'yUIxZ2tzexcjYVagaAumKhdZSeRQKq3n3OMbpZFV',NULL,NULL,'desktop','Other','2026-07-19 03:22:35'),(1265,'/',NULL,NULL,'8KswoeZf4NTHiCW2BJGq4JUjs3HAuKLM6rmKdTQ0',NULL,NULL,'desktop','Other','2026-07-19 04:05:18'),(1266,'/',NULL,NULL,'RzrgxVYFm4mpielq1MFWzowURLa31Fq7XN8x1Plt',NULL,NULL,'desktop','Other','2026-07-19 04:48:27'),(1267,'/',NULL,NULL,'y9Al7jH1z69q96m7YVHdivjONRDfOn1lD0KcNVUu',NULL,NULL,'desktop','Other','2026-07-19 05:31:57'),(1268,'/',NULL,NULL,'0wr7MBUVpglAW0tXZGYKmoLnu99f9WHY3NuFa6bB',NULL,NULL,'desktop','Other','2026-07-19 06:15:13'),(1269,'/',NULL,NULL,'6hSyXSPnwV4prvDcOuXrt5KL1NqY7NA2HWcgQsz7',NULL,NULL,'desktop','Other','2026-07-19 06:58:28'),(1270,'/',NULL,NULL,'1hBStE1fUURI7aYfiRC2Unkd7ASLHcMqv8fJowe8',NULL,NULL,'desktop','Other','2026-07-19 07:41:53'),(1271,'/',NULL,NULL,'OOCrYpcvLpm9ihBKgxyltiTG9eVjkqEvxEwwS46Q',NULL,NULL,'desktop','Other','2026-07-19 08:25:24'),(1272,'/',NULL,NULL,'6b2vnWa2kADoTDFaLRJrROKbSzj8Y1UW2yGOfI2H',NULL,NULL,'desktop','Other','2026-07-19 09:08:17'),(1273,'/',NULL,NULL,'Gl9IQesGcrNQSA8hZ3upOtCQ0B9zID1PC0lpd09w',NULL,NULL,'desktop','Other','2026-07-19 09:50:51'),(1274,'/',NULL,NULL,'WOBQ374M3Mp54t1fv0sPA7IDEEl9mGOeMJLXv6F5',NULL,NULL,'desktop','Other','2026-07-19 10:35:11'),(1275,'/',NULL,NULL,'sBTMGGFMKMigxhzKmCekhjXUQgmFJVlSntY29nDp',NULL,NULL,'desktop','Other','2026-07-19 11:18:59'),(1276,'/',NULL,NULL,'iSAh8y8m8HD8HJsm4mwQu14dFLT9P0aX5uZ5bHSF',NULL,NULL,'desktop','Other','2026-07-19 12:01:18'),(1277,'/',NULL,NULL,'ddloCMtMs0Dr7c23ckbsHB1UOAIQP9Z9o3nGG31t',NULL,NULL,'desktop','Other','2026-07-19 12:44:05'),(1278,'/',NULL,NULL,'Fnrk8nYBQZBOBYJPugE4bSJINQRVJbFI31tI6Nup',NULL,NULL,'mobile','Safari','2026-07-19 13:03:53'),(1279,'/',NULL,NULL,'7DAtGVDyryu0mURD4HIWoPkiCnlan9s8hi4Rvvxc',NULL,NULL,'mobile','Safari','2026-07-19 13:03:54'),(1280,'/',NULL,NULL,'uUNNwfe7llLLrAB6irrfdPGmJh8K4MyvQnlhGW7A',NULL,NULL,'desktop','Other','2026-07-19 13:27:00'),(1281,'/',NULL,NULL,'yrk31Kedkg0A7AbeCi7PfZS2E1npMPOymQkk7wd9',NULL,NULL,'desktop','Other','2026-07-19 14:10:22'),(1282,'/',NULL,NULL,'rN0oTPf0oAtsCdA4zRQZR5FTyjL54XcEOC0YFLnZ',NULL,NULL,'desktop','Other','2026-07-19 14:52:36'),(1283,'/',NULL,NULL,'3jAeF6Frnbz0tIkUjf2QMBYXQUkEQp92DUGgX2Ec',NULL,NULL,'desktop','Other','2026-07-19 15:35:16'),(1284,'/',NULL,NULL,'PStNrwJRjrwCtephc2pTAsKGWQKo0klwaCSHEQRE',NULL,NULL,'desktop','Other','2026-07-19 16:19:08'),(1285,'/',NULL,NULL,'wW9HESjRwNxeQcRb6xC09f8fVqRGEmEVBzAKbg2Z',NULL,NULL,'desktop','Other','2026-07-19 17:02:00'),(1286,'/',NULL,NULL,'fNIrbscirFFcpr3KvYr8Wi00kzVTdm6V9eyohSaJ',NULL,NULL,'desktop','Other','2026-07-19 17:45:54'),(1287,'/',NULL,NULL,'dmNfcv8yfjhcWWssOBo8zYIkl1uK8QGEIa6HWXrj',NULL,NULL,'desktop','Other','2026-07-19 18:30:13'),(1288,'/',NULL,NULL,'y21H2RKJ3nLmUduDHDMCppEzlJw30RQnRq8jd1Aw',NULL,NULL,'desktop','Other','2026-07-19 19:14:06'),(1289,'/',NULL,NULL,'QXvyFsTsZi7GFkVcsJ1I4jqX4GjGQAc0G9bgdkjf',NULL,NULL,'desktop','Other','2026-07-19 19:56:33'),(1290,'/',NULL,NULL,'iahXtD1wijGWymNk3w9OQqstS9PHdS4GyzmbzhEz',NULL,NULL,'desktop','Chrome','2026-07-19 20:03:15'),(1291,'shop/cart',NULL,NULL,'iahXtD1wijGWymNk3w9OQqstS9PHdS4GyzmbzhEz',NULL,NULL,'desktop','Chrome','2026-07-19 20:03:18'),(1292,'contact',NULL,NULL,'iahXtD1wijGWymNk3w9OQqstS9PHdS4GyzmbzhEz',NULL,NULL,'desktop','Chrome','2026-07-19 20:03:21'),(1293,'login',NULL,NULL,'iahXtD1wijGWymNk3w9OQqstS9PHdS4GyzmbzhEz',NULL,NULL,'desktop','Chrome','2026-07-19 20:03:23'),(1294,'register',NULL,NULL,'iahXtD1wijGWymNk3w9OQqstS9PHdS4GyzmbzhEz',NULL,NULL,'desktop','Chrome','2026-07-19 20:03:26'),(1295,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'iahXtD1wijGWymNk3w9OQqstS9PHdS4GyzmbzhEz',NULL,NULL,'desktop','Chrome','2026-07-19 20:03:28'),(1296,'blog',NULL,NULL,'iahXtD1wijGWymNk3w9OQqstS9PHdS4GyzmbzhEz',NULL,NULL,'desktop','Chrome','2026-07-19 20:03:30'),(1297,'shop',NULL,NULL,'iahXtD1wijGWymNk3w9OQqstS9PHdS4GyzmbzhEz',NULL,NULL,'desktop','Chrome','2026-07-19 20:03:33'),(1298,'search',NULL,NULL,'iahXtD1wijGWymNk3w9OQqstS9PHdS4GyzmbzhEz',NULL,NULL,'desktop','Chrome','2026-07-19 20:03:36'),(1299,'contact',NULL,NULL,'ccvxod1t4Ayks9eOOGGanNM3jOYNNEzw8WKWGhiM',NULL,NULL,'desktop','Other','2026-07-19 20:04:45'),(1300,'/',NULL,NULL,'MKgYJwHlhBeY7CwvNucgWnR0ET8xL9Q9EGnRMCZB',NULL,NULL,'desktop','Other','2026-07-19 20:42:04'),(1301,'/',NULL,NULL,'lfAJpj7P2XQt2voZwZGVyjGjkVzpZlIDMay1VyiD',NULL,NULL,'desktop','Other','2026-07-19 21:26:54'),(1302,'/',NULL,NULL,'6P8teVrPDeS8M7jYaADaWGBoFJwcRFGUgTpD7UdC',NULL,NULL,'desktop','Other','2026-07-19 22:10:33'),(1303,'/',NULL,NULL,'S5CRRQeeCYssr5NDGXfCX3IQBOSgMd17gwtXerys',NULL,NULL,'desktop','Other','2026-07-19 22:52:56'),(1304,'/',NULL,NULL,'gO37R7lTjYbuCvRGnpLNnq5SLDFe2UykthkZ9RD0',NULL,NULL,'desktop','Other','2026-07-19 23:38:05'),(1305,'/',NULL,NULL,'wPQtMMdEHbs7K5ejCfytKdx8clWd6xpcxOqlDYPL',NULL,NULL,'desktop','Other','2026-07-20 00:22:12'),(1306,'/',NULL,NULL,'h3j0b3IBVJi3JNqIZcDI88OE4lVikHMgih4U1V5H',NULL,NULL,'desktop','Other','2026-07-20 01:05:19'),(1307,'/',NULL,NULL,'0Griwj3mCfHRsDXVsFalQfRPiVrVBum3PqMEKeY3',NULL,NULL,'desktop','Other','2026-07-20 01:50:22'),(1308,'/',NULL,NULL,'LNbgtIvtRqbMK180A0tFd2ChaEhw0atTRi4BDREO',NULL,NULL,'desktop','Other','2026-07-20 02:36:00'),(1309,'/',NULL,NULL,'QZEMVY16akKdeQBOp9DJBQluzSYV0jOp4aPIiwUs',NULL,NULL,'desktop','Other','2026-07-20 03:21:26'),(1310,'/',NULL,NULL,'D471ElXFnCZWDEiO5IWA69vJvzSk0xtBIvs07VhY',NULL,NULL,'desktop','Other','2026-07-20 04:06:20'),(1311,'/',NULL,'http://safhenokhost.ir/','QT2m0CtOT9W3KII1gwvjH8Cvq071QwgFRNVcbIle',NULL,NULL,'desktop','Firefox','2026-07-20 04:19:57'),(1312,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'fVBM7FseKzv134DHGcrtbs1Y1wFjJB3KoEbIWhqA',NULL,NULL,'desktop','Firefox','2026-07-20 04:19:59'),(1313,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'3dFXeWJbUWWZNR3St4XsIzU4dSxg1Mh30d1yo5mu',NULL,NULL,'desktop','Firefox','2026-07-20 04:20:01'),(1314,'blog/sayt-hmh-karh',NULL,NULL,'oWJTNTxepfpcqHgb2Pu7hmYWTVacpbizCqu0GExy',NULL,NULL,'desktop','Firefox','2026-07-20 04:20:03'),(1315,'/',NULL,NULL,'sDJtopoEee1nMpF7DLKp5fmaVOKbV76jDdSVwZ4I',NULL,NULL,'desktop','Other','2026-07-20 04:52:24'),(1316,'/',NULL,NULL,'WKrK397AsqirQkjD9TD9nASZKLZpvODCJefS3tUX',NULL,NULL,'desktop','Other','2026-07-20 05:39:51'),(1317,'/',NULL,NULL,'7h6VjlcOgG1JT8o195fOUsb2wYbFXhYJaw9jsG3k',NULL,NULL,'desktop','Other','2026-07-20 06:26:02'),(1318,'/',NULL,NULL,'51gGmRZXSlXJOAkJ1mdEb3VBskVZkoHFRseoyeoH',NULL,NULL,'desktop','Other','2026-07-20 07:11:43'),(1319,'/',NULL,NULL,'FDJSm4yEUYdh5fYdG5nMOO7f33c3fB0gOizvZxkb',NULL,NULL,'desktop','Other','2026-07-20 07:57:29'),(1320,'/',NULL,NULL,'4glHwanxcKN4ihE8T71M9YlzW7DNuav47DjFJCrX',NULL,NULL,'desktop','Other','2026-07-20 08:45:20'),(1321,'/',NULL,NULL,'AuAyUiDbiS1EyJTc0rS6SrFZjStfzrm6H370LpW4',NULL,NULL,'desktop','Other','2026-07-20 09:32:07'),(1322,'/',NULL,NULL,'N4HjQ4eP5mACXEsaU94xCmvVJQbDOXvepOK9OOxA',NULL,NULL,'desktop','Other','2026-07-20 10:16:59'),(1323,'/',NULL,NULL,'L1PIRyJUIJhqdb3l6fGSWtAnZxNggVsrEuLi6mGB',NULL,NULL,'mobile','Chrome','2026-07-20 11:00:31'),(1324,'/',NULL,NULL,'SmG6LFV6idyn5rk7Nn3szT08iWCJF3GZL6ORvhZs',NULL,NULL,'desktop','Other','2026-07-20 11:02:22'),(1325,'/',NULL,NULL,'7gVGOI2ksVxOSJRClkbJ4zU3XRvYSqJNX2o3vyLT',NULL,NULL,'desktop','Other','2026-07-20 11:47:50'),(1326,'/',NULL,NULL,'7qrnSACtY0sICWKhRtEtSIn91Pd7QUhxijUmd9XH',NULL,NULL,'desktop','Firefox','2026-07-20 13:18:03'),(1327,'/',NULL,'http://safhenokhost.ir/','OnHNUO4TMLGJ3eJd7YswfFtBr0Ful0MH7lMz81oU',NULL,NULL,'desktop','Firefox','2026-07-20 13:18:04'),(1328,'/',NULL,NULL,'pjJAlCgYsKWBsKictofKUV1FHlmpH6ai9Aq6PBr6',NULL,NULL,'desktop','Other','2026-07-20 13:19:58'),(1329,'/',NULL,NULL,'ysVMBEbXuNosgfF2I0300axpxrbvgCS6lBDsPuTl',NULL,NULL,'desktop','Other','2026-07-20 14:04:23'),(1330,'/',NULL,NULL,'LVBW6r2JKQDIwxRaibk7iCuerSkhKxXoKtBerqWP',NULL,NULL,'desktop','Other','2026-07-20 14:50:36'),(1331,'/',NULL,NULL,'3WEbCb7Y0NMIkW9qZn6cK6IAQ4hKGexP0lkS5eW1',NULL,NULL,'desktop','Other','2026-07-20 15:36:55'),(1332,'/',NULL,NULL,'uT9qDGrKQwlGxFYmqhoUECFuVQHmQPJ6L4SkGb0y',NULL,NULL,'desktop','Other','2026-07-20 16:21:14'),(1333,'/',NULL,NULL,'0I7OPAISVuwZC0Xqhu6LKc5qIPr4B2bReYejQndI',NULL,NULL,'desktop','Other','2026-07-20 17:04:46'),(1334,'/',NULL,NULL,'sfQfe6gTVnc20Hfxios9eQPoLAIDShXvHVr428tS',NULL,NULL,'desktop','Other','2026-07-20 17:26:43'),(1335,'/',NULL,NULL,'kq7m8sDMT4LxVdDosu5swGCr7CqXABAIyktv40s6',NULL,NULL,'desktop','Other','2026-07-20 17:49:01'),(1336,'/',NULL,NULL,'Rmd1dxuT329uwlSKmnMh2NffbgcJBlyEpeHyI3ZN',NULL,NULL,'desktop','Other','2026-07-20 18:34:17'),(1337,'/',NULL,NULL,'xbYeMtbQRZsaxXYdMoXvzfcukzTEbeL3DCxkNUJ6',NULL,NULL,'desktop','Other','2026-07-20 19:17:13'),(1338,'/',NULL,NULL,'RCyz2UPVGMlytQbX7NBAkOZtcpJ8KcfwmSuC8v7L',NULL,NULL,'desktop','Other','2026-07-20 19:58:47'),(1339,'/',NULL,NULL,'Xmm8W1poxXVbq1PdgShCKfJnncRMd3MnE1fPys0R',NULL,NULL,'desktop','Other','2026-07-20 20:42:28'),(1340,'/',NULL,NULL,'zZaJhW2S2WbrPmC9THrJA6wYlRzpD0HLsfXhGpX0',NULL,NULL,'desktop','Other','2026-07-20 21:25:44'),(1341,'/',NULL,NULL,'LrwonRMVjAEyia515W4bewBQZGg2rt2ojU6tXY9H',NULL,NULL,'desktop','Other','2026-07-20 22:08:42'),(1342,'/',NULL,NULL,'LiCXBMvLo95AdkYRP8ci96Zl2pPcSmX8mg4vhiVU',NULL,NULL,'mobile','Chrome','2026-07-20 22:20:21'),(1343,'/',NULL,NULL,'WStDRaePALpDWP1ifaE0fobofJrrnZoniSMq8ION',NULL,NULL,'desktop','Other','2026-07-20 22:50:55'),(1344,'/',NULL,NULL,'VoetpldJmXZxDhkGageC9R022jXEIZnJmMdo6DE8',NULL,NULL,'desktop','Other','2026-07-20 23:33:31'),(1345,'/',NULL,NULL,'NaeE9NWrV7fXXTzA8xkOEVAoU07xR33G43wOi2Qu',NULL,NULL,'desktop','Other','2026-07-21 00:15:30'),(1346,'/',NULL,NULL,'VsEV1hFh2r01yhKXf6aIE0Efc7Izh0T2C3kbKxwT',NULL,NULL,'desktop','Other','2026-07-21 00:57:35'),(1347,'/',NULL,NULL,'Oid6aOfeB3N3xqYy4hLcL3uIjhQP6lKPVAlIGcYF',NULL,NULL,'desktop','Chrome','2026-07-21 01:31:10'),(1348,'/',NULL,NULL,'MAPcPvXeIQSFQfQnTvPUb27RyD5VaHwCK95bUvxY',NULL,NULL,'desktop','Other','2026-07-21 01:42:03'),(1349,'/',NULL,NULL,'06ebyBMh70lwLcZeqCBrGNq3IIcFaANi48KNsrqc',NULL,NULL,'desktop','Other','2026-07-21 02:26:22'),(1350,'/',NULL,NULL,'LaH0iotl0eoEG3XSuMa1e5bCqpgv05xMJInnpeGC',NULL,NULL,'desktop','Other','2026-07-21 03:10:39'),(1351,'/',NULL,NULL,'FH5YvvtGcwVIEEOnOBJdv6MpGn6nqV88A1yrze97',NULL,NULL,'desktop','Other','2026-07-21 03:54:48'),(1352,'/',NULL,NULL,'xxVLBbTQzcU52DNl0E0PWukJbDWYszMGAq19eNtf',NULL,NULL,'desktop','Other','2026-07-21 04:40:00'),(1353,'/',NULL,NULL,'RR63jnT918Nk8YiKo7m3WaVysOTcDKR6BGC63upA',NULL,NULL,'desktop','Other','2026-07-21 05:25:00'),(1354,'/',NULL,NULL,'CpDD8kG9gEbotXpMdGZNvFb72b4XE8rsTf1C4GxP',NULL,NULL,'desktop','Other','2026-07-21 06:08:55'),(1355,'/',NULL,NULL,'sxdGjCx7Iq2g6QdJNlUgGHomry76of6W2oreHyW8',NULL,NULL,'desktop','Chrome','2026-07-21 06:52:40'),(1356,'/',NULL,NULL,'W8lXPb8jqzAnQLz1E7aAgGDevH5eGItocFcNLfM6',NULL,NULL,'desktop','Other','2026-07-21 06:53:53'),(1357,'/',NULL,NULL,'h5Fw4ZBQo7xS8VrVFb0iLjfKLhLCiklHcahgvGSm',NULL,NULL,'desktop','Other','2026-07-21 07:37:31'),(1358,'/',NULL,NULL,'Itdtn9BcQxpP1yct9ttb7MpJMI9CJUEK827TP31E',NULL,NULL,'desktop','Other','2026-07-21 08:25:04'),(1359,'/',NULL,NULL,'Si3o4MI0q2UOrxO1LjVHSzLmtRZkkJXyv06UirEb',NULL,NULL,'desktop','Other','2026-07-21 09:08:13'),(1360,'/',NULL,NULL,'lzvO8tbPxhHCYd9znqRbypYnKaIC0qkNT2ghsepq',NULL,NULL,'desktop','Other','2026-07-21 09:54:58'),(1361,'/',NULL,NULL,'Fd5PjBoAvNx2ioUEhyVhRaVriY8qY26r37hdTFKl',NULL,NULL,'desktop','Edge','2026-07-21 10:30:22'),(1362,'/',NULL,NULL,'wWjehkouA1ESvFJq28DAhahEZxPmNoVmU98G7OUT',NULL,NULL,'desktop','Other','2026-07-21 10:40:09'),(1363,'/',NULL,NULL,'WrfuZYoK5qZRJzsN8Fo8CnkEUWxyU1cfwHdaV7iq',NULL,NULL,'desktop','Other','2026-07-21 11:22:45'),(1364,'/',NULL,NULL,'kseV13S2A8Ir1zeMXoQ3vDZR0UnZqUqzYAJWNSES',NULL,NULL,'desktop','Other','2026-07-21 12:21:45'),(1365,'/',NULL,NULL,'tJRlRVBir51DJHvljukRstH9EB0iw6gQbhwgEKnz',NULL,NULL,'desktop','Other','2026-07-21 13:09:09'),(1366,'/',NULL,NULL,'0ucnDsTFLxUZ4jAzUm3wrro5tDoM3lziLMUQRtZ0',NULL,NULL,'desktop','Other','2026-07-21 13:52:09'),(1367,'/',NULL,NULL,'Fg8bdVVjKEPsjEylAu0Fz7juVGcWmgYc5elAvkSG',NULL,NULL,'desktop','Other','2026-07-21 14:36:29'),(1368,'/',NULL,NULL,'eacszOwc937mkUBBipuJGVfnwjxnyZTBvsjOX6Kq',NULL,NULL,'desktop','Other','2026-07-21 15:19:37'),(1369,'/',NULL,NULL,'Xrua3gdXmKIFaWxAyeVDJLMnbeiSji07HWyakTyA',NULL,NULL,'mobile','Chrome','2026-07-21 15:53:45'),(1370,'/',NULL,NULL,'2AfXhbSdRCwo4637sy3ja6CnkoetG95ASkUxQplS',NULL,NULL,'desktop','Other','2026-07-21 16:03:00'),(1371,'/',NULL,NULL,'GWKB1uw5i7IBBSCpsORoGzLkbS9QA543dGuNfOXp',NULL,NULL,'desktop','Other','2026-07-21 16:47:12'),(1372,'/',NULL,NULL,'PDwe185tuzyIK25RWRAeK832M4VQEWsrZd2ZE9dU',NULL,NULL,'desktop','Other','2026-07-21 17:31:28'),(1373,'/',NULL,NULL,'MsawV9fIJc3K9XboHbFURCwHGWSW0f4RzmcjqtP6',NULL,NULL,'desktop','Other','2026-07-21 18:16:13'),(1374,'/',NULL,NULL,'XKkd3dJ6G80T96eHsUKEDHnqplvlCtQVSIui2hCl',NULL,NULL,'desktop','Firefox','2026-07-21 18:37:24'),(1375,'/',NULL,NULL,'sBRfG1cKUsRkHeEOza5SkBnekWP3KZTtkG5QAOvp',NULL,NULL,'desktop','Other','2026-07-21 19:00:18'),(1376,'/',NULL,NULL,'im2bj0eh1aowwhV4V6OB7sYDqjGnK75aBnpbgdyM',NULL,NULL,'desktop','Other','2026-07-21 19:46:41'),(1377,'/',NULL,NULL,'7BgFkQg5STae5bXARZHpZyXR8nHs3XLhTXb5Jlng',NULL,NULL,'desktop','Other','2026-07-21 20:31:39'),(1378,'/',NULL,NULL,'IErALLeJ2wCM20KkIegACsWFpcwZ1c4Iwi7KkWaA',NULL,NULL,'desktop','Other','2026-07-21 21:42:47'),(1379,'/',NULL,NULL,'77lOHMhDoI3iI517mcKIAmXvxG87WY9EtABxXmNz',NULL,NULL,'desktop','Other','2026-07-21 22:26:17'),(1380,'/',NULL,NULL,'gIx5XKaQdcAsEasGJXfGTQd2534TnUDlQamawHrp',NULL,NULL,'desktop','Other','2026-07-21 23:07:59'),(1381,'/',NULL,NULL,'17aAShzMEwddeC1JTpKIOLOlbyGHsDtHD8fsBoz2',NULL,NULL,'desktop','Other','2026-07-21 23:50:12'),(1382,'/',NULL,NULL,'bdgPBPtcYmMFjxL72AYJ7auMZypBowUz3F83w2JS',NULL,NULL,'desktop','Other','2026-07-22 00:33:25'),(1383,'/',NULL,NULL,'zjANL7TYyWDEwATgy5U1tm2ZKYewG4WyVFlnvNtt',NULL,NULL,'desktop','Firefox','2026-07-22 00:49:32'),(1384,'/',NULL,NULL,'DECMvslsjCnrENSFoRe9LjxcYglGu7NXLykqpBlR',NULL,NULL,'desktop','Other','2026-07-22 01:15:38'),(1385,'/',NULL,NULL,'xyAl0n9z4wUNbhHuv9WwLFKnq9eumItOvp32ooTF',NULL,NULL,'desktop','Other','2026-07-22 01:59:15'),(1386,'/',NULL,NULL,'lyRMPlCw57CeuBzqYe9aut3ILDCBXE2RgaejDU1w',NULL,NULL,'desktop','Other','2026-07-22 02:42:40'),(1387,'/',NULL,NULL,'Blc4PtjEfYBlWmm891LHlAYf43Ab0ZkItfSC8gJ5',NULL,NULL,'desktop','Other','2026-07-22 03:22:56'),(1388,'/',NULL,NULL,'AzjevaESNlNq7sW9MeeZ4hoIhY8qszFE3BdR4wa6',NULL,NULL,'desktop','Other','2026-07-22 03:25:57'),(1389,'/',NULL,NULL,'jtzOVX65Ymqnon7HRwnvVEzjN1OHZ0HuD8QlBRN2',NULL,NULL,'desktop','Firefox','2026-07-22 03:57:50'),(1390,'/',NULL,NULL,'l9b57BwM5lLqZQEcX7Mx4G5Hju2D3xmE9NQqcxtB',NULL,NULL,'desktop','Other','2026-07-22 04:08:51'),(1391,'/',NULL,NULL,'ah62aa563hKEkrdO4lhtA7U0Up1ZhjZKPTeUSbN2',NULL,NULL,'desktop','Other','2026-07-22 04:53:12'),(1392,'/',NULL,'http://safhenokhost.ir/','qSWoSbjWx20QY9oPv2m2NNj27ykDchBVxAZR2HAA',NULL,NULL,'mobile','Safari','2026-07-22 04:59:20'),(1393,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'X1sBBup4rcCCaJWIbHA2UVDYJpliTpnItZkHt298',NULL,NULL,'mobile','Safari','2026-07-22 04:59:21'),(1394,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'xxG4wlNkCFIivvo1gKi1UeTVyoaIrSbBRcCFqKuo',NULL,NULL,'mobile','Safari','2026-07-22 04:59:22'),(1395,'blog/sayt-hmh-karh',NULL,NULL,'Pdbiqlikv73Iq7zH3VfM8m8lbWxf8BxvPXG6IIfq',NULL,NULL,'mobile','Safari','2026-07-22 04:59:23'),(1396,'/',NULL,NULL,'UDaiPiUED2IOob5GlhK7NKq8oPrYlyBJSYEhtBf0',NULL,NULL,'desktop','Other','2026-07-22 05:37:23'),(1397,'/',NULL,NULL,'02euTcCqg1KPgDzNLZJEPU84tPjAmNAg3hL3VVMj',NULL,NULL,'desktop','Other','2026-07-22 06:20:36'),(1398,'/',NULL,NULL,'rSdnJOjCF6woBpylW8rhLxluSeIDCIT0voHEn821',NULL,NULL,'desktop','Other','2026-07-22 07:03:23'),(1399,'/',NULL,NULL,'u1CRqk35laQkwbvgTgIynmEUOqg5cEGGuNBw0b8C',NULL,NULL,'desktop','Other','2026-07-22 07:47:31'),(1400,'/',NULL,NULL,'eaGm1hI9kuiwFV6lOdsNTUYSntUuHgtxP47s0pKp',NULL,NULL,'desktop','Other','2026-07-22 08:31:35'),(1401,'/',NULL,'http://safhenokhost.ir','ewHj5NBcI7qhnqtnMqJtycdFBsTgM0Sr7G8uyqSv',NULL,NULL,'desktop','Other','2026-07-22 08:36:09'),(1402,'/',NULL,NULL,'P2C6oikOWzP1qinHar6u8oCYeQr4yhEYsrt7VAF9',NULL,NULL,'desktop','Other','2026-07-22 09:15:54'),(1403,'/',NULL,NULL,'OWjIY6YqoP51jTfetzJpEHYE76DW0LvouAU3JGCL',NULL,NULL,'desktop','Other','2026-07-22 10:02:13'),(1404,'/',NULL,NULL,'gRxB4u3OAp4MlcGjsRfd5tqLJi8BAXTlrxJnqivL',NULL,NULL,'mobile','Safari','2026-07-22 10:03:42'),(1405,'/',NULL,NULL,'5M47KGxZGJDakhQwByuK5o7W3esaUQQhLkhJZbfn',NULL,NULL,'desktop','Other','2026-07-22 10:47:35'),(1406,'/',NULL,NULL,'aAFvmXJ8r1epku5z6lhAlQ8ZNnkDftHmEa8rCFCo',NULL,NULL,'desktop','Other','2026-07-22 11:30:44'),(1407,'/',NULL,NULL,'BVCtHxFJljuChggQ7n63vflki98GSh4GFIsaCVDO',NULL,NULL,'desktop','Other','2026-07-22 12:13:29'),(1408,'/',NULL,NULL,'TpLTV4cehDwHBQFktBskufxQE0Q9vBSXxGeFPDXU',NULL,NULL,'mobile','Chrome','2026-07-22 12:20:39'),(1409,'/',NULL,NULL,'F3ZJCmrHQkfGRYW6e4KwKGkb9XPPsKGAQhGmvQdI',NULL,NULL,'desktop','Other','2026-07-22 12:56:38'),(1410,'/',NULL,NULL,'uky76bJ9S5oXASOoUVth03Ot3WhttkdV9rc4RBPu',NULL,NULL,'desktop','Other','2026-07-22 13:39:15'),(1411,'/',NULL,NULL,'BQJ1LPSHZG7iXDzH4IAIuK38qbf8MNzvNBBEfsez',NULL,NULL,'desktop','Other','2026-07-22 14:21:43'),(1412,'/',NULL,NULL,'qxpOH4N2kejaNb1QgeDrpXo725a9j2U8LbrPUAjr',NULL,NULL,'desktop','Other','2026-07-22 15:04:10'),(1413,'/',NULL,NULL,'aodIsnWQjGx7tmGPFtnvXxHPIGLkk2eHUhK4Im2l',NULL,NULL,'desktop','Other','2026-07-22 15:46:57'),(1414,'/',NULL,NULL,'NnlS8hULd70AuoawSvn8deTNXfr4pjpQHRWvjEkT',NULL,NULL,'desktop','Other','2026-07-22 16:29:24'),(1415,'/',NULL,NULL,'VP30nlIpzHwdjGGNJKInudWHe9qvellyzSt4bAoF',NULL,NULL,'desktop','Other','2026-07-22 17:12:09'),(1416,'/',NULL,NULL,'beFCcpOQoUMDdwAdWguCmDflR5duhs0KzD0U1hkZ',NULL,NULL,'desktop','Other','2026-07-22 17:57:21'),(1417,'/',NULL,NULL,'rslnl8KDOOBkFzOMXFDFk1DF4sy0KPQieSVemJKV',NULL,NULL,'desktop','Other','2026-07-22 18:43:07'),(1418,'/',NULL,NULL,'SN5VIFth1x1gR77ouxX8HWaAC4cqx691Ik6ZOYwf',NULL,NULL,'desktop','Other','2026-07-22 19:26:49'),(1419,'/',NULL,NULL,'Y3McXnTH9cDz3yLzmjgFLY8XXa8xgl6P3w08hmcD',NULL,NULL,'desktop','Other','2026-07-22 20:09:25'),(1420,'/',NULL,NULL,'xvBRjKniTbz7e8QZT5phtOTN8AlO0rq97tY015At',NULL,NULL,'desktop','Other','2026-07-22 20:51:22'),(1421,'/',NULL,NULL,'GjnpPLZkyR7Di2j4tHYI58pODHEolyYelApP3g5o',NULL,NULL,'desktop','Other','2026-07-22 21:33:27'),(1422,'/',NULL,NULL,'nU51YSOfzMfdHaM1IXAq4h3W8ryL3KksJmEsYYl7',NULL,NULL,'desktop','Other','2026-07-22 22:14:42'),(1423,'/',NULL,NULL,'0CAdIMgbB6BdhViCHU82dxaON0S4vkQcg1cUn3nn',NULL,NULL,'desktop','Other','2026-07-22 22:56:20'),(1424,'/',NULL,NULL,'mKEcO3Nb4wnBDTZFHBsAatvWoA1bEPr2sKFhGQLh',NULL,NULL,'desktop','Other','2026-07-22 23:38:39'),(1425,'/',NULL,NULL,'FZDzxqESKx1LvwWUuYy3OaZMtoJlvNYqi2DlBa2V',NULL,NULL,'desktop','Other','2026-07-23 00:20:20'),(1426,'/',NULL,NULL,'9a5HKM3ieaE68q6t9rJNBhttWCIG55n721YCkRxB',NULL,NULL,'desktop','Other','2026-07-23 01:01:53'),(1427,'/',NULL,NULL,'YmJKo9pCAR6rPuWTpl5oMm3nAqoPqz92oHgh0z7d',NULL,NULL,'desktop','Other','2026-07-23 01:45:17'),(1428,'/',NULL,NULL,'ttKmYqtG4bpL5OWMS7IUXrFigMO9Niw5cA3Cycbi',NULL,NULL,'desktop','Firefox','2026-07-23 02:13:10'),(1429,'login',NULL,'https://safhenokhost.ir/','ttKmYqtG4bpL5OWMS7IUXrFigMO9Niw5cA3Cycbi',NULL,NULL,'desktop','Firefox','2026-07-23 02:13:40'),(1430,'blog',NULL,'https://safhenokhost.ir/','ttKmYqtG4bpL5OWMS7IUXrFigMO9Niw5cA3Cycbi',NULL,NULL,'desktop','Firefox','2026-07-23 02:15:00'),(1431,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,'https://safhenokhost.ir/blog','ttKmYqtG4bpL5OWMS7IUXrFigMO9Niw5cA3Cycbi',NULL,NULL,'desktop','Firefox','2026-07-23 02:15:09'),(1432,'contact',NULL,'https://safhenokhost.ir/','ttKmYqtG4bpL5OWMS7IUXrFigMO9Niw5cA3Cycbi',NULL,NULL,'desktop','Firefox','2026-07-23 02:15:43'),(1433,'/',NULL,NULL,'iyvOv7Xt64e2ZBzY1YbZ8eVSZhugXxWlbHQEridZ',NULL,NULL,'desktop','Other','2026-07-23 02:27:46'),(1434,'/',NULL,NULL,'rRTvu0JvEGfBemQS0a4kWdvYyJafA221nzQTmDbc',NULL,NULL,'desktop','Other','2026-07-23 03:09:23'),(1435,'/',NULL,NULL,'ZZv1C5NoOkVxF4Pe43ubA0zaQosrfDzuc0dBFW5V',NULL,NULL,'desktop','Other','2026-07-23 03:52:14'),(1436,'/',NULL,NULL,'7xAqfY4iqrbQ0xobGrY7nunl8FmnKVY7XBKlRnC2',NULL,NULL,'desktop','Other','2026-07-23 04:35:35'),(1437,'/',NULL,NULL,'OyJpEWa6bKkWtyisQTiSHiOPGaV6SwSoHiMQFl10',NULL,NULL,'desktop','Other','2026-07-23 05:18:50'),(1438,'/',NULL,NULL,'WvW90VQuNPvk6yHhUvTfVV74g8rvQd12sj0Z0SQF',NULL,NULL,'desktop','Firefox','2026-07-23 05:45:03'),(1439,'/',NULL,NULL,'vfqguUpQMxM19Ce5d1M44h6NwDFbtb0wLjVfmM6Q',NULL,NULL,'desktop','Other','2026-07-23 06:02:12'),(1440,'/',NULL,NULL,'ti6FNnXJ3o0VV3UPs9MtYp2aKYPKSnPoT9vBcVXg',NULL,NULL,'desktop','Other','2026-07-23 06:34:50'),(1441,'/',NULL,NULL,'ifdfJAHqrroB1Mgizcm3EXErK93ajFt4TUTPIbW6',NULL,NULL,'desktop','Chrome','2026-07-23 06:38:32'),(1442,'/',NULL,NULL,'2dQHa9ZIiu1kvdRYKIOxYcfiRQisWWkDHdUTZxiS',NULL,NULL,'desktop','Other','2026-07-23 06:47:02'),(1443,'/',NULL,NULL,'BAvbukNDNzVKDE18EaIehEfIPibCXOTZ1wL4GGtB',NULL,NULL,'desktop','Other','2026-07-23 07:29:57'),(1444,'/',NULL,NULL,'Gj2u6YsMnBxgBcZAOaV0xJnRjWrTVWAq88M3gFCx',NULL,NULL,'desktop','Other','2026-07-23 08:12:06'),(1445,'/',NULL,NULL,'E23Zr1qt8ORoYQc737wI1H42uyDKslhoBjgJCZGb',NULL,NULL,'desktop','Other','2026-07-23 08:55:54'),(1446,'/',NULL,NULL,'Tn8B3Kn5aDMBX6ibGDMc97edpOuwVSQviVxXcxme',NULL,NULL,'desktop','Other','2026-07-23 09:39:33'),(1447,'/',NULL,NULL,'lEEwlDhhgA4CgC4SpNFCt0Y1EnIKg9mMCptlZIZJ',NULL,NULL,'desktop','Other','2026-07-23 10:21:54'),(1448,'/',NULL,NULL,'iYMPV0cT1Aj5cnEYtPeHARbBzDkSjaB92rbZnjiP',NULL,NULL,'desktop','Other','2026-07-23 11:05:18'),(1449,'login',NULL,'https://safhenokhost.ir/login','HzEPWS3dguwdeZh2Sql1HBmjMjGEGtcLkbr5SJgc',NULL,NULL,'desktop','Firefox','2026-07-23 11:08:45'),(1450,'login',NULL,'https://safhenokhost.ir/admin/dashboard','RUB9NHgddLy3DaQeDZeIpJIrm0gc9igJMAL2lq4U',1,NULL,'desktop','Firefox','2026-07-23 11:09:19'),(1451,'/',NULL,NULL,'f4A96S5orqzbtvQwThD0N1bHWgKi0LShqOHIp6tk',NULL,NULL,'desktop','Other','2026-07-23 11:47:49'),(1452,'/',NULL,NULL,'x1tTfonk89xwCpQdOBjMIq1BUSQnsyLq2C2piavx',NULL,NULL,'desktop','Other','2026-07-23 12:30:13'),(1453,'/',NULL,NULL,'lNObzHy2nAWtdHkSm3aNpX1GX38Ojg82W9QaL9tp',NULL,NULL,'desktop','Other','2026-07-23 13:06:35'),(1454,'/',NULL,NULL,'8YiiYEeGPZ4DrVyjBEQUbWgGo0LGGDmc1dhFJ8s3',NULL,NULL,'desktop','Other','2026-07-23 13:12:04'),(1455,'/',NULL,NULL,'SbfJxRXenKyIjhsgAIqKDSWPg2jKHAjsNB8lgWFX',NULL,NULL,'mobile','Chrome','2026-07-23 13:29:39'),(1456,'/',NULL,NULL,'QdNdiy3wUXrlKnNe63gFFd49ErLJC6DUSQnCH3XU',NULL,NULL,'mobile','Chrome','2026-07-23 13:30:20'),(1457,'/',NULL,NULL,'7wXwKDPkODYOeJemzX4H5Qp7WOi719ERMucmUL5m',NULL,NULL,'desktop','Other','2026-07-23 13:30:25'),(1458,'/',NULL,NULL,'n5t9lQxxB0qFECtVPM0w4bUJemvYb85YxtQjXS36',NULL,NULL,'mobile','Chrome','2026-07-23 13:30:26'),(1459,'/',NULL,NULL,'JnFBRC5khbUUnTpzz7TUgNemdxGwPlKj56PTEvOv',NULL,NULL,'desktop','Other','2026-07-23 13:30:26'),(1460,'/',NULL,NULL,'jcEwstEILFeOY0vEgh8uhgUQZR5hw7rP8lEzHAsL',NULL,NULL,'desktop','Other','2026-07-23 13:55:03'),(1461,'/',NULL,NULL,'VfG9cOuHNoBm0KaZS16UWMJtO5G0UIKQT244uH50',NULL,NULL,'mobile','Chrome','2026-07-23 14:19:37'),(1462,'/',NULL,NULL,'oR3m2yCoytZskOUzHSXbJDBw8cHTHFDqTitgv7OE',NULL,NULL,'desktop','Other','2026-07-23 14:37:40'),(1463,'/',NULL,NULL,'GBQlHxJvOO4KA1Bh7kyZ1ruUjUsPwSnDa55y5cAm',NULL,NULL,'desktop','Other','2026-07-23 15:20:10'),(1464,'/',NULL,NULL,'I9xPmRhkO4TgZ6iA83SXcQRHSkhynLTFMl1x45EQ',NULL,NULL,'desktop','Other','2026-07-23 16:03:05'),(1465,'login',NULL,'https://safhenokhost.ir/admin/license','RUB9NHgddLy3DaQeDZeIpJIrm0gc9igJMAL2lq4U',1,NULL,'desktop','Firefox','2026-07-23 16:41:21'),(1466,'/',NULL,NULL,'lqrCeqEaDu251qnDfzetWILhAu2W8FNeFrrODYAI',NULL,NULL,'desktop','Other','2026-07-23 16:46:52'),(1467,'/',NULL,NULL,'fWHU1YIv3BBTIK2urj8Yr5CIvSH4jcsae8lSRXD1',NULL,NULL,'desktop','Other','2026-07-23 17:29:44'),(1468,'/',NULL,NULL,'3EEXsK0yX6tjeHedEFtJAplYo9c3YqnUwPDAuxIS',NULL,NULL,'desktop','Other','2026-07-23 18:13:10'),(1469,'/',NULL,NULL,'CG7RjUqGxLTAcycoSUyY4j0tLx6dIb7OujpmHfqs',NULL,NULL,'desktop','Other','2026-07-23 18:56:11'),(1470,'/',NULL,NULL,'b1gkkoABav22m0lcLBbwiEYdFduVQgZkJuupi67N',NULL,NULL,'desktop','Other','2026-07-23 19:39:38'),(1471,'/',NULL,'https://safhenokhost.ir/?rest_route=%2Fjetpack%2Fv4%2Fsync%2Fstatus&_for=jetpack&token=uThbNbe%21qJyhj8YyhV13%28O%26uLR3Ka6%28f%3A1%3A0&timestamp=1784848439&nonce=EMMoFnS7Mh&body-hash&signature=PYDbwM1ETeHCDT5XxKlqgfCGuFY%3D','Rpv9ie1RVAvIsUeLaIvcyfcD2dMFYqWjWAr4qytr',NULL,NULL,'desktop','Other','2026-07-23 19:43:55'),(1472,'/',NULL,NULL,'eKfTo041mCZOEKDEo6pULOVXHsSZTAiceirXT5Mk',NULL,NULL,'desktop','Other','2026-07-23 20:21:56'),(1473,'/',NULL,NULL,'K4Uk9TO0rMYExkgRnOiSpcwNT3WsNDeEI5fNIZvO',NULL,NULL,'desktop','Other','2026-07-23 21:04:07'),(1474,'/',NULL,NULL,'57f8bMRbUYE5RDufPdqvkTj74Q24JPU1EKI7qurr',NULL,NULL,'desktop','Other','2026-07-23 21:47:18'),(1475,'/',NULL,NULL,'gyn9VnRhAzz49XQJGhkOlND9QT510uwP8iSLUmYO',NULL,NULL,'desktop','Other','2026-07-23 22:29:05'),(1476,'/',NULL,NULL,'j8SpSku809yjeDGtLKFKRKnzz8olAxMJ76KgGV8q',NULL,NULL,'desktop','Other','2026-07-23 23:10:30'),(1477,'/',NULL,'http://safhenokhost.ir/','64tSMfFowVdtxUJSLNwCfZLk38Tnw9bOFDRop9yE',NULL,NULL,'mobile','Firefox','2026-07-23 23:33:56'),(1478,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'iSdKpZm7nt8Ajh9udSxsqwgWHw3rr3lnXt6x2AUh',NULL,NULL,'mobile','Firefox','2026-07-23 23:33:57'),(1479,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'anwKunjgOsKopJMsxrRIRmoFS8pySpWp86maGvSE',NULL,NULL,'mobile','Firefox','2026-07-23 23:33:57'),(1480,'blog/sayt-hmh-karh',NULL,NULL,'tn0k3pyRr7mD6TOMcwazG2pNiMV9c0dXs6P2LGOD',NULL,NULL,'mobile','Firefox','2026-07-23 23:33:58'),(1481,'/',NULL,NULL,'hYbLCKEVemIEaE5SpxvtP0faq3rdTah3IiIuIUby',NULL,NULL,'desktop','Chrome','2026-07-23 23:36:00'),(1482,'/',NULL,NULL,'dR4M3ySzTyRfQ1dJGAGkd4FH3HvgBqmbd3JTwNCb',NULL,NULL,'desktop','Other','2026-07-23 23:53:08'),(1483,'/',NULL,NULL,'22ACEbRkxRxQaXKlDSY40E9YXzLX4zprNacxpfPB',NULL,NULL,'desktop','Other','2026-07-24 00:34:57'),(1484,'/',NULL,NULL,'0L8hUhXw4ovxjAG9zYMspmuv7kPISKZrveG48tTx',NULL,NULL,'desktop','Other','2026-07-24 01:16:33'),(1485,'/',NULL,NULL,'ltJsPFmgoxrJmP6jKNyCqHfAXJcVGzZUYhWeighJ',NULL,NULL,'desktop','Other','2026-07-24 01:59:10'),(1486,'/',NULL,NULL,'XZO3jT6hqCbwZM02u73yXrMimt6Y78eEtmZy8CS0',NULL,NULL,'desktop','Other','2026-07-24 02:42:10'),(1487,'/',NULL,NULL,'6k7to1EzaGhpHwx6vnTzKgklnUIIjEJWQUuHYfYJ',NULL,NULL,'desktop','Other','2026-07-24 03:24:24'),(1488,'/',NULL,NULL,'CkEqMUtreO33mKtDPkGFwPq7zqm1G65T6Z65OcUs',NULL,NULL,'desktop','Other','2026-07-24 04:06:21'),(1489,'/',NULL,NULL,'uK0kdml8CtStX3yMaPEf6hBiUQHGOnEcehqUZXcO',NULL,NULL,'desktop','Other','2026-07-24 04:49:36'),(1490,'/',NULL,NULL,'nKSRoanEyc0tXIi4HGz4LgeULQR83v7K2o4WmuUV',NULL,NULL,'desktop','Other','2026-07-24 05:31:41'),(1491,'/',NULL,NULL,'nbVTj0l2rEVtOQujYKoxzGkSOM2rXvvvx3vaxwmM',NULL,NULL,'mobile','Chrome','2026-07-24 05:46:34'),(1492,'/',NULL,NULL,'6ZiUAEaZxoNFlP2S1pRwrlo6HUvpA4XgpXd958JW',NULL,NULL,'desktop','Other','2026-07-24 06:14:28'),(1493,'/',NULL,NULL,'Thn0EnOS1xIRaQ2WqXiMSUowufpvcf2mr6JCws6W',NULL,NULL,'desktop','Other','2026-07-24 06:57:40'),(1494,'/',NULL,NULL,'K3hi6pj3J4QyosWNowXIOlu08k0QIGyppHET8tlP',NULL,NULL,'desktop','Other','2026-07-24 07:40:51'),(1495,'login',NULL,'https://safhenokhost.ir/admin/license','iFyRW2Yfnbwb2e97lPuJx31W5vXatO1ca59NmZZd',NULL,NULL,'desktop','Firefox','2026-07-24 11:50:23'),(1496,'login',NULL,'https://safhenokhost.ir/admin/dashboard','hPWqaTnzMwJSECnkD5g1JuJlm38LTUr8nk6ucK8X',1,NULL,'desktop','Firefox','2026-07-24 11:50:38'),(1497,'/',NULL,NULL,'ZltBjHs0V9GolgqXpTPfqOO7L5wFuwOGsdvTX08s',NULL,NULL,'desktop','Other','2026-07-24 11:53:38'),(1498,'/',NULL,NULL,'EoKIg3kgVXWHrqEk8SNYtgUph5OBSSvm4Lt1YBva',NULL,NULL,'desktop','Other','2026-07-24 09:06:00'),(1499,'/',NULL,NULL,'uDcLtOx2tFp3ZCSvJpWiLr2j0vjur6Rizd5fshbm',NULL,NULL,'desktop','Other','2026-07-24 09:50:05'),(1500,'/',NULL,NULL,'u21847weAcuSSoryDINicP5Fjs3IxZ2SCtW9k4vI',NULL,NULL,'desktop','Other','2026-07-24 10:32:31'),(1501,'/',NULL,NULL,'JK5trP2XTGOycIR8uzcDuARVReW0xtkcvCzGAY9u',NULL,NULL,'desktop','Other','2026-07-24 11:15:04'),(1502,'/',NULL,NULL,'oaUbPSPz5FbPojJmWFukbIHIUz3CXHBLa8N3ZJ7c',NULL,NULL,'desktop','Other','2026-07-24 11:58:29'),(1503,'/',NULL,NULL,'Mwo74IAn2MZTNoB54aWFO953NZYdSyWzxSj1vaP5',NULL,NULL,'desktop','Other','2026-07-24 12:41:32'),(1504,'/',NULL,NULL,'U8fOOzgEiBK2ZDXB6RXA2nf0b7hKQRzJ5WHc299N',NULL,NULL,'desktop','Other','2026-07-24 13:24:14'),(1505,'/',NULL,NULL,'t3X4XZov47hkVqxp3s0hnbnHgNkhQx0prL2nS0Bh',NULL,NULL,'desktop','Other','2026-07-24 14:06:54'),(1506,'/',NULL,NULL,'KjpifCSZ0zMCtgtU1taGFmHbNkxkB0JpHG9jiOuo',NULL,NULL,'mobile','Chrome','2026-07-24 14:28:31'),(1507,'shop',NULL,'https://safhenokhost.ir/','KjpifCSZ0zMCtgtU1taGFmHbNkxkB0JpHG9jiOuo',NULL,NULL,'mobile','Chrome','2026-07-24 14:29:41'),(1508,'shop/cart',NULL,'https://safhenokhost.ir/shop','KjpifCSZ0zMCtgtU1taGFmHbNkxkB0JpHG9jiOuo',NULL,NULL,'mobile','Chrome','2026-07-24 14:29:44'),(1509,'blog',NULL,'https://safhenokhost.ir/','KjpifCSZ0zMCtgtU1taGFmHbNkxkB0JpHG9jiOuo',NULL,NULL,'mobile','Chrome','2026-07-24 14:29:56'),(1510,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,'https://safhenokhost.ir/blog','KjpifCSZ0zMCtgtU1taGFmHbNkxkB0JpHG9jiOuo',NULL,NULL,'mobile','Chrome','2026-07-24 14:29:58'),(1511,'/',NULL,NULL,'WJWdsyVSfhA4ehS2kmm4YZb4wDhfQfqYpIJUnZ58',NULL,NULL,'desktop','Other','2026-07-24 14:50:24'),(1512,'/',NULL,NULL,'1azUNHXeedWskg2TS18H0TAxpobDG4gFVkSqz92O',NULL,NULL,'desktop','Other','2026-07-24 15:33:44'),(1513,'login',NULL,'https://safhenokhost.ir/admin/dashboard','hPWqaTnzMwJSECnkD5g1JuJlm38LTUr8nk6ucK8X',1,NULL,'desktop','Firefox','2026-07-24 15:49:26'),(1514,'/',NULL,NULL,'GD6EFBISCCSqcP6AVivT3ZCyGDJzQ4g2nzGWJNJD',NULL,NULL,'desktop','Other','2026-07-24 16:16:04'),(1515,'/',NULL,NULL,'XHSX8HaPCKpiM90eCfbEmxIs0P9QCuGS92hZkO1K',NULL,NULL,'desktop','Chrome','2026-07-24 16:39:31'),(1516,'/',NULL,NULL,'j7AeHVqsQ43ceG1afQiPPxCVCfTYsYxLEBlwUA5I',NULL,NULL,'desktop','Other','2026-07-24 16:58:46'),(1517,'/',NULL,NULL,'4iTVqUIKHlWIZ0AD9dNpVu37zQnB62Msk20e2aB7',NULL,NULL,'desktop','Other','2026-07-24 17:41:29'),(1518,'/',NULL,NULL,'4kpyB2vHmjibTZaQ6EhI9qVXHyvDHMX230fYrtBM',NULL,NULL,'desktop','Other','2026-07-24 18:24:36'),(1519,'/',NULL,NULL,'HDfVgkIg2IWVLBAdOIfvam9gjsyHCQurfGNX0dj6',NULL,NULL,'desktop','Firefox','2026-07-24 18:36:35'),(1520,'/',NULL,NULL,'ZgkqVWWQu9DL35SEMFxlQBpA9s81I4eYeqcijwwf',NULL,NULL,'desktop','Chrome','2026-07-24 18:46:50'),(1521,'/',NULL,'http://safhenokhost.ir','0DQahv08JvUZNRnIjFedHaoID1A6l0dR6ZrDmYtK',NULL,NULL,'desktop','Chrome','2026-07-24 18:46:51'),(1522,'/',NULL,NULL,'HPIswve9GRqEg96bZkLXo95Jk8vq7ChAHLGi5c9H',NULL,NULL,'desktop','Other','2026-07-24 19:07:44'),(1523,'/',NULL,NULL,'Yfgror1tU4pmYADkJeeJ2SPbvenJqy4X1H4Y6YUz',NULL,NULL,'desktop','Chrome','2026-07-24 19:38:14'),(1524,'/',NULL,NULL,'lOwGD3MNYNcpLmQeAGgdSMar3mhdmlcYWrevVekY',NULL,NULL,'desktop','Other','2026-07-24 19:50:51'),(1525,'/',NULL,NULL,'LOPmCxfrRwFBsmXoUr6PoPxmYAMjlDhWmF9tapq9',NULL,NULL,'desktop','Firefox','2026-07-24 20:01:39'),(1526,'/',NULL,NULL,'UTMVgKdJtIzM1Q93zKTp4lYCctAEVtkoPhVuR2tC',NULL,NULL,'desktop','Other','2026-07-24 20:04:30'),(1527,'/',NULL,NULL,'jxZwPzrqC4i0zZI4O5W0tfyHstAFuj2i8EaRefZW',NULL,NULL,'desktop','Firefox','2026-07-24 20:05:24'),(1528,'/',NULL,NULL,'6NelzxsKFRE615jW30O0eyGYUIcHK9BWw9CDmMBV',NULL,NULL,'desktop','Other','2026-07-24 20:05:36'),(1529,'/',NULL,NULL,'mx0crakq84Wl4Sz2j71zM3Ax4N1efugFOYcT13ih',NULL,NULL,'desktop','Other','2026-07-24 20:07:00'),(1530,'/',NULL,NULL,'uCPVnuhxAdfth1XwrasNebHocJ0hGUC9TjoyLs1v',NULL,NULL,'desktop','Other','2026-07-24 20:07:01'),(1531,'/',NULL,NULL,'N88S2af1sV8SKXtiOt6pQCVhGOmGE8cxBPHwlYhE',NULL,NULL,'desktop','Other','2026-07-24 20:07:01'),(1532,'/',NULL,NULL,'ciU1t9U8KNpBmb4SA4fY2YJCkDDtn4LMcsjQYdh5',NULL,NULL,'desktop','Other','2026-07-24 20:07:31'),(1533,'/',NULL,NULL,'KBaLvpX3UXD8qsY5spNIG8aAB6jQhVASdAoLkzfk',NULL,NULL,'desktop','Other','2026-07-24 20:07:32'),(1534,'/',NULL,NULL,'kkIb5jKt7V8ATLRwVd2BnhtOIjWB7ei4qH6wEnib',NULL,NULL,'desktop','Other','2026-07-24 20:07:32'),(1535,'/',NULL,NULL,'hdHspYY0zPlJQwK0n0n0YuTazP0rGOt9Hmz0VbtQ',NULL,NULL,'desktop','Other','2026-07-24 20:32:53'),(1536,'/',NULL,NULL,'lfgrCcOFcjEJaWUA4braXm82qVSuRA19BkyW2YR8',NULL,NULL,'desktop','Other','2026-07-24 21:14:49'),(1537,'shop/cart',NULL,NULL,'x1gBMV7ivDSe0CxmyQjLTihA0pKExKzu7IPgbzAv',NULL,NULL,'desktop','Other','2026-07-24 21:17:35'),(1538,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'SG93bP35qW4RQAqv4eZBCM2Ce40sldtzEd55mxYw',NULL,NULL,'desktop','Other','2026-07-24 21:17:47'),(1539,'/',NULL,NULL,'09TQHz1ayQT1sjYhnhnSiKXYv5rS1ghJfM1q3fRF',NULL,NULL,'desktop','Other','2026-07-24 21:58:02'),(1540,'/',NULL,NULL,'i9aahcBDyTYTZJVUNJsZc8JUvEuJK5H4B4hX9Tih',NULL,NULL,'desktop','Other','2026-07-24 22:40:24'),(1541,'/',NULL,NULL,'WvMGmOa2Nl2y5lZ0rydbgv14xerpqtKyiYWNHcqI',NULL,NULL,'desktop','Other','2026-07-24 23:22:12'),(1542,'/',NULL,NULL,'aiDVEzySPsuGy2pwUjK3QCVnfVGUUPzRWqyQu83Q',NULL,NULL,'desktop','Other','2026-07-24 23:35:33'),(1543,'/',NULL,NULL,'TbZS1zUtkW6HgJ77bYiG1UpfTTh7nbTZefjqtRn9',NULL,NULL,'desktop','Other','2026-07-25 00:04:46'),(1544,'/',NULL,NULL,'lnzoLSjcgEeBY5F0g7CLPq0fk6iMKrh9ffxB73DB',NULL,NULL,'desktop','Other','2026-07-25 00:46:45'),(1545,'/',NULL,NULL,'mHiyKziJTuhpNq9SmhdxWYxqJr4IT1pDE6KA3Hee',NULL,NULL,'desktop','Other','2026-07-25 01:30:01'),(1546,'/',NULL,NULL,'3HjmQ7y4JAQiyscoYYFcz6QdmDloJylguP0agbhD',NULL,NULL,'desktop','Chrome','2026-07-25 01:39:49'),(1547,'/',NULL,NULL,'7SCwAvaT38cA6RHVz2VIVQzLQJcmpaLtIRD8UpOj',NULL,NULL,'mobile','Chrome','2026-07-25 01:45:38'),(1548,'/',NULL,NULL,'wCrlgZetJPYocc7GvLHpWZ8VinbUkFQOxte9qTHx',NULL,NULL,'desktop','Other','2026-07-25 02:13:37'),(1549,'/',NULL,NULL,'7SCwAvaT38cA6RHVz2VIVQzLQJcmpaLtIRD8UpOj',NULL,NULL,'mobile','Chrome','2026-07-25 02:35:39'),(1550,'/',NULL,NULL,'cpOFPn9loPeJ01vhZB1AjUHOpJAumRlq95rC1ilV',NULL,NULL,'desktop','Other','2026-07-25 02:57:31'),(1551,'/',NULL,NULL,'7gRSbKoTn2JM1kmMV0OThFFpGvebQ07JTBaCKCgy',NULL,NULL,'desktop','Other','2026-07-25 03:41:11'),(1552,'/',NULL,NULL,'QiVG45wLDu0MW9bIERTwTu9IUEOMYrDaXFLrYtGY',NULL,NULL,'desktop','Other','2026-07-25 04:23:58'),(1553,'/',NULL,NULL,'NyEGzXxy6Lo77rCdfutaBZSCN3guzAVFUOYPaVRU',NULL,NULL,'desktop','Other','2026-07-25 05:08:42'),(1554,'/',NULL,NULL,'hqr1EC2gxcTCxg5CEXQ8A4TLoccS7DqV4VZOXzNx',NULL,NULL,'desktop','Chrome','2026-07-25 05:29:22'),(1555,'/',NULL,NULL,'M8ErnhsQmNsqyTR2lWMK38RCrH8hynhNFmeyzhjd',NULL,NULL,'desktop','Other','2026-07-25 05:53:25'),(1556,'/',NULL,NULL,'CyK9FQiGK4LIA7gL49MzFya4DY8yMtr6NIHIBrfF',NULL,NULL,'mobile','Chrome','2026-07-25 06:30:08'),(1557,'blog',NULL,NULL,'f0zjV7E3PmPwfkCKJD4ZkzFVn8Am6zTNxETrYoMu',NULL,NULL,'desktop','Other','2026-07-25 06:31:54'),(1558,'/',NULL,NULL,'lQNTp4p5JJTJFAcXGirjQpxzTHXNO7tFlNkv1mpE',NULL,NULL,'desktop','Other','2026-07-25 06:37:47'),(1559,'/',NULL,NULL,'EbxJimYjcmuhVwYL1nHLpfyn9OTL6Jc7UzqSmqv5',NULL,NULL,'desktop','Other','2026-07-25 07:20:46'),(1560,'/',NULL,NULL,'76qRsuXfGWiflv0xjrpGM3ioptgT0hNQf6KPEeDT',NULL,NULL,'desktop','Other','2026-07-25 08:03:55'),(1561,'/',NULL,NULL,'pbCkR4HL7st4ZLePkRY6Ls4JAIbWRYTRBMEkdyX4',NULL,NULL,'desktop','Other','2026-07-25 08:48:00'),(1562,'/',NULL,NULL,'Uu9byBKLuDGilY5LJzgY5eJRC1rGEeiCMeIT9qzp',NULL,NULL,'desktop','Other','2026-07-25 09:24:49'),(1563,'/',NULL,NULL,'mwjBI8VGCjBXVAaXQ8YcC3StvLGRpGcnqukqZ0En',NULL,NULL,'desktop','Other','2026-07-25 09:31:25'),(1564,'/',NULL,NULL,'L7lXk17s5C9l9BTkcaJkdtyed9cLSZ1hcq3qmgOr',NULL,NULL,'desktop','Other','2026-07-25 10:17:43'),(1565,'/',NULL,NULL,'b2rHvqZ2PG5OmALpNNVdU6Qd8XhYiympXNUbGQEU',NULL,NULL,'desktop','Other','2026-07-25 11:04:47'),(1566,'/',NULL,NULL,'GvB43kVEki53HvUOAKqeMUpAj21vwyehkBPyflZy',NULL,NULL,'desktop','Other','2026-07-25 11:51:21'),(1567,'/',NULL,NULL,'6KMeFtCe8e9AG4oAb9faWDFouUXXHLyynwMtfnqH',NULL,NULL,'desktop','Other','2026-07-25 12:37:28'),(1568,'/',NULL,NULL,'OrggPBpJDNkTa6kvmVkAaEaxwTE04qJxLL4tKcaV',NULL,NULL,'desktop','Other','2026-07-25 13:24:09'),(1569,'/',NULL,NULL,'0JwCgcX9pDnqTv9M0Ep4JQing7Z2DcUJTTiaVyDR',NULL,NULL,'desktop','Other','2026-07-25 14:10:42'),(1570,'login',NULL,NULL,'B3TirVJRPhZbUtUmHhFU3gZabCkBaTjomFHtNqS2',NULL,NULL,'desktop','Other','2026-07-25 14:34:48'),(1571,'/',NULL,NULL,'HOQgVvCZAwJmkYlX4ewVupeBnCiYqwLkR8oWIXRV',NULL,NULL,'desktop','Other','2026-07-25 14:57:47'),(1572,'/',NULL,NULL,'yBWHWEGB7V6UV779ccIIdZSsgxdMxwXtYDkdEkyi',NULL,NULL,'desktop','Other','2026-07-25 15:43:43'),(1573,'/',NULL,'http://safhenokhost.ir/','btBVAC87K1EpMO7taV6HhKf653mvO7PXVjdCJpt5',NULL,NULL,'desktop','Chrome','2026-07-25 16:29:22'),(1574,'/',NULL,NULL,'EhiXxjcvUpMqP6pkLy00rZ71bhdLDLnWEbW8sap0',NULL,NULL,'desktop','Other','2026-07-25 16:30:08'),(1575,'/',NULL,NULL,'dixa9CfII8CilR0yUF5VV8FxCXtsYdsST5OcX9Wo',NULL,NULL,'desktop','Other','2026-07-25 16:48:15'),(1576,'/',NULL,NULL,'zzilR2LD8Jz9A6kqZmXrJAG1XmppiX4dW5MyPycd',NULL,NULL,'desktop','Other','2026-07-25 17:16:17'),(1577,'/',NULL,NULL,'efnnWRhHcpYWHXhRAq3W4xcdhVXNugDByRhil3re',NULL,NULL,'desktop','Other','2026-07-25 18:03:07'),(1578,'/',NULL,NULL,'r0LlqxcMvolD6TCxxCzU7M8ZHc24emt0p9jiroQu',NULL,NULL,'desktop','Other','2026-07-25 18:29:44'),(1579,'/',NULL,NULL,'iuQ9P64IOli5UNZEOYIWGZAuhfBPn3uF7ZOhOITR',NULL,NULL,'desktop','Other','2026-07-25 18:29:45'),(1580,'/',NULL,NULL,'77yL7vrBTDovSUWOVLFPP8YkoD3j32bb7BrV3pAw',NULL,NULL,'desktop','Other','2026-07-25 18:49:42'),(1581,'/',NULL,NULL,'QmJ4lXiCuAk5Cia4189wuc0ciksVmQ2WXXhbFTBM',NULL,NULL,'desktop','Other','2026-07-25 19:36:00'),(1582,'/',NULL,NULL,'stqzU05cLKJyAXnh5qzsezZ52Fce1Qwfkcf0P0ha',NULL,NULL,'desktop','Other','2026-07-25 20:22:25'),(1583,'/',NULL,NULL,'xcAmjHhzrk6yDVttPRsRWXqakjSVeLwMWQSS7cdf',NULL,NULL,'desktop','Other','2026-07-25 21:08:47'),(1584,'/',NULL,NULL,'rmT6yAd2g11o81d0nX7QqSLkq22zdQGiVynn7tKb',NULL,NULL,'desktop','Safari','2026-07-25 21:42:27'),(1585,'/',NULL,NULL,'fPTUpeRa71ICeks0XyYd1aOkvgF7essQFqVOo1If',NULL,NULL,'desktop','Other','2026-07-25 21:55:51'),(1586,'/',NULL,NULL,'ho5prqQOnCMNGN8bM1P5tuX7cZ8FBcuUjbwR1eyr',NULL,NULL,'desktop','Other','2026-07-25 22:41:16'),(1587,'/',NULL,NULL,'8evxthUjaj056kOGCaoQkoQdGbZXNm9Nhg4QmxQ3',NULL,NULL,'desktop','Chrome','2026-07-25 23:25:26'),(1588,'/',NULL,NULL,'vYmxZp2xfQBe8xPluDHf5YUHT0e5WQRPhE8BvHkx',NULL,NULL,'desktop','Other','2026-07-25 23:27:49'),(1589,'/',NULL,NULL,'bLZGNum8rtK1MNFxl6AXQr4GRtP2Dl14Z4thZrab',NULL,NULL,'desktop','Other','2026-07-26 00:14:34'),(1590,'/',NULL,NULL,'OdQzuLAft9PEGPSGOnFiNFj9do0medg7qHG5Ej8A',NULL,NULL,'desktop','Firefox','2026-07-26 00:51:17'),(1591,'/',NULL,NULL,'VG0X1TnDv7qWNbXweHnPBQOrawlp3MmsEOOnQRre',NULL,NULL,'desktop','Other','2026-07-26 01:00:57'),(1592,'/',NULL,NULL,'zFd3wi7GS10FlOtmtKyzvF6SDnDigq3teoQydHcA',NULL,NULL,'desktop','Other','2026-07-26 01:47:50'),(1593,'/',NULL,'http://safhenokhost.ir/','zR8Va8EeOnd9ne7wz5CDPShFv7tfl80ppECNBQYT',NULL,NULL,'desktop','Chrome','2026-07-26 01:52:26'),(1594,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'sU8GgiNGlklEsTIxa0RHBaammRQ1fEUdJeyT2vqr',NULL,NULL,'desktop','Chrome','2026-07-26 01:52:26'),(1595,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'9I1ent9rGVeDevjq0NbBKG3VdnRSwdFcjD9xZxYy',NULL,NULL,'desktop','Chrome','2026-07-26 01:52:27'),(1596,'blog/sayt-hmh-karh',NULL,NULL,'WnZvOFNXyfAU23aoYewoDKAZgUBVjcZmxpVooANi',NULL,NULL,'desktop','Chrome','2026-07-26 01:52:28'),(1597,'/',NULL,NULL,'v48FzuXyH9TPBi7iWNztU2zzteIK4HrrgywZiyEA',NULL,NULL,'desktop','Other','2026-07-26 02:35:25'),(1598,'/',NULL,NULL,'FiIyS1nycP0VjymTqf45f86EB1ZHYif0a3yoAj7s',NULL,NULL,'desktop','Other','2026-07-26 03:21:59'),(1599,'/',NULL,NULL,'QvaBoorDBKwW85aRHHEazaWmcsleXHU4xv802mWa',NULL,NULL,'desktop','Other','2026-07-26 04:09:25'),(1600,'/',NULL,NULL,'iqqGkO8a2VMzTUjbJ9PkX7MlOeAVmBTj3qMoISPe',NULL,NULL,'desktop','Other','2026-07-26 04:56:39'),(1601,'/',NULL,NULL,'ROOj5oKxoSbzN6sZoRvmcuowr4v3P5lF2qUy1f5U',NULL,NULL,'mobile','Safari','2026-07-26 05:37:32'),(1602,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'ROOj5oKxoSbzN6sZoRvmcuowr4v3P5lF2qUy1f5U',NULL,NULL,'desktop','Chrome','2026-07-26 05:37:45'),(1603,'blog',NULL,NULL,'ROOj5oKxoSbzN6sZoRvmcuowr4v3P5lF2qUy1f5U',NULL,NULL,'desktop','Chrome','2026-07-26 05:37:45'),(1604,'shop',NULL,NULL,'ROOj5oKxoSbzN6sZoRvmcuowr4v3P5lF2qUy1f5U',NULL,NULL,'mobile','Safari','2026-07-26 05:37:46'),(1605,'shop/cart',NULL,NULL,'ROOj5oKxoSbzN6sZoRvmcuowr4v3P5lF2qUy1f5U',NULL,NULL,'desktop','Chrome','2026-07-26 05:37:47'),(1606,'search',NULL,NULL,'ROOj5oKxoSbzN6sZoRvmcuowr4v3P5lF2qUy1f5U',NULL,NULL,'desktop','Chrome','2026-07-26 05:37:47'),(1607,'login',NULL,NULL,'ROOj5oKxoSbzN6sZoRvmcuowr4v3P5lF2qUy1f5U',NULL,NULL,'desktop','Chrome','2026-07-26 05:37:48'),(1608,'/',NULL,NULL,'a3U1kSG4VrDMT5dM6sBsqMM6td4mA5hZMcNkrQb6',NULL,NULL,'desktop','Other','2026-07-26 05:44:33'),(1609,'/',NULL,NULL,'wpJzBx03DDYNgwVGYrlpfQ9c5rpwjlXHFg7vjsPr',NULL,NULL,'desktop','Other','2026-07-26 06:32:10'),(1610,'/',NULL,NULL,'dkizvYeZapBGYwmbfNpukovf2MT8UJDByePQeuqU',NULL,NULL,'desktop','Other','2026-07-26 07:19:01'),(1611,'/',NULL,NULL,'z0RtaygXNGpETCjE2KpD4lh50TXJ8qGxOoGL2cPE',NULL,NULL,'desktop','Other','2026-07-26 08:06:58'),(1612,'shop',NULL,NULL,'5cUcg5XpZSZJIS13Pl3vfL8fpYmoBIeGsZqC9AVX',NULL,NULL,'desktop','Other','2026-07-26 08:40:26'),(1613,'/',NULL,NULL,'ncazafWOLfbWpWVHsSY7GkJahHEupm71VeYU41u8',NULL,NULL,'desktop','Other','2026-07-26 08:54:24'),(1614,'/',NULL,NULL,'v5HeOY06m44UkDSxUYkd8Zak3eBTthKYZpDWoGcu',NULL,NULL,'mobile','Chrome','2026-07-26 09:15:38'),(1615,'/',NULL,NULL,'GO5YGVbsHX0JdddqNWzLI00jG2Q7sUM6ig4YwlZc',NULL,NULL,'desktop','Other','2026-07-26 09:41:09'),(1616,'/',NULL,NULL,'7aWQXfwOv2c1uy9pcLcqW06SvdByqivHnOg1Zilj',NULL,NULL,'desktop','Other','2026-07-26 10:28:53'),(1617,'/',NULL,NULL,'qW8IDTwsOiJFW9KmNIIHLAAg5oEsMazs4Ah64GOh',NULL,NULL,'desktop','Other','2026-07-26 11:16:31'),(1618,'/',NULL,NULL,'K9PheotmJtTKf7ZrtUtAD3XQpVbZcFXSMrGmpLxy',NULL,NULL,'desktop','Other','2026-07-26 12:04:11'),(1619,'/',NULL,NULL,'HjtouICMs2NyPJpKasGbb7iSDzbaXMLAvb2mAxyY',NULL,NULL,'mobile','Safari','2026-07-26 12:11:01'),(1620,'/',NULL,'http://safhenokhost.ir','siX0BSMAfvMDX4SlsYy6tvDiiGY7nwqFNxiwHvfU',NULL,NULL,'desktop','Firefox','2026-07-26 12:11:18'),(1621,'blog/sayt-hmh-karh',NULL,NULL,'siX0BSMAfvMDX4SlsYy6tvDiiGY7nwqFNxiwHvfU',NULL,NULL,'desktop','Safari','2026-07-26 12:12:08'),(1622,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'siX0BSMAfvMDX4SlsYy6tvDiiGY7nwqFNxiwHvfU',NULL,NULL,'desktop','Edge','2026-07-26 12:12:08'),(1623,'blog',NULL,NULL,'siX0BSMAfvMDX4SlsYy6tvDiiGY7nwqFNxiwHvfU',NULL,NULL,'mobile','Chrome','2026-07-26 12:12:16'),(1624,'shop/cart',NULL,NULL,'siX0BSMAfvMDX4SlsYy6tvDiiGY7nwqFNxiwHvfU',NULL,NULL,'desktop','Safari','2026-07-26 12:12:17'),(1625,'search',NULL,NULL,'siX0BSMAfvMDX4SlsYy6tvDiiGY7nwqFNxiwHvfU',NULL,NULL,'desktop','Chrome','2026-07-26 12:12:18'),(1626,'login',NULL,NULL,'siX0BSMAfvMDX4SlsYy6tvDiiGY7nwqFNxiwHvfU',NULL,NULL,'desktop','Chrome','2026-07-26 12:12:20'),(1627,'contact',NULL,NULL,'siX0BSMAfvMDX4SlsYy6tvDiiGY7nwqFNxiwHvfU',NULL,NULL,'desktop','Chrome','2026-07-26 12:12:20'),(1628,'shop',NULL,NULL,'siX0BSMAfvMDX4SlsYy6tvDiiGY7nwqFNxiwHvfU',NULL,NULL,'desktop','Firefox','2026-07-26 12:12:21'),(1629,'shop/compare',NULL,NULL,'siX0BSMAfvMDX4SlsYy6tvDiiGY7nwqFNxiwHvfU',NULL,NULL,'mobile','Chrome','2026-07-26 12:12:38'),(1630,'blog/category/mhtoa',NULL,NULL,'Hh3sk0RRBdx385QmnnbY8D7TzmWf1aNH51FAATNK',NULL,NULL,'mobile','Chrome','2026-07-26 12:12:40'),(1631,'blog',NULL,NULL,'Dt6GjnCO41ieqn8SOBNsa1pcTpHoZmOHCWd2HcXN',NULL,NULL,'mobile','Chrome','2026-07-26 12:12:40'),(1632,'/',NULL,NULL,'WTx2nQ3f6XObytoYGYLXKppoyPbk5bkX9RZqqDFI',NULL,NULL,'mobile','Chrome','2026-07-26 12:23:44'),(1633,'/',NULL,NULL,'8dZVzC7OaYrD630bXpCGOkM5olUhHIMMz9ojkwVF',NULL,NULL,'desktop','Other','2026-07-26 12:50:46'),(1634,'/',NULL,NULL,'84NGqWZpjXA01Wy02Z3vhc7aIKyN03R1vGe5jLIx',NULL,NULL,'desktop','Other','2026-07-26 13:37:06'),(1635,'/',NULL,NULL,'pTBaKsqboWdEef2BKStUJHZYc5tKSHQsAoZuN5iy',NULL,NULL,'desktop','Other','2026-07-26 14:23:22'),(1636,'/',NULL,NULL,'ZQb1O00msK3AHUyiIaXsxgNvJRfevcgmgb9QAhbR',NULL,NULL,'desktop','Other','2026-07-26 14:42:42'),(1637,'/',NULL,NULL,'P6KtQdfoWPsugKHr0nQ7r44MnOR2wEbKV4L944lf',NULL,NULL,'desktop','Other','2026-07-26 14:42:42'),(1638,'/',NULL,NULL,'5IE7xNMH35FkArEbF39M1qE4cYmxYMODBVBv70hu',NULL,NULL,'desktop','Other','2026-07-26 15:09:24'),(1639,'/',NULL,NULL,'w8wKhTk9yTOlA1DlnrjTJ2IRuXujPMDGr559gjie',NULL,NULL,'desktop','Other','2026-07-26 15:56:18'),(1640,'blog/sayt-hmh-karh',NULL,NULL,'MMF2CBwfJl16dKQMnkzrhx2kmkjIPo3W0vm8kPk3',NULL,NULL,'desktop','Other','2026-07-26 16:02:06'),(1641,'/',NULL,NULL,'SW0Ibha1K1lfGrsDSV81Rie3On2ClgpwQ6UMfTpX',NULL,NULL,'desktop','Chrome','2026-07-26 16:15:46'),(1642,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'SW0Ibha1K1lfGrsDSV81Rie3On2ClgpwQ6UMfTpX',NULL,NULL,'desktop','Chrome','2026-07-26 16:16:01'),(1643,'blog',NULL,NULL,'SW0Ibha1K1lfGrsDSV81Rie3On2ClgpwQ6UMfTpX',NULL,NULL,'mobile','Chrome','2026-07-26 16:16:02'),(1644,'shop',NULL,NULL,'SW0Ibha1K1lfGrsDSV81Rie3On2ClgpwQ6UMfTpX',NULL,NULL,'mobile','Chrome','2026-07-26 16:16:04'),(1645,'shop/cart',NULL,NULL,'SW0Ibha1K1lfGrsDSV81Rie3On2ClgpwQ6UMfTpX',NULL,NULL,'mobile','Chrome','2026-07-26 16:16:05'),(1646,'search',NULL,NULL,'SW0Ibha1K1lfGrsDSV81Rie3On2ClgpwQ6UMfTpX',NULL,NULL,'mobile','Safari','2026-07-26 16:16:06'),(1647,'login',NULL,NULL,'SW0Ibha1K1lfGrsDSV81Rie3On2ClgpwQ6UMfTpX',NULL,NULL,'desktop','Firefox','2026-07-26 16:16:08'),(1648,'/',NULL,NULL,'HTnaFAC2ngtc5p71gCOQBbC6sibvHaAgCYjF0O1w',NULL,NULL,'desktop','Other','2026-07-26 16:43:09'),(1649,'/',NULL,NULL,'XXsEDZCZNcQJLCTDSkXyMkkTMopI6P3JGVXq8eei',NULL,NULL,'desktop','Other','2026-07-26 17:29:06'),(1650,'/',NULL,NULL,'OKkvh6xc6xCYU6bNIYBFe1bwwaMzQsOTfgoYO9kH',NULL,NULL,'desktop','Other','2026-07-26 18:15:37'),(1651,'/',NULL,NULL,'NxlQOK4sntuhPpgQGtsX6ch0x8Eq4wfXFQdf1gxa',NULL,NULL,'mobile','Chrome','2026-07-26 18:21:52'),(1652,'/',NULL,NULL,'HOTdylyYD5uX8X7Om2ZN3BcfIipRV24Ta9KuayN5',NULL,NULL,'mobile','Chrome','2026-07-26 18:24:29'),(1653,'/',NULL,NULL,'6Ww7bKMCS68ZyZpMwyJkoxHDL6pHRfYq0tI0RHNM',NULL,NULL,'desktop','Other','2026-07-26 19:02:09'),(1654,'/',NULL,NULL,'GQrrWlceiI1rY1PvFICK2pooSoXTRePLN29FloWW',NULL,NULL,'desktop','Other','2026-07-26 19:48:42'),(1655,'/',NULL,NULL,'0VSb8VV4qnJxzowRpJwNTdejgehX8wJJ3qZw7GKU',NULL,NULL,'desktop','Other','2026-07-26 20:34:11'),(1656,'search',NULL,NULL,'HmSbbFg5cnKGPWOpRuB3i53vIezeP2DgatwmcFMu',NULL,NULL,'desktop','Other','2026-07-26 21:11:31'),(1657,'/',NULL,NULL,'OZ5d8JpPaNCBMsAp2erZRo9PjHJ0z0s743JFgIHU',NULL,NULL,'desktop','Other','2026-07-26 21:20:04'),(1658,'/',NULL,NULL,'es4uTKtZsWGrprispmLsxMotkaTyf1HvOarnqaVB',NULL,NULL,'desktop','Other','2026-07-26 22:06:56'),(1659,'/',NULL,NULL,'eVmlls51RCz86ct3TJtKK5ljnB8J0FxkvBiclyKx',NULL,NULL,'desktop','Other','2026-07-26 22:52:56'),(1660,'/',NULL,NULL,'1H16ydQJfhJdJJelgryHH545mwcFOWL3pprzQVBJ',NULL,NULL,'desktop','Other','2026-07-26 23:38:38'),(1661,'/',NULL,NULL,'tmIfC4iCYi9qzkmabKwAIZbL0q2wcIOr1kA5KO7C',NULL,NULL,'desktop','Other','2026-07-27 00:24:40'),(1662,'/',NULL,NULL,'oH7SbF8xMRl2qdLyUT6mBOSeJxHNBjzZbiHzz7Fo',NULL,NULL,'desktop','Chrome','2026-07-27 00:43:11'),(1663,'/',NULL,NULL,'rBmqYZzq4hw0DlHw5PbcZ5kLU4EnphPvnowFXLxy',NULL,NULL,'desktop','Firefox','2026-07-27 01:10:32'),(1664,'/',NULL,NULL,'D0GMoRlDyaFFlLhQmr15CwgfIEjQe5n3F0iCDYeH',NULL,NULL,'desktop','Other','2026-07-27 01:11:24'),(1665,'/',NULL,NULL,'pOxP2Bsxu50GC665krim0OtDgUNx8OgtuwMtVZRR',NULL,NULL,'desktop','Other','2026-07-27 01:57:38'),(1666,'/',NULL,NULL,'snCwMokhgZ9ZBjcIbGUxn2kEdZa9ZmmIZkcRSFVL',NULL,NULL,'desktop','Other','2026-07-27 02:44:55'),(1667,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'SAcngcRxBhtzIoT2Y0R8PVDm0xXJjfqMH6VQ55fU',NULL,NULL,'desktop','Other','2026-07-27 03:17:34'),(1668,'/',NULL,NULL,'LI96NYhJmfpaab2oL7aJHLO6uz4LtxBdhy6VB08x',NULL,NULL,'desktop','Other','2026-07-27 03:31:42'),(1669,'/',NULL,NULL,'jmyVx3hRqVhMnR7CFs578A9XfUK7oOVVuXP7zHrM',NULL,NULL,'desktop','Chrome','2026-07-27 03:48:29'),(1670,'/',NULL,NULL,'15CmH9kI4RORNmV4a7np2SmHARFeeTWhElXQEOCv',NULL,NULL,'desktop','Other','2026-07-27 04:18:03'),(1671,'/',NULL,NULL,'Hn7r0wlwxySwlmlhFsusoG2Uy5rRUQ0ZwotoQFNf',NULL,NULL,'desktop','Other','2026-07-27 05:05:53'),(1672,'/',NULL,NULL,'KMfJD99m1qph4uLx0f6v57PXbSxEy5MAtCFThEWc',NULL,NULL,'desktop','Other','2026-07-27 05:53:34'),(1673,'/',NULL,NULL,'XsrJnbUeIBhZwjH5WqXjvXXpJzY3sdgNPB339sfJ',NULL,NULL,'desktop','Other','2026-07-27 06:41:03'),(1674,'/',NULL,NULL,'PztGFuDhT4Oaxx4hlqEPZsYgQaW4I9S1wZgGMe4o',NULL,NULL,'desktop','Other','2026-07-27 07:28:05'),(1675,'/',NULL,NULL,'SMNGhAdQzyVJT2aCMnEZ6Japlt4oYtmMxOWh86iZ',NULL,NULL,'desktop','Other','2026-07-27 08:16:14'),(1676,'/',NULL,NULL,'lLkZum7al8bdtBjVyo9pIgMxSs7OP6xCKyXQsJdO',NULL,NULL,'desktop','Firefox','2026-07-27 08:39:16'),(1677,'/',NULL,NULL,'nDPMfqwAQ8ZbErKBY0MgqXvSROqj6pV2cfz8XAnx',NULL,NULL,'desktop','Other','2026-07-27 09:04:40'),(1678,'/',NULL,NULL,'myti7GTZFSTeMhRkCQKKLHW4wd1M9CYXFYS13dtM',NULL,NULL,'desktop','Other','2026-07-27 09:52:06'),(1679,'/',NULL,NULL,'KeB7SMZ9PmKU5hCFHmgx99Ugd6SIR72MXqb00W8A',NULL,NULL,'desktop','Other','2026-07-27 10:40:04'),(1680,'/',NULL,NULL,'DHvXRq49qJtVZx59NbYncL1Q10BWiRvdqAMoOQ0Z',NULL,NULL,'desktop','Chrome','2026-07-27 10:46:41'),(1681,'/',NULL,NULL,'O4zAbT3dFukfxwSqdlAikJlmAW9cEbpLKft5lwsK',NULL,NULL,'desktop','Other','2026-07-27 11:27:25'),(1682,'/',NULL,NULL,'sfq9uWlQRi3V25HLeCocAFidEzSFl5xp9VoUwXFm',NULL,NULL,'desktop','Other','2026-07-27 12:14:02'),(1683,'/',NULL,NULL,'auDOUUceFzyB4QfsJny1rp3SFp1dA3pZvduwGNEt',NULL,NULL,'desktop','Other','2026-07-27 13:01:19'),(1684,'/',NULL,NULL,'gTmra4yNSYEnN9c4oVIHL64OEG9JvZs3GIWjgfdW',NULL,NULL,'desktop','Other','2026-07-27 13:47:38'),(1685,'/',NULL,NULL,'AMj7x89x8iJiAE9en8re8J59ffMSY1n93kXGMLXG',NULL,NULL,'desktop','Other','2026-07-27 14:34:31'),(1686,'/',NULL,NULL,'rj82W1hcxVARy0xwIv78wmnBQ5gyzWUSQLasHk4c',NULL,NULL,'desktop','Other','2026-07-27 15:20:24'),(1687,'/',NULL,NULL,'mwdK7cg9n1tVPF5PQSIECwwTs7I4cPpO2KrGKycE',NULL,NULL,'desktop','Other','2026-07-27 16:06:08'),(1688,'/',NULL,NULL,'HdyNUra0kUzEaUXgv02UN8DDwYpRNk0i3O3fVw7S',NULL,NULL,'desktop','Other','2026-07-27 16:51:04'),(1689,'/',NULL,NULL,'qOCyXjcUiSgWUKddQzG6A6dJAziZi44GTMMma8I1',NULL,NULL,'desktop','Other','2026-07-27 17:36:19'),(1690,'/',NULL,'https://trustseal.enamad.ir/','UdiknbEJSppsHATwdpIQNPNvx16XnBK5sKDUMWly',NULL,NULL,'desktop','Firefox','2026-07-27 18:11:56'),(1691,'/',NULL,NULL,'p18voOrgjJCRKpC32VGtxI1aNoazGmeRcpDEeT90',NULL,NULL,'desktop','Other','2026-07-27 18:22:51'),(1692,'/',NULL,'http://safhenokhost.ir/','IwscXO3FNKHbVGTCia1UBrXBUyyHjw0kos2gBl16',NULL,NULL,'mobile','Safari','2026-07-27 18:27:21'),(1693,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'cJ1FXq5ygo6HQoy0FQEZx2p7ySWssW11Ch7uLTSR',NULL,NULL,'mobile','Safari','2026-07-27 18:27:22'),(1694,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'ehfbMZjheJlilkBNyOoAzlJBXqa8dIaRXRWJXViJ',NULL,NULL,'mobile','Safari','2026-07-27 18:27:22'),(1695,'blog/sayt-hmh-karh',NULL,NULL,'02ytEmNBHunbMKR6LsqV2iLfaZAXFGSeXU6es6RR',NULL,NULL,'mobile','Safari','2026-07-27 18:27:23'),(1696,'/',NULL,NULL,'uYXJAIZ6RgWyxwKltTqhNndetQZXiKrgPhhOTxim',NULL,NULL,'desktop','Other','2026-07-27 19:08:35'),(1697,'/',NULL,NULL,'ZdizkZdNlsawh0jSFbIjiYhqYuzz4dJaqsQ0vMLq',NULL,NULL,'desktop','Other','2026-07-27 19:49:18'),(1698,'/',NULL,NULL,'9I61fUEBDp0TXJM7tMksR9uLxzNlnTOOdfTpL1Yq',NULL,NULL,'desktop','Other','2026-07-27 19:54:52'),(1699,'blog',NULL,NULL,'U5RpSVJy6jf3kagiJ6hBkEviN7Zs2eoaKpWBRgph',NULL,NULL,'desktop','Other','2026-07-27 20:14:07'),(1700,'/',NULL,NULL,'zSFmHQfbmkQyAFXPQnExGFvBGFrWzLVnt8WHgLM9',NULL,NULL,'desktop','Other','2026-07-27 20:41:34'),(1701,'/',NULL,NULL,'MbUfHTg4K594aWXcTE2I3XrdMM6kvwwrzNp3WR7q',NULL,NULL,'desktop','Other','2026-07-27 21:27:07'),(1702,'/',NULL,NULL,'pR9I3byWBfQgKkxdaX2TQBbSQZMm0ZBrDZRMDH9P',NULL,NULL,'desktop','Other','2026-07-27 22:09:14'),(1703,'/',NULL,NULL,'7MRkd9mjHlb61f2jHgxcVWNf9JmJfvmZ57dRr1gd',NULL,NULL,'desktop','Other','2026-07-27 22:14:24'),(1704,'blog',NULL,NULL,'7eU4GjOav4HhdkhcKlx1O0iQfPkAQjMDqwv5vVzD',NULL,NULL,'desktop','Other','2026-07-27 22:38:37'),(1705,'blog',NULL,NULL,'kYZWV1ttowaqfDJHkPg747Nycea2SUMXRDtlSGeI',NULL,NULL,'desktop','Other','2026-07-27 22:39:07'),(1706,'/',NULL,NULL,'CxQ9N427cvMah8PTWSG1n2FPt83cP7kfqLWlKRgr',NULL,NULL,'desktop','Other','2026-07-27 23:00:18'),(1707,'/',NULL,NULL,'51Bo6R57FKm5XwJtQMPxqj5hZqJxS18I3PI2d4YH',NULL,NULL,'desktop','Other','2026-07-27 23:46:55'),(1708,'/',NULL,NULL,'KjkR9Ndv4riqPS4Cqfm9JyaVlj1r5KNBAFig33Fa',NULL,NULL,'desktop','Other','2026-07-28 00:32:05'),(1709,'/',NULL,NULL,'flfp9DWJc2WWDgHMQO5ygARxfab8ZjitQyh1IKqo',NULL,NULL,'desktop','Other','2026-07-28 00:37:33'),(1710,'/',NULL,NULL,'QO7UhG5r8VqCHKUjXR7WxKLXigqdZentJKCk1DGy',NULL,NULL,'desktop','Other','2026-07-28 01:18:50'),(1711,'blog',NULL,NULL,'7MgHF1282G73F7HZV7Hx6dbgyjiWimPKKrGw6iL9',NULL,NULL,'desktop','Other','2026-07-28 01:43:00'),(1712,'/',NULL,NULL,'Xm1PtAFJRVth9m4kqwvh1iuDHceLxCyoMCxrKcu0',NULL,NULL,'desktop','Other','2026-07-28 02:06:29'),(1713,'/',NULL,NULL,'FrPzI07RegFM5hJuHsliclwtqDnNRuqliOEXb82h',NULL,NULL,'desktop','Other','2026-07-28 02:54:12'),(1714,'/',NULL,NULL,'IWcPGEoxVUgv2BOZxXdSgf4D6bXH3JXrBbw44Var',NULL,NULL,'desktop','Other','2026-07-28 03:39:12'),(1715,'/',NULL,NULL,'QUBFHayqJThsy4gY3HXmEYmxwnBh4nPyzs1Jmyb3',NULL,NULL,'desktop','Other','2026-07-28 04:25:56'),(1716,'blog',NULL,NULL,'NFSuyF7VtDWyK3HSGsSrq4aq5X1Aakn8EnlCkthQ',NULL,NULL,'desktop','Other','2026-07-28 04:47:00'),(1717,'/',NULL,NULL,'ZdibEjD1zai5U1aEXAPWIqQG1j4fdJxowylsAtLP',NULL,NULL,'desktop','Other','2026-07-28 05:12:54'),(1718,'/',NULL,NULL,'4BVhWdc0oYfwq29sPMJ9FY87S6UwnL0AsVMse2ET',NULL,NULL,'desktop','Other','2026-07-28 06:01:00'),(1719,'/',NULL,NULL,'LmPgo0XeNkZJ9QmTdY1J0NStzMbJNA9VFKj8yGIH',NULL,NULL,'desktop','Other','2026-07-28 06:47:42'),(1720,'/',NULL,NULL,'m0qqKfS7GYnG7D3BDNYFtZKIUoZltJeAnJnb7pkc',NULL,NULL,'desktop','Other','2026-07-28 07:34:28'),(1721,'/',NULL,NULL,'smKy6c0z5foZqy6M3rYHb98y15fuiB8IVj1hvXX3',NULL,NULL,'desktop','Other','2026-07-28 08:22:16'),(1722,'/',NULL,NULL,'jnvjjwgxLdVeB34xGVUnYalrj5Rcpru5u425pvQ8',NULL,NULL,'desktop','Firefox','2026-07-28 08:44:58'),(1723,'/',NULL,NULL,'y9JhI09VqnwKUqQ8N4I39KcW8czvYtuh2teNcjAA',NULL,NULL,'desktop','Other','2026-07-28 09:10:24'),(1724,'/',NULL,NULL,'UQtAyjsC5N0zbZP6qbVKupAYFH2t07Hl358NiSAm',NULL,NULL,'desktop','Other','2026-07-28 09:57:15'),(1725,'/',NULL,NULL,'oIEAP57mVRmz90yQlzJMhUqtIlmbW3xmb1JE3svx',NULL,NULL,'desktop','Other','2026-07-28 10:44:10'),(1726,'/',NULL,NULL,'ToeN21xRV1E60aLf8ey2qbd3rYjQnrork6Fube6P',NULL,NULL,'mobile','Chrome','2026-07-28 11:26:25'),(1727,'blog/sayt-hmh-karh',NULL,'https://safhenokhost.ir/','ToeN21xRV1E60aLf8ey2qbd3rYjQnrork6Fube6P',NULL,NULL,'mobile','Chrome','2026-07-28 11:27:18'),(1728,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,'https://safhenokhost.ir/','ToeN21xRV1E60aLf8ey2qbd3rYjQnrork6Fube6P',NULL,NULL,'mobile','Chrome','2026-07-28 11:27:21'),(1729,'blog',NULL,'https://safhenokhost.ir/blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd','ToeN21xRV1E60aLf8ey2qbd3rYjQnrork6Fube6P',NULL,NULL,'mobile','Chrome','2026-07-28 11:27:24'),(1730,'/',NULL,NULL,'gH1JSB58zABHlJ9yRO8bG2LEVEsbtBLjPfwRu1yQ',NULL,NULL,'desktop','Other','2026-07-28 11:31:47'),(1731,'/',NULL,NULL,'vrdwXSBVYCSOcgmjtnnqXzLyp0c8xqRcibnfSU8i',NULL,NULL,'desktop','Other','2026-07-28 12:20:18'),(1732,'blog',NULL,NULL,'ZXGkRh3CEnHA0oX2grYl0sEGRdY6wa7znWAsGinj',NULL,NULL,'desktop','Other','2026-07-28 13:02:40'),(1733,'/',NULL,NULL,'wA3W4zRyXJb2JKh7w0yGpqVobUq8odpnTTVnhks8',NULL,NULL,'desktop','Other','2026-07-28 13:08:46'),(1734,'/',NULL,NULL,'CwP9VwnrjjmFqIrvVEN6URqJ2YaQEk4LyC66Q5LU',NULL,NULL,'desktop','Other','2026-07-28 13:55:51'),(1735,'shop/wishlist',NULL,NULL,'Vkeuwpn1Biw6SgTibUIBSHpZJgcXqo5Rs4BucO6H',NULL,NULL,'desktop','Other','2026-07-28 14:32:23'),(1736,'/',NULL,NULL,'ApgZFR23uUT63ZtytSNmq8ZEUxbhwl3z07vZQK5F',NULL,NULL,'desktop','Other','2026-07-28 14:42:19'),(1737,'/',NULL,NULL,'c9nYw756vSajrjJsTcoHrXujJZDEvXQW52SVOlbb',NULL,NULL,'desktop','Other','2026-07-28 15:29:24'),(1738,'/',NULL,NULL,'Kfi2MqhftdkeqJCCaUOn0qLr2WWVGM28ZzQYrqZl',NULL,NULL,'desktop','Other','2026-07-28 16:16:25'),(1739,'/',NULL,NULL,'VqcOtUqsKaL7BzDXjhG1sKU3pTfKAKBm3afbG136',NULL,NULL,'desktop','Other','2026-07-28 17:03:50'),(1740,'/',NULL,NULL,'TobnXFEgtJYOtYJwDHr1UJ7ZAQAKZ2nwKb1OmcU5',NULL,NULL,'desktop','Other','2026-07-28 17:50:11'),(1741,'/',NULL,NULL,'tEbvRlp1H1xX8jbG5BoZYyWTN62E5Tb7QGgX22Do',NULL,NULL,'desktop','Chrome','2026-07-28 17:56:14'),(1742,'/',NULL,NULL,'LFK98bZGc4qBrFsg4XUgSPA7vtiJM3eSqggUQ8gG',NULL,NULL,'desktop','Other','2026-07-28 18:37:39'),(1743,'/',NULL,NULL,'tvXEbGNhbKWZi3lT9gGrwEP4ENobKv9v2XU6jG2U',NULL,NULL,'desktop','Firefox','2026-07-28 18:40:25'),(1744,'/',NULL,NULL,'CLB9UBfRJdS4KwPEcy5dndhs9Tg8NxgOAvmGr8WR',NULL,NULL,'desktop','Chrome','2026-07-28 18:50:42'),(1745,'blog',NULL,NULL,'ZUia8K40jxRvmbtkQ0cCjYwt5hUEYqKAFWX2VWqL',NULL,NULL,'desktop','Other','2026-07-28 19:01:13'),(1746,'/',NULL,NULL,'Z2tlfBDUjdvuwxSx6x2HHVZ0UUoVVLIShiQBMW8N',NULL,NULL,'desktop','Other','2026-07-28 19:25:14'),(1747,'/',NULL,NULL,'w9sKGzOp02R4xnyUZhFSeafdTIqScZEWXXQPkiez',NULL,NULL,'desktop','Other','2026-07-28 20:12:27'),(1748,'/',NULL,NULL,'Td40iZYEaZ4Kun3401YXNswZQ37GIygPrQx8Ghiy',NULL,NULL,'desktop','Other','2026-07-28 20:58:44'),(1749,'/',NULL,NULL,'diU4TGe2MtXMyml15esr4D5Y5YQoCMloLYL7WOaA',NULL,NULL,'desktop','Other','2026-07-28 21:45:12'),(1750,'/',NULL,NULL,'GdKHZS2k2lKpEEXQKwRxWcjDP9iu94dKqTbTltTm',NULL,NULL,'desktop','Other','2026-07-28 22:31:58'),(1751,'/',NULL,NULL,'uyKibLj7TI1zN4P8BMD7wlOWlx3SyWnSP52i0y1v',NULL,NULL,'desktop','Other','2026-07-28 23:19:00'),(1752,'/',NULL,NULL,'qcUhRnbvwmLLHTEZzF1qTHlZyAFp31x8ezWX6VpE',NULL,NULL,'desktop','Chrome','2026-07-28 23:27:21'),(1753,'/',NULL,NULL,'NEYbRmShB5cfcMviZNRn2wHxVmMxljOZmgE71W2G',NULL,NULL,'desktop','Other','2026-07-29 00:06:23'),(1754,'/',NULL,NULL,'zmNkVZwinOmNeumyjRLaHyu86MYuAwpvKohYuQw1',NULL,NULL,'desktop','Other','2026-07-29 00:53:28'),(1755,'/',NULL,NULL,'8pbvHMv9L0BONbiebn6ooWgZa2A9sVmqhy9uZ3XV',NULL,NULL,'desktop','Other','2026-07-29 01:42:20'),(1756,'/',NULL,NULL,'twKFapRsOhNwbgCAh7QcnQay2gag7kHAdkkM36ks',NULL,NULL,'desktop','Other','2026-07-29 02:30:05'),(1757,'/',NULL,NULL,'pZrRKXy3ikT0DQSEb5TD7rHlEqHLPvkHcbgKDfyG',NULL,NULL,'desktop','Firefox','2026-07-29 02:50:24'),(1758,'/',NULL,NULL,'SzIVS78nkHnxSH4y3dceeJD7KyOSTNAIBuI0FfYl',NULL,NULL,'desktop','Other','2026-07-29 03:18:11'),(1759,'/',NULL,NULL,'9jUMpMgDzi1uBnRHjvggkTbMbIt4wyIQWxCUFeea',NULL,NULL,'desktop','Other','2026-07-29 04:06:05'),(1760,'/',NULL,NULL,'cmU5eMf6sJnG3qn9FZ67lFWudskioR8ChQRFal3G',NULL,NULL,'desktop','Other','2026-07-29 04:55:47'),(1761,'/',NULL,NULL,'4wDSKnGcyPL4yf08ZkEcuJGHdosi31n4ZUgzcedL',NULL,NULL,'desktop','Other','2026-07-29 05:45:01'),(1762,'/',NULL,NULL,'sMY0A0aAhAOFhk0hhAfaZncSDmCzi0sVVBMEvKQI',NULL,NULL,'desktop','Other','2026-07-29 06:32:19'),(1763,'blog',NULL,NULL,'4LlyxXEWVdd5ClNLEpB0RLaKwVeGhFBV4mDQ8K7l',NULL,NULL,'desktop','Other','2026-07-29 06:43:46'),(1764,'/',NULL,'http://safhenokhost.ir/','wMSIDM1slY48XkVbCguNJ0FrZsJZeU2GmxYjOL9h',NULL,NULL,'desktop','Firefox','2026-07-29 07:01:49'),(1765,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'ctW22rg9jTz3wsp6orhq5uyiJNNWV7ubPijB3bNp',NULL,NULL,'desktop','Firefox','2026-07-29 07:01:50'),(1766,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'BBM3Q7CMfAVyP6N1KrenNrU2wCbcxtwrkjLVQ2aK',NULL,NULL,'desktop','Firefox','2026-07-29 07:01:51'),(1767,'blog/sayt-hmh-karh',NULL,NULL,'604f15Y5Cn6k0F8AxxAixa9VW05aW7tL4Uw0Va1Y',NULL,NULL,'desktop','Firefox','2026-07-29 07:01:51'),(1768,'/',NULL,NULL,'LpsiXT8oKs7x4VmJHJ1xYPdQTfvOZhSUUE4w3Qou',NULL,NULL,'desktop','Other','2026-07-29 07:20:19'),(1769,'blog',NULL,NULL,'pnax0nuAPuAVyItEPGIeLDi9UDLBfmF9ZHrIGe3m',NULL,NULL,'desktop','Other','2026-07-29 07:26:46'),(1770,'/',NULL,NULL,'tAQV0HPU4jCo5oJXJYaENAwEl8US7Vy3JarSjHk7',NULL,NULL,'desktop','Other','2026-07-29 08:08:25'),(1771,'/',NULL,NULL,'Nmvt8ox4gsaaHxuIv6BLYTb4JvXl7iiWD97LeaL5',NULL,NULL,'desktop','Firefox','2026-07-29 08:29:45'),(1772,'blog/series/syo',NULL,NULL,'hT6zjrYa6D4UqisYZyCTaUZ9FHjVELfDoY7TjXlW',NULL,NULL,'desktop','Other','2026-07-29 08:53:42'),(1773,'/',NULL,NULL,'2W4FeAQv27SjNisKC0O9Jl4f25xXKKbfWHO6slNR',NULL,NULL,'desktop','Other','2026-07-29 08:55:37'),(1774,'/',NULL,NULL,'lUfavvoQdkVCJXM07c5QT5vHevJvfgarT1iQD7BG',NULL,NULL,'desktop','Other','2026-07-29 09:42:52'),(1775,'/',NULL,'https://safhenokhost.ir','gGm2ZBsVvww5oNKar1W9AHtsTa2IqYLpGVtRnXuY',NULL,NULL,'desktop','Firefox','2026-07-29 10:21:19'),(1776,'/',NULL,NULL,'PfxEc7JhJuu7jj7h5vcNeKZt5uSYUxVajShzHGvM',NULL,NULL,'desktop','Other','2026-07-29 10:30:17'),(1777,'/',NULL,NULL,'nP1aIaP8hydMCeDpPDs7usgL4ir2SauRhFkWCkdU',NULL,NULL,'desktop','Other','2026-07-29 11:17:11'),(1778,'/',NULL,NULL,'kw1pWp2Sh54zZw3X2eLrvgrUeNTgVVcMFB8trmKO',NULL,NULL,'desktop','Chrome','2026-07-29 11:17:18'),(1779,'/',NULL,NULL,'L7uVOt9nzRhoJDvM5DeVwY5qt1wE8752dBLq7BLh',NULL,NULL,'desktop','Other','2026-07-29 12:04:11'),(1780,'login',NULL,'https://safhenokhost.ir/admin/license','YLanDgR4HekRO8CWBPB1pOtkWNiAkuzBuxn7gkRe',NULL,NULL,'desktop','Firefox','2026-07-29 12:41:59'),(1781,'login',NULL,'https://safhenokhost.ir/admin/dashboard','4lgGdPSCQQNEoQ3yeDAQSX4nNNMJJbF71Ml3kRj2',1,NULL,'desktop','Firefox','2026-07-29 12:42:24'),(1782,'/',NULL,NULL,'WMbWjP3GJnZzMSX0w4f7X28dNnhWvIi8O3yTD7Rp',NULL,NULL,'desktop','Other','2026-07-29 12:51:15'),(1783,'/',NULL,NULL,'4lgGdPSCQQNEoQ3yeDAQSX4nNNMJJbF71Ml3kRj2',1,NULL,'desktop','Firefox','2026-07-29 12:53:21'),(1784,'/',NULL,NULL,'vTwx8tBvOxbZC1ySUYVYN9pIwSdX20cU4zfCHxTd',NULL,NULL,'desktop','Other','2026-07-29 13:37:12'),(1785,'/',NULL,NULL,'EZJUM1vDf41SoNHasxkWSKUyVq5OdAxp5QWuhVfN',NULL,NULL,'desktop','Other','2026-07-29 14:23:37'),(1786,'/',NULL,NULL,'k423O68QZHX3GK7jJifBhgv7roz5waNFzG4A82kt',NULL,NULL,'desktop','Other','2026-07-29 15:10:03'),(1787,'/',NULL,NULL,'eOc6Z0Vj2PEO8o806dzjdbG9VRwn0Blv7aSdhY9d',NULL,NULL,'desktop','Other','2026-07-29 15:56:10'),(1788,'/',NULL,NULL,'HXj1aQs6FN5zumMSuShHINCHxXetSSnPjVETVxeN',NULL,NULL,'desktop','Other','2026-07-29 16:42:23'),(1789,'/',NULL,NULL,'pmG2shNdmA1Tv56NVSBQjzxxbPiITkqrW2wq2mcl',NULL,NULL,'desktop','Other','2026-07-29 17:28:05'),(1790,'/',NULL,NULL,'2zcojFSMenhGDTZut0LCetGfzcXZBxFMouitqAPu',NULL,NULL,'desktop','Other','2026-07-29 18:15:17'),(1791,'/',NULL,NULL,'0YMEfIgADC1WIbdMQbTNuKXTRqHUX2tzooc9hcUU',NULL,NULL,'desktop','Other','2026-07-29 19:03:14'),(1792,'/',NULL,NULL,'4UUTuivtsdFAImQZoVDnO0l9RAvdN3jDh6hV5RhI',NULL,NULL,'desktop','Other','2026-07-29 19:49:27'),(1793,'/',NULL,NULL,'2THQNSKZW1bYWapwxYKC2gTX1R2CE6xmV4xwWGvT',NULL,NULL,'desktop','Other','2026-07-29 20:35:25'),(1794,'/',NULL,NULL,'7Pz59FYCXUzRJ0FQAORLOtOUMeDjdueCrsfSTH9x',NULL,NULL,'desktop','Other','2026-07-29 21:21:18'),(1795,'/',NULL,NULL,'Y03aoMtMJeFahB3jjqPmgwZlL01GT15haLxPjB5s',NULL,NULL,'desktop','Other','2026-07-29 22:07:45'),(1796,'/',NULL,NULL,'4q877Zl0ZkxxEuAs5nhDM3C473JCUe37tIZNf2ec',NULL,NULL,'desktop','Other','2026-07-29 22:53:47'),(1797,'/',NULL,NULL,'A6zp687kpVfUaJe6cD2bmVAPpTbBKaFPw3ZypJZp',NULL,NULL,'desktop','Other','2026-07-29 23:39:35'),(1798,'/',NULL,NULL,'rVU5qbgCkvZp6RXBWFfgL0WTpXIPjD1ntwUcgeqN',NULL,NULL,'desktop','Other','2026-07-30 00:25:27'),(1799,'/',NULL,NULL,'7JooGqpTXBxLIdkfuXne0N2D7Vf5PyAzpUhvSNnX',NULL,NULL,'desktop','Other','2026-07-30 01:11:47'),(1800,'search',NULL,NULL,'7ePqi3f2lLeGLNAOgOUB1CMmLu7G3LQxtwJIuwqL',NULL,NULL,'desktop','Other','2026-07-30 01:15:18'),(1801,'/',NULL,NULL,'LKMAWeRPZEu4Q5BZXpQIuShBv1J8O93Rro17KhBy',NULL,NULL,'desktop','Other','2026-07-30 01:58:51'),(1802,'/',NULL,NULL,'AAOGFzkDpeHlkvxLNkNKVVYFh1DvLOMoPIXUpv3k',NULL,NULL,'desktop','Other','2026-07-30 02:45:32'),(1803,'/',NULL,NULL,'jDISQbuuPzLX6FEBlSn230wLeZcy6pvWcNyxnUN7',NULL,NULL,'desktop','Other','2026-07-30 03:32:08'),(1804,'/',NULL,NULL,'v6BMfD8ycznhbK0lYwvREYU4WfEY7tfk4o1Q6FLL',NULL,NULL,'desktop','Other','2026-07-30 04:19:38'),(1805,'/',NULL,NULL,'D50x2etkHENM9EBJaU4zuiUr5lA28yOLAeQupt6X',NULL,NULL,'desktop','Other','2026-07-30 05:07:50'),(1806,'/',NULL,NULL,'dAP5VR6rmjWsZ5KL6qADMqQbIZAnkUEhXehN1qI4',NULL,NULL,'mobile','Safari','2026-07-30 05:49:52'),(1807,'/',NULL,NULL,'uZ7SNgSKNMhgIsxaapDcgtrEUdkP5ZqIzFBsKb8I',NULL,NULL,'desktop','Other','2026-07-30 05:55:39'),(1808,'/',NULL,NULL,'GTimXq2IbNazdoAOulxB19ZzV0w7Fg6xZJN2Lalh',NULL,NULL,'desktop','Firefox','2026-07-30 06:18:06'),(1809,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,'https://safhenokhost.ir/','GTimXq2IbNazdoAOulxB19ZzV0w7Fg6xZJN2Lalh',NULL,NULL,'desktop','Firefox','2026-07-30 06:18:18'),(1810,'blog',NULL,'https://safhenokhost.ir/blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd','GTimXq2IbNazdoAOulxB19ZzV0w7Fg6xZJN2Lalh',NULL,NULL,'desktop','Firefox','2026-07-30 06:18:22'),(1811,'/',NULL,NULL,'S7SvcL14hXwLXlVnNkn7xVvu2L0gWT2idfy33ouj',NULL,NULL,'desktop','Other','2026-07-30 06:42:37'),(1812,'/',NULL,NULL,'z6vAJdCIHGWEvCcj248w5gBw0qudzFIV8OlzEb3h',NULL,NULL,'desktop','Chrome','2026-07-30 07:12:55'),(1813,'/',NULL,NULL,'OGh7lIkNUDSMOFZgBihMHyfws0Oa1r78AgQwub1p',NULL,NULL,'desktop','Other','2026-07-30 07:29:53'),(1814,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'Q3EWPPXOjM3R9vwtiWRc3pmbGR40JHndnvrY7icz',NULL,NULL,'desktop','Other','2026-07-30 07:38:36'),(1815,'/',NULL,NULL,'xJHdGnGqQisKaDcTBWpydoB4KFgMwUdjkpXG3s7y',NULL,NULL,'desktop','Other','2026-07-30 08:17:33'),(1816,'/',NULL,NULL,'N146mNmUK2iWYMpqO4t2KO2BNQxjjLHBXbSBoHQ4',NULL,NULL,'desktop','Other','2026-07-30 09:05:10'),(1817,'/',NULL,NULL,'knj1x1N3zND2D460eELOt39qx3JR0J68x3s1ebbW',NULL,NULL,'desktop','Other','2026-07-30 09:52:44'),(1818,'blog/category/mhtoa',NULL,NULL,'hlazrMsNWhmJDiWpGfA6653x2LqRWMmrYLHo5E7O',NULL,NULL,'desktop','Other','2026-07-30 10:00:59'),(1819,'/',NULL,NULL,'CmNfeTExurYt8u7ABC1R8dco4HX5ir4f03F5M6KA',NULL,NULL,'desktop','Chrome','2026-07-30 10:38:07'),(1820,'/',NULL,NULL,'h40OFlZNpT0MQjaJ2eLkdBJHDcLtEtARAOkoIax7',NULL,NULL,'desktop','Other','2026-07-30 10:39:28'),(1821,'/',NULL,NULL,'jTxygluHy0cizI1KLrtJaJfh8vS9ScaVSWenLsPD',NULL,NULL,'desktop','Other','2026-07-30 11:25:53'),(1822,'/',NULL,NULL,'elug6BOqiAK5Jcg9DUpfC5mjIHx24wefKeimvvIj',NULL,NULL,'desktop','Other','2026-07-30 12:12:48'),(1823,'/',NULL,NULL,'2FXm84F6JWo3VB5b0dqhSxJlllRRzIrbx8dj9vq4',NULL,NULL,'desktop','Other','2026-07-30 12:59:32'),(1824,'/',NULL,NULL,'HvY7ivGfof25n9QaH7LBHVg2qLS5OfAApgcTyPL8',NULL,NULL,'mobile','Chrome','2026-07-30 13:11:51'),(1825,'/',NULL,NULL,'X3FoBksdGI8kRvhtlQRi58MH02tqXiBwYrMwoseb',NULL,NULL,'desktop','Other','2026-07-30 13:46:37'),(1826,'/',NULL,NULL,'6kViEp9TpnGY2JWWRyWqSX5uvtSoCXMEQv1y9CqD',NULL,NULL,'desktop','Other','2026-07-30 14:33:16'),(1827,'/',NULL,'http://safhenokhost.ir/','EH4YX4KMfcpparTg2QQA7dVxmMsI5wwJDeiszKD6',NULL,NULL,'mobile','Firefox','2026-07-30 14:51:28'),(1828,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'HejgSb01JRp36MwBmqElYp2Xmr3fvdmFY9BFioxg',NULL,NULL,'mobile','Firefox','2026-07-30 14:51:29'),(1829,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'7MYKqCJz5kQsU526u39tWSngEabBNH0xN9IL3elV',NULL,NULL,'mobile','Firefox','2026-07-30 14:51:30'),(1830,'blog/sayt-hmh-karh',NULL,NULL,'LIL1CsDb2SwDtL9z6H9OnT6BmOhXPaGktpwMfMYa',NULL,NULL,'mobile','Firefox','2026-07-30 14:51:30'),(1831,'/',NULL,NULL,'Indq4HVhMRUVkRTlX2JOE0DVibXiJnze6mwermVp',NULL,NULL,'desktop','Other','2026-07-30 15:19:35'),(1832,'/',NULL,NULL,'yXbccXrv4SpcMdUO4OmhcKCyCqFE3wcHHhSu0zNY',NULL,NULL,'desktop','Other','2026-07-30 16:06:48'),(1833,'/',NULL,NULL,'tEI3bUXVaFlpfuRTGQWIupJuhkTo1GZKNQChvMWc',NULL,NULL,'desktop','Other','2026-07-30 16:53:44'),(1834,'/',NULL,NULL,'eHfk3V42LzcHmb4xX724yXJeqf1oVMtmhoYz1h6e',NULL,NULL,'desktop','Other','2026-07-30 17:39:48'),(1835,'/',NULL,NULL,'U4pjJP3NvuMRiWaYXmNXnKFJmGQKntmLMNj6O2Z3',NULL,NULL,'mobile','Safari','2026-07-30 17:42:01'),(1836,'/',NULL,NULL,'K0thK9dOkuhZb65tee3RK5YPFaQf3xtvdLEtnPW2',NULL,NULL,'desktop','Other','2026-07-30 18:26:57'),(1837,'/',NULL,NULL,'JBieHKRuXpqgZDt4dLNjwXF9yWXjs5cecZMXkEF5',NULL,NULL,'desktop','Other','2026-07-30 19:14:29'),(1838,'/',NULL,NULL,'86QEBefAocyNulW1Gj86dzrFRR8BIP7v5mZpJMYg',NULL,NULL,'desktop','Other','2026-07-30 20:01:44'),(1839,'/',NULL,NULL,'Luc42Si0QxpiIAnNWsypGAnPE0jlehDsQoRfdttK',NULL,NULL,'desktop','Other','2026-07-30 20:48:53'),(1840,'/',NULL,'https://www.google.com','AUo6eHjCJDWQCdpdddQKyqVR0414bU9lYe24AJJh',NULL,NULL,'desktop','Edge','2026-07-30 20:57:59'),(1841,'/',NULL,NULL,'fHkD5xAfuMI2Wmw97WgbAzhv0IYQeIQCla6ZW90x',NULL,NULL,'desktop','Other','2026-07-30 21:34:33'),(1842,'/',NULL,NULL,'a6xgGiAesstuiOeEy0DMJ9yGqWsM8OiISUNC8so8',NULL,NULL,'desktop','Other','2026-07-30 22:21:22'),(1843,'/',NULL,NULL,'wimARuGFX6Ih6k3eqke8ywOrl4yZrdvbbqCDjKB2',NULL,NULL,'desktop','Other','2026-07-30 23:07:57'),(1844,'/',NULL,NULL,'2YJaJt5jhv21oPEqSLC2xQukjzLbCQpPmxdgc1E6',NULL,NULL,'desktop','Other','2026-07-30 23:54:22'),(1845,'blog',NULL,NULL,'LswH0Ntj4677AtTVIlGvuc6ypfJ8ATE26BU38a7z',NULL,NULL,'desktop','Other','2026-07-31 00:27:29'),(1846,'/',NULL,NULL,'vHTJfJ0G6NtK2fdrFNgJsoIAmxIJqxLJVaEcBfPQ',NULL,NULL,'desktop','Other','2026-07-31 00:39:47'),(1847,'/',NULL,NULL,'fpkKzUj0T1OBLiNvLXOCyrdJ0cDJvecaTXx2drSp',NULL,NULL,'desktop','Other','2026-07-31 01:26:32'),(1848,'/',NULL,NULL,'FqJWun925sghn8w5WbmnshspyKKtYH164iF46YZH',NULL,NULL,'desktop','Other','2026-07-31 02:12:58'),(1849,'blog',NULL,NULL,'FVMMQTfKz2h60RV3f9xSzyPKLUqAUK7QUd98sVPZ',NULL,NULL,'desktop','Other','2026-07-31 02:49:48'),(1850,'blog',NULL,NULL,'le46VcdF8UlLX1c5ZFlPu9QOMCK2OAa23bcJ0vhO',NULL,NULL,'desktop','Other','2026-07-31 02:49:54'),(1851,'/',NULL,NULL,'q2OQKTKG1gMOv7ORYTzT8iLQ57UKtlO2P87Blezw',NULL,NULL,'desktop','Other','2026-07-31 02:59:38'),(1852,'/',NULL,NULL,'kWxJlXzBwOXxal3m5xuPAJlKdjx3CWQtlesaozgQ',NULL,NULL,'desktop','Other','2026-07-31 03:46:11'),(1853,'/',NULL,NULL,'1hHE6HdOSIrRiNFWfZI4uXTaYts89XoghvZEWCnT',NULL,NULL,'desktop','Other','2026-07-31 04:33:00'),(1854,'/',NULL,NULL,'kKRar1E7UePuDZMACjFAxAdzfDZWhdhBxlusty3P',NULL,NULL,'desktop','Other','2026-07-31 05:19:21'),(1855,'blog',NULL,NULL,'eAuX7zFYIKAkGXqltGivkM5GSiUQVjws91ac8v9E',NULL,NULL,'desktop','Other','2026-07-31 05:49:52'),(1856,'/',NULL,NULL,'qv02vJFguxYzY3cXZOgT1BhJRZAlALxt6bEbI03U',NULL,NULL,'desktop','Other','2026-07-31 06:06:50'),(1857,'/',NULL,NULL,'UGvKwsekv8mFPj436qqSve2KV4MmB2RBoqwEeI3Z',NULL,NULL,'desktop','Other','2026-07-31 06:53:30'),(1858,'/',NULL,NULL,'I27KSdAPEfP1iyDghmuyIMPXJZcEpGYRWNvyLKbX',NULL,NULL,'desktop','Other','2026-07-31 07:40:40'),(1859,'/',NULL,NULL,'oazGBMIOhwLWdvGR6xopzLzL5fIWMqtzkXLGACJx',NULL,NULL,'desktop','Firefox','2026-07-31 08:09:49'),(1860,'login',NULL,'https://safhenokhost.ir/admin/dashboard','wqU9WirLeIYFYCAm8uT3GpSgMBo6NtB8Iu3dtmn8',NULL,NULL,'desktop','Firefox','2026-07-31 08:12:56'),(1861,'login',NULL,'https://safhenokhost.ir/admin/content','SP5Lln1SStqch3tnt9WIG19lLoNee4vHfB7KvGcl',1,NULL,'desktop','Firefox','2026-07-31 08:13:06'),(1862,'/',NULL,NULL,'UETu0h484TEmHqS2JRVrtMdI1srSdvWEZdnqi80t',NULL,NULL,'desktop','Other','2026-07-31 08:27:12'),(1863,'login',NULL,'https://safhenokhost.ir/admin/license','SP5Lln1SStqch3tnt9WIG19lLoNee4vHfB7KvGcl',1,NULL,'desktop','Firefox','2026-07-31 08:49:03'),(1864,'blog',NULL,NULL,'RJuNwi62DUyvrckTjGGOZiiieYruz3MSxRV3XqoJ',NULL,NULL,'desktop','Other','2026-07-31 08:53:00'),(1865,'/',NULL,NULL,'rscGEPFVxKDoO4aOv7enJYPuKU9OwrtcsPowMUvV',NULL,NULL,'desktop','Other','2026-07-31 09:13:52'),(1866,'/',NULL,'http://safhenokhost.ir/','kD0T3bHoh0VtoP9eilqGvWydbTOQmNG9g5XX0sEU',NULL,NULL,'mobile','Chrome','2026-07-31 09:29:40'),(1867,'/',NULL,NULL,'kyXucrkLuPIK2Y0I8hHWPe9RhJmBcXMrcsVc1poe',NULL,NULL,'desktop','Other','2026-07-31 10:01:07'),(1868,'/',NULL,NULL,'FgxblPYQoKlfxaoPObhnaPPt9Zq40o8bAWWZWPeT',NULL,NULL,'desktop','Other','2026-07-31 10:48:30'),(1869,'shop/compare',NULL,NULL,'GKtQnmQY9QRoYFIBazCebsm8HCsfcrv8hnFqixHp',NULL,NULL,'desktop','Other','2026-07-31 11:11:12'),(1870,'/',NULL,NULL,'GGH0xNTR7tOCbQOf3rd54MCwCrQJfsvdJH0ZEgem',NULL,NULL,'desktop','Other','2026-07-31 11:34:52'),(1871,'/',NULL,NULL,'18zZGPSq3y393Vit8Szabk9TQX5k3eziXfJX4e9Y',NULL,NULL,'desktop','Firefox','2026-07-31 11:35:06'),(1872,'/',NULL,NULL,'g4P8B7rFj7mkun2WIZJAOSzg2V0dk3qw2Bp92Wdx',NULL,NULL,'desktop','Other','2026-07-31 12:21:56'),(1873,'/',NULL,NULL,'BhRjIq0XeU0Hv9CeZJL8yFY5TtWsYuDBoohKZqSk',NULL,NULL,'desktop','Other','2026-07-31 13:09:21'),(1874,'/',NULL,NULL,'fBaTvNJFVWVY9PGjW1ZFqaswNGlFep93olkEU1cz',NULL,NULL,'desktop','Other','2026-07-31 13:55:58'),(1875,'/',NULL,NULL,'7XGm4LlZVcHb0PIgO8iX4oyFyoSkjoY506N8e3ZM',NULL,NULL,'desktop','Other','2026-07-31 14:41:44'),(1876,'/',NULL,NULL,'FCgSrEdixTNeDxcxRNEcM16yOAAY4v82rDzP1FLC',NULL,NULL,'desktop','Chrome','2026-07-31 14:53:54'),(1877,'/',NULL,NULL,'DA6PqRsMVPAHlUIQZy655cTCNrPQivzLRLwixyjh',NULL,NULL,'desktop','Other','2026-07-31 15:28:31'),(1878,'/',NULL,NULL,'svw4iSpwFh2lgLMQ0knOacTpUn72J6lihJ7iimHJ',NULL,NULL,'desktop','Other','2026-07-31 16:16:03'),(1879,'/',NULL,NULL,'o3GxZ724OcZ9dHhX91lW5Pgx3ucBkR13QBUfWJTY',NULL,NULL,'desktop','Other','2026-07-31 17:03:11'),(1880,'blog',NULL,NULL,'Uv9SUbqNzEss8W1CqhEOfXtiDO0rPPHx9XzTx1tR',NULL,NULL,'desktop','Other','2026-07-31 17:13:32'),(1881,'/',NULL,NULL,'E7WNjqnZWXIgd88BqJkinEK1CrTHmX0w3E7v7nOH',NULL,NULL,'desktop','Other','2026-07-31 17:50:54'),(1882,'/',NULL,NULL,'cef5vyFFCfwSWwO5lx22cEMYuyWhVbg81x4ZsZDb',NULL,NULL,'desktop','Other','2026-07-31 18:37:12'),(1883,'shop/wishlist',NULL,NULL,'I9icao5YxC6MAkbg43CO09Q29ObC14expX23qqwC',NULL,NULL,'desktop','Other','2026-07-31 18:41:59'),(1884,'/',NULL,NULL,'Y0aK3fzCuoShFj3u8AVOdVWHudhf6EHxOPCdmDvn',NULL,NULL,'desktop','Other','2026-07-31 19:24:31'),(1885,'/',NULL,NULL,'MyJnZRjKP60Av7Bz8BujjmuhB5JWVsIINLEziRdr',NULL,NULL,'desktop','Other','2026-07-31 20:11:12'),(1886,'/',NULL,NULL,'8hfNyhaGFK8t4Gyop85Hf1N23LAh4xm0tn3DeI4z',NULL,NULL,'desktop','Other','2026-07-31 20:57:02'),(1887,'/',NULL,NULL,'KbAru2BeIjnxz9yAFI7xmEnAAT2K315sC5Btw2lv',NULL,NULL,'desktop','Other','2026-07-31 21:43:26'),(1888,'/',NULL,NULL,'S3jD7kVY6lJskFMmGCtc9OR1Heamyaj8jua0vXMA',NULL,NULL,'desktop','Other','2026-07-31 22:29:05'),(1889,'blog',NULL,NULL,'NQ29Y53ypJkLyl3Yom12r6XNXeuwrCTiFyVtRyRw',NULL,NULL,'desktop','Other','2026-07-31 23:09:04'),(1890,'/',NULL,NULL,'P4kHujhPRf70e6y10edK9l0PCkQoglmNUFKWkW3m',NULL,NULL,'desktop','Other','2026-07-31 23:14:37'),(1891,'/',NULL,NULL,'RQOIq98c5NQX87q7HhgCK80fa459b3rSusRMrthW',NULL,NULL,'desktop','Other','2026-08-01 00:00:27'),(1892,'/',NULL,NULL,'JlV5zYbMB89jKhDnEt4B93a0ZrEFixfNGmyxx3lZ',NULL,NULL,'desktop','Other','2026-08-01 00:45:38'),(1893,'/',NULL,NULL,'7E1FCuYtdIkDNmO5o2dGIYxX2ZoHO9oi1DXvb4zA',NULL,NULL,'desktop','Other','2026-08-01 01:32:24'),(1894,'/',NULL,NULL,'fOOgPOEaKJAZK6aYPfJxNH6ZxKVn7OFMk83rOvJ3',NULL,NULL,'desktop','Other','2026-08-01 02:19:13'),(1895,'/',NULL,NULL,'qulCvsr96pIxYZKuEHmxoz7WKKojHso3kun9LZ78',NULL,NULL,'desktop','Chrome','2026-08-01 02:34:40'),(1896,'/',NULL,NULL,'iWNUo8tLfJkwhYiv4f6dnHuGVtomRjnGAAh8S3Ct',NULL,NULL,'desktop','Other','2026-08-01 03:06:04'),(1897,'/',NULL,'http://safhenokhost.ir/','zEO4KAhcsAQwXrUvsLODE1FPcXqHhU2cHw4U2xgI',NULL,NULL,'mobile','Chrome','2026-08-01 03:17:27'),(1898,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'ZLuwzdcVopMqV3XThxreBJ2RO87WaiypkNNnyPdT',NULL,NULL,'mobile','Chrome','2026-08-01 03:17:28'),(1899,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'3UCunDPRX7lNl4A9K7cldMvhWHDwGadVImhy5DcZ',NULL,NULL,'mobile','Chrome','2026-08-01 03:17:29'),(1900,'blog/sayt-hmh-karh',NULL,NULL,'lPNHhtCfn48T2TGgs7Ab3TMmSIPuczmMSNVxj1hS',NULL,NULL,'mobile','Chrome','2026-08-01 03:17:29'),(1901,'/',NULL,NULL,'O8cYjzsR5EQ1OF7I2XoLBSwPFIIJSQVcQqFW1lEv',NULL,NULL,'desktop','Other','2026-08-01 03:52:37'),(1902,'/',NULL,NULL,'B8pNjKdiXMO7lQ3kxHb4i4rZRl0MoMhvUHgWOItk',NULL,NULL,'desktop','Other','2026-08-01 04:39:37'),(1903,'/',NULL,NULL,'lc17XddJzjlVlcPnEwDTIXVRvZsNTOErymznrDJo',NULL,NULL,'desktop','Chrome','2026-08-01 05:16:17'),(1904,'/',NULL,NULL,'BcHABUF5kRImLfwY25Qtn9ybDG66zTtelswQd3SB',NULL,NULL,'desktop','Other','2026-08-01 05:27:51'),(1905,'/',NULL,NULL,'jy0hzGFrAWYgCwolej5KxgyhA3wUdLRZFwXzEE1y',NULL,NULL,'desktop','Edge','2026-08-01 05:42:13'),(1906,'/',NULL,NULL,'Xal8iHHnUtZ85rdWVFxS2DuywXUlXevVVYMlKE4h',NULL,NULL,'desktop','Other','2026-08-01 06:15:42'),(1907,'/',NULL,NULL,'oGwkmaX2ENBmCNQrawihOVXuoZXC0HO4R1NfThMi',NULL,NULL,'desktop','Other','2026-08-01 07:02:41'),(1908,'/',NULL,NULL,'sD4EPKl1XOrSJxakBRo2jmoUEWX68hBDaIBB2WV3',NULL,NULL,'desktop','Other','2026-08-01 07:49:27'),(1909,'/',NULL,NULL,'sy5mYlv7vf0WuusXpILHRnkbAXR0QLrcq5mvgcAl',NULL,NULL,'desktop','Other','2026-08-01 08:39:03'),(1910,'/',NULL,NULL,'aKqECLdJ1MLKvTQTgBLNTAZcmDAhjnERMgGXFJeH',NULL,NULL,'desktop','Other','2026-08-01 09:27:48'),(1911,'/',NULL,NULL,'vP2HOhwPi7BREYa65FPXJa8YiUKZ0s5I3brU8ad4',NULL,NULL,'desktop','Other','2026-08-01 10:16:56'),(1912,'blog',NULL,NULL,'hoLbfhaVTA4uX2TZY3HKgBebteNRZeutHmI2bwJY',NULL,NULL,'desktop','Other','2026-08-01 10:54:56'),(1913,'/',NULL,NULL,'lU1tl11MxYyA2A9uIMq3V9LGw488tRklhoSLHKDT',NULL,NULL,'desktop','Other','2026-08-01 11:05:16'),(1914,'/',NULL,NULL,'3z86wTpl2xp5NniFINpkM9Y5QJlxD97jltukBuvA',NULL,NULL,'mobile','Safari','2026-08-01 11:05:56'),(1915,'blog',NULL,NULL,'J10Nw33YzrbnnO9SdhKLBTfqW1fT7C0bFremgVy0',NULL,NULL,'desktop','Other','2026-08-01 11:38:09'),(1916,'/',NULL,NULL,'d4JM4ZB6eX0JEflscuQBp1fw1K0cIwDXJoItSl82',NULL,NULL,'desktop','Other','2026-08-01 11:51:48'),(1917,'/',NULL,NULL,'QEWoCJxQlumAzGUYAnADR04kZl1OJLunqQGxC5xZ',NULL,NULL,'desktop','Other','2026-08-01 12:39:15'),(1918,'blog/series/syo',NULL,NULL,'i5eQAHOxZAcVNs3SoxiuTpFymoYsszn2ROzhvFQR',NULL,NULL,'desktop','Other','2026-08-01 13:05:05'),(1919,'/',NULL,NULL,'XaWeeUJ9bzN6b27yiBtMjyC3SNRmU34hFw2Lvsuv',NULL,NULL,'desktop','Other','2026-08-01 13:26:06'),(1920,'/',NULL,NULL,'ty1u7YhEEO54Chz3AMmJQKpQen5Pk9uOhc9oia8d',NULL,NULL,'desktop','Other','2026-08-01 14:13:26'),(1921,'/',NULL,NULL,'EOUydcmF4I0gYOF4q6o4Wt9AbHKSgBonMU3S1StZ',NULL,NULL,'desktop','Other','2026-08-01 15:00:32'),(1922,'/',NULL,NULL,'JUbSkceherBJnAZRnNsZ6s8bfwFiNmNPROFNUmbJ',NULL,NULL,'desktop','Other','2026-08-01 15:47:51'),(1923,'login',NULL,'https://safhenokhost.ir/admin/license','jvP1bwdjv12yhR2n8GG4CHzo3vQuHSAZLWkh4oju',NULL,NULL,'desktop','Firefox','2026-08-01 16:04:20'),(1924,'login',NULL,'https://safhenokhost.ir/admin/dashboard','q7bP656uXsN4RYzyNay5lGwH7e6SdgAwyL23Sw0j',1,NULL,'desktop','Firefox','2026-08-01 16:04:33'),(1925,'/',NULL,NULL,'MFnZd5RNVnJ5JnGKjUXpf04n0HjNDsx3mYsYkCUg',NULL,NULL,'desktop','Other','2026-08-01 16:34:23'),(1926,'/',NULL,NULL,'pkxSPyvIOThQc1hs7Gv3CMY2CzAGwtjGCrokTX3l',NULL,NULL,'desktop','Other','2026-08-01 17:21:51'),(1927,'login',NULL,'https://safhenokhost.ir/admin/dashboard','q7bP656uXsN4RYzyNay5lGwH7e6SdgAwyL23Sw0j',1,NULL,'desktop','Firefox','2026-08-01 17:57:36'),(1928,'/',NULL,NULL,'hjbkwYpgJNwM11fu418CR0FoTb7NZLX8Kzcy3zXO',NULL,NULL,'desktop','Other','2026-08-01 18:09:47'),(1929,'/',NULL,NULL,'bn3NXyTXsWeoYYkQOc49FN14RspdhP042CxCekKL',NULL,NULL,'desktop','Other','2026-08-01 18:55:53'),(1930,'/',NULL,NULL,'opkh6OIIJJIpwWf1c3GF9NEM9LB5FxawQEfZlyxp',NULL,NULL,'desktop','Other','2026-08-01 19:42:54'),(1931,'/',NULL,NULL,'pHIseJ1rJYiIMEP5NMip9WB7z6jVzFUAu7MAHIVo',NULL,NULL,'desktop','Other','2026-08-01 20:30:12'),(1932,'/',NULL,NULL,'NdAYzGl8bOvD1G0xUmzieEf3AKLg14DdTJws4k8b',NULL,NULL,'desktop','Other','2026-08-01 21:16:39'),(1933,'/',NULL,NULL,'LtX9Q5urhp2dF5QdiIaBABoyQvwdGhLL2uNkSrId',NULL,NULL,'desktop','Other','2026-08-01 22:03:42'),(1934,'/',NULL,NULL,'rVn3nuqeMzkffMJH1zcgMlKxoLIfCplT8yON5xwf',NULL,NULL,'desktop','Other','2026-08-01 22:49:00'),(1935,'/',NULL,NULL,'U5NCDl9DpxIizUX22tsWYZpMzNCpf4qcAmpNW1Vv',NULL,NULL,'desktop','Other','2026-08-01 23:34:36'),(1936,'/',NULL,NULL,'5ky9olNTEdcn9M5kXxGyTSne3tqFe2U6LH5g0GC5',NULL,NULL,'desktop','Other','2026-08-02 00:20:24'),(1937,'/',NULL,NULL,'09u5y5GNL2SkNSWlY8jIciHlnRigircpTXlsJ0j3',NULL,NULL,'desktop','Chrome','2026-08-02 00:47:18'),(1938,'/',NULL,NULL,'wQ2H88dC6B7HlAaQ2xe6KMfy3xf1iRxTdzJOjQhF',NULL,NULL,'desktop','Other','2026-08-02 01:07:09'),(1939,'/',NULL,NULL,'OzzuhX1vvEz2BIiFYOrMNluMret0OUD9ypzbRVF3',NULL,NULL,'desktop','Other','2026-08-02 01:53:34'),(1940,'/',NULL,NULL,'MMkMnMBGRb13JhyO0W7uGbUxb7E5PfrHmenBk033',NULL,NULL,'desktop','Other','2026-08-02 02:40:19'),(1941,'/',NULL,NULL,'Vq7zQuPuWHOD4FJXMZ59XY9zsy4PnICHSaVbACe7',NULL,NULL,'desktop','Other','2026-08-02 03:28:06'),(1942,'/',NULL,NULL,'mJX9ZZxK2GYNLGE7dfUk6PhXrBxvOt8kzMYnb5GC',NULL,NULL,'desktop','Other','2026-08-02 04:16:32'),(1943,'/',NULL,NULL,'eIZrttHWy47dlJktYJDP6lDeo5dpiQoVDxra76wh',NULL,NULL,'desktop','Other','2026-08-02 05:04:38'),(1944,'search',NULL,NULL,'qlPL0EXvrmPgIvt0byfVYM8H5IrnY6jNEL5M50YV',NULL,NULL,'desktop','Other','2026-08-02 05:10:42'),(1945,'/',NULL,NULL,'aDUjBfjIavDNrl7lrMzD7Ni7fLLYygYZi8Pjr06O',NULL,NULL,'desktop','Other','2026-08-02 05:53:20'),(1946,'/',NULL,NULL,'8HwOVtTdAhu4ycXn2Kw4Pgd4t1m4qrQTRA9dERKM',NULL,NULL,'desktop','Other','2026-08-02 06:41:31'),(1947,'/',NULL,NULL,'efDQiyiAwL9JGWM3P8AOitk7CSlbinr8znKjWcyW',NULL,NULL,'desktop','Other','2026-08-02 07:29:33'),(1948,'/',NULL,NULL,'cnzMmUrFjcvywoGtSCjd4JMLGMCnzu3woVQfq3z2',NULL,NULL,'desktop','Other','2026-08-02 08:17:45'),(1949,'/',NULL,NULL,'oHjh9WETj3mfp9onJCbr6FsHbIsR7apPzndhSEX1',NULL,NULL,'desktop','Edge','2026-08-02 08:19:07'),(1950,'/',NULL,NULL,'d1RZfEe38fDkkruOcDHcYMB0UgWmoWW1m33Y6lT9',NULL,NULL,'desktop','Other','2026-08-02 09:06:50'),(1951,'/',NULL,'http://safhenokhost.ir/','aKYBv0kRip7Lvj0DOIbRhA5iDjMl6hEDGYRNl7Mj',NULL,NULL,'mobile','Firefox','2026-08-02 09:39:08'),(1952,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'RrHUh92BlinHdpDcjtsbcPYt1oKsg3UEZkKa8yqA',NULL,NULL,'mobile','Firefox','2026-08-02 09:39:09'),(1953,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'VjWITMtG7z4houEKP7gvZDEEnABvlIu5X6HFOfOB',NULL,NULL,'mobile','Firefox','2026-08-02 09:39:09'),(1954,'blog/sayt-hmh-karh',NULL,NULL,'0HMqPoHlJcfebT8A8hnCVl88yQQtvD69JXGwONCZ',NULL,NULL,'mobile','Firefox','2026-08-02 09:39:10'),(1955,'/',NULL,NULL,'IuN8btyH04urO8JNvy4H3SY3PqGllbiniSpNEn2Z',NULL,NULL,'desktop','Other','2026-08-02 09:55:19'),(1956,'/',NULL,NULL,'hoMqVd28NyhgXwD94PQUnFxXoSff656xaHOoitKj',NULL,NULL,'desktop','Other','2026-08-02 10:42:37'),(1957,'/',NULL,NULL,'fgORGfUvc4knBpHnImtbccXqPhhOWUmoWiFq9NZV',NULL,NULL,'mobile','Safari','2026-08-02 11:06:12'),(1958,'/',NULL,NULL,'BDOWnYZQEA4QYQ9zQ7cyaWeMCsY4ZO1r4mxlOhhk',NULL,NULL,'desktop','Other','2026-08-02 11:30:16'),(1959,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'EqAUcYpJc7k1PJrRq4x5GwjShHoqITaWuSCFrcvE',NULL,NULL,'desktop','Other','2026-08-02 11:31:46'),(1960,'login',NULL,'https://safhenokhost.ir/admin/license','Vdt7VitVJdmBDCyjbby6ackTwVtPZw7nzgoarD8l',NULL,NULL,'desktop','Firefox','2026-08-02 11:46:03'),(1961,'login',NULL,'https://safhenokhost.ir/admin/dashboard','jJ570PuMX1ubfkOAHzQsEh7PQKKioBvIHJDBGdfP',1,NULL,'desktop','Firefox','2026-08-02 11:46:15'),(1962,'/',NULL,NULL,'vbZDkTgXHnp1M6lZ3fR6gNr9Zpn367XVXbfgHyZC',NULL,NULL,'desktop','Other','2026-08-02 12:18:05'),(1963,'/',NULL,NULL,'Mkp062Hw19jTSQbxd8pP1cDkObfooF3MsDmCBqhy',NULL,NULL,'desktop','Other','2026-08-02 13:05:50'),(1964,'login',NULL,'https://safhenokhost.ir/admin/dashboard','jJ570PuMX1ubfkOAHzQsEh7PQKKioBvIHJDBGdfP',1,NULL,'desktop','Firefox','2026-08-02 13:50:32'),(1965,'/',NULL,NULL,'5JqsExJwPCMscvVNP5itqkwtwf6wMenuy9wtob7k',NULL,NULL,'desktop','Other','2026-08-02 13:52:56'),(1966,'blog/category/mhtoa',NULL,NULL,'4qdW2DLmImr3YSYFhluxZJF8pbsUNdkDDvoJHtbE',NULL,NULL,'desktop','Other','2026-08-02 13:56:13'),(1967,'login',NULL,'https://safhenokhost.ir/admin/dashboard','jJ570PuMX1ubfkOAHzQsEh7PQKKioBvIHJDBGdfP',1,NULL,'desktop','Firefox','2026-08-02 14:23:56'),(1968,'/',NULL,'https://www.bing.com/','x5uVqirNmk9fqpVW1A1BBafhECcS429sgz8u5Y37',NULL,NULL,'desktop','Chrome','2026-08-02 14:30:56'),(1969,'/',NULL,'https://duckduckgo.com/','o03mcnva7DxkL8XWo8fNFmuiwI6Dr6WTHHmgAfOD',NULL,NULL,'desktop','Chrome','2026-08-02 14:30:58'),(1970,'/',NULL,NULL,'FNXXBWPuI4d6HEIcavCAYu3c63BtCBTe0i6Lo0SB',NULL,NULL,'mobile','Safari','2026-08-02 14:31:03'),(1971,'/',NULL,NULL,'2yy5UuJ84DlFLyN7HXU5uO0qeh4QsE8X1JUPD3Ed',NULL,NULL,'desktop','Other','2026-08-02 14:39:59'),(1972,'/',NULL,NULL,'Gl8Z5k3Iv58sW6A1B4gGjFWjMBWk0S5Y1qg0LNkI',NULL,NULL,'desktop','Other','2026-08-02 15:28:07'),(1973,'/',NULL,NULL,'CGPt3KNaNAmph5fD2IlYWYkJSDCVYC8Mdk8KBU3V',NULL,NULL,'desktop','Other','2026-08-02 16:15:46'),(1974,'/',NULL,NULL,'Xx8kvVrhDKcbU0dh6MPybZ08wkqzrgdh9ODsV8gv',NULL,NULL,'desktop','Other','2026-08-02 17:02:40'),(1975,'/',NULL,NULL,'yWmkTSGtgTQWmeLSL3JpxWuELwG08Px9dkUK1kio',NULL,NULL,'desktop','Chrome','2026-08-02 17:10:27'),(1976,'/',NULL,NULL,'GKaaD0mTWUCl1swOwUkLW6n5eXF7qnZ9S6wsxvWx',NULL,NULL,'mobile','Chrome','2026-08-02 17:21:12'),(1977,'/',NULL,NULL,'eWXxMtKr8HA8V22IB2B4GvhVFNkck5LF0VWYK973',NULL,NULL,'desktop','Other','2026-08-02 17:50:48'),(1978,'login',NULL,'https://safhenokhost.ir/admin/dashboard','jJ570PuMX1ubfkOAHzQsEh7PQKKioBvIHJDBGdfP',1,NULL,'desktop','Firefox','2026-08-02 18:19:57'),(1979,'/',NULL,NULL,'KLbCpCtKXPmgxRes2cPEmSTzvSONFQIUQfYOFTXN',NULL,NULL,'desktop','Other','2026-08-02 18:37:45'),(1980,'/',NULL,NULL,'b6ZbMEjVIHBrokeZMFCqoC0bTOHGjiUpIFDb9Zh5',NULL,NULL,'desktop','Other','2026-08-02 19:25:52'),(1981,'/',NULL,NULL,'1Tyj3XxNZQTp3gKafU2Ijrab5xukLePgl7WoT94i',NULL,NULL,'desktop','Other','2026-08-02 20:14:13'),(1982,'/',NULL,NULL,'xMYY8qwdkj8y5pqDrXmB9S2oWlB8X3LKqYkg6kjg',NULL,NULL,'desktop','Other','2026-08-02 21:01:08'),(1983,'/',NULL,NULL,'6pfE4ygdTaJqfbb4lju5RkT3fhosSRGPCIlO0QXX',NULL,NULL,'desktop','Other','2026-08-02 21:49:02'),(1984,'/',NULL,NULL,'jB3clCgQlu3C7iLy5MEKZ4djrkPhBJEoQoqpjDZQ',NULL,NULL,'desktop','Other','2026-08-02 22:36:53'),(1985,'/',NULL,NULL,'w3CWYx4zbjAwKfbHCELM1kkMSJ1o1nG1dulDl0bk',NULL,NULL,'desktop','Other','2026-08-02 23:23:42'),(1986,'/',NULL,NULL,'2GaRAzutmW5rcnvR3AhYUPLY2H0H2pQUlHacdo35',NULL,NULL,'desktop','Other','2026-08-03 00:11:48'),(1987,'/',NULL,NULL,'ZHYQH6ZjNxHGX1XedQ72R3cFEPLSJ8FIaAgItgoJ',NULL,NULL,'mobile','Chrome','2026-08-03 00:12:28'),(1988,'/',NULL,NULL,'FWivJflDE6ZkBSeBEIWpZ1N4GctwfjxrtA22uNnu',NULL,NULL,'desktop','Other','2026-08-03 00:59:07'),(1989,'/',NULL,NULL,'mLfP6pe7MFsYNFpuWhZB4Frjg9wuKn0EfqEaj8HV',NULL,NULL,'desktop','Other','2026-08-03 01:47:09'),(1990,'register',NULL,NULL,'3STp2D2ge6BjGlQcqDbpFysEco82oITQ202b1THm',NULL,NULL,'desktop','Other','2026-08-03 02:08:08'),(1991,'blog',NULL,NULL,'Vcvbp2vuS9FUFhU4ZBQbgRuGKi8rJRiOXMXZMuHt',NULL,NULL,'desktop','Other','2026-08-03 02:09:19'),(1992,'/',NULL,NULL,'0WS75LechqOLbOdyfojljMVS0F7s5LxHfYHiGvrG',NULL,NULL,'desktop','Other','2026-08-03 02:35:32'),(1993,'login',NULL,'https://safhenokhost.ir/admin/license','bWQvaQLlA7jpHzITu9OAAM2cbteDTnGvQeicwgzm',NULL,NULL,'desktop','Firefox','2026-08-03 02:44:41'),(1994,'login',NULL,'https://safhenokhost.ir/admin/dashboard','M50vDtFb51DbAOZlb77XRuLhWeeNYKuNiNwya2hf',1,NULL,'desktop','Firefox','2026-08-03 02:45:13'),(1995,'/',NULL,NULL,'7CyMPRYiys9dlSkZW7Pj69myxQEO1emdbqqT5jxK',NULL,NULL,'desktop','Other','2026-08-03 03:23:50'),(1996,'/',NULL,NULL,'mei6RSRTprkz6DnvgJamcgQZFLiucpQLWaEAOo4L',NULL,NULL,'desktop','Other','2026-08-03 04:11:58'),(1997,'blog',NULL,NULL,'Rv0WMyuZmTH75QbSS0WfC325MeTa0akXvB5tmih7',NULL,NULL,'desktop','Other','2026-08-03 04:37:20'),(1998,'/',NULL,NULL,'qotT8QzmfOBo54JXstK5hLPA4jjVZKIVZolwGun6',NULL,NULL,'desktop','Other','2026-08-03 05:00:18'),(1999,'/',NULL,NULL,'CpKkHzcyJEUGksp6emb6fwehaV02JtyQ0PW5a8hI',NULL,NULL,'desktop','Other','2026-08-03 05:47:47'),(2000,'/',NULL,NULL,'59fzBDleGC8Fl5BYz0elwWmlMgHEzeuKuaGD6Pxk',NULL,NULL,'desktop','Other','2026-08-03 06:35:35'),(2001,'/',NULL,NULL,'FxVaJ2iqltVrWLbUS1gVo4dRvYICPjsMc1QwYCgb',NULL,NULL,'desktop','Other','2026-08-03 07:27:58'),(2002,'/',NULL,NULL,'Q316zZViiH1fz7XmpTKoI4rWbmiIwPM2dIHoA2tq',NULL,NULL,'desktop','Firefox','2026-08-03 08:06:52'),(2003,'/',NULL,NULL,'GSJM6kzLTncEAMz90BqrY1Lhm0RZDz35njdaaAhI',NULL,NULL,'desktop','Other','2026-08-03 08:16:14'),(2004,'/',NULL,NULL,'seQaEvOdItCNQLwgP5t0nNnNq4wbgpS7SfjaMhDh',NULL,NULL,'mobile','Chrome','2026-08-03 08:20:19'),(2005,'/',NULL,NULL,'M1aYdl0SN4lyVbCWTqg64PB0ISA3ZGkjJ9icF9BA',NULL,NULL,'desktop','Other','2026-08-03 09:05:33'),(2006,'/',NULL,NULL,'LkjCk2FEncqHQx0kn07DkhOzD4b2aRWyEkvZ8NHT',NULL,NULL,'desktop','Edge','2026-08-03 09:41:09'),(2007,'/',NULL,NULL,'67alaJFDl6uE03GYjLw2WzWVMcm5lf17Rb9lEtAX',NULL,NULL,'desktop','Chrome','2026-08-03 09:41:23'),(2008,'/',NULL,NULL,'AXGanUP7SPmy9GaoJiVF1wC38AUybySLTliLe5QU',NULL,NULL,'desktop','Other','2026-08-03 09:53:11'),(2009,'login',NULL,'https://safhenokhost.ir/admin/dashboard','M50vDtFb51DbAOZlb77XRuLhWeeNYKuNiNwya2hf',1,NULL,'desktop','Firefox','2026-08-03 09:53:38'),(2010,'blog',NULL,NULL,'Z27RE5s0bJwEWYoaZFTuHW1B25D602BtBwP8kkGa',NULL,NULL,'desktop','Other','2026-08-03 10:10:25'),(2011,'/',NULL,NULL,'hBbyEkLpb6YDOCpfHU3WKcHiLkQR35imAXczB2Ub',NULL,NULL,'desktop','Other','2026-08-03 10:41:22'),(2012,'/',NULL,NULL,'fsMX01M3is4eJqdVbt1AWvIGThrfajuOfAB0dYgN',NULL,NULL,'desktop','Firefox','2026-08-04 21:03:06'),(2013,'login',NULL,NULL,'fsMX01M3is4eJqdVbt1AWvIGThrfajuOfAB0dYgN',NULL,NULL,'desktop','Firefox','2026-08-04 21:03:28'),(2014,'/',NULL,NULL,'500PGZ7dFQFjXTy1U3WHq7Nc6Qg587g7jrQPcSWi',NULL,NULL,'desktop','Chrome','2026-08-04 21:21:14'),(2015,'/',NULL,NULL,'IENVo8faob9MT32T5hq81W5eA1hqct1SvzhMQlfb',NULL,NULL,'desktop','Other','2026-08-04 21:47:10'),(2016,'/',NULL,NULL,'RimDdfEONfyyOAmxvgdLqjecF5YSheA2Fwt7UGWD',NULL,NULL,'desktop','Other','2026-08-04 22:35:01'),(2017,'/',NULL,NULL,'3kgCsoYFKfg0CNYIRM1k5D30UAXM3zg7C3WqX3yf',NULL,NULL,'desktop','Firefox','2026-08-04 23:19:39'),(2018,'/',NULL,NULL,'xRJczaCDxU60rbg1RFNqHopYgtl72YyCY5xtDCWO',NULL,NULL,'desktop','Other','2026-08-04 23:22:45'),(2019,'/',NULL,NULL,'YZdgxbLBS5xMl3Sz01BBvKCZWqd8HfgfylyZNeW3',NULL,NULL,'desktop','Other','2026-08-05 00:09:48'),(2020,'/',NULL,NULL,'mc828gxq92P7JrSPeoHBVTcL7iWQyUEH3Y2hqb7G',NULL,NULL,'desktop','Other','2026-08-05 00:09:53'),(2021,'/',NULL,NULL,'pMM6LPYPHmLvxLGwnTLZOiRaHuy52FRFQGiIlaGV',NULL,NULL,'desktop','Other','2026-08-05 00:57:37'),(2022,'/',NULL,NULL,'Ts2kECJxM2nBRX9JJWPWRfmQyeQqSiC2pNJLtWpK',NULL,NULL,'desktop','Other','2026-08-05 01:46:16'),(2023,'/',NULL,NULL,'Vm2WkWgIzbHlzpOCvKjDGscRBohGEE0G7GfLFTmy',NULL,NULL,'desktop','Other','2026-08-05 02:34:44'),(2024,'/',NULL,NULL,'A475FCZ2fIAVVErbSjXnI9MgfRUmn6h5wBqBVhKn',NULL,NULL,'desktop','Other','2026-08-05 03:23:18'),(2025,'/',NULL,NULL,'DIla9XSLkvOuKe9vzUykPkEotWEIKgdpUkPzLjjo',NULL,NULL,'desktop','Other','2026-08-05 04:12:08'),(2026,'/',NULL,NULL,'D5SXavOdu5DQtpSPmOvyFKI4Zbd3QSVwECSsyywQ',NULL,NULL,'desktop','Other','2026-08-05 05:00:46'),(2027,'/',NULL,NULL,'iQRDthkRGbDhWdpQlVbSnykPYgpCVwSejcCnZ2Dg',NULL,NULL,'desktop','Other','2026-08-05 05:49:12'),(2028,'/',NULL,NULL,'o1gJcThklKUrM8aTtsrNlO8tSCxpNsVjS0H9JrDh',NULL,NULL,'desktop','Other','2026-08-05 06:37:39'),(2029,'/',NULL,NULL,'SGNLWMctMS5nIzwtaizDvbfqf0uxNYyUX8qWIgex',NULL,NULL,'desktop','Other','2026-08-05 07:25:48'),(2030,'/',NULL,NULL,'hv39TFIHU16Fv1DaFTXzkdPcRWFvQ96cyborLwyH',NULL,NULL,'desktop','Firefox','2026-08-05 07:30:34'),(2031,'/',NULL,'http://safhenokhost.ir/','a5LHV0Q5UMKahki0D4lXOUze4ArRTd4GSWBUmciB',NULL,NULL,'desktop','Safari','2026-08-05 08:13:38'),(2032,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'5ac1LQ8URhbboQmPT8dyFrs9OrpumsmNhiny0WTB',NULL,NULL,'desktop','Safari','2026-08-05 08:13:38'),(2033,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'Oh05Ll4aDY4kPykvWgNuudw9Rp4Q2wZiFs5oOShw',NULL,NULL,'desktop','Safari','2026-08-05 08:13:39'),(2034,'blog/sayt-hmh-karh',NULL,NULL,'UjYzGAyClkSe5OYHrSmA7XYvUY1f6wbEXliRyQ7p',NULL,NULL,'desktop','Safari','2026-08-05 08:13:40'),(2035,'/',NULL,NULL,'FuhPxVGY42jssHpnALNLTc9RbP46jOePpOO59oSc',NULL,NULL,'desktop','Other','2026-08-05 08:15:24'),(2036,'/',NULL,NULL,'dwQd0WyG1lIinCcWFHMyKN9pORLC59kmxAr6rF3w',NULL,NULL,'desktop','Other','2026-08-05 09:04:40'),(2037,'/',NULL,NULL,'X7EkPfJL2Oh8V5d4RRVybAM2H8GSAYpxkoBqParV',NULL,NULL,'mobile','Chrome','2026-08-05 09:37:45'),(2038,'blog',NULL,'https://safhenokhost.ir/','X7EkPfJL2Oh8V5d4RRVybAM2H8GSAYpxkoBqParV',NULL,NULL,'mobile','Chrome','2026-08-05 09:37:59'),(2039,'blog',NULL,NULL,'dECpOalT707UiaZt3y0veRLZDZ3Xm7GB4CfDg0qE',NULL,NULL,'mobile','Chrome','2026-08-05 09:38:04'),(2040,'blog',NULL,NULL,'3xAfsWWPKpl0X57A96jSXQYMoPJZqE6vDt8QpumP',NULL,NULL,'mobile','Chrome','2026-08-05 09:38:05'),(2041,'blog',NULL,NULL,'iEu0wrEFwazEgMjTjCeot980Oxi6kf7rWxB9pEub',NULL,NULL,'mobile','Chrome','2026-08-05 09:38:05'),(2042,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,'https://safhenokhost.ir/blog','X7EkPfJL2Oh8V5d4RRVybAM2H8GSAYpxkoBqParV',NULL,NULL,'mobile','Chrome','2026-08-05 09:38:13'),(2043,'/',NULL,NULL,'VBuHwpQatMFTBnyJybwl50jCAJyFzcbEyftyPCpo',NULL,NULL,'desktop','Other','2026-08-05 09:52:23'),(2044,'/',NULL,NULL,'qmmQdsjQBRNnSdXAfJ8FhlpY33jRugK8YuZX5Cvd',NULL,NULL,'desktop','Other','2026-08-05 11:29:41'),(2045,'/',NULL,NULL,'uin6IFBVfp5omGAHpzwKgRSWKFxsXyeky0wEc2Od',NULL,NULL,'mobile','Chrome','2026-08-05 12:13:39'),(2046,'/',NULL,NULL,'erEdpz56j4IS6CSLqoFqxoZaKSznvRO9jAwF0LXw',NULL,NULL,'mobile','Chrome','2026-08-05 12:14:19'),(2047,'/',NULL,NULL,'61tCGkHXIIYdV1Rlyg8KVEsPblWejFlVtf5z3ABF',NULL,NULL,'desktop','Other','2026-08-05 12:14:49'),(2048,'/',NULL,NULL,'vJJ1HzctijVf9DNy7rgl6kCV2kq8wsD379LafUXE',NULL,NULL,'desktop','Other','2026-08-05 12:18:05'),(2049,'/',NULL,NULL,'EimXYcJZ7rVIMkgSJ9tobyhNJErtcLRQ9TJIBcVP',NULL,NULL,'desktop','Other','2026-08-05 13:05:50'),(2050,'/',NULL,NULL,'JHi5f1JiXQave5DDD0Fpksw6AFOIIkDa3QxCaEEu',NULL,NULL,'desktop','Other','2026-08-05 13:54:23'),(2051,'/',NULL,NULL,'nTqg7q5d3ehzElZUt9fbVBN9EyRyfbQwIbehZpHb',NULL,NULL,'desktop','Other','2026-08-05 14:42:12'),(2052,'login',NULL,'https://safhenokhost.ir/login','iU3u3EoRYLuZsNHDGGUEC94CTe85DIM98HITy5PZ',NULL,NULL,'desktop','Firefox','2026-08-05 14:59:22'),(2053,'/',NULL,NULL,'XghJ5g8zdnp6R0pD0HFPlnr8TrjpylQ9bCd0SVJu',1,NULL,'desktop','Firefox','2026-08-05 14:59:40'),(2054,'/',NULL,NULL,'6CWMKrTNUAn58HmyN5TGLuECMM8I7dk50Y5ngXql',NULL,NULL,'desktop','Other','2026-08-05 15:30:17'),(2055,'/',NULL,NULL,'yPSep70OgRLmM94BvonuslvUAvBOsrehX3UbRVYv',NULL,NULL,'desktop','Chrome','2026-08-05 15:50:15'),(2056,'/',NULL,'https://safhenokhost.ir/admin/dashboard','XghJ5g8zdnp6R0pD0HFPlnr8TrjpylQ9bCd0SVJu',1,NULL,'desktop','Firefox','2026-08-05 15:58:36'),(2057,'login',NULL,NULL,'XghJ5g8zdnp6R0pD0HFPlnr8TrjpylQ9bCd0SVJu',1,NULL,'desktop','Firefox','2026-08-05 15:58:43'),(2058,'login',NULL,'https://safhenokhost.ir/admin/dashboard','GeiFMLQXTfm53LUfnqqRjwbFi2bK8inBpbMGVvq7',1,NULL,'desktop','Firefox','2026-08-05 16:04:12'),(2059,'/',NULL,NULL,'GeiFMLQXTfm53LUfnqqRjwbFi2bK8inBpbMGVvq7',1,NULL,'desktop','Firefox','2026-08-05 16:06:05'),(2060,'/',NULL,NULL,'HcERbusvLOpLtExXBuGa0DpCXFPV6ZufI3Gazg6V',NULL,NULL,'desktop','Other','2026-08-05 16:18:22'),(2061,'/',NULL,NULL,'7UhBwVBFQQN7dC8yfBFR5UX5Kmu1KB5cgfoQ6QAc',NULL,NULL,'desktop','Other','2026-08-05 17:06:13'),(2062,'/',NULL,NULL,'ks4gQiOpU0bLrqdUSZRaf1T8BtPkW68uhiFsI0vp',NULL,NULL,'mobile','Chrome','2026-08-05 17:33:43'),(2063,'shop',NULL,'https://safhenokhost.ir/','ks4gQiOpU0bLrqdUSZRaf1T8BtPkW68uhiFsI0vp',NULL,NULL,'mobile','Chrome','2026-08-05 17:34:31'),(2064,'/',NULL,NULL,'tZrPXJidO1rXlbyLCdcyGBDLs2uHXE9BI1rTsIKt',NULL,NULL,'desktop','Other','2026-08-05 17:54:46'),(2065,'/',NULL,NULL,'ks4gQiOpU0bLrqdUSZRaf1T8BtPkW68uhiFsI0vp',NULL,NULL,'mobile','Chrome','2026-08-05 18:38:22'),(2066,'/',NULL,NULL,'YPVHzhijhLGX9ul6LwW16iXg7uE628mGwraERqiH',NULL,NULL,'desktop','Other','2026-08-05 18:43:05'),(2067,'/',NULL,NULL,'tYW6sN50VWLbf7D4vdEKexFkCmQiLyvH6l2Z2HhC',NULL,NULL,'desktop','Other','2026-08-05 19:31:41'),(2068,'/',NULL,NULL,'CYHsX1WmYz1ewpzxctSTlxt8i9admcMfOdSzcQAz',NULL,NULL,'desktop','Other','2026-08-05 20:19:46'),(2069,'/',NULL,'https://safhenokhost.ir/','fr9jkcJ4XwKVFSWitZiEQviUd5rJLUmnhLtsDHHW',NULL,NULL,'desktop','Other','2026-08-05 20:28:27'),(2070,'/',NULL,'https://safhenokhost.ir/?rest_route=/','3KbdGpn7yhPHQjgFXFpe5Wsr8U6LkZCMva5ZyiZJ',NULL,NULL,'desktop','Other','2026-08-05 20:28:36'),(2071,'/',NULL,NULL,'437YpNFomtmAmG0yZjOAr45Vkfps9rjhwIUtgwQi',NULL,NULL,'desktop','Other','2026-08-05 21:07:29'),(2072,'/',NULL,NULL,'EHocOUQBf7PdFImI67KD55upeXNEPnHtIj43a3Dk',NULL,NULL,'desktop','Other','2026-08-05 21:55:29'),(2073,'/',NULL,NULL,'ZQBZCLMm1VY0dzCtGElIH1f4KqltS4rABgVG1nFR',NULL,NULL,'desktop','Other','2026-08-05 22:43:33'),(2074,'/',NULL,NULL,'eru4NYWN8MGRsbZqajGzUbYPWYWz9d3xt6Vidm4m',NULL,NULL,'desktop','Other','2026-08-05 23:30:57'),(2075,'/',NULL,NULL,'uvoNzxPWG2P4CxAh8QNdgtti6WDpFVMVOtds1X9x',NULL,NULL,'desktop','Other','2026-08-06 00:18:49'),(2076,'/',NULL,NULL,'vDGRCjYNGMaEuHxBkQCuD0xYeNMhMDACYd29lu18',NULL,NULL,'desktop','Other','2026-08-06 01:07:15'),(2077,'/',NULL,NULL,'OMjfdEwHow3qHre3YSOI2l7O9GdD7u5yH8EjhILg',NULL,NULL,'desktop','Other','2026-08-06 01:55:17'),(2078,'/',NULL,NULL,'DNz0yM6LHiVzYMVW6LpWtdcNVQyZhj4ShLdyZygq',NULL,NULL,'desktop','Other','2026-08-06 02:43:47'),(2079,'/',NULL,NULL,'nPaHydoSO8POd13EOU9097bGpzGqLU3VnR97pFVh',NULL,NULL,'desktop','Other','2026-08-06 03:32:22'),(2080,'login',NULL,'https://safhenokhost.ir/admin/license','yx1S9FtVOvsYbyR64SP7eLRDddKhKnKZAHKLwfZi',NULL,NULL,'desktop','Firefox','2026-08-06 03:47:56'),(2081,'/',NULL,NULL,'yx1S9FtVOvsYbyR64SP7eLRDddKhKnKZAHKLwfZi',NULL,NULL,'desktop','Firefox','2026-08-06 03:48:57'),(2082,'login',NULL,'https://safhenokhost.ir/admin/dashboard','BaCJuPdFgS1bR8PmXS79138FMoXIopgTgGpgIV03',1,NULL,'desktop','Firefox','2026-08-06 03:49:23'),(2083,'/',NULL,NULL,'y0WkRt5la20567D3hLhGiU8sE7CCVrlOuGzuY8IX',NULL,NULL,'desktop','Other','2026-08-06 04:21:26'),(2084,'/',NULL,NULL,'BaCJuPdFgS1bR8PmXS79138FMoXIopgTgGpgIV03',1,NULL,'desktop','Firefox','2026-08-06 05:05:44'),(2085,'login',NULL,'https://safhenokhost.ir/admin/dashboard','BaCJuPdFgS1bR8PmXS79138FMoXIopgTgGpgIV03',1,NULL,'desktop','Firefox','2026-08-06 05:05:44'),(2086,'/',NULL,NULL,'cyt6eIoI1GsTEuPsN4m9vbSGLN9QmGepQRswGjLB',NULL,NULL,'desktop','Other','2026-08-06 05:10:01'),(2087,'/',NULL,NULL,'CyzciCqxtwyOb5gshl4U5VQquAWMyKohSqCzctLI',NULL,NULL,'desktop','Other','2026-08-06 05:58:19'),(2088,'/',NULL,NULL,'NElXGiZ1cn4nfQo03JtsHSauZI9UJGmEfa7vFcnW',NULL,NULL,'desktop','Other','2026-08-06 06:46:44'),(2089,'/',NULL,'https://safhenokhost.ir/?rest_route=%2Fjetpack%2Fv4%2Fsync%2Fstatus&_for=jetpack&token=uThbNbe%21qJyhj8YyhV13%28O%26uLR3Ka6%28f%3A1%3A0&timestamp=1786013073&nonce=09J3ewIxJK&body-hash&signature=VQydnYR99yhlAulrtYKi05ByTyQ%3D','y2dV2an6RzEVyfdHDmjHJf8SPLQft28FrXBlafqM',NULL,NULL,'desktop','Other','2026-08-06 07:14:28'),(2090,'/',NULL,NULL,'lp6UQnvjCWlx9WPbkxnwsbpgaN4whF0Sx6Tq6CNR',NULL,NULL,'desktop','Other','2026-08-06 07:33:22'),(2091,'/',NULL,NULL,'30c0KA1IJxZi1yBoEb8LIBHGOngQixCLMfDCBcoh',NULL,NULL,'desktop','Other','2026-08-06 08:16:47'),(2092,'/',NULL,NULL,'fx9gcGzmYIa33AfL2e9EaEhfWa1NYCfy0eUHz7UX',NULL,NULL,'desktop','Other','2026-08-06 09:00:34'),(2093,'/',NULL,NULL,'IqqOue1zHaCxaFHBqQnFLV4WA54J7dnOAAUso9SK',NULL,NULL,'desktop','Other','2026-08-06 09:44:55'),(2094,'/',NULL,NULL,'VfJWYAJipD5dtA1F6WPHdwXBWwVjEiHw9cgg1WFS',NULL,NULL,'desktop','Other','2026-08-06 10:29:10'),(2095,'/',NULL,NULL,'DjE1FFIuUyEdyT077yy3eTPem74LBMb4xDIwnrAH',NULL,NULL,'desktop','Other','2026-08-06 11:13:23'),(2096,'/',NULL,NULL,'dapvp6YTA76fRpOJm42tyXUjGw3SxE9imdMmonx9',NULL,NULL,'desktop','Other','2026-08-06 11:56:39'),(2097,'/',NULL,NULL,'GJpU5jnQF8bA2zmvy8IMKglC0WmYCEmoYootkSG9',NULL,NULL,'desktop','Other','2026-08-06 12:40:17'),(2098,'/',NULL,NULL,'M4Tu0Z92dz0elFNVXmDN0ghxXELnx5VHaMBijmRf',NULL,NULL,'desktop','Other','2026-08-06 13:24:22'),(2099,'/',NULL,NULL,'B7CxYvXrzBwutHcM5G0ZXwTXmtOAzcugfzf17gNQ',NULL,NULL,'desktop','Other','2026-08-06 14:07:27'),(2100,'/',NULL,NULL,'iZTaA6dLnSiD4HHJm1lj81Ex187geRFL4VvrmSul',NULL,NULL,'desktop','Other','2026-08-06 14:50:20'),(2101,'/',NULL,NULL,'vpNmb8Q34AZRWYGF1fdpo6DpPXfTjOzsXwEWl3o4',NULL,NULL,'desktop','Other','2026-08-06 15:34:06'),(2102,'login',NULL,'https://safhenokhost.ir/login','Pk4thNhcEam3tWnfKpAYcepskaKoPxMww3Mfhl73',NULL,NULL,'desktop','Firefox','2026-08-06 16:05:59'),(2103,'login',NULL,'https://safhenokhost.ir/admin/dashboard','N1i72RH01o24j25ayYtFyIb4iexeqDY4fGNjdMI0',1,NULL,'desktop','Firefox','2026-08-06 16:06:09'),(2104,'/',NULL,NULL,'o3iKFQ0CGYFOvBkSwFWzJrbw217K0ozp0ArtT92J',NULL,NULL,'desktop','Other','2026-08-06 16:18:06'),(2105,'/',NULL,NULL,'uezbhfKZgLoZeNBHI18ge2BfQgSczArQVfw0bqkh',NULL,NULL,'desktop','Other','2026-08-06 17:02:08'),(2106,'/',NULL,NULL,'MPzklSJNGMXZbkyxMDZOlEBblCrrSeHEATJp3QCt',NULL,NULL,'desktop','Other','2026-08-06 17:46:53'),(2107,'/',NULL,NULL,'SEXsqabOqkUcvUEs65PZQmJKmXczRxNdAjIVcmRf',NULL,NULL,'desktop','Other','2026-08-06 18:31:21'),(2108,'/',NULL,'https://www.google.com/','C6oRCL20C49ekHce2s14xPE2Jzxe9o8bMsMJoOQu',NULL,NULL,'mobile','Chrome','2026-08-06 19:06:59'),(2109,'/',NULL,NULL,'bo4fOyvOTAD4DCqPznL1NMwxksfCRh4zFWDgNlSd',NULL,NULL,'mobile','Chrome','2026-08-06 19:08:33'),(2110,'login',NULL,NULL,'bo4fOyvOTAD4DCqPznL1NMwxksfCRh4zFWDgNlSd',NULL,NULL,'mobile','Chrome','2026-08-06 19:11:12'),(2111,'login',NULL,'https://safhenokhost.ir/admin/dashboard','Djvzwq3WbzHsxJqjW2Oi8h5VNd9GnSKzx3385aF2',1,NULL,'mobile','Chrome','2026-08-06 19:11:28'),(2112,'/',NULL,NULL,'HnrPKvPZSQ1qvfUVeTYnK364JVcBHGLyCO62AHfb',NULL,NULL,'desktop','Other','2026-08-06 19:15:01'),(2113,'/',NULL,'http://safhenokhost.ir/','rA0fiB9zK0o3b6bRIvOhR8ppXLUgXp7ocGi8k3sW',NULL,NULL,'desktop','Firefox','2026-08-06 19:27:23'),(2114,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'on4IIdbLcWQhlIGGofqUP2sLTH3aHIAltQIZnznf',NULL,NULL,'desktop','Firefox','2026-08-06 19:27:24'),(2115,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'YUlKk2joy6uq8rlLhCiQdIDxZxz6wRQDrE3mihUz',NULL,NULL,'desktop','Firefox','2026-08-06 19:27:25'),(2116,'blog/sayt-hmh-karh',NULL,NULL,'uRjnsx1MgDjKzXJGINSZeHHrvGvMJNhWnGxy9lBh',NULL,NULL,'desktop','Firefox','2026-08-06 19:27:25'),(2117,'/',NULL,NULL,'oAbpmssqlYueLzW5g0LOUopC5vnvBlFMt2R6IRzm',NULL,NULL,'desktop','Other','2026-08-06 19:58:37'),(2118,'/',NULL,NULL,'8aTnwyAP9Vu24HN6HyIU7tOYToXCEiGCtlbMZXbU',NULL,NULL,'desktop','Chrome','2026-08-06 20:15:35'),(2119,'/',NULL,NULL,'0X0j6eG9yJEkfsdHhfoeU2RB0Fyh7tKxWDz7xRaA',NULL,NULL,'desktop','Other','2026-08-06 20:42:41'),(2120,'/',NULL,NULL,'62T4zQVdordqIJUCYr9GLLcrFGx3GIhAEyYjTLUL',NULL,NULL,'desktop','Other','2026-08-06 21:26:58'),(2121,'/',NULL,NULL,'M31gEnwXVTFELCmApjBkTgSeAdgoxsIMNc92biRA',NULL,NULL,'desktop','Other','2026-08-06 22:10:21'),(2122,'/',NULL,NULL,'d8ZVGg7Ff2INKKMr0YeurZ0RgYlkWTUo0Ti9Ns8R',NULL,NULL,'desktop','Other','2026-08-06 22:52:52'),(2123,'/',NULL,NULL,'0SgXvIOFVn9fmBAnjiYPv4h0RIVc5KduPkve1Zeo',NULL,NULL,'desktop','Other','2026-08-06 23:35:34'),(2124,'/',NULL,NULL,'FmC6aqC5I6Ju6JywXMOrpBZQ4UB3k2ZzyGfwCg6t',NULL,NULL,'desktop','Other','2026-08-07 00:18:35'),(2125,'/',NULL,NULL,'KbKxE0pawmNN0Ffkh3LlD7OrPeOjL3xKHfcAt6S8',NULL,NULL,'desktop','Other','2026-08-07 01:01:05'),(2126,'/',NULL,NULL,'6QZsAZVni2DzwKXbHS6IbTmxzQQea1zKBxHgpZo7',NULL,NULL,'desktop','Other','2026-08-07 01:45:21'),(2127,'/',NULL,NULL,'4lJkzYZcv4f4qm6Gl5pZYo0uAx6nLopm7IBYH3VG',NULL,NULL,'desktop','Other','2026-08-07 02:29:19'),(2128,'/',NULL,NULL,'wOmpvY8YTu4NHHT5tSdJ1f6YDtZ3hcevovqTiJEl',NULL,NULL,'desktop','Other','2026-08-07 03:12:21'),(2129,'/',NULL,NULL,'RPqlwFWaoOzNN10psa3uGpXSIohNG2GXctxxJ2VW',NULL,NULL,'desktop','Other','2026-08-07 03:56:09'),(2130,'/',NULL,NULL,'IXvXYm0Ly78lUa0iqUZHiBCK8StHD1ImDoUGTqKc',NULL,NULL,'desktop','Other','2026-08-07 04:41:39'),(2131,'/',NULL,NULL,'TmIkCv8AMd6unikjLZmh93wa4miJtREk0dDkfk5C',NULL,NULL,'desktop','Other','2026-08-07 05:26:09'),(2132,'/',NULL,NULL,'vuKVSHjvhVOtiK8du4asXp5uHKfqMJaHfUdgXU0B',NULL,NULL,'desktop','Other','2026-08-07 06:09:49'),(2133,'/',NULL,NULL,'byqQS6eqeKVgxQ6AOGLs7tY9W1Tqp1ZaJM0ZXc2C',NULL,NULL,'desktop','Other','2026-08-07 06:52:25'),(2134,'/',NULL,NULL,'6s9M9gfAysDSE7e3hLvZhoqqZyIjcDwkfY60M1kZ',NULL,NULL,'desktop','Other','2026-08-07 07:36:29'),(2135,'/',NULL,NULL,'psZNVe5EH3aoclcuwrAH1PkBGB7bIeNddp3xyqVD',NULL,NULL,'desktop','Other','2026-08-07 08:21:03'),(2136,'/',NULL,NULL,'wyhSG9MSXDGLH70alQNSpZz0sr4AKlDNaOb5l46f',NULL,NULL,'desktop','Other','2026-08-07 09:04:16'),(2137,'/',NULL,NULL,'UDsoKpPovByGVPaG1c5dngC4Ftb6azbAD8tN5x3N',NULL,NULL,'desktop','Other','2026-08-07 09:41:36'),(2138,'/',NULL,NULL,'P6B17vWvQOtSHt40XMgkKBjG8HlBQZ5qfbabBO3F',NULL,NULL,'desktop','Other','2026-08-07 09:41:37'),(2139,'/',NULL,NULL,'DXqT1sbBFMvNdJT8fCQD9n7CFO3BGMnxQ8JMM138',NULL,NULL,'desktop','Other','2026-08-07 09:48:00'),(2140,'/',NULL,NULL,'zFcohVrIJtLDpqUcDASBFCiw6VWmr9pnRWDz5nMo',NULL,NULL,'mobile','Safari','2026-08-07 10:16:27'),(2141,'/',NULL,NULL,'74zZ8O17jOIcqXu2SKCm9rEPUBwUmE0AqKWSljMp',NULL,NULL,'desktop','Other','2026-08-07 10:31:59'),(2142,'/',NULL,NULL,'4UVDtIIATYEupS4TxF30v1T5K9zncDuveLPCcsqm',NULL,NULL,'desktop','Other','2026-08-07 11:15:33'),(2143,'/',NULL,NULL,'xhEPdUlI8LTduDQrSfBy92cXLkM5NZwMPD1mGIPX',NULL,NULL,'desktop','Other','2026-08-07 11:59:23'),(2144,'/',NULL,NULL,'XT4sleMaQzRJVvqU0H3KlOaVJKRL9ScNHi5pP6Tq',NULL,NULL,'desktop','Other','2026-08-07 12:43:14'),(2145,'/',NULL,NULL,'Ell82mYF9U4wvrBM6q5McI0kDpwPAM4msT1zZrVD',NULL,NULL,'desktop','Other','2026-08-07 13:27:04'),(2146,'/',NULL,NULL,'1zIvEVWfONnkytCG8dZ74Cq4MfxEjBAGxWrJOnnR',NULL,NULL,'desktop','Other','2026-08-07 14:10:13'),(2147,'/',NULL,NULL,'04nLpnFvCwMUymqtyxUHDFP18ROyLKhQv2fs1igk',NULL,NULL,'desktop','Chrome','2026-08-07 14:21:18'),(2148,'/',NULL,NULL,'tbSLS6Nkfvu2fBGHCCM5DgFbMZvwKN1R0v4Nqd9L',NULL,NULL,'desktop','Other','2026-08-07 14:24:31'),(2149,'/',NULL,NULL,'prFgCVQufBg7iMjCMjs1lLZ1RNO1D9hn0mZcxY4c',NULL,NULL,'desktop','Other','2026-08-07 14:24:31'),(2150,'/',NULL,NULL,'Z1Jn7cyoTYWLOPmv0p8oPypmygbidcYiv3OoX6SF',NULL,NULL,'mobile','Chrome','2026-08-07 14:29:28'),(2151,'/',NULL,NULL,'NdxCTxQd34QCVvAmmW4vZoseEnVQXMkzI9y063Rs',NULL,NULL,'desktop','Other','2026-08-07 14:53:02'),(2152,'/',NULL,NULL,'6pn26HSeSMXqRRSGm8KnmrWSwuu88N6cGgLPlKkW',NULL,NULL,'desktop','Other','2026-08-07 15:37:53'),(2153,'/',NULL,NULL,'N2Bmgsu5we0C5iBx9lRUXXcJ4LNQPHbS2N0lenZm',NULL,NULL,'desktop','Other','2026-08-07 16:20:58'),(2154,'/',NULL,NULL,'RJyKF8Q3nmfrypn4ys8P8SuRfsbNrJKQp7TH37vI',NULL,NULL,'desktop','Other','2026-08-07 17:03:54'),(2155,'/',NULL,NULL,'MslBTeE83QkQlIRABfejiw2JBr4tdHhAqzqlo9Qx',NULL,NULL,'desktop','Other','2026-08-07 17:48:42'),(2156,'/',NULL,NULL,'uGuVtbkcifJUSe66YerBkQ0JSEB3WSdVO2WlwjgC',NULL,NULL,'desktop','Other','2026-08-07 18:33:27'),(2157,'/',NULL,NULL,'yWkJEKhBLYgdIzu8UOM8rK8PeolI5WLqQQrIjwrF',NULL,NULL,'desktop','Other','2026-08-07 19:16:45'),(2158,'/',NULL,NULL,'WX99f83Gh1EqEIzsIpLvbmnytV0foRzE2gyXvKWc',NULL,NULL,'desktop','Other','2026-08-07 19:59:15'),(2159,'/',NULL,NULL,'ZKLj4QwVvDzfziQnOUq1fNEewXRm9uZC525tPiaE',NULL,NULL,'desktop','Other','2026-08-07 20:42:45'),(2160,'/',NULL,NULL,'ViiLotvGK1yKd9dZcNkhwfgNRIUaWtStkXPslrLE',NULL,NULL,'desktop','Other','2026-08-07 21:26:35'),(2161,'/',NULL,NULL,'zFoOtalrepD7PLIkWR7oMdWdXRVA6TxGo880azG5',NULL,NULL,'desktop','Other','2026-08-07 22:10:00'),(2162,'/',NULL,NULL,'ywOIuIIb9rBKJWyStJGHDHCVOMpOgR9pV2EDqTdb',NULL,NULL,'desktop','Other','2026-08-07 22:52:45'),(2163,'/',NULL,NULL,'YBdQzOYTx16qiijufNOf1OSlYRxhbZUtQOctDF0P',NULL,NULL,'desktop','Other','2026-08-07 23:36:07'),(2164,'/',NULL,NULL,'Qv1G1CaiR73DH0VJDLDrWv4QXZ3asLrkDtkTCKq5',NULL,NULL,'desktop','Other','2026-08-08 00:18:22'),(2165,'/',NULL,NULL,'uEMAy2hLWPcoZLgp2LoGsH2CrSHklo4TMItBjNhL',NULL,NULL,'desktop','Other','2026-08-08 01:00:21'),(2166,'/',NULL,NULL,'YQb78zlH8KCLtDtegxU7INRzLKbnmA4uT9ms1Fo2',NULL,NULL,'desktop','Other','2026-08-08 01:45:17'),(2167,'/',NULL,NULL,'l2jDg93k5I2yZzJLPH7wpMD1LVndO9HjdpTQ9WxV',NULL,NULL,'desktop','Other','2026-08-08 02:31:14'),(2168,'/',NULL,'http://safhenokhost.ir/','fu9eL7TH6t9V6ktJJu7Ok68LDrObBEHwcYqeVheD',NULL,NULL,'desktop','Chrome','2026-08-08 02:41:21'),(2169,'/',NULL,NULL,'b4aPizzatUGU3CsPyWSZINkqV3nSY5ch914nhiHy',NULL,NULL,'desktop','Other','2026-08-08 03:15:12'),(2170,'login',NULL,'https://safhenokhost.ir/login','qThBM5Ol6aCuaYfHqDOUwoKZcbGapK6ZSQu9vQWF',NULL,NULL,'desktop','Firefox','2026-08-08 03:53:16'),(2171,'login',NULL,'https://safhenokhost.ir/admin/dashboard','4n6vLqR6gphL6UgJMqjb3mfVbL9Xg3iAZuZapnmu',1,NULL,'desktop','Firefox','2026-08-08 03:53:40'),(2172,'/',NULL,NULL,'4n6vLqR6gphL6UgJMqjb3mfVbL9Xg3iAZuZapnmu',1,NULL,'desktop','Firefox','2026-08-08 03:53:47'),(2173,'/',NULL,NULL,'Gxtnu8SL0xGH592PeX906rMaMsDwvR43y1FiGZ9B',NULL,NULL,'desktop','Other','2026-08-08 03:58:55'),(2174,'/',NULL,NULL,'sRQne4lgK9tSCz4dquF6Oju4a1JfGeDQxj776UzY',NULL,NULL,'desktop','Other','2026-08-08 04:43:24'),(2175,'/',NULL,NULL,'01GgYgGK4445YCXI66qN8rERoxkiVPhUnoa6KlWs',NULL,NULL,'desktop','Chrome','2026-08-08 05:14:32'),(2176,'/',NULL,NULL,'AWnkk3azoNEvuJuP5jcZNqwRa11gSQf18WOETvnh',NULL,NULL,'desktop','Other','2026-08-08 05:29:30'),(2177,'/',NULL,NULL,'LhdhUuWuCk8sidNNU0bp9Xjw6NYphbPLzuPjESJQ',NULL,NULL,'desktop','Other','2026-08-08 06:13:47'),(2178,'/',NULL,NULL,'mDvpM4cXsCPBOKStWKnDgZlmoS1fqq1mjg2HdnLm',NULL,NULL,'desktop','Other','2026-08-08 06:58:09'),(2179,'/',NULL,NULL,'F1blfEJSqB4mJ3os3rzSqXlKjbQgnr8npmkbcad6',NULL,NULL,'desktop','Other','2026-08-08 07:42:23'),(2180,'/',NULL,NULL,'rKvhUjWS2aA3kh2KMjQXPqauuVkoviCE00UodL56',NULL,NULL,'desktop','Other','2026-08-08 08:26:47'),(2181,'/',NULL,NULL,'sSmNUlCk22Xdc2UwU638ejQ3KZZYwHDsnxRqeJj0',NULL,NULL,'desktop','Other','2026-08-08 09:11:20'),(2182,'/',NULL,NULL,'EjRhnsZ1Xm8HlqZiPWSeMfMTXGPf5c22gMGg38re',NULL,NULL,'desktop','Other','2026-08-08 09:55:56'),(2183,'/',NULL,NULL,'BsB9oPmJDg6fPTr3lVNMrsZCPE42l5CBraGW5qAL',NULL,NULL,'desktop','Other','2026-08-08 10:39:11'),(2184,'/',NULL,NULL,'iBMqICOssaXKiwpt15oJKhbHXyJRFTZZ1Okpjy5d',NULL,NULL,'desktop','Other','2026-08-08 11:23:33'),(2185,'/',NULL,NULL,'98orAjoPEtvIFkGHNu1Mta6IxV4dujuiNdc3ooBZ',NULL,NULL,'desktop','Other','2026-08-08 12:06:42'),(2186,'/',NULL,NULL,'OkDCxbLMOTwoQLMty07ucgJM70X6KAL0h6FhVTZI',NULL,NULL,'desktop','Other','2026-08-08 12:39:43'),(2187,'/',NULL,NULL,'WWzXgWUsw7Dg89FwJLb9KFLHQoA9vetpCOiLzEjr',NULL,NULL,'desktop','Other','2026-08-08 12:50:03'),(2188,'/',NULL,NULL,'hgSzMC6Ogcl3WaZB0Zbd1F97ybGmotrY8KWD9MJH',NULL,NULL,'desktop','Other','2026-08-08 13:34:12'),(2189,'/',NULL,NULL,'jcsMWR9JF9hEY4L6WyeL8i8sGx6sbJRNsYiTBDL9',NULL,NULL,'desktop','Chrome','2026-08-08 13:40:21'),(2190,'/',NULL,NULL,'XHYROYjiiiV67CoEkYHTNua2c4WhrzGc2Txt09K5',NULL,NULL,'desktop','Other','2026-08-08 14:17:55'),(2191,'/',NULL,NULL,'qf2eOGEQ9VMIEJH4HaHBhcHweuUYWcxhtP7TjNg5',NULL,NULL,'desktop','Other','2026-08-08 15:01:01'),(2192,'/',NULL,NULL,'GZeMQ8n3l0pZSfmK7e4HorwvHCo3x3hcjkA6T2zd',NULL,NULL,'desktop','Other','2026-08-08 15:45:36'),(2193,'login',NULL,'https://safhenokhost.ir/login','iF8yjBnegNrIIzChE6obVSZ2EPI5U6la5WoDqiAj',NULL,NULL,'desktop','Firefox','2026-08-08 16:06:02'),(2194,'/',NULL,NULL,'MHJ0kEOzTuol9RHZhjTKvS8lOI9y5DlU3BcvZXcU',1,NULL,'desktop','Firefox','2026-08-08 16:06:27'),(2195,'login',NULL,'https://safhenokhost.ir/admin/dashboard','MHJ0kEOzTuol9RHZhjTKvS8lOI9y5DlU3BcvZXcU',1,NULL,'desktop','Firefox','2026-08-08 16:06:59'),(2196,'/',NULL,NULL,'HCC0AU4GMa7jAMcFXoI8ldqpAtrDxhORiLUaSHIU',NULL,NULL,'desktop','Other','2026-08-08 16:29:33'),(2197,'/',NULL,NULL,'9hf03mNQ2qXUXOhT5FD8HRU8YShjk0CTn3XmhpWJ',NULL,NULL,'desktop','Other','2026-08-08 17:12:25'),(2198,'/',NULL,NULL,'Niy01LwsdpvEe9t5ELYzQPJS3FEBkW8lSdBrIqF5',NULL,NULL,'desktop','Other','2026-08-08 17:55:56'),(2199,'/',NULL,NULL,'Y3L0E8FejImV797zUmwlNbtU1pxRlFU8AmmlfIWC',NULL,NULL,'desktop','Other','2026-08-08 18:39:45'),(2200,'/',NULL,NULL,'2wuSMOfOMHnvmKSH7lL5FIBYOpx3NyK6cvn0TB9d',NULL,NULL,'desktop','Other','2026-08-08 19:23:08'),(2201,'/',NULL,NULL,'y36Opof5MpceZETvGSkrGstZFB2DsqzVeaRM5phU',NULL,NULL,'desktop','Other','2026-08-08 20:05:08'),(2202,'/',NULL,NULL,'m9PyZ16THU1vEYHgrlCUxKk9WPD1dUKxWnqhAdBa',NULL,NULL,'desktop','Other','2026-08-08 20:47:58'),(2203,'/',NULL,NULL,'QJWV4yRsaMnLhE9quuQU9qq7VOX63uWlfosOeLbG',NULL,NULL,'desktop','Other','2026-08-08 21:31:50'),(2204,'/',NULL,NULL,'CmrhE3USgPixGeepkkzu5ZIkgKgyiFncB30q0Uyv',NULL,NULL,'desktop','Other','2026-08-08 22:14:18'),(2205,'/',NULL,'http://safhenokhost.ir/','bNzzmHr3jnIWqA5ERi3V6RJOYDnaLc4C96pxjfET',NULL,NULL,'desktop','Chrome','2026-08-08 22:43:33'),(2206,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'dYMnLlTpGhfaOcAkEQrj6CG0piwgz3vVZCB97HOY',NULL,NULL,'desktop','Chrome','2026-08-08 22:43:33'),(2207,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'0zTyK5OH07ZK1gpl3vkpQgkx9VeundzpGWmLNc99',NULL,NULL,'desktop','Chrome','2026-08-08 22:43:34'),(2208,'blog/sayt-hmh-karh',NULL,NULL,'L6vUGNkG8sAMaedYbMMEEB0AsRb5AVhA14fMf3uG',NULL,NULL,'desktop','Chrome','2026-08-08 22:43:35'),(2209,'/',NULL,NULL,'VVbIvjlOLJ0AvvLQyHNt9T5TkBdGCUsdtxvBV9m0',NULL,NULL,'desktop','Other','2026-08-08 22:58:01'),(2210,'/',NULL,NULL,'ga6hDjcZSmuqSJtzsFpDiNngpkyJSDcY7Y6jgfV0',NULL,NULL,'desktop','Other','2026-08-08 23:40:55'),(2211,'/',NULL,NULL,'gBGpwSlNg8MLIrqVcb0NzipHuLbMED7akwpzAAtj',NULL,NULL,'desktop','Other','2026-08-09 00:23:38'),(2212,'/',NULL,NULL,'E0fsLSiiUUc2Q2swLYAPBrxc8y7sgzxP9AsYhUIK',NULL,NULL,'desktop','Other','2026-08-09 01:05:49'),(2213,'/',NULL,NULL,'3KtejT5vzClDJDXmV5JILINT1Og0xr6WHyMN37Zw',NULL,NULL,'desktop','Other','2026-08-09 01:50:11'),(2214,'/',NULL,NULL,'GDc5DRCMi5ui1XjJJEI6UhJWFhsZK1IJtugEuNRj',NULL,NULL,'desktop','Other','2026-08-09 02:34:49'),(2215,'/',NULL,NULL,'TNWem6xtO8JgNo8kVsKLUF3mgCCzL2UT0baqc2wL',NULL,NULL,'desktop','Other','2026-08-09 03:18:47'),(2216,'/',NULL,NULL,'c5hILnLJHdBsvKEpD3CWje7eqiSWh6e7nPsjtOfM',NULL,NULL,'desktop','Other','2026-08-09 04:02:28'),(2217,'/',NULL,NULL,'9jbMJP8X0jZaNimKIh1RpPSxGIKULgIcEVGSAqkz',NULL,NULL,'desktop','Other','2026-08-09 04:46:49'),(2218,'/',NULL,NULL,'1O7IFGyyPSXUEeJGHKUkN2S8c6mbeAE0xetQgREn',NULL,NULL,'desktop','Other','2026-08-09 05:31:25'),(2219,'/',NULL,NULL,'6En5nMEW4dRA8WcnFeHeDwzJ5eQoXy3srnYGWkE3',NULL,NULL,'desktop','Other','2026-08-09 06:15:08'),(2220,'/',NULL,NULL,'N3kYqv2sEcyf18JNTC9bMG0OqBf5MpK30ZZfjyLg',NULL,NULL,'desktop','Other','2026-08-09 06:58:18'),(2221,'/',NULL,NULL,'CMXj9Gf6YaSEZaRPter2kp4ggMAxoft7iUq0STl3',NULL,NULL,'desktop','Other','2026-08-09 07:42:35'),(2222,'/',NULL,NULL,'ANUDzDNDHEOkQslnMHECoY7WO04PtiJ2sFNqeIuO',NULL,NULL,'desktop','Other','2026-08-09 08:27:39'),(2223,'login',NULL,'https://safhenokhost.ir/login','yzj6VZj6yUoHu3MTl39YUFDOpKx3gO0FV2aQ2LDg',NULL,NULL,'desktop','Firefox','2026-08-09 08:58:53'),(2224,'/',NULL,NULL,'yzj6VZj6yUoHu3MTl39YUFDOpKx3gO0FV2aQ2LDg',NULL,NULL,'desktop','Firefox','2026-08-09 08:58:54'),(2225,'login',NULL,'https://safhenokhost.ir/admin/dashboard','PWpQJd3eo22e6kvabsyG6Wto8cuFH23knfmLt19b',1,NULL,'desktop','Firefox','2026-08-09 08:59:28'),(2226,'/',NULL,NULL,'sEnihBHbPDI1HhnckctIr1gOtAEuZZDzwQwxAvZ2',NULL,NULL,'desktop','Other','2026-08-09 09:12:07'),(2227,'login',NULL,'https://safhenokhost.ir/admin/posts','PWpQJd3eo22e6kvabsyG6Wto8cuFH23knfmLt19b',1,NULL,'desktop','Firefox','2026-08-09 09:32:34'),(2228,'/',NULL,NULL,'4XiS9CDAWZSNRXOk2GV39LMupyKBHvs0WZiV3fSn',NULL,NULL,'desktop','Other','2026-08-09 09:55:28'),(2229,'/',NULL,NULL,'66EzHL7k6JzyGEkuFVARWMUhU8aYYVGtSMJwdekw',NULL,NULL,'desktop','Other','2026-08-09 10:39:52'),(2230,'/',NULL,NULL,'0NuXGaLLmWBfdT3Khz4JGsyfyiqRxNfqsIWWznaw',NULL,NULL,'desktop','Other','2026-08-09 11:23:38'),(2231,'/',NULL,NULL,'OpONh2FkK4IWg5PLaFYiC4wZYtCpvq9IQgjuya8c',NULL,NULL,'desktop','Other','2026-08-09 12:06:36'),(2232,'/',NULL,NULL,'yRNV1BXefY9s4VhEOVbq8E4BtNZqJ7R7aBCsSYTP',NULL,NULL,'desktop','Other','2026-08-09 12:49:14'),(2233,'/',NULL,NULL,'8GcerlyY7vwNlzT72ZY4PUAEtA83A4MzeutvqKx6',NULL,NULL,'desktop','Other','2026-08-09 13:32:50'),(2234,'/',NULL,NULL,'6VaDmofSsUTmMV0HSODN1WYEZWA82TruYSNl3MtJ',NULL,NULL,'desktop','Other','2026-08-09 14:15:19'),(2235,'/',NULL,NULL,'NcXXFTXRgaxF0Fnvdse72IseMlbYXRaUUUrNSdQO',NULL,NULL,'desktop','Other','2026-08-09 14:58:21'),(2236,'/',NULL,NULL,'cPjykrpQZaxJdbZpPlCDADYRsSNO8vGADC8vay8A',NULL,NULL,'desktop','Other','2026-08-09 15:41:56'),(2237,'/',NULL,NULL,'ue6MyaOwWcgrpSLOmI76oypPeu4vXSQjEurpYDCP',NULL,NULL,'desktop','Other','2026-08-09 16:25:44'),(2238,'/',NULL,NULL,'O7nRUe1Ix3jR63FXqgyXzzgdDO8JFtrgmHW4u31u',NULL,NULL,'desktop','Other','2026-08-09 17:09:29'),(2239,'/',NULL,NULL,'yMFLHMky5kNCWgQBl3UxfWWO4vylxTCvSDdnNaql',NULL,NULL,'desktop','Other','2026-08-09 17:52:54'),(2240,'/',NULL,NULL,'6g0fCMMHNcTygIKNvBVPjmJIpURHYx5THuYo0ikA',NULL,NULL,'mobile','Chrome','2026-08-09 17:59:03'),(2241,'blog',NULL,'https://safhenokhost.ir/','6g0fCMMHNcTygIKNvBVPjmJIpURHYx5THuYo0ikA',NULL,NULL,'mobile','Chrome','2026-08-09 17:59:12'),(2242,'blog/sayt-hmh-karh',NULL,'https://safhenokhost.ir/blog','6g0fCMMHNcTygIKNvBVPjmJIpURHYx5THuYo0ikA',NULL,NULL,'mobile','Chrome','2026-08-09 17:59:29'),(2243,'shop',NULL,'https://safhenokhost.ir/','6g0fCMMHNcTygIKNvBVPjmJIpURHYx5THuYo0ikA',NULL,NULL,'mobile','Chrome','2026-08-09 17:59:36'),(2244,'shop',NULL,NULL,'7WyO6RYUEAGwn9AFy5ud9s4Od50NLBjqnoFvrVVk',NULL,NULL,'mobile','Chrome','2026-08-09 17:59:37'),(2245,'shop',NULL,NULL,'eUirihzstc7DHJDK6pICl3bm4uibvZPFOaLHCJeX',NULL,NULL,'mobile','Chrome','2026-08-09 17:59:38'),(2246,'shop',NULL,NULL,'josh5jFcXi03i5paUMunyJ7Nr8dvYsG5Knmi9bBB',NULL,NULL,'mobile','Chrome','2026-08-09 17:59:38'),(2247,'login',NULL,NULL,'6g0fCMMHNcTygIKNvBVPjmJIpURHYx5THuYo0ikA',NULL,NULL,'mobile','Chrome','2026-08-09 17:59:59'),(2248,'login',NULL,'https://safhenokhost.ir/admin/dashboard','Gh1rBBTDu9yk60PKg64BJ3vg7ClMZbzA3T3H7xcK',1,NULL,'mobile','Chrome','2026-08-09 18:00:18'),(2249,'/',NULL,NULL,'OlPHy2nUZsjbhlxJxxMz7iUUGDERaVA6OGMUvRku',NULL,NULL,'desktop','Chrome','2026-08-09 18:04:08'),(2250,'/',NULL,NULL,'KkAZtMK1WUHNhh2A8yXPN8w6L7TAEW06xikGCgLz',NULL,NULL,'desktop','Other','2026-08-09 18:36:30'),(2251,'/',NULL,NULL,'2GlYnCjYhL8cJojNVgCAMhbfPXem1yev8ftR19vQ',NULL,NULL,'desktop','Other','2026-08-09 19:20:48'),(2252,'/',NULL,NULL,'7MSYMO2jXpBh6wt5aFYVOvG6bGpqbqmW0tS4jA2c',NULL,NULL,'desktop','Other','2026-08-09 20:02:37'),(2253,'/',NULL,NULL,'O95HSTUfQjPcH1BvoHGvkNi0tKIpIXrZYPPGdKjN',NULL,NULL,'desktop','Other','2026-08-09 20:46:16'),(2254,'/',NULL,NULL,'i19URZTMsaPXtslO8Rx5B9KGGpYjEqHBnHzIcsal',NULL,NULL,'desktop','Other','2026-08-09 21:29:22'),(2255,'/',NULL,NULL,'0Q59f4LluiRiiJHN8lj84GHmfUaP67H8zlmzyx12',NULL,NULL,'desktop','Other','2026-08-09 22:11:42'),(2256,'/',NULL,NULL,'H0vm3Z1f6peYBQWhVVxRVNBOUgrSQzD8enin0Gqj',NULL,NULL,'desktop','Other','2026-08-09 22:53:26'),(2257,'/',NULL,NULL,'wyqNctZvYd2CaUaSI9uYjciUDOMphY3aWtcwEjZu',NULL,NULL,'desktop','Other','2026-08-09 23:36:23'),(2258,'/',NULL,NULL,'6POIsUdL8YB1xA9JZpwT8a0PvbJeGAStNCrgafct',NULL,NULL,'desktop','Other','2026-08-10 00:19:23'),(2259,'/',NULL,NULL,'FBVpYACNkw73ZesDhGaCV4mRSi2qHbBXj3MW9cal',NULL,NULL,'desktop','Other','2026-08-10 01:01:23'),(2260,'/',NULL,NULL,'qf0vDmVY60B6zaYB4fiuSSsDTaBM6JVX9INzqUUZ',NULL,NULL,'desktop','Other','2026-08-10 01:45:57'),(2261,'login',NULL,'https://safhenokhost.ir/admin/posts','urKmQ2BwcGZtYgqJNo5iBTlfspdF9cd6aafucsMS',NULL,NULL,'desktop','Firefox','2026-08-10 02:02:11'),(2262,'/',NULL,NULL,'gYwqpiDe9WkXbdInkok1vuRoK4cJRwq6i45aDYcM',NULL,NULL,'desktop','Other','2026-08-10 02:30:38'),(2263,'/',NULL,NULL,'CawuJrfWXIoqUoloQBKmoZgwcoixnyJMRWBA8CKJ',NULL,NULL,'desktop','Other','2026-08-10 03:14:31'),(2264,'/',NULL,NULL,'QLJB8RZf3UiZZpGLHggH80HciXbyeZTg1aXLgY3w',NULL,NULL,'desktop','Chrome','2026-08-10 03:43:08'),(2265,'/',NULL,NULL,'56LUGHW7wh9HKSYVexaYQaZfeAiuI4RXZ24PpoaD',NULL,NULL,'desktop','Other','2026-08-10 03:58:01'),(2266,'/',NULL,NULL,'Xek1V63KWLL373xoQofcU6P8Y7BqBxj028ZB2XWr',NULL,NULL,'desktop','Other','2026-08-10 04:43:21'),(2267,'/',NULL,NULL,'baQD5V6Rje8aFG0s1N178PUBZmoSuZCyOSs9HPxs',NULL,NULL,'desktop','Other','2026-08-10 05:27:35'),(2268,'/',NULL,'http://safhenokhost.ir/','rCqLiJ4X1Onw594bVKfgSlheB2jixUdHX6EH4DQr',NULL,NULL,'mobile','Safari','2026-08-10 05:35:03'),(2269,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'gmZxYH3dR3IMcvSIrDxrQmJ4EzsHxjxMaLIxRtfG',NULL,NULL,'mobile','Safari','2026-08-10 05:35:04'),(2270,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'UEn5fqsvNMVjtThTooUVpsDpZoBzVwGx2TRBo4Lp',NULL,NULL,'mobile','Safari','2026-08-10 05:35:05'),(2271,'blog/sayt-hmh-karh',NULL,NULL,'xP3AHTZ9onKHiXH1BsDlwNs8bePhP0QhXOfeWsPz',NULL,NULL,'mobile','Safari','2026-08-10 05:35:06'),(2272,'/',NULL,NULL,'fFgilY4r7zf4xXTGmBI2ivFUcK1L0qF2kneMn2Ei',NULL,NULL,'desktop','Other','2026-08-10 06:12:07'),(2273,'/',NULL,NULL,'c4efBEySaElCQ3XiZBuuxPkDMlzrqT0jCd4DRjA4',NULL,NULL,'desktop','Other','2026-08-10 06:56:04'),(2274,'/',NULL,NULL,'COVulDyDccAG7IxmKMk4LgS27dmqJcRA65obh9vd',NULL,NULL,'desktop','Other','2026-08-10 07:40:25'),(2275,'/',NULL,NULL,'1yMcdidRarfMzvbUCjz2BEL5LJ6gNiQ3BcwV8e5u',NULL,NULL,'desktop','Firefox','2026-08-10 07:48:35'),(2276,'/',NULL,NULL,'ErzZqQ5Dbru5yJQGU270uCeTQl3WBCzzD3d3gyF5',NULL,NULL,'desktop','Chrome','2026-08-10 08:00:13'),(2277,'/',NULL,NULL,'1ENF3p8IRzrfZAP7Ii7UYQgHe74Siz4ibkkD5K6v',NULL,NULL,'desktop','Other','2026-08-10 08:24:55'),(2278,'/',NULL,NULL,'2qutDqUlb8szZj6WpXQn9PW7tPNMbLQhKqwrZJYZ',NULL,NULL,'desktop','Other','2026-08-10 09:09:13'),(2279,'/',NULL,NULL,'vEpTb395HFX08JFrwHrL6Rn6aywc9akDCtSHw2Xb',NULL,NULL,'desktop','Other','2026-08-10 09:54:04'),(2280,'/',NULL,NULL,'vsNrEkuInUHOuTKY0pegZK3XNwmu9c0VNIPla7CC',NULL,NULL,'mobile','Chrome','2026-08-10 10:38:23'),(2281,'/',NULL,NULL,'enaf7O8kznxV3E33O8XGK2mobLdQKnfoaWPlCg4f',NULL,NULL,'desktop','Other','2026-08-10 10:38:50'),(2282,'/',NULL,NULL,'ZUDdwBJ4nblFuoerFfaNjyCuqs9s5hy8Mdnroo0U',NULL,NULL,'mobile','Chrome','2026-08-10 10:39:27'),(2283,'/',NULL,NULL,'Dik1cy3UA6PWRARl3l3gHW8CmzongBxQslQDblWh',NULL,NULL,'desktop','Other','2026-08-10 10:39:27'),(2284,'/',NULL,'https://safhenokhost.ir','LmcUin7jMo5kOYZ4NkCWWQoQ1MajtgD1b7gXaojW',NULL,NULL,'desktop','Safari','2026-08-10 10:43:17'),(2285,'/',NULL,NULL,'g6wTedQuLse8bOpembX8pNcvBLYp7adjlNBTFivW',NULL,NULL,'desktop','Other','2026-08-10 11:23:00'),(2286,'/',NULL,NULL,'kbOHtkcTwbgcAUBuW8dpt04mS93x1hjV5lJvoEZC',NULL,NULL,'desktop','Other','2026-08-10 12:06:45'),(2287,'/',NULL,NULL,'BQ4l8N4VesXxlNqHX9XoPJsDPZkdZ1AlHMoJthnq',NULL,NULL,'desktop','Other','2026-08-10 12:50:14'),(2288,'/',NULL,NULL,'29Coyhvn4HCRSmGWRU1Cx49vmrzwFPR66bVvlqDG',NULL,NULL,'desktop','Other','2026-08-10 13:33:29'),(2289,'/',NULL,NULL,'knlKZaNWcfAkv4T5jjerSGrCAB0zI9aCCRZRm1HP',NULL,NULL,'desktop','Other','2026-08-10 14:17:25'),(2290,'/',NULL,NULL,'p4J6amw37cj64UFhUS8D7585qogVqfVxiE42Aw3w',NULL,NULL,'desktop','Other','2026-08-10 15:00:21'),(2291,'/',NULL,NULL,'AJ3HfhMBjoZ7INb8ErtAOKgGdbDrTGb9U8c6XdH4',NULL,NULL,'desktop','Other','2026-08-10 15:45:33'),(2292,'/',NULL,NULL,'ql4guXqdyFpRHSHiKM2R3ppHthjtBVSTYhxzXYYz',NULL,NULL,'desktop','Other','2026-08-10 16:29:36'),(2293,'/',NULL,NULL,'hhr2hgK7hF4EPScMXLKgnw3jbBv8DFeQgTCLz0As',NULL,NULL,'desktop','Other','2026-08-10 17:13:41'),(2294,'/',NULL,NULL,'TEfx5Z5pJ2vPQMTtMjPgqAv0YnaREpu9kKfHsVJd',NULL,NULL,'desktop','Other','2026-08-10 17:57:52'),(2295,'/',NULL,NULL,'DbeCshS2dcoC4296emYptg8gcN5VRHdKMum1m8Co',NULL,NULL,'desktop','Other','2026-08-10 18:42:12'),(2296,'/',NULL,NULL,'JCvgOjCmYGzqg1zuJutqVJj7VMi9P9uWQK0l0drA',NULL,NULL,'desktop','Other','2026-08-10 19:26:21'),(2297,'/',NULL,NULL,'xbY90tbAgVL979eV8PHC83KwPQIRsHfOv1HPIYTk',NULL,NULL,'desktop','Other','2026-08-10 20:09:06'),(2298,'/',NULL,NULL,'pcZ1dQGAUgQ5NqvNHUWeCXFZ6pnmAAJr28mzFxVv',NULL,NULL,'desktop','Other','2026-08-10 20:51:49'),(2299,'/',NULL,NULL,'ORMsvLMT0PkpMs0uXbYMdGVxDaBVZW0o8uSP4lQ3',NULL,NULL,'desktop','Other','2026-08-10 21:35:40'),(2300,'/',NULL,NULL,'YkiesBiOC7q8tUGpNtRd7uVkfz0hmtOdH0UYnx7l',NULL,NULL,'desktop','Other','2026-08-10 22:18:54'),(2301,'/',NULL,NULL,'xIYyJtu4A6gpMhh98lp9WggfbceXcIlTyIYXE9Id',NULL,NULL,'desktop','Other','2026-08-10 23:02:16'),(2302,'/',NULL,NULL,'wYUzXw6oyFFqZEUHY2EPTP8jh0u3yfUc8Lpsf3cf',NULL,NULL,'desktop','Other','2026-08-10 23:45:14'),(2303,'/',NULL,NULL,'LgHwRHWYOIaPocI69cYL2xDlR979LDjg62nVd7of',NULL,NULL,'desktop','Other','2026-08-11 00:28:22'),(2304,'/',NULL,NULL,'jDRrCLzeyVNOlF9WxupXn7EGfxXk8VkaLMnlgleM',NULL,NULL,'desktop','Other','2026-08-11 01:11:35'),(2305,'/',NULL,NULL,'WaSv6PeCmu67w7xDSO4SLr4jRWciEjTMdiiyPCyx',NULL,NULL,'desktop','Other','2026-08-11 01:56:07'),(2306,'/',NULL,NULL,'EAQqE8lmgbZNXfqOHPODeFzwpwL2dVgJGh3GWU2b',NULL,NULL,'desktop','Other','2026-08-11 02:41:20'),(2307,'/',NULL,NULL,'gkE4El2ngQ3kQQPM9TY4puOTovU2kLIjPMunax3g',NULL,NULL,'desktop','Chrome','2026-08-11 02:42:20'),(2308,'/',NULL,'http://safhenokhost.ir','mBJ30z9SzWEZR68huvbdvHvtuuQyW5NPPnIvCusY',NULL,NULL,'desktop','Chrome','2026-08-11 02:42:21'),(2309,'/',NULL,NULL,'wglKP4z6pk6mIH5d0EHLxA6mNy98riw77wksMb9D',NULL,NULL,'mobile','Chrome','2026-08-11 03:21:22'),(2310,'/',NULL,NULL,'l6oKxwbgi5YTBxmFu3yLei59N0Sgd2WiZMzOxOHG',NULL,NULL,'desktop','Other','2026-08-11 03:25:30'),(2311,'/',NULL,NULL,'wJD9nxscjcAJYYgUdEOfBjhdBMt8RoiBpk2WbRGL',NULL,NULL,'desktop','Other','2026-08-11 04:09:23'),(2312,'/',NULL,NULL,'FleEjINXLV9mlWMiDO2UJ9FpeHyPkgB4erMmQBx8',NULL,NULL,'desktop','Other','2026-08-11 04:35:45'),(2313,'/',NULL,NULL,'kgTAiODM74fA1MKk3Ltk5DG6HA4aiB5TIas0VYR1',NULL,NULL,'desktop','Other','2026-08-11 04:53:44'),(2314,'/',NULL,NULL,'XXjGKdKqCP5cntfHeHJX9VbcuY6vYfHJqwRmJGb0',NULL,NULL,'desktop','Other','2026-08-11 05:38:38'),(2315,'/',NULL,NULL,'v836tsjbcdZvArDZK6Xwsxz9R3CEtWmSwGAmD3le',NULL,NULL,'desktop','Other','2026-08-11 06:22:45'),(2316,'login',NULL,NULL,'TMEj7ITK4BhCvxkul3PrSSCGhB1MUrpLstr9NPOS',NULL,NULL,'desktop','Firefox','2026-08-11 07:05:27'),(2317,'/',NULL,NULL,'V3IN6gmU1ToU6CDFnFP20STetJ4ttG2gQX0rW4kQ',1,NULL,'desktop','Firefox','2026-08-11 07:05:49'),(2318,'/',NULL,NULL,'S0S5ztIU4DWyohcLG3Lrf1komfgos9gKGYrn4V6H',NULL,NULL,'desktop','Other','2026-08-11 07:06:03'),(2319,'login',NULL,'https://safhenokhost.ir/admin/dashboard','V3IN6gmU1ToU6CDFnFP20STetJ4ttG2gQX0rW4kQ',1,NULL,'desktop','Firefox','2026-08-11 07:06:41'),(2320,'/',NULL,NULL,'eVTIb1KdaMoJPZE2kLf15wdSaLuIUmXwDUJYWTt3',NULL,NULL,'desktop','Chrome','2026-08-11 07:22:08'),(2321,'/',NULL,NULL,'4S8M7WPdI1NzJ38rL806u43ow20a3qJo3zFMNkBm',NULL,NULL,'desktop','Other','2026-08-11 08:34:11'),(2322,'/',NULL,NULL,'FBLjdsEGEsgGYezbmxpFPLxlMAvF1sex4C3kaLbz',NULL,NULL,'desktop','Other','2026-08-11 09:18:07'),(2323,'login',NULL,'https://safhenokhost.ir/admin/profile','V3IN6gmU1ToU6CDFnFP20STetJ4ttG2gQX0rW4kQ',1,NULL,'desktop','Firefox','2026-08-11 09:24:31'),(2324,'/',NULL,NULL,'g3LrDIrS1bi6GOwL5mHcqjy7ubBZRdiMbAhyXKGP',NULL,NULL,'desktop','Other','2026-08-11 10:02:13'),(2325,'/',NULL,NULL,'iint3jyjfnFMHeKGDOuemuTPr0fN67n22BxJN16b',NULL,NULL,'mobile','Chrome','2026-08-11 10:13:06'),(2326,'login',NULL,NULL,'iint3jyjfnFMHeKGDOuemuTPr0fN67n22BxJN16b',NULL,NULL,'mobile','Chrome','2026-08-11 10:13:17'),(2327,'login',NULL,'https://safhenokhost.ir/admin/dashboard','tYiVXnfKwUHg1CiCXOzPwDwJeRnUiE6yYS69ryKr',1,NULL,'mobile','Chrome','2026-08-11 10:13:29'),(2328,'/',NULL,'https://safhenokhost.ir/admin/dashboard','8Kqq5Ruj6TZ0cckeENuVi9oTPxFZp6wpDU9arvaN',NULL,NULL,'mobile','Chrome','2026-08-11 10:17:14'),(2329,'/',NULL,NULL,'0xMfM9J1WLbfmXNkDghbD4Q1lMDctqHj1suZjLOK',NULL,NULL,'desktop','Other','2026-08-11 10:47:22'),(2330,'/',NULL,NULL,'jWu6LC3TvBHMuHLvMfYUa8eXszMLuXEbnJOYz2Dj',NULL,NULL,'desktop','Other','2026-08-11 11:27:32'),(2331,'/',NULL,NULL,'9xBzMN7NzfHpekXtBRVwV5FWgeqbjehybhMYsscI',NULL,NULL,'desktop','Other','2026-08-11 11:31:11'),(2332,'/',NULL,NULL,'5BD4uYjDfsH5PFYO56liSOv7JKqlSqYru3xVPR3o',NULL,NULL,'desktop','Other','2026-08-11 12:14:29'),(2333,'/',NULL,NULL,'xHb3Go0esabbBaIvfN2tW6EMPrkKz6B9g8BvhRjH',NULL,NULL,'desktop','Other','2026-08-11 12:57:17'),(2334,'/',NULL,NULL,'TuWXcDad4puoJWoGkLECXAzl7GOqFzeumTpUWYKW',NULL,NULL,'desktop','Other','2026-08-11 13:41:05'),(2335,'/',NULL,NULL,'rEOoQhfAkqCvslIDUTyPyWdosOHKsk0xeM9ktEXH',NULL,NULL,'desktop','Other','2026-08-11 14:23:46'),(2336,'/',NULL,NULL,'CVr7z5pnf7Ppt3PDnLoXF8o6h8mfZsKfabvtqnAs',NULL,NULL,'desktop','Other','2026-08-11 15:07:02'),(2337,'/',NULL,NULL,'8JrRUhxUNF7hTDbWgZGOvHIZFGzEDFol9bCiLgoR',NULL,NULL,'desktop','Other','2026-08-11 15:51:00'),(2338,'/',NULL,NULL,'534eNjRi8913QwCCUxXeVm3lsbTuXJFwG5DIQRPJ',NULL,NULL,'desktop','Other','2026-08-11 16:33:55'),(2339,'login',NULL,'https://safhenokhost.ir/admin/dashboard','V3IN6gmU1ToU6CDFnFP20STetJ4ttG2gQX0rW4kQ',1,NULL,'desktop','Firefox','2026-08-11 16:50:44'),(2340,'/',NULL,NULL,'MPMChlPmMfEnmGmvGQDoV31TrkSdJzgYvHw6qcNO',NULL,NULL,'desktop','Other','2026-08-11 17:16:55'),(2341,'/',NULL,NULL,'4wfYSLriCkUrpvlblmK7rQA12tbIi66FOFCjsDfK',NULL,NULL,'desktop','Other','2026-08-11 17:59:53'),(2342,'/',NULL,NULL,'eOj0QHcOldDzYy4kX98vmTJjHK1siOA4YH7uIk9N',NULL,NULL,'desktop','Firefox','2026-08-11 18:31:54'),(2343,'/',NULL,NULL,'O60Kr2O0sfvUnUbN03cAQQLHxTn3tMYhyeRotxCQ',NULL,NULL,'desktop','Other','2026-08-11 18:44:01'),(2344,'/',NULL,NULL,'1POXlpbKFg2dot8XWAQEltrwJTfBj8IfUXBOlHsX',NULL,NULL,'desktop','Other','2026-08-11 19:27:21'),(2345,'/',NULL,NULL,'wWxAuN6OPLYSVScHTx8T6ntg02VFSg05XXmHAe3e',NULL,NULL,'desktop','Other','2026-08-11 20:09:40'),(2346,'/',NULL,NULL,'aafrV0ZYHIYfKTSh5P7CkEVkdxkn8NgAhBFaDTL8',NULL,NULL,'desktop','Other','2026-08-11 20:52:06'),(2347,'/',NULL,NULL,'zIolfUzPAsUVZG7nzYczUR21U144xjaJVqSfT0Gr',NULL,NULL,'desktop','Other','2026-08-11 21:35:13'),(2348,'/',NULL,NULL,'znEzQsAU8CCjy0qeoX0hh5pBBirPoxbBWbkaVx39',NULL,NULL,'desktop','Other','2026-08-11 22:17:55'),(2349,'/',NULL,NULL,'ZXUUe2tiX71GVpXaUesuD7GHD4OmpLJEgMPnONzn',NULL,NULL,'desktop','Other','2026-08-11 22:59:55'),(2350,'/',NULL,NULL,'sQj2ASF1BfjLanLFaBsvdWnrKnPA56O3WIKFUpyQ',NULL,NULL,'desktop','Other','2026-08-11 23:42:38'),(2351,'/',NULL,NULL,'QRFLW7ZltfbZzEmIdTxYij8YwZ3uGugoqeLn6lZ0',NULL,NULL,'desktop','Other','2026-08-12 00:24:52'),(2352,'/',NULL,NULL,'V6NfMUBeSjkA335OMI4TWgzRTpmjiGrm1i2SkajD',NULL,NULL,'desktop','Other','2026-08-12 01:06:55'),(2353,'/',NULL,NULL,'ydjsMQcrgebgmcV5KRma3ffvtFLnAJ1zNHwmWCFZ',NULL,NULL,'desktop','Other','2026-08-12 01:52:14'),(2354,'/',NULL,NULL,'eAiOSnGfSAa1R6Rt4SrsG6WSpNCAh6jRkKctsgn8',NULL,NULL,'desktop','Other','2026-08-12 02:35:33'),(2355,'/',NULL,NULL,'90TluSWQM50xkgKZWQUntiRJd4JnroFWCzGD856z',NULL,NULL,'desktop','Other','2026-08-12 03:18:56'),(2356,'/',NULL,NULL,'Rpely9dT8nuX7Qm3yR6uP46WLJOIeCGBZkiWyqqR',NULL,NULL,'desktop','Chrome','2026-08-12 03:44:25'),(2357,'/',NULL,NULL,'M5gDdWX1dbvW3nI2zXOvmjSGjgTgMOEUNQGWL3NL',NULL,NULL,'desktop','Other','2026-08-12 04:01:56'),(2358,'/',NULL,NULL,'ovm6rdsEBAhqiOwYav5pfQ6yVxZ5FfpYv13BVk9K',NULL,NULL,'desktop','Other','2026-08-12 04:02:20'),(2359,'/',NULL,NULL,'DOCDC5KK2WNg3sB5sOLqI6ceeoxabbIbxh6AtPlS',NULL,NULL,'desktop','Other','2026-08-12 04:46:26'),(2360,'/',NULL,NULL,'PfOtbKCodCwYv50ErVF2AhHlkkTRqjyRGgMvoXnO',NULL,NULL,'desktop','Other','2026-08-12 05:30:00'),(2361,'/',NULL,'https://safhenokhost.ir/','O4TI4AHHb6AylGaWvEBuduf2efOG36KzTK5EtWoa',NULL,NULL,'desktop','Other','2026-08-12 06:07:06'),(2362,'/',NULL,NULL,'6Rk3Z2htH1MlFb8XHvimnYFVu4nsl3zUfS82oe8O',NULL,NULL,'desktop','Other','2026-08-12 06:12:51'),(2363,'/',NULL,NULL,'EKlfWVxlwAeG7CryVNQfnLEicdXtO7njjb9EFbR2',NULL,NULL,'desktop','Other','2026-08-12 06:56:24'),(2364,'/',NULL,NULL,'giffZaugbvWJOfhM5AKJIJySvEOVxpJwETkcTGSu',NULL,NULL,'desktop','Other','2026-08-12 07:40:30'),(2365,'/',NULL,NULL,'VHk1U6K79rfapuNf6KeSZuR3r1k2HlBATXRRgC88',NULL,NULL,'desktop','Chrome','2026-08-12 08:23:15'),(2366,'/',NULL,NULL,'TL7onZmyYC4awcrbvqZKDSdkYKbNNUBpw8S04X90',NULL,NULL,'desktop','Other','2026-08-12 08:24:04'),(2367,'/',NULL,'http://safhenokhost.ir/','v2WSnmYGDpU04m2aBFa6A7TOtClVziHKm67Bv0hy',NULL,NULL,'mobile','Safari','2026-08-12 08:49:37'),(2368,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'eGOcnmtmoFy0BYUVjcUTDq1DAlWCdzUCvTjdFZhZ',NULL,NULL,'mobile','Safari','2026-08-12 08:49:38'),(2369,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'iDj4fHd6WyblsM8X3Wuv3MqIh7cBaKTXbPNkz3Eg',NULL,NULL,'mobile','Safari','2026-08-12 08:49:38'),(2370,'blog/sayt-hmh-karh',NULL,NULL,'qr5EM3bCy7YKjyV26xDCeRrWIlDV07neTa2MUbnZ',NULL,NULL,'mobile','Safari','2026-08-12 08:49:39'),(2371,'/',NULL,NULL,'hATQAuK5Ye1TBYA6SRZlclISecFHqceUn9lE01JK',NULL,NULL,'desktop','Other','2026-08-12 09:07:32'),(2372,'/',NULL,NULL,'D4VXBfYCLRpXZp6xDEIULIvA1xycVWcgNKAIJIU5',NULL,NULL,'desktop','Other','2026-08-12 09:51:52'),(2373,'/',NULL,NULL,'vbbqaCjIkzaOegZUhkUuWmd2Q9ERv4Fo8poNglqx',NULL,NULL,'desktop','Other','2026-08-12 10:35:41'),(2374,'/',NULL,NULL,'DrFheDKEdyQ2Sg1JgfHCHIJ2ghx3INMNxzSLJj87',NULL,NULL,'desktop','Other','2026-08-12 11:18:29'),(2375,'/',NULL,NULL,'OArgVo3h8gnkkVShazCYianpNeN9cuOPUQImjeaI',NULL,NULL,'desktop','Other','2026-08-12 12:01:06'),(2376,'/',NULL,NULL,'YM6Iqvui3xga6GgHu1SFPzbFsPkMIAHgj8DEzVwM',NULL,NULL,'desktop','Other','2026-08-12 12:44:46'),(2377,'/',NULL,NULL,'Y4byOMG33agBEWaut50lkxZgHrcT66835dcTUo0r',NULL,NULL,'desktop','Other','2026-08-12 13:20:06'),(2378,'/',NULL,NULL,'Qg7vc7j5ta9OQ8R9KaHqTxldM3eUV4er10coYgPj',NULL,NULL,'desktop','Other','2026-08-12 13:27:59'),(2379,'/',NULL,NULL,'mk5R6bmBy1sVTg46V4ZzScXEYfyk1lbYuwBhYy1L',NULL,NULL,'desktop','Other','2026-08-12 14:10:21'),(2380,'/',NULL,NULL,'3BJN7ZVXblYA0mxLEmIHrmBegrYSyMBRRvil7hDj',NULL,NULL,'mobile','Chrome','2026-08-12 14:44:41'),(2381,'blog',NULL,'https://safhenokhost.ir/','3BJN7ZVXblYA0mxLEmIHrmBegrYSyMBRRvil7hDj',NULL,NULL,'mobile','Chrome','2026-08-12 14:44:50'),(2382,'/',NULL,NULL,'g0qshSpafgozmiFcyPbjBGrMW2tpC9pPH3xtYFSE',NULL,NULL,'desktop','Other','2026-08-12 14:53:39'),(2383,'/',NULL,'https://safhenokhost.ir/?rest_route=%2Fjetpack%2Fv4%2Fsync%2Fstatus&_for=jetpack&token=uThbNbe%21qJyhj8YyhV13%28O%26uLR3Ka6%28f%3A1%3A0&timestamp=1786559588&nonce=ibuB4lp526&body-hash&signature=trbufkZuSObLXl%2BBVMRDJEUe7YA%3D','NKXrGHzVmYFLo5zdF267kBriDFxO0yj9pCeQGHPu',NULL,NULL,'desktop','Other','2026-08-12 15:03:10'),(2384,'/',NULL,NULL,'Ha98RSOJS0qQO5i9C8BiZCn3zjhNSqnZCDeXzJQ3',NULL,NULL,'desktop','Other','2026-08-12 15:37:13'),(2385,'/',NULL,NULL,'xA19USoYKkDkdY7LdVrxbQgFxrx9z8dXuQVyrNcE',NULL,NULL,'desktop','Other','2026-08-12 16:20:25'),(2386,'/',NULL,NULL,'b7DHheoxvqNAa3oizQkdTCc8yrw3EBbQ8wVkXfMa',NULL,NULL,'desktop','Other','2026-08-12 17:03:02'),(2387,'/',NULL,NULL,'S68NUmsodcZFjYOHuVgxlaPmYhvD1tivFmPzedJu',NULL,NULL,'desktop','Other','2026-08-12 17:47:23'),(2388,'/',NULL,NULL,'NbcG1b4fJ8GnuODs7OimT60a1RGyGOEYglGfhVsH',NULL,NULL,'desktop','Other','2026-08-12 18:31:20'),(2389,'/',NULL,NULL,'IofCW4R0zLS57YSZhdUAXIFvkPzpB3pG8He8Vfjz',NULL,NULL,'desktop','Other','2026-08-12 19:14:11'),(2390,'/',NULL,NULL,'r1Pu7rdAx9LDNCX6Z0GnkXqdC8mdJeaO7Ee3416L',NULL,NULL,'desktop','Other','2026-08-12 19:57:03'),(2391,'/',NULL,NULL,'kRhGq1uJhc7goT8Fw3cekD63GtdzFjR4A2faCeHP',NULL,NULL,'desktop','Other','2026-08-12 20:40:56'),(2392,'/',NULL,NULL,'9a5eDX486ZHVsdPmdSfJqZVOL0K3EUMBIhCmD0tN',NULL,NULL,'desktop','Other','2026-08-12 21:24:11'),(2393,'/',NULL,NULL,'goAk3Q4RsQMkBy4NGItCH52fodpdQjiqTHADeO5d',NULL,NULL,'desktop','Chrome','2026-08-12 21:24:43'),(2394,'/',NULL,NULL,'cgnAaW0XSZI1TzA6sz79CEXvDZyvLnOKPnxmN6WI',NULL,NULL,'desktop','Other','2026-08-12 22:07:10'),(2395,'/',NULL,NULL,'wvB4pP3Ax32bXuYlouC8njDgbwtwOasyHWG2qYfn',NULL,NULL,'desktop','Other','2026-08-12 22:50:24'),(2396,'/',NULL,NULL,'HUGOYHO8ITRKEyAcQ3dMWSwXNtyw28uGOgniIjdP',NULL,NULL,'desktop','Other','2026-08-12 23:32:32'),(2397,'/',NULL,'https://www.google.com/','vzciP8HPQXD0yURvnYDHM1YAKduW02zxPJNBeZFq',NULL,NULL,'desktop','Chrome','2026-08-12 23:34:59'),(2398,'/',NULL,NULL,'VZ8jiC7OPjdhokcNXCVI9bYTo0P5rcvHaLfMUi8E',NULL,NULL,'desktop','Other','2026-08-13 00:14:00'),(2399,'/',NULL,NULL,'XEYQ1ZGzscVTNia6RTwqrSCF61rYI2NYyww6AnIK',NULL,NULL,'desktop','Other','2026-08-13 00:55:51'),(2400,'/',NULL,NULL,'u4MJ1WifPPSbzXhaIChyIb744D6SAcEfO9Zz0c12',NULL,NULL,'desktop','Other','2026-08-13 01:39:34'),(2401,'/',NULL,NULL,'Dq67AsyfYkU9bDce5i1mzgmfEJXAegQC3cu1eG3F',NULL,NULL,'desktop','Other','2026-08-13 02:22:58'),(2402,'/',NULL,'https://safhenokhost.ir','AlkGcYK5LEWsdXjtnf7GPMhsI1LBxfUK6oz9bOLq',NULL,NULL,'desktop','Firefox','2026-08-13 02:30:10'),(2403,'/',NULL,NULL,'pK29gMNu1NWRA4ehoKFFz9VBQ9xXTUsjxYUv2LKC',NULL,NULL,'desktop','Other','2026-08-13 03:05:15'),(2404,'/',NULL,NULL,'Ztg9bvAO5HUQ8xDQVOmuKbitKuDrDDUIIrshQ4v6',NULL,NULL,'desktop','Other','2026-08-13 03:47:51'),(2405,'/',NULL,NULL,'0HtD59gOoD7rzEgjMCnFaIOAL7O262imKi8o3tv9',NULL,NULL,'desktop','Other','2026-08-13 04:31:21'),(2406,'/',NULL,NULL,'QT6A1dAOHjCoNY5RQtMHSj7ZNbXlUsi3kgn4h2Pl',NULL,NULL,'desktop','Chrome','2026-08-13 04:50:00'),(2407,'/',NULL,NULL,'2w0w8QlSqbuBUaZOJ80oA2pvptxzzpVtB5uQmPxd',NULL,NULL,'desktop','Other','2026-08-13 05:15:07'),(2408,'/',NULL,NULL,'62EU4Bt9Gc7VfrHngV8K4pTdpvQ6eZi78evcMotO',NULL,NULL,'desktop','Other','2026-08-13 05:58:46'),(2409,'/',NULL,NULL,'vn2SVfFQZWiykD4UNVZIduargbdTggnhBzHnwEtn',NULL,NULL,'desktop','Other','2026-08-13 06:43:32'),(2410,'/',NULL,NULL,'REhKwhBxNjSx5OlXSQpCLuGsma86UFxnRQi9ZFQc',NULL,NULL,'desktop','Other','2026-08-13 07:26:59'),(2411,'/',NULL,NULL,'Gl5la2J2Q4MxQOZL0NYNGgdvFg9T2HMLAwn89rV7',NULL,NULL,'desktop','Other','2026-08-13 08:09:58'),(2412,'/',NULL,NULL,'ixwpbFDr7zs6iC88mP7NN4n9G2kep063Kwv1Isiu',NULL,NULL,'desktop','Other','2026-08-13 08:54:00'),(2413,'/',NULL,NULL,'CYKduQYsOG9so1ai9fZAoXVfBsiwecWPf0lna4s6',NULL,NULL,'desktop','Other','2026-08-13 09:38:12'),(2414,'/',NULL,NULL,'gqN57dZGDTcdWVZColDu5n3fXFOcwzrtSXxSoUji',NULL,NULL,'desktop','Other','2026-08-13 10:21:36'),(2415,'/',NULL,NULL,'RcKAMHe1aR7gjVCFM0jDyYUv9Z0fSUIlDsY2Cqaf',NULL,NULL,'desktop','Other','2026-08-13 11:04:58'),(2416,'/',NULL,NULL,'JREAfph3Jqpvx4Z719Bb2XoDnkku3BfzuQvfeEBU',NULL,NULL,'desktop','Other','2026-08-13 11:48:57'),(2417,'/',NULL,NULL,'5QueWZO9H35qIkWUXsbFuTLM08CgzKiK4DOcfH1T',NULL,NULL,'desktop','Other','2026-08-13 11:55:20'),(2418,'/',NULL,NULL,'eW18gilMAgzWz3U2sxLcHxTy0TIc3fOOejhba3U9',NULL,NULL,'desktop','Other','2026-08-13 11:55:30'),(2419,'/',NULL,NULL,'ZrFK9g7LXA3kZnWppMH4PPw2tVwCI8fPWEihktpb',NULL,NULL,'desktop','Other','2026-08-13 12:32:02'),(2420,'/',NULL,NULL,'fdzPufbcX0H6DwQ9HcVpIFHFHbph0xt99ksbewWr',NULL,NULL,'desktop','Other','2026-08-13 13:15:01'),(2421,'/',NULL,NULL,'rAwoSMaR7MRU0ZRNO1zNyAqCdwCsOTN0n2o0bQh5',NULL,NULL,'desktop','Other','2026-08-13 13:58:21'),(2422,'/',NULL,NULL,'4pzLU4irOLKEZGqrWlvpALeNrFMkQuSBQjFmY1t3',NULL,NULL,'desktop','Other','2026-08-13 14:36:11'),(2423,'/',NULL,NULL,'jWUcaIkjP0jAQ0r22u0ZGiXX5oazlNuy4v6cbXHL',NULL,NULL,'desktop','Other','2026-08-13 14:36:12'),(2424,'/',NULL,NULL,'gl4Lb6kX2HBifSQ8rDT56VHifOo4X8INGtSEmr03',NULL,NULL,'desktop','Other','2026-08-13 14:40:37'),(2425,'/',NULL,NULL,'s88foLbcm3GqrqZ2aD6aquyn4KpSBeo61wyms0bn',NULL,NULL,'desktop','Other','2026-08-13 14:42:06'),(2426,'/',NULL,NULL,'7XufPt0NhVggGRBJzzA85FazEGVGRh8QNakrujRn',NULL,NULL,'desktop','Other','2026-08-13 15:25:27'),(2427,'/',NULL,NULL,'d3dMLrEZBd1ZGk9uFTnV534D3Hz7RKmdz8Hjpven',NULL,NULL,'desktop','Other','2026-08-13 16:07:54'),(2428,'/',NULL,NULL,'j1EZYWBCSdWYJOohpdSwg87SZQIqmrRKkILwM7xt',NULL,NULL,'desktop','Other','2026-08-13 16:50:52'),(2429,'/',NULL,NULL,'PhIJtOqhj9sTRvEgFKCMZRdg5GUAEMshmLT4JmP9',NULL,NULL,'desktop','Other','2026-08-13 17:34:35'),(2430,'/',NULL,NULL,'Jte5thmBRgX1aoHDfjAjIyOmiVVYpUyDpae492hL',NULL,NULL,'desktop','Other','2026-08-13 18:17:25'),(2431,'/',NULL,NULL,'Fi5RnGhjaDN3n2vGzAhJnLYjwsTFHqfhq95s3pJc',NULL,NULL,'desktop','Other','2026-08-13 19:00:30'),(2432,'/',NULL,NULL,'rJ6uEfQ2C7KFXccz7pbua67T9F0brZVBOS7UHlCv',NULL,NULL,'desktop','Other','2026-08-13 19:43:43'),(2433,'/',NULL,NULL,'HdI4zrKZuJgednZi599zEMD2lhr62OX8N0KnxXT8',NULL,NULL,'desktop','Other','2026-08-13 20:27:08'),(2434,'/',NULL,NULL,'s177r5dHTzDKWvQKXi5FNCaLC2KP1e5gC91E5KfL',NULL,NULL,'desktop','Other','2026-08-13 21:09:22'),(2435,'/',NULL,NULL,'2ZhsFj3XbzWbG2IpHN8zALGF0vGsgwGAw7QClGLf',NULL,NULL,'desktop','Other','2026-08-13 21:53:29'),(2436,'/',NULL,NULL,'lRX8GSmsyc1KMkZ1k4S3irL9MrqamL2bsJbjR9M0',NULL,NULL,'desktop','Other','2026-08-13 22:36:40'),(2437,'/',NULL,NULL,'2uIaCqjOW4Eh4bd86O832r5wGFrlqjhLp0UeUX9O',NULL,NULL,'desktop','Other','2026-08-13 23:19:02'),(2438,'/',NULL,NULL,'NH6ocfjmykwpiA8S4TitOlxuTJ5cZ41j49GwefIz',NULL,NULL,'desktop','Other','2026-08-14 00:01:57'),(2439,'/',NULL,NULL,'kqBFhEVMfwaEtllSSE1CSfRyuZqZYatnXbi2tdHX',NULL,NULL,'desktop','Other','2026-08-14 00:44:28'),(2440,'/',NULL,NULL,'eTOUhfGvg1qHrYtN7X5haRXikacL24GbjcaBGajU',NULL,NULL,'desktop','Other','2026-08-14 01:27:14'),(2441,'/',NULL,NULL,'OxvT9AnFER3bfiZxVtk3McfcxkiHNgiGqXQmNEPt',NULL,NULL,'desktop','Other','2026-08-14 02:10:25'),(2442,'/',NULL,NULL,'SUeeu8CU94LRPTi4UnC5ClyedQQtgPLl4QqpBpzI',NULL,NULL,'desktop','Other','2026-08-14 02:53:55'),(2443,'/',NULL,NULL,'GsLicsCJHUrQospaurQXlbAXek0DBPA3P3MG7xbD',NULL,NULL,'desktop','Other','2026-08-14 03:36:35'),(2444,'/',NULL,NULL,'SaXDRL3OfnQAgZqMpgCGZZ9Wx95ziT1xjNPo3GJD',NULL,NULL,'desktop','Other','2026-08-14 04:19:24'),(2445,'/',NULL,NULL,'19zgF829IMzwMu5qQaNhvpGRaHYu1UsOM5V8gmta',NULL,NULL,'desktop','Other','2026-08-14 05:02:30'),(2446,'/',NULL,NULL,'Gzm4Mx9ztNNsPn7YbyQvCtiUzc3TbEtVcqcUF0F4',NULL,NULL,'desktop','Other','2026-08-14 05:46:03'),(2447,'/',NULL,NULL,'bn7yrh3l4vx1dXBVkqy5xp7iDytkSfmrNRECYoPL',NULL,NULL,'desktop','Other','2026-08-14 06:29:34'),(2448,'/',NULL,NULL,'mmhtNaRGJo5rCGKnGyXWz9kCZ9NLlBjPlo0WHSIh',NULL,NULL,'desktop','Other','2026-08-14 07:12:56'),(2449,'/',NULL,NULL,'tV7cgct5XFpXeQlilClfy8usxwnSR3dmzEqNTD99',NULL,NULL,'desktop','Other','2026-08-14 07:57:17'),(2450,'/',NULL,NULL,'BKihsVDHMHFf8y7IrzTgOMJfbULtspn3rc5tJg2U',NULL,NULL,'desktop','Other','2026-08-14 08:41:22'),(2451,'/',NULL,NULL,'JzEtLSNeM9Zg56edHtAaADuox07rEWGLxcbWQvBf',NULL,NULL,'desktop','Other','2026-08-14 09:25:30'),(2452,'/',NULL,NULL,'NGJCMKL0WZgpOY3qUnnMXzoCknq1Pyan22R44FyB',NULL,NULL,'desktop','Other','2026-08-14 10:09:04'),(2453,'/',NULL,NULL,'SXDiF5ENxbrdJMMpWHwNJmW1hk2xw49lq1nmcQiL',NULL,NULL,'desktop','Other','2026-08-14 10:53:03'),(2454,'/',NULL,NULL,'aWWHuJaBvIkUfHvPVUhV0QsTqcil9OcuVS34I3Xt',NULL,NULL,'desktop','Other','2026-08-14 11:36:07'),(2455,'/',NULL,NULL,'SJttF63zOZ9om5JQOFChYDFOcHLfLIJryCQdqVGC',NULL,NULL,'desktop','Other','2026-08-14 12:19:07'),(2456,'/',NULL,NULL,'jrDrdg3gUJ5OJYC4U3kbwzzTwMekuTAuMg8McDK3',NULL,NULL,'desktop','Other','2026-08-14 13:02:38'),(2457,'/',NULL,NULL,'2zhsIc1WLj5hihL7Q1v3AJnXoGHRr2fYB1tQNjBK',NULL,NULL,'desktop','Other','2026-08-14 13:45:48'),(2458,'/',NULL,NULL,'lssj5L2fZ4GIGGRy9NrEQ4zEES1LlE3iCoJAdemQ',NULL,NULL,'desktop','Other','2026-08-14 14:28:52'),(2459,'/',NULL,NULL,'dUS9nb2qGMLNrO4FUxilDbjcm5jsbTHTyAjxJGdi',NULL,NULL,'desktop','Other','2026-08-14 15:11:04'),(2460,'/',NULL,NULL,'H5465B7zvOuJYjFc8Klv8Qijg8xYvnDm761IkMEW',NULL,NULL,'desktop','Other','2026-08-14 15:55:11'),(2461,'/',NULL,NULL,'2CaA5jjMmDTBmU6soTG0B66t61wsLnSslMupFzFV',NULL,NULL,'desktop','Other','2026-08-14 16:38:10'),(2462,'/',NULL,NULL,'F8h18AgUECXdXkjMPEMgJzRcbvJTdGm3voKoD5wW',NULL,NULL,'desktop','Other','2026-08-14 17:21:09'),(2463,'/',NULL,NULL,'toLZdDPIN7bhO5ju5degpLgcJ1jn49YkdpMjyHpO',NULL,NULL,'desktop','Other','2026-08-14 18:04:17'),(2464,'/',NULL,NULL,'oGILBV3tLmdI1M4wptulJqoUV5iX019iOxjr7Gu7',NULL,NULL,'desktop','Other','2026-08-14 18:47:02'),(2465,'/',NULL,NULL,'lsIiHwWh9djFWofz1MZpS0U3dmowmkDDShw4NDXc',NULL,NULL,'desktop','Other','2026-08-14 19:29:47'),(2466,'/',NULL,NULL,'jDpdXKzLNlVzAGrPPAkQ1lEiP61uHadOQPMzFJ6b',NULL,NULL,'desktop','Other','2026-08-14 20:11:58'),(2467,'/',NULL,NULL,'jgTzd2m0P5H3eDuGycxjtmVeKzZrmR7YYi35U9cv',NULL,NULL,'desktop','Other','2026-08-14 20:54:54'),(2468,'/',NULL,NULL,'9wV5jwnfbXC4JCttXPUh36PdiImS3McSTb6bKztU',NULL,NULL,'desktop','Other','2026-08-14 21:38:01'),(2469,'/',NULL,NULL,'D49RGGvstOVNujrR7BLCFv5EVnrcYLDJUqwaX89x',NULL,NULL,'desktop','Other','2026-08-14 22:20:57'),(2470,'/',NULL,NULL,'nzkCFjs3oWYQCkjO1vs9b4T5nWJId86W0J1YwqL6',NULL,NULL,'desktop','Other','2026-08-14 23:03:40'),(2471,'/',NULL,NULL,'zdEONRRU50FAwi37GPyplDXLDLEFjoERTbaYeeGG',NULL,NULL,'desktop','Other','2026-08-14 23:46:09'),(2472,'/',NULL,NULL,'nu2UgoZYbonbxkgT5MyPzWg4lsLDs6vkguicW6x0',NULL,NULL,'desktop','Other','2026-08-15 00:28:23'),(2473,'/',NULL,NULL,'vr6pmfarBvPO2aMxyqnMCgze6mvFG8G414phnocx',NULL,NULL,'desktop','Other','2026-08-15 01:11:32'),(2474,'/',NULL,NULL,'09xmTtBImArjrPih51cmKNfJ89u9wHJKHZwfUnGH',NULL,NULL,'desktop','Other','2026-08-15 01:56:07'),(2475,'/',NULL,NULL,'ymovR3zIcXRClSpm027f4ugZOCJsQaHek9Ql2nfl',NULL,NULL,'desktop','Other','2026-08-15 02:39:50'),(2476,'/',NULL,NULL,'tN29WxhQx3D62k5ulFCWmi2mHPnpkN1epYdBRFQQ',NULL,NULL,'desktop','Other','2026-08-15 03:23:33'),(2477,'/',NULL,NULL,'g4mShmIGp4CgE9IT6fdrkc1bNTCPhwZ3YQXa9E4e',NULL,NULL,'desktop','Other','2026-08-15 04:07:41'),(2478,'/',NULL,NULL,'0fVh4PTAQWC8aUXR634vtGqtE6th2ntDWetvBbCt',NULL,NULL,'desktop','Other','2026-08-15 04:52:06'),(2479,'/',NULL,NULL,'LwH0my0nXacZMX1ToftZRVW8B89wXqn8hwoFYNDW',NULL,NULL,'desktop','Other','2026-08-15 05:36:18'),(2480,'/',NULL,'http://safhenokhost.ir/','dHc3y2xmLcyjadwjEvjzZRwHfyOm4jjrRyl8TpgR',NULL,NULL,'mobile','Safari','2026-08-15 06:14:28'),(2481,'/',NULL,NULL,'ObgDfcogcRhJWfRVUh7qUYsloJiwoJlTEx8CKkS4',NULL,NULL,'desktop','Other','2026-08-15 06:19:39'),(2482,'login',NULL,NULL,'gpWZgj90LRXytwZgxAl65djWP9TlmzgOj4lGlL2y',NULL,NULL,'desktop','Firefox','2026-08-15 06:52:56'),(2483,'login',NULL,'https://safhenokhost.ir/admin/dashboard','iSVr2HbV1Uq5f9SSGH69N9sgk1cPsZxHjvEFlr2X',1,NULL,'desktop','Firefox','2026-08-15 06:53:16'),(2484,'/',NULL,NULL,'PCaj0o7FQuQ1wfWA6Tb9DlyWHqDzvT1PHZgXX5YD',NULL,NULL,'desktop','Other','2026-08-15 07:03:50'),(2485,'/',NULL,NULL,'xCrOoner4OsWpP1CgyuoCTOJJ8m5JTmcnpARTsqH',NULL,NULL,'desktop','Other','2026-08-15 07:47:51'),(2486,'/',NULL,NULL,'1TSvv9f75nM4TSXLrAsQsUZ14tyVPOxjD3mLX7Xf',NULL,NULL,'desktop','Other','2026-08-15 08:31:39'),(2487,'/',NULL,NULL,'IoD6dPzdCJPX3rRi1czdp8YZX15PHFeOKi2Kgn0m',NULL,NULL,'desktop','Other','2026-08-15 09:15:24'),(2488,'/',NULL,NULL,'YOEPI3da0IgnuH4fZGnoAwdMMN4XGXZlmzwz2TRl',NULL,NULL,'desktop','Other','2026-08-15 09:59:39'),(2489,'login',NULL,'https://safhenokhost.ir/admin/dashboard','iSVr2HbV1Uq5f9SSGH69N9sgk1cPsZxHjvEFlr2X',1,NULL,'desktop','Firefox','2026-08-15 10:23:14'),(2490,'/',NULL,NULL,'lmWDrjzw6Rx4KrP9NKt2ikXQGq2jbA2m7QJl1qs4',NULL,NULL,'mobile','Safari','2026-08-15 10:29:48'),(2491,'/',NULL,NULL,'P6C5FJxNs9iplyvcCxPvZrAssvxB9W849wornLmd',NULL,NULL,'desktop','Other','2026-08-15 10:43:25'),(2492,'/',NULL,NULL,'603u1CcDwf5mmFj59RUruXxMC06gle75IxWbkW1I',NULL,NULL,'desktop','Other','2026-08-15 11:26:34'),(2493,'/',NULL,NULL,'I1FfJPHojksU2PaaRl3pRuMjwgjWGV3CMETT1XxS',NULL,NULL,'desktop','Other','2026-08-15 12:10:10'),(2494,'/',NULL,NULL,'d8mG2gzUWd4uCzzRNPsxn2JwJrZvkagiKVdLamgj',NULL,NULL,'desktop','Other','2026-08-15 12:53:23'),(2495,'/',NULL,NULL,'R8RsO0uYlPI0Oca8tEWCDNjDPa0hWlTfAXpeqP1b',NULL,NULL,'desktop','Other','2026-08-15 13:35:53'),(2496,'/',NULL,NULL,'0nALzcjcw4PjK0JgWnRGVVFCCvWUbVWXIQBlJEsl',NULL,NULL,'desktop','Other','2026-08-15 14:19:17'),(2497,'/',NULL,NULL,'bAjjDZPiyJPMSLzNtMAczDGgOiWZkRmr4mEOATBP',NULL,NULL,'desktop','Other','2026-08-15 15:03:02'),(2498,'/',NULL,NULL,'5JoH2spVoUdoEbctaeEqdENCmaz5JEDENzpk4CrE',NULL,NULL,'desktop','Other','2026-08-15 15:46:44'),(2499,'/',NULL,NULL,'1x35X9lAgNw7RJV2ZjnNSbgQmFbnpGMuDaTVEAEN',NULL,NULL,'desktop','Other','2026-08-15 16:29:40'),(2500,'/',NULL,NULL,'ZLeSS00W7ZLCyic42GTEeNfMS8mcrBULQKEQ7xwz',NULL,NULL,'desktop','Other','2026-08-15 17:12:43'),(2501,'/',NULL,NULL,'Mg3qEYKrku159kUIWKH6PcAalQ8w6yoYy4deZj5l',NULL,NULL,'desktop','Other','2026-08-15 17:56:01'),(2502,'/',NULL,NULL,'wRZueC2hW7xHHUhksXdl8CUyLSsaWPrfC9HzbIYZ',NULL,NULL,'desktop','Other','2026-08-15 18:39:00'),(2503,'/',NULL,NULL,'8qA5XCKEPJFleFkONhcB6z6o8nwn3yDlACEXMzHW',NULL,NULL,'desktop','Other','2026-08-15 19:21:47'),(2504,'/',NULL,NULL,'F4xsHVKKchDDp0jqMyNem0kOijzeBm2JFYxT0GND',NULL,NULL,'desktop','Other','2026-08-15 20:05:10'),(2505,'/',NULL,'http://safhenokhost.ir/','Ingox2BTSgei2uX8PK8lBdHGZ1zQVisTOjtRkf1a',NULL,NULL,'mobile','Chrome','2026-08-15 20:11:00'),(2506,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'zEM6QmAj9Pca71qdAZpEFZKzDBLhgn31FLeyHzVv',NULL,NULL,'mobile','Chrome','2026-08-15 20:11:01'),(2507,'blog/sayt-hmh-karh',NULL,NULL,'G3kVz63idVTgdc13PUXJkoFKwzKgaMLTh6fyNooY',NULL,NULL,'mobile','Chrome','2026-08-15 20:11:12'),(2508,'/',NULL,NULL,'CBbo31KXz5nBWKGfoyAQSpZ8TVd7QtMAGOS3emXJ',NULL,NULL,'desktop','Other','2026-08-15 20:48:53'),(2509,'/',NULL,NULL,'y255kAgQJkeHN3OrIjOXSgl1VCTW7SVm02Dvs507',NULL,NULL,'desktop','Other','2026-08-15 21:32:17'),(2510,'/',NULL,NULL,'ZMdW7gRP4xXEPrYRkzkMER6a4JJwmtWKmREPrQ0u',NULL,NULL,'desktop','Other','2026-08-15 22:15:01'),(2511,'/',NULL,NULL,'3G6Ns51pf6SWKMjUnwTGD0c5HOvM2ZqRg1ADtqC9',NULL,NULL,'desktop','Chrome','2026-08-15 22:20:05'),(2512,'/',NULL,NULL,'61Lf5FOCCImdwF2dBZHx1FOtbWOqPj6p0MvXhAVb',NULL,NULL,'desktop','Other','2026-08-15 22:58:12'),(2513,'/',NULL,NULL,'NDzp24eNZqdNaRrjebaauMZ1ldfywA6BfQ21av8k',NULL,NULL,'desktop','Other','2026-08-15 23:41:17'),(2514,'/',NULL,NULL,'3iAiEs493UOliZgxTuxrdsvCte5z15KgcFaoaaXs',NULL,NULL,'desktop','Other','2026-08-16 00:23:24'),(2515,'/',NULL,NULL,'rXAPnMw0vFU27shRr55RA04wCqJXSrLFzcYCafBS',NULL,NULL,'desktop','Other','2026-08-16 01:06:48'),(2516,'/',NULL,NULL,'P4aKXweuQf0AyL4ftmCGdFZmczBW3grDJpQnLrPk',NULL,NULL,'desktop','Other','2026-08-16 01:51:33'),(2517,'/',NULL,NULL,'lHDcbJUDj3dhuCzxZG0sIXgDMTQEMoBNBJSYH0PS',NULL,NULL,'desktop','Other','2026-08-16 02:36:18'),(2518,'/',NULL,NULL,'7MNzxhVsMugeEFblc5fuOtNTxtVkeAwwZ80S8WWn',NULL,NULL,'desktop','Other','2026-08-16 03:19:27'),(2519,'/',NULL,NULL,'XD8V377YN4F1AqLaXj6pJpUB1b4jg3dwr3PXEbj7',NULL,NULL,'desktop','Other','2026-08-16 04:03:40'),(2520,'/',NULL,NULL,'IeM8gLVrujKZkluiSd6nJxdajv6huuK5W4dQYJ4J',NULL,NULL,'desktop','Other','2026-08-16 04:48:04'),(2521,'/',NULL,NULL,'5Sqdjie391mNBsfjtgGaB37YuMWl06ToMb4nJKGO',NULL,NULL,'desktop','Other','2026-08-16 05:31:51'),(2522,'/',NULL,NULL,'21q6zotnMW7ySFkxJNN4IVay6QQBm7QWi3w9XkRb',NULL,NULL,'desktop','Other','2026-08-16 06:15:28'),(2523,'/',NULL,NULL,'nBQb8RRZ9uxgod1ADH6cKTOzSWPZ1LJUjGMr14jM',NULL,NULL,'desktop','Other','2026-08-16 07:00:11'),(2524,'/',NULL,NULL,'fS85rL9UkqIBZwWdJKck2QGNReg7WafiVWDYVZBm',NULL,NULL,'desktop','Other','2026-08-16 07:45:06'),(2525,'login',NULL,'https://safhenokhost.ir/login','iJIhih205JXFGygU7bFDYHi8oPqKVfXkMHWSGqdZ',NULL,NULL,'desktop','Firefox','2026-08-16 07:54:00'),(2526,'login',NULL,'https://safhenokhost.ir/admin/dashboard','u9VooOJJLWJDZOsthSbVqPrFxlnWQtS0TokVh2Jv',1,NULL,'desktop','Firefox','2026-08-16 07:54:19'),(2527,'/',NULL,NULL,'CGCnR9CdOH2ty3uCEPJA4wNLlMsSckSlwNZhIyBJ',NULL,NULL,'desktop','Other','2026-08-16 08:29:31'),(2528,'/',NULL,NULL,'oG9H9PdKwI92hbka1rqvu7xLFtjlmp4LqYyQXBO8',NULL,NULL,'desktop','Other','2026-08-16 09:14:52'),(2529,'/',NULL,NULL,'RkomKIXCmGWakXcsaZhUk6p98lblrXYfkfFUIPgO',NULL,NULL,'desktop','Other','2026-08-16 09:59:29'),(2530,'/',NULL,NULL,'ATEAHspm3BC7u5suYgZsLqarwHbLpUKHFxRT1RKj',NULL,NULL,'desktop','Other','2026-08-16 10:43:09'),(2531,'/',NULL,NULL,'yXaYvmDol1uaG8q7iHI2Zg7h5j8OyEQxTwGotKJq',NULL,NULL,'desktop','Other','2026-08-16 11:27:07'),(2532,'/',NULL,NULL,'J4vgWZAjDs8Zc1gIgw3hRIw5J8s0PJ3e9eBciLrA',NULL,NULL,'desktop','Other','2026-08-16 12:10:33'),(2533,'/',NULL,NULL,'nGWZ2n6mtUUXIY1rcFVu1ebIPhgunq3LyaM2v04R',NULL,NULL,'desktop','Other','2026-08-16 12:54:36'),(2534,'/',NULL,NULL,'nDSwK7s43FLrxbDAKEBPlliJglmWk4zz9JiyMEo4',NULL,NULL,'desktop','Other','2026-08-16 13:37:59'),(2535,'login',NULL,'https://safhenokhost.ir/admin/dashboard','u9VooOJJLWJDZOsthSbVqPrFxlnWQtS0TokVh2Jv',1,NULL,'desktop','Firefox','2026-08-16 13:53:40'),(2536,'/',NULL,NULL,'tBknVZaUV9z8kggSZFafyuB0KFQFP3niSaDoJvqD',NULL,NULL,'desktop','Other','2026-08-16 14:17:23'),(2537,'/',NULL,NULL,'PUcZKwsK3Rgp8E5ITUvChZS5s2PobH22JHMFD1Bp',NULL,NULL,'desktop','Other','2026-08-16 14:17:23'),(2538,'/',NULL,NULL,'A6uPM23FmrrhG5umUAzWkQpUJZukYxgSJtkTRlmk',NULL,NULL,'desktop','Other','2026-08-16 14:21:44'),(2539,'/',NULL,NULL,'S10VlpCjg57TLKeLPzkCel9KALf6cZVsMkP2CUX2',NULL,NULL,'desktop','Other','2026-08-16 14:34:57'),(2540,'/',NULL,NULL,'6l3CrRh3A9hBVsRJPDTYxJfV8pJdYYjV8gBQJcBs',NULL,NULL,'desktop','Other','2026-08-16 14:34:58'),(2541,'/',NULL,NULL,'8uXS9TgHZeRaxbygZKEH8vviSYvEziOVtLkv7zOA',NULL,NULL,'desktop','Other','2026-08-16 14:34:58'),(2542,'/',NULL,NULL,'Mny2qpEoNTmUEEPiHe94l7BtJOZ7mEtdMvxH8vbf',NULL,NULL,'desktop','Other','2026-08-16 14:34:58'),(2543,'/',NULL,NULL,'pgemaO9UQb7fcsUcyhUejrJnJE6NnagoypVK0ABL',NULL,NULL,'desktop','Other','2026-08-16 15:05:16'),(2544,'/',NULL,NULL,'ow6iKrJWmssmTbEZhTKw7iCuIyFvZkAThUQXtTwB',NULL,NULL,'desktop','Other','2026-08-16 15:51:06'),(2545,'/',NULL,NULL,'AC8OeVkwsvDzCgx6b2UOmP15Wy4fXbj4MOrCSJZ9',NULL,NULL,'desktop','Other','2026-08-16 16:34:28'),(2546,'/',NULL,NULL,'QNdhmlSv55e7y5d9rES2bfvEjDiDnpNmxWhCKmHo',NULL,NULL,'desktop','Other','2026-08-16 17:18:46'),(2547,'/',NULL,NULL,'9nYQn4cOIzhuy6J8sfiO20PEqDfJd0o8LrXIAACH',NULL,NULL,'desktop','Other','2026-08-16 18:03:26'),(2548,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','tDW7GKh2wWe3HThj8RznRVT2Dbh5HsOMhflP5zrJ',NULL,NULL,'desktop','Other','2026-08-16 18:04:56'),(2549,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','GcnTYwwdf67gdmd7BTUTW1o1C69S7GhCZknBpN8L',NULL,NULL,'desktop','Other','2026-08-16 18:04:59'),(2550,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','5u79chTUnfvaBZLqtsFNOYrd7WbMHm3APGW5Ctr0',NULL,NULL,'desktop','Other','2026-08-16 18:05:00'),(2551,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','BndJzRFcbyLXvWtoTwfeQtm7WClygk6agJkvKaj8',NULL,NULL,'desktop','Other','2026-08-16 18:05:02'),(2552,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','KsDeYxw0raIiebjfe6GIsReFOVbecQvFFKBajA2s',NULL,NULL,'desktop','Other','2026-08-16 18:05:02'),(2553,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','6aLfCk1PnLwj8JBRh7xiA6DGkIakDcagAGwDkvbV',NULL,NULL,'desktop','Other','2026-08-16 18:05:02'),(2554,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','E2ouhY5xQAUePGx5UYXCxVZLa7fOcOkTvzAnjpQl',NULL,NULL,'desktop','Other','2026-08-16 18:05:03'),(2555,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','xJmhijPR6569thY2AhC6BCg2wcZW6XsTOl50SJUi',NULL,NULL,'desktop','Other','2026-08-16 18:05:06'),(2556,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','A0DSxkPoZB6OvSJitTBCfmiCaf4t0Z7a7eQDnb8H',NULL,NULL,'desktop','Other','2026-08-16 18:05:06'),(2557,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','AgveEwhlfvUf3JvXQEncYVjNeiJYIGJloMGdSKli',NULL,NULL,'desktop','Other','2026-08-16 18:05:06'),(2558,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','zyLnSYAFhfkEqEQfKl0e12vfhNpQfCLvHuEdEbUg',NULL,NULL,'desktop','Other','2026-08-16 18:05:11'),(2559,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','MdftmZszj5bxzzFx2G4IwXIRqvNDdxsJuoniORt9',NULL,NULL,'desktop','Other','2026-08-16 18:05:13'),(2560,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','4fq10ECMpem63xsK84lwMAETlObHSDCEKBVzkv71',NULL,NULL,'desktop','Other','2026-08-16 18:05:13'),(2561,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','2LE63kE3Q6OzbPUUspUqgDkj8rS8LZKNazRy08I4',NULL,NULL,'desktop','Other','2026-08-16 18:05:14'),(2562,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','rBRPpkoBhrMepwcYxDkBeNZRN91SGHZfKsSn6gtf',NULL,NULL,'desktop','Other','2026-08-16 18:05:15'),(2563,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','UgjlkXe17DfGco4yqsMJCMs1HlkJz43jMzJa82Pp',NULL,NULL,'desktop','Other','2026-08-16 18:05:19'),(2564,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','SVLWAWueD74thePKNN3eHuNSyBdLhx87mlkkROId',NULL,NULL,'desktop','Other','2026-08-16 18:05:31'),(2565,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','7sQYBiQkvVZ9gGbXCMIPEx07Tw6w1EEJAcs0eo1Z',NULL,NULL,'desktop','Other','2026-08-16 18:05:32'),(2566,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','QJvBuQpl2LNSy1aGmvmhtnuh7OT34FpnSgxgDXmj',NULL,NULL,'desktop','Other','2026-08-16 18:05:37'),(2567,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','x2nXhyfmLBcqOhs5R5k6nGDsDFtxzZJ3g3VLBxuY',NULL,NULL,'desktop','Other','2026-08-16 18:09:18'),(2568,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','WvOtqDdmva0R3r4LkDdg1OxL6bYcnWaOrzlbMgOD',NULL,NULL,'desktop','Other','2026-08-16 18:09:18'),(2569,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','MwsNK3WYPpDtGYC319UdR8qiyKnoaPyE30foIXlt',NULL,NULL,'desktop','Other','2026-08-16 18:09:18'),(2570,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','BZZE4DeTQgO63fxTg9nAINM6O1TUMmuYNKtIJVBT',NULL,NULL,'desktop','Other','2026-08-16 18:09:21'),(2571,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','308kmC0tZk4zOG78o0rNdRI6K4JiGxW8cVJqbo0Q',NULL,NULL,'desktop','Other','2026-08-16 18:10:24'),(2572,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','3Siu8xOJ37cHCq4UDsLi08IhD2IRDkN7cb06faoy',NULL,NULL,'desktop','Other','2026-08-16 18:10:25'),(2573,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','kQz9EPbTK5qt3O67EzfBz89nwyoi23tEytoKDgMx',NULL,NULL,'desktop','Other','2026-08-16 18:10:26'),(2574,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','vfu5UffcpAvVQLFKpySAns1290pW9F1dX4covGHf',NULL,NULL,'desktop','Other','2026-08-16 18:10:30'),(2575,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','urw0DqXWQVJya22gl2HeeyLLi1ccOCt857efYRck',NULL,NULL,'desktop','Other','2026-08-16 18:10:31'),(2576,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','vLOrotOEiPT7nwysDN6hmaC3oTxNQJdiAYKyx9Qa',NULL,NULL,'desktop','Other','2026-08-16 18:10:33'),(2577,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','wCXMmF2JVSFuudu6bW0rskfnskVrIcFUbJ7siUv2',NULL,NULL,'desktop','Other','2026-08-16 18:10:35'),(2578,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','BJpMY7RpfwHqzXuh8D7yr4jFLl7hv26MiXVxD63c',NULL,NULL,'desktop','Other','2026-08-16 18:10:37'),(2579,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','rmRXuzPHwWyfsxtx4eImG3eIQFFuGLj1af1a6TiC',NULL,NULL,'desktop','Other','2026-08-16 18:10:38'),(2580,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','w6hgdhFj8oMatQOToFhwEQmaQVIubcVUu76qtA3t',NULL,NULL,'desktop','Other','2026-08-16 18:10:41'),(2581,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','qf82nJFQQplknmMyIDySrZFmVscNobWu9xSuGaJV',NULL,NULL,'desktop','Other','2026-08-16 18:10:41'),(2582,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','vtZYr5Dd32ViCfAA7kFZyz6Ir6TdwiRCo3qYFA8O',NULL,NULL,'desktop','Other','2026-08-16 18:10:41'),(2583,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','Jf3MNXqvsLt67tc15wNfMchbl9kZHWSAVEHBfxyf',NULL,NULL,'desktop','Other','2026-08-16 18:10:44'),(2584,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','7FJPCDLussr3AaDyHTucpsSp5d9j4dGaBKb6cj0E',NULL,NULL,'desktop','Other','2026-08-16 18:10:45'),(2585,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','MbmJmj8mHiC3xcDkN5ywJ9Y1J4yhhG7kTC0oTP3i',NULL,NULL,'desktop','Other','2026-08-16 18:10:45'),(2586,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','jjad81bSp5Y0PPfDA699vMkuHoiLoGXTuwmGCCfk',NULL,NULL,'desktop','Other','2026-08-16 18:10:46'),(2587,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','xKE0i1sa79Y7LKqyHWoJtD7mutDAhFh5kEvT41PW',NULL,NULL,'desktop','Other','2026-08-16 18:10:46'),(2588,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','RGtuBO6VGPhu4mblPuflZEzdYLEhMBcVqadcXVhj',NULL,NULL,'desktop','Other','2026-08-16 18:10:47'),(2589,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','SnbKbOyWin8q4ZV0Bnm2GUd4FrDVsKocX5jUlvNI',NULL,NULL,'desktop','Other','2026-08-16 18:10:48'),(2590,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','mo8AB5dcYkcWOYa31zaLpVZo7XJgrjLv6p9JQSDK',NULL,NULL,'desktop','Other','2026-08-16 18:10:48'),(2591,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','IQvEWdrNjWzzwHHHAU4svpLu3Qz9LntUcxvhWENj',NULL,NULL,'desktop','Other','2026-08-16 18:10:49'),(2592,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','uTnLR0XXKyHApuOoBS92rVm8c4bFOMuutDc08c8Z',NULL,NULL,'desktop','Other','2026-08-16 18:10:49'),(2593,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','875Oh1En85l4BK9NSimQ14AHIPdzpqcCxZjVfxAP',NULL,NULL,'desktop','Other','2026-08-16 18:10:50'),(2594,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','a43Cw0ArBim5y7ukP2CZeghObvuh4RC1wssBZHxL',NULL,NULL,'desktop','Other','2026-08-16 18:10:50'),(2595,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','BosTr0sq5sZ4o0aUGS6yhWUQ8SJUhf9x6vCFMFFi',NULL,NULL,'desktop','Other','2026-08-16 18:10:50'),(2596,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','Ew9b7lMDIbuDTe5eeYy5XGrUSKsQpAoD7NkSA2Mo',NULL,NULL,'desktop','Other','2026-08-16 18:10:51'),(2597,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','DGplHKoCuKroXhKoTrBAkXEbuB5ZnOtEe0LuaKWh',NULL,NULL,'desktop','Other','2026-08-16 18:10:53'),(2598,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','TefpNdpffW0oUXA9x7Sed3XMJoCrN4DZnYOwa8z9',NULL,NULL,'desktop','Other','2026-08-16 18:10:55'),(2599,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','LntH6fko9qbYxt4cbr7BKLcCTexbjBEnICfkm9wj',NULL,NULL,'desktop','Other','2026-08-16 18:10:57'),(2600,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','ulHGwz5YjJxqJGkup854qmywUcYcQgb3oSGZN8iD',NULL,NULL,'desktop','Other','2026-08-16 18:10:57'),(2601,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','E68rAFEDCIR0lEpCe8NT4Qm0BSrIHyAvhCGf0NKC',NULL,NULL,'desktop','Other','2026-08-16 18:10:58'),(2602,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','VtVmMJI6dSWAnidbMWl5L2KgUiHEmtMwkFJTE0JN',NULL,NULL,'desktop','Other','2026-08-16 18:11:00'),(2603,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','J3Revso5N0D3R90zjxPE1OT1JXviG3fMKqfyVdP4',NULL,NULL,'desktop','Other','2026-08-16 18:13:16'),(2604,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','clZhriGFB5S2DaOe1I9bVY7A0NEpakSoOPGCDPhc',NULL,NULL,'desktop','Other','2026-08-16 18:13:18'),(2605,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','VbvJzOWkMOkSbhsSkXa6lktZzIMkyqSyPs2bq2Cb',NULL,NULL,'desktop','Other','2026-08-16 18:13:19'),(2606,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','aeBAvJZF32Xrl9oebwu8my1Seajnn0DZMdrYsPc9',NULL,NULL,'desktop','Other','2026-08-16 18:13:22'),(2607,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','SFg1XLbJEAKnn9ITC9b7G7aSVaoAw9hIZVlMQkBE',NULL,NULL,'desktop','Other','2026-08-16 18:14:46'),(2608,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','frKi4g7YnvT9XQQg9s1GFgSRW5edEiUedqLlnxn4',NULL,NULL,'desktop','Other','2026-08-16 18:14:47'),(2609,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','Gt8MKHXAimMmOwlxI8q4e1vXCY0MHUUe806nXo0X',NULL,NULL,'desktop','Other','2026-08-16 18:14:47'),(2610,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','fO84XLF7hQuSmUDHV8dzuBoIPENdpOiuC5MQR52j',NULL,NULL,'desktop','Other','2026-08-16 18:14:49'),(2611,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','KjgQo9F1toXOPDmSbBowbrSCPIvIDUEIjthdVMar',NULL,NULL,'desktop','Other','2026-08-16 18:16:09'),(2612,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','MvghqRljByTNrw8mcbTQQdbiJyNrUh63xtIdtWxL',NULL,NULL,'desktop','Other','2026-08-16 18:16:10'),(2613,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','rSqtn53Vna9MOJFnQkDLJopVcHcvzduG0dYp62jp',NULL,NULL,'desktop','Other','2026-08-16 18:16:15'),(2614,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','zFxitQMjFbNv4z1gifqBmq6wO4VLRfRCSIB0HWoT',NULL,NULL,'desktop','Other','2026-08-16 18:16:18'),(2615,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','w0kxYue3kDjh0YWRLmsI0KM1swMxkbi4tkuU4qyE',NULL,NULL,'desktop','Other','2026-08-16 18:17:29'),(2616,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','ajuhtfLjtewdibtXxGYl61cORB1BDUHpf0R30bWL',NULL,NULL,'desktop','Other','2026-08-16 18:17:30'),(2617,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','mFhXoyy4ZKVDZdPcetWVN8P0fUUsiQjCwyCrCayl',NULL,NULL,'desktop','Other','2026-08-16 18:17:31'),(2618,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','rzpSHtlMsqp0CDrqwxdduqEexJSsLlGLF4EZolIJ',NULL,NULL,'desktop','Other','2026-08-16 18:17:31'),(2619,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','b2VV7yRUTxy3V1oR4k1HTl5QaPmnDRt4dRTvPHhn',NULL,NULL,'desktop','Other','2026-08-16 18:17:32'),(2620,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','lxTyec192MA1SwhlRiUkrTByPIAFBzKTvqnPG5B7',NULL,NULL,'desktop','Other','2026-08-16 18:17:33'),(2621,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','S0NycsfDydC8cFCf8ke0NYwqepwfkHE4B7WlcjSd',NULL,NULL,'desktop','Other','2026-08-16 18:17:35'),(2622,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','qhK1lZYzagqgZlL0MlG1ruZ8YVu0wmDYetIKCqxS',NULL,NULL,'desktop','Other','2026-08-16 18:17:36'),(2623,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','CuFxX5tnGIkn6fQQS4m1kZb8YYF1oIFfvtZcfzzb',NULL,NULL,'desktop','Other','2026-08-16 18:17:36'),(2624,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','cQ3n4PF36otUh3LcWqOgTMIy1WDyC6EqJ2V8GnqK',NULL,NULL,'desktop','Other','2026-08-16 18:17:36'),(2625,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','l24D7fxU0prOAa7QSJEX7KCpyO9A5MeOmDZPhXVi',NULL,NULL,'desktop','Other','2026-08-16 18:17:38'),(2626,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','zA0X0HkFfzkCLmUjb0VGwPQw9BQdGWynFCPTT4kt',NULL,NULL,'desktop','Other','2026-08-16 18:17:38'),(2627,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','6xLDpr6pogCNfvKz46GxCs0qEr9qQQG3qxEeXPn5',NULL,NULL,'desktop','Other','2026-08-16 18:17:39'),(2628,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','p18318g4Fp8dj6AH9CCKjNgzd68k7tbWJCwfkGTS',NULL,NULL,'desktop','Other','2026-08-16 18:17:39'),(2629,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','NDSBlF4o1YX1p29YKY9R7qoeMhinWqdvn18JlxHt',NULL,NULL,'desktop','Other','2026-08-16 18:17:39'),(2630,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','vZdIc8QfzhqEBWSyrJ3LRDvJNqPzrklhb74P6QTL',NULL,NULL,'desktop','Other','2026-08-16 18:17:39'),(2631,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','nNrGI6VCEre3dZxgPGnEd05p1XiPaFrTTPbIMFnL',NULL,NULL,'desktop','Other','2026-08-16 18:17:39'),(2632,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','f47viAeE7F9dDfr7VtHJSCmVxsQqganwH5uaLyUf',NULL,NULL,'desktop','Other','2026-08-16 18:17:40'),(2633,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','zpZTv0Ku7bqOMQg3dhDz2maBPNkF6tigaNRcgNip',NULL,NULL,'desktop','Other','2026-08-16 18:17:41'),(2634,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','ehbLoXMHTUSMweg1ibeUQRaIzowmcufIjLy8eeFM',NULL,NULL,'desktop','Other','2026-08-16 18:17:42'),(2635,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','Y1o6pjmrZAX0dN8iqmODw5k9MoUc95PO0y75wdmB',NULL,NULL,'desktop','Other','2026-08-16 18:17:42'),(2636,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','Tj4EswNGd0FO3Idi5sEEQcjJVe8Ds1FTtUeBaCog',NULL,NULL,'desktop','Other','2026-08-16 18:17:42'),(2637,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','O0pZMi7UCfOwhC6jEB8T2WudGmVBYuh1ZBzsOqWf',NULL,NULL,'desktop','Other','2026-08-16 18:17:43'),(2638,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','l213sGaiwNHvX3lqVs4Br6xvftVIrUuMUXhna14X',NULL,NULL,'desktop','Other','2026-08-16 18:17:43'),(2639,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','1RI8gOZg43UwEpa58kg8agdLQA53NY7meT7Yd8XA',NULL,NULL,'desktop','Other','2026-08-16 18:17:43'),(2640,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','YJRVsZJq7Lt8bMP0XaFjMFA5GbMv1o0SCv76kOoY',NULL,NULL,'desktop','Other','2026-08-16 18:17:43'),(2641,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','dhEy3LMF9BlPAR18j9ETxxqwRmorH87SrJtgxg9C',NULL,NULL,'desktop','Other','2026-08-16 18:17:44'),(2642,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','NXecI9aXgjirfGwnVFoKJDlYzIZGJyycna3sQMfo',NULL,NULL,'desktop','Other','2026-08-16 18:17:45'),(2643,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','nbzb98OVpLCNFsfyT0SjyyWRWnqn8TLx4af2HrG7',NULL,NULL,'desktop','Other','2026-08-16 18:17:45'),(2644,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','2PRvmt4Rct1LHlo4bnqgNhGwQyp2YNBdGExyOfkf',NULL,NULL,'desktop','Other','2026-08-16 18:17:45'),(2645,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','toy3GMvpnEKfRDlPHIGgeIDN5ebUHMd5d60sCLSg',NULL,NULL,'desktop','Other','2026-08-16 18:17:46'),(2646,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','dwSFKNQWDiYcHXJ8s0AC3APQNfQfUIKzVyccwrjn',NULL,NULL,'desktop','Other','2026-08-16 18:17:46'),(2647,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','1arLbqIge8kjTTrXnfTpkTJU36Z2aV9JLXZX0mbq',NULL,NULL,'desktop','Other','2026-08-16 18:17:47'),(2648,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','6fCZajd8iZd0pT2r3QO5tM6vywVJwD7ZqLwbIrmr',NULL,NULL,'desktop','Other','2026-08-16 18:17:47'),(2649,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','WoCKilbA27DxYjvAvlSr6cYueVrgfVsoUa7pBoVt',NULL,NULL,'desktop','Other','2026-08-16 18:17:48'),(2650,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','8m5yuNBnYlRpsQ4lPfFEjAr6haQBhDNILUukxHSl',NULL,NULL,'desktop','Other','2026-08-16 18:17:49'),(2651,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','Ql3NcW0FXzYf0cS6c2PPhCM07c5eOFnVkxrXGTQm',NULL,NULL,'desktop','Other','2026-08-16 18:17:50'),(2652,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','C8plbQBAAprDrpplFx6iLBXochyS8IunTrg1rP0p',NULL,NULL,'desktop','Other','2026-08-16 18:17:51'),(2653,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','IZpXyiz5GlrtJbSvK344NE6BFATGAaa2VJAFAx0y',NULL,NULL,'desktop','Other','2026-08-16 18:17:51'),(2654,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','y6TisZfZDgRoSFZ6zQDw6y5P3UvX9iimgks4Ujwg',NULL,NULL,'desktop','Other','2026-08-16 18:17:52'),(2655,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','d3mwsps9CZiyuRxYsaT1cwGqrHWNC0RK0bP6t20T',NULL,NULL,'desktop','Other','2026-08-16 18:17:52'),(2656,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','ZeIQPv8LVvm3I2ICjBESm5Feds8ywOwbBrU0AyF3',NULL,NULL,'desktop','Other','2026-08-16 18:17:52'),(2657,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','c6VWbNyssuRXoEhohz89UiK18PjwlV1z1aoEE1IX',NULL,NULL,'desktop','Other','2026-08-16 18:17:53'),(2658,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','1wb03B1rTZ0uIAXWt7r0teZpsFI8iTkqV8a3aWaH',NULL,NULL,'desktop','Other','2026-08-16 18:17:53'),(2659,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','48SkHyvu3hSIir2ZnUzw13eED5jZAcMLOLU38nYU',NULL,NULL,'desktop','Other','2026-08-16 18:17:54'),(2660,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','6NPktWDbkGo8AsuMPxXl9y6d5RF9SUaDVV3dyo5Y',NULL,NULL,'desktop','Other','2026-08-16 18:17:55'),(2661,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','P72ilBEgBSbhK0KRqouAmptFPbZ4jhq1wrRVKs57',NULL,NULL,'desktop','Other','2026-08-16 18:17:55'),(2662,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','WCjpwcRNZVDBzuS3o2ossPMuE6WkSCpWneJeO4lo',NULL,NULL,'desktop','Other','2026-08-16 18:18:11'),(2663,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','0mF3CMCbp3Ad5d0XJec14dXaBLVhjQw6slZhx0V1',NULL,NULL,'desktop','Other','2026-08-16 18:18:13'),(2664,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','ufBMXbXZe8iCFbUUvH3GPWWQQiVMbsGWx9meHN6j',NULL,NULL,'desktop','Other','2026-08-16 18:18:14'),(2665,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','RayTj0oHbwkABaBTZ7jtEkBLFgr9mRilLyG8GiUe',NULL,NULL,'desktop','Other','2026-08-16 18:18:16'),(2666,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','bAiAvL6xdth8Quzn13MrYxIrjn2PEjYr6wgYBMcW',NULL,NULL,'desktop','Other','2026-08-16 18:18:17'),(2667,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','49wTex5CoOPQLL6cgNv5SNumzBD6Tt7dOV61lBsp',NULL,NULL,'desktop','Other','2026-08-16 18:18:18'),(2668,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','z5d7qhVsXFGIzxNKZ1LZwy4M0Nt8lxsAK9QUOrUK',NULL,NULL,'desktop','Other','2026-08-16 18:18:18'),(2669,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','omeLe3QTQ03KEQhweba2xYGvxqapzwfosUMRFtU5',NULL,NULL,'desktop','Other','2026-08-16 18:18:19'),(2670,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','XS2dqTSx9UyOsLeipfCOJ4BjMBE52I7OJNCFW1df',NULL,NULL,'desktop','Other','2026-08-16 18:18:20'),(2671,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','Ahtg68UxkIA4t0Nf527x8i7Wee6D9hnzulkdnpox',NULL,NULL,'desktop','Other','2026-08-16 18:18:21'),(2672,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','zeRBBVyKeawM35Cgc3Q4Ciq8MvRtMCA37y8ulfGo',NULL,NULL,'desktop','Other','2026-08-16 18:18:22'),(2673,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','aQ0RQiJVEJvrlOxSguDt7FCQz1FrL3Cgo4cGGtap',NULL,NULL,'desktop','Other','2026-08-16 18:18:22'),(2674,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','FKLDCmPSCHm57CW9IuyB8lNIqfDLeAl4O9M94DV0',NULL,NULL,'desktop','Other','2026-08-16 18:18:29'),(2675,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','2EV23F4EouFYYgcKcOCrNwvUcdq0rnGG3raQzsad',NULL,NULL,'desktop','Other','2026-08-16 18:18:30'),(2676,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','dbwLf7GOlZo4qng5cX5RikKPSbnIkunukNRpEcI0',NULL,NULL,'desktop','Other','2026-08-16 18:18:30'),(2677,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','5O9lEnF9BnSrX6a5ngLPdbfN4wDccJ7xqEpps8MU',NULL,NULL,'desktop','Other','2026-08-16 18:18:31'),(2678,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','SaqYdEsOG1mKpjq6UpAgz4MnAKqAQ6fn20SpkwQs',NULL,NULL,'desktop','Other','2026-08-16 18:18:32'),(2679,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','f7pVnatiaNQ6OXyiNbZsrSf5fQZvrBMWAP5qt32z',NULL,NULL,'desktop','Other','2026-08-16 18:18:32'),(2680,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','y6XTvYoFtBwj5fUw0nnVddtRfXHzEnmtN5TueLBU',NULL,NULL,'desktop','Other','2026-08-16 18:18:33'),(2681,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','EiMZzLPxgXwwwHU0BVbLgcv1VIpRUri3wPZayjkP',NULL,NULL,'desktop','Other','2026-08-16 18:18:33'),(2682,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','ShpYgzKKJn2GSpR1Tc2t8o9jxb3KlZ4OnF0QvuP5',NULL,NULL,'desktop','Other','2026-08-16 18:18:34'),(2683,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','vWiltCAqhMlALVrnYQOmt9ohFzFXjN4U6FQxc98g',NULL,NULL,'desktop','Other','2026-08-16 18:18:35'),(2684,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','cprWlm4N3VuhdKagkUer4biHa8ux2UC3tt6vUSfT',NULL,NULL,'desktop','Other','2026-08-16 18:18:35'),(2685,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','TBxR9cHuUnF0c3goggZCcK1a0BfriW6U0rmPS7DU',NULL,NULL,'desktop','Other','2026-08-16 18:18:36'),(2686,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','l9Oh8XnFS8ap5QdLExGNSgbehzeKxxWtZz6KiNcU',NULL,NULL,'desktop','Other','2026-08-16 18:18:37'),(2687,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','qlBWmlM9xhAvNBClBNPu5G70Pe3HSx7u8emD6ZXT',NULL,NULL,'desktop','Other','2026-08-16 18:18:37'),(2688,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','gmjOygPhlwdKGg9FDItpn1w3kUYMXSslxt4cSNXp',NULL,NULL,'desktop','Other','2026-08-16 18:18:38'),(2689,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','IIr3vDA1kntyetT1du5ff2gmkMxUk0YOLIWIDBJA',NULL,NULL,'desktop','Other','2026-08-16 18:18:38'),(2690,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','PFUGusvhwdJzrjriSb5FKfvGCkZ67IupdWEzC089',NULL,NULL,'desktop','Other','2026-08-16 18:18:39'),(2691,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','dG0XfjwvN0kHV2CWKjPsRl1In7jaG8IMPo19LR8i',NULL,NULL,'desktop','Other','2026-08-16 18:18:39'),(2692,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','GTAGsE5RQeQUtKTqYzN8b6rL6zC2ynd198UFMBtX',NULL,NULL,'desktop','Other','2026-08-16 18:18:40'),(2693,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','ZblLZgO4Fs4MgnW6rey1V0lQYanWixQ9ZOqyzUKH',NULL,NULL,'desktop','Other','2026-08-16 18:18:40'),(2694,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','yPUlfWzoDHaDTRrkVpdUO0uXlcgTTspvChOjatCN',NULL,NULL,'desktop','Other','2026-08-16 18:18:40'),(2695,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','hXRg2YqJVJRwMzdcwWxLtURsXkmVcYKCiuldNNoI',NULL,NULL,'desktop','Other','2026-08-16 18:18:40'),(2696,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','SorD2EwkMGCdDICldNw6Wdx53cpsOIcXW38JhgSZ',NULL,NULL,'desktop','Other','2026-08-16 18:18:40'),(2697,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','d0hKm27edi1rW5cluQwimQTx3ej6UnJLWJE7waQJ',NULL,NULL,'desktop','Other','2026-08-16 18:18:41'),(2698,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','rcwgzC36BnCuqb8w8BXQDNFxCqrWGQ3Gc5ItpJrX',NULL,NULL,'desktop','Other','2026-08-16 18:18:41'),(2699,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','xOKNtHaD0yWwGbkrbmDMZ4IzWE8PwIJGONiPN50I',NULL,NULL,'desktop','Other','2026-08-16 18:18:41'),(2700,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','fnSzR3tSF3Nzceapuo9gOLSiAJYIuHGGEn17mMgg',NULL,NULL,'desktop','Other','2026-08-16 18:18:43'),(2701,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','Muj44iuDSIYgs8m7uM1xAmJPl7wEqICydOU2qTL5',NULL,NULL,'desktop','Other','2026-08-16 18:18:44'),(2702,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','EinoHaoqzzs6Tm6H5N6y8rOFAumihKg84EcCn6CG',NULL,NULL,'desktop','Other','2026-08-16 18:18:44'),(2703,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','ygeQiqHlLEBhh2L2nZ8Wb69jFKWMNj25zoZjIGlG',NULL,NULL,'desktop','Other','2026-08-16 18:18:45'),(2704,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','Izpi8XJoPbS7DaUomu0eru32QJbTmVKY0Y9VWPKP',NULL,NULL,'desktop','Other','2026-08-16 18:18:46'),(2705,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','ravShYJqOc34jK2JWssOitAr5ooOCHNNyW5YvWFP',NULL,NULL,'desktop','Other','2026-08-16 18:18:46'),(2706,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','hyMdAsLysXDqZFwt0Q47puuwh8KM44hJDZeWWT4D',NULL,NULL,'desktop','Other','2026-08-16 18:18:46'),(2707,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','xbc2GcYd7QOHxas4XKeg7NMgNixMUTBex1O3OwP8',NULL,NULL,'desktop','Other','2026-08-16 18:18:48'),(2708,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','w1jzKJXe4O2B4z1kzxPTcLwJ8yog1Gfn8xrXRUQ2',NULL,NULL,'desktop','Other','2026-08-16 18:18:48'),(2709,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','YUUnHJxo4nabvDZ5KUeU5Mn0EyzeQAc16W6SBToH',NULL,NULL,'desktop','Other','2026-08-16 18:18:48'),(2710,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','efIYSSFJts1VvOEkQPLixB5fYeEYgrTDGvejRj5o',NULL,NULL,'desktop','Other','2026-08-16 18:18:49'),(2711,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','tEsEFdh1TF0oz3gswiKmc1fCq1WVnhi2xBrHUt7t',NULL,NULL,'desktop','Other','2026-08-16 18:18:49'),(2712,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','tT3AnK7JkYPtWy7vP6JrBG0Z1pSfuD1MuJCOXUiT',NULL,NULL,'desktop','Other','2026-08-16 18:18:50'),(2713,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','033lI80iFqWBPcS10KqkzE6zJunl7QqAaCYYOu2I',NULL,NULL,'desktop','Other','2026-08-16 18:18:50'),(2714,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','Ad8Ek6L1iwWgDC2hB0g5lfCqlfYRB6zybKtECxrz',NULL,NULL,'desktop','Other','2026-08-16 18:18:51'),(2715,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','LGLChrem3CxNSvkMqBDA3T1ETAbrNFVUvFhHDpzd',NULL,NULL,'desktop','Other','2026-08-16 18:18:52'),(2716,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','goxkUzql1BmzmWFwrLU8At1weHYksxtqv0kFCJsm',NULL,NULL,'desktop','Other','2026-08-16 18:18:52'),(2717,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','VVOdKNvGjlQ2TX3LgzCPUy4BLfH0LWsvbRvzQWDB',NULL,NULL,'desktop','Other','2026-08-16 18:18:52'),(2718,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','2WP8rZKNnpAnWlFBcJLCO5NTxJV9H5LYCXsJPkBm',NULL,NULL,'desktop','Other','2026-08-16 18:18:52'),(2719,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','IYDFqg0qvl2NoEWNmjtkkxvbN5jXGLui7XWSUVHR',NULL,NULL,'desktop','Other','2026-08-16 18:18:52'),(2720,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','RSUWfUohfubXOQa6pCvQ58AJlVG2emusWAuxImQR',NULL,NULL,'desktop','Other','2026-08-16 18:18:53'),(2721,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','qV46YY4njkPtQApR2REN86VPin8vmo1inHlHBOyE',NULL,NULL,'desktop','Other','2026-08-16 18:18:53'),(2722,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','5aJg1WSyFnP6c5D7qE26Vvpru3zFtgv4tTa8s2HZ',NULL,NULL,'desktop','Other','2026-08-16 18:18:53'),(2723,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','SOlnFzkbOzBpB0jtD5uqGXhPzpFRrXPruLCUJw3U',NULL,NULL,'desktop','Other','2026-08-16 18:18:53'),(2724,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','lZwXsMNoc0wnkMYxjhv4w19COHa858PTVYaI4vmP',NULL,NULL,'desktop','Other','2026-08-16 18:18:54'),(2725,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','bcqTbbdi0Zj3IryoCzNwMXSePS8hB0LuXzQI6L6t',NULL,NULL,'desktop','Other','2026-08-16 18:18:54'),(2726,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','aA0wxFOPi55uIfBHNJwFBYHEujM1JeVJpHzViksh',NULL,NULL,'desktop','Other','2026-08-16 18:18:55'),(2727,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','bbnUh3yjhwOQwJBICVOaW0EcOb0IFuMPYyvNOM1a',NULL,NULL,'desktop','Other','2026-08-16 18:18:55'),(2728,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','3bvVQFiWcXkMixUrTD5hsv5gJr45kopavIsQSGS2',NULL,NULL,'desktop','Other','2026-08-16 18:18:55'),(2729,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','aznmZKTNNFhHsswinONz3aI06XhrQZgmL27xFmHM',NULL,NULL,'desktop','Other','2026-08-16 18:18:56'),(2730,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','lo4bToOyTZg954JuJPAETev225bzHVmtU3XgQllO',NULL,NULL,'desktop','Other','2026-08-16 18:18:56'),(2731,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','ULnaGfaMhi4BE2nazqIKQDogQPTsyGWRUIMu0yF0',NULL,NULL,'desktop','Other','2026-08-16 18:18:56'),(2732,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','gMWtm5UGXLjLDwvRdArdISGDGnLBZcZoBoc7tvQf',NULL,NULL,'desktop','Other','2026-08-16 18:18:57'),(2733,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','oT5RLI4sQ09RofHpOyQwaRUcy1wNuL8YKmIf3cx9',NULL,NULL,'desktop','Other','2026-08-16 18:18:58'),(2734,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','Dm4NtjYxWfgY8VlUZyW4MO9dX8itsUDT5ZxmKBW0',NULL,NULL,'desktop','Other','2026-08-16 18:18:58'),(2735,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','yv5X9yeikgEmf3IGjbApzpwRSu6pd8ngdO0tDl2i',NULL,NULL,'desktop','Other','2026-08-16 18:18:59'),(2736,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','nxVz1TbtkO6mUxmSZj9rtbkA8iTu3jG11r0QVRXd',NULL,NULL,'desktop','Other','2026-08-16 18:18:59'),(2737,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','c8tyv8zeJ6Rvvcy79ezl6oTPc3lVMAGVB8AufGhG',NULL,NULL,'desktop','Other','2026-08-16 18:18:59'),(2738,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','HSqoBupdJcJaWkbCvcIqkFM8WwUbvj2k8b5EAzSS',NULL,NULL,'desktop','Other','2026-08-16 18:19:00'),(2739,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','5ZgGw0T9BRFFuXCn9bQf4qZaLgDlJy8Ko4nIxsIN',NULL,NULL,'desktop','Other','2026-08-16 18:19:00'),(2740,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','Ee6tP5bJ9gVFuTBRieVxS7mcSC86gKG6ykVGeTrh',NULL,NULL,'desktop','Other','2026-08-16 18:19:00'),(2741,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','eeqYo428dCNLi0VRNqjw3CJAUbbqybhyDCGnScke',NULL,NULL,'desktop','Other','2026-08-16 18:19:00'),(2742,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','qzpjNKvCaUCHCisL9AGzRfiLkTNtvka7mOtoaDjn',NULL,NULL,'desktop','Other','2026-08-16 18:19:00'),(2743,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','8p71cPhAYklLJ6dxyi986MwUjUGGNLyzciltTJEl',NULL,NULL,'desktop','Other','2026-08-16 18:19:00'),(2744,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','N8IQdoGTv5vWlnbAv9o2AlqmnBrXRFi18yTnYW1q',NULL,NULL,'desktop','Other','2026-08-16 18:19:00'),(2745,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','05nQWuFulsSg45sSyDINycRePJen1Eqb3hDAgAov',NULL,NULL,'desktop','Other','2026-08-16 18:19:00'),(2746,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','O1Z8h3Ym7Qz4LBF3ZZNojuaagxKdC24XlB33l9Sn',NULL,NULL,'desktop','Other','2026-08-16 18:19:01'),(2747,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','WtopHanlQm7kjJ6u7LowVzo0BX1LW8vGUy3tKmrh',NULL,NULL,'desktop','Other','2026-08-16 18:19:01'),(2748,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','EcOS9vMgn7QlMHYo34k1VAj8k8tbcHckZsWTZxoz',NULL,NULL,'desktop','Other','2026-08-16 18:19:01'),(2749,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','LfYkLJ7NwRzcIHJD6ubxSH92enlBfovXhWwaujkh',NULL,NULL,'desktop','Other','2026-08-16 18:19:01'),(2750,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','lfEsDSOEliu6Puyyb561oVuRu3PKtYIl9QyHbxvT',NULL,NULL,'desktop','Other','2026-08-16 18:19:03'),(2751,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','ZzZKp0d9B1QzJpSy0Ir2PJkpeIfRDkx3ZCEf7XHm',NULL,NULL,'desktop','Other','2026-08-16 18:19:04'),(2752,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','oprGJyowQFImKoE2SXk9ul6g9576Z32nHkcI7aDx',NULL,NULL,'desktop','Other','2026-08-16 18:19:04'),(2753,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','4Wi12R3sZQM6pvRr8pN4J1H1LxYl2Pqin6lVXqwm',NULL,NULL,'desktop','Other','2026-08-16 18:19:04'),(2754,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','EyczRkBfLjVcPsquu8pf2Su0WaW6FKM3dPuEFoVv',NULL,NULL,'desktop','Other','2026-08-16 18:19:05'),(2755,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','6ac3TNbJdBw7pCcui7cJEZP7AlMFTugO0XU8l7Ms',NULL,NULL,'desktop','Other','2026-08-16 18:19:05'),(2756,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','z1zb2fCrtCT4ZTqEFVjU5T43L2TiG7rYYvKr5vJ7',NULL,NULL,'desktop','Other','2026-08-16 18:19:05'),(2757,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','wki9J73nnTBVY4Tc70WBFSuVPIWHxjG9U60RIuZg',NULL,NULL,'desktop','Other','2026-08-16 18:19:05'),(2758,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','msK6ylHVfYBlhBtIlHZwJ8eacxbSC7hIGW99rIBW',NULL,NULL,'desktop','Other','2026-08-16 18:19:06'),(2759,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','IlOgSRt1L4uUMHFRd3zpVKOpfv9m0msnBQObh7zp',NULL,NULL,'desktop','Other','2026-08-16 18:19:06'),(2760,'/',NULL,'() { :; }; echo; echo X-Probed: shellshock-poc','mk05xuABaFATseldLDHnkzaqNVoVgQuXWvCDsHit',NULL,NULL,'desktop','Other','2026-08-16 18:19:07'),(2761,'/',NULL,NULL,'QXleQjg4LfdX9LxCqUO3kvzxyntnpC8LvBgSAv9F',NULL,NULL,'desktop','Other','2026-08-16 18:47:37'),(2762,'/',NULL,NULL,'aOfOPomWs8412GgCxusepyeBZe6XEFx1uk8CckDq',NULL,NULL,'desktop','Chrome','2026-08-16 19:24:56'),(2763,'/',NULL,NULL,'ulHtHpSm0i7AevTwTlszRucpAUS0aQc9I03zQy6L',NULL,NULL,'desktop','Other','2026-08-16 19:31:10'),(2764,'/',NULL,NULL,'dq0gc61TKPZWkMGZn7m30Uij8lZVLJFtk2jH88TG',NULL,NULL,'desktop','Other','2026-08-16 20:15:06'),(2765,'/',NULL,NULL,'nPMo4fqxlonUfNWJS8ayuNA6yTb0uowBQ8XekMXJ',NULL,NULL,'desktop','Chrome','2026-08-16 20:30:01'),(2766,'/',NULL,NULL,'dM1bpFngCMHYNzAgEkzRYz6ggALP29jLlcuHFeo6',NULL,NULL,'desktop','Other','2026-08-16 20:58:41'),(2767,'/',NULL,NULL,'TOPos6VThcliUKs3dZpwySurAlO0NAwekYFgBFLK',NULL,NULL,'desktop','Other','2026-08-16 21:41:12'),(2768,'/',NULL,NULL,'2SUmj27YxIsO0DMH1J8L1ZmLK8V8201E7bzD4oqT',NULL,NULL,'desktop','Other','2026-08-16 22:24:09'),(2769,'/',NULL,NULL,'UKV9ytqBHhqaaSbfu2w5Il6LKrMjSbIqKpcY44eV',NULL,NULL,'mobile','Chrome','2026-08-16 23:07:11'),(2770,'/',NULL,NULL,'utb6T4sbQYU31EvT2kxtnvdhko4u9GfJttxW6u0E',NULL,NULL,'desktop','Other','2026-08-16 23:07:23'),(2771,'/',NULL,NULL,'2ZoE0AJ8vVPyHFPjwAs40XajYYaWlesbz8DbVis0',NULL,NULL,'desktop','Other','2026-08-16 23:49:58'),(2772,'/',NULL,NULL,'DEKzXJSS2gYN2OpEdJ8T0fWkbnR71nVRmEa4cm7H',NULL,NULL,'desktop','Other','2026-08-17 00:32:18'),(2773,'/',NULL,'http://safhenokhost.ir/','rPhvSlUjGFHYzYSw5QrORyBzQztDtjEkXxUNx4B6',NULL,NULL,'desktop','Safari','2026-08-17 00:53:40'),(2774,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'V5D4nxZFmQRlgdEkoQkQjArlBcerbDCjS5TL4wOx',NULL,NULL,'desktop','Safari','2026-08-17 00:53:41'),(2775,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'y1CGyvP1KrglnLwPB6nt4TGkkxlTlauh3JDeytjx',NULL,NULL,'desktop','Safari','2026-08-17 00:53:42'),(2776,'blog/sayt-hmh-karh',NULL,NULL,'UixRJouHTzypAmgsY7m54VO1qHsbMRsdtxrchVZI',NULL,NULL,'desktop','Safari','2026-08-17 00:53:42'),(2777,'/',NULL,NULL,'kq0FF4vonlNeq0qFday2feriLOHDVq4R8M2rL2Xk',NULL,NULL,'desktop','Other','2026-08-17 01:15:10'),(2778,'/',NULL,NULL,'oZZkLhgWRYGCy9znQ01DEFrjad0YolRc8FabIXGM',NULL,NULL,'desktop','Other','2026-08-17 01:59:50'),(2779,'/',NULL,NULL,'lBH1ObCjjPA7lopMblEeWAEJMDMX4DF7RIfMINBa',NULL,NULL,'desktop','Other','2026-08-17 02:44:18'),(2780,'/',NULL,NULL,'AnCnOJQZAMl6E8iCQ77flMiqoWNQY9znh3s2FHFB',NULL,NULL,'desktop','Other','2026-08-17 03:28:33'),(2781,'/',NULL,NULL,'RgPuwCGp50sjdmxxVZWlVQJvoYmm6iqKH6ngmGO1',NULL,NULL,'desktop','Other','2026-08-17 04:13:29'),(2782,'/',NULL,NULL,'qekubf0pF7XVkhBJicDrpjiTKP0PIWUxxj9aEnuf',NULL,NULL,'desktop','Chrome','2026-08-17 04:21:17'),(2783,'/',NULL,NULL,'jLckBLBOAVkMykhlNYptvptMuPNp5ZD7EfrROXJh',NULL,NULL,'desktop','Other','2026-08-17 04:57:53'),(2784,'/',NULL,NULL,'mD1gMf0La5jS6CqV4GXVwxhikeQDj0kQyDsc7ZEQ',NULL,NULL,'desktop','Other','2026-08-17 05:42:09'),(2785,'/',NULL,NULL,'s0aWAwBmhqf9elb6v72fN0oDNdLd5TKxvKwB2Eqt',NULL,NULL,'desktop','Other','2026-08-17 06:27:42'),(2786,'/',NULL,NULL,'H7KQoOYeC1GtiPbksfwqvsWtI6bwcwuQccN0E9ma',NULL,NULL,'desktop','Other','2026-08-17 07:13:10'),(2787,'/',NULL,NULL,'w2xJ9LExDTU94VMR0bxzouBRHEYHp42Tl2YS5de6',NULL,NULL,'desktop','Other','2026-08-17 07:16:07'),(2788,'/',NULL,NULL,'XjnGYHVLENmFe3HbjLOfjOB9xP2c6OrCrYJojH6w',NULL,NULL,'mobile','Chrome','2026-08-17 07:16:33'),(2789,'/',NULL,NULL,'qf7jwNuSLwC5XE9Wb41qdIR7yTkF7zAN6XEbod3R',NULL,NULL,'desktop','Other','2026-08-17 07:59:10'),(2790,'/',NULL,NULL,'ujZqAPUlPVHDsj27EwmKSRx4jGnyO9BvD15h41QN',NULL,NULL,'desktop','Other','2026-08-17 08:43:46'),(2791,'/',NULL,NULL,'jFrBCcaBfK6mBwKQE04df8z98d8ZgwEctpXOZsV4',NULL,NULL,'desktop','Other','2026-08-17 09:28:54'),(2792,'/',NULL,NULL,'6Qp9G6ndzIEBsmpFGSmEgOnn11bU9mZ5tvMsS3Om',NULL,NULL,'desktop','Other','2026-08-17 10:13:47'),(2793,'/',NULL,NULL,'6Q5Hr61IB1Q4ZrDXmJQFT18569sThOG82kkPLDfZ',NULL,NULL,'desktop','Other','2026-08-17 10:58:04'),(2794,'/',NULL,NULL,'Qxn7LthOgzgpQQlO6mTaCG2FkY6qT0SkFOa98WMH',NULL,NULL,'desktop','Other','2026-08-17 11:42:18'),(2795,'/',NULL,NULL,'BCxHQdpDmqpb106pn2E6SfYpXN0kdH5LWgwL4bDZ',NULL,NULL,'desktop','Other','2026-08-17 12:25:11'),(2796,'/',NULL,NULL,'rSqtJBFQhG6SmzRGZ4FHeQEW59Yj7TS3Omix8e6e',NULL,NULL,'desktop','Chrome','2026-08-17 12:33:17'),(2797,'/',NULL,NULL,'jRyFRZ8GW5HwdWf145mPofSL8XsBUIFPg0zlllDK',NULL,NULL,'desktop','Other','2026-08-17 13:08:49'),(2798,'/',NULL,NULL,'soD2W29z9p4oFPplxIBjW2zkOI7Pk8DzhVrUKBaB',NULL,NULL,'desktop','Other','2026-08-17 13:52:06'),(2799,'/',NULL,NULL,'LfaiJKJjuQeXGCxZJ2tx9i6uGSbTUW18lrZKnxIp',NULL,NULL,'desktop','Other','2026-08-17 14:35:07'),(2800,'/',NULL,NULL,'jKk6sbZookpidBCQACbj4HzT2RoWnPzdFOXPXqdz',NULL,NULL,'desktop','Other','2026-08-17 14:44:40'),(2801,'sitemap.xml',NULL,NULL,'jKk6sbZookpidBCQACbj4HzT2RoWnPzdFOXPXqdz',NULL,NULL,'desktop','Other','2026-08-17 14:44:41'),(2802,'/',NULL,NULL,'3NatqWosdwTV2GepLhxK21muNBmLPuujJr8JctSo',NULL,NULL,'desktop','Other','2026-08-17 14:44:42'),(2803,'contact',NULL,NULL,'jKk6sbZookpidBCQACbj4HzT2RoWnPzdFOXPXqdz',NULL,NULL,'desktop','Other','2026-08-17 14:44:43'),(2804,'shop/cart',NULL,NULL,'jKk6sbZookpidBCQACbj4HzT2RoWnPzdFOXPXqdz',NULL,NULL,'desktop','Other','2026-08-17 14:44:44'),(2805,'login',NULL,NULL,'jKk6sbZookpidBCQACbj4HzT2RoWnPzdFOXPXqdz',NULL,NULL,'desktop','Other','2026-08-17 14:44:44'),(2806,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'jKk6sbZookpidBCQACbj4HzT2RoWnPzdFOXPXqdz',NULL,NULL,'desktop','Other','2026-08-17 14:44:46'),(2807,'blog',NULL,NULL,'jKk6sbZookpidBCQACbj4HzT2RoWnPzdFOXPXqdz',NULL,NULL,'desktop','Other','2026-08-17 14:44:47'),(2808,'shop',NULL,NULL,'jKk6sbZookpidBCQACbj4HzT2RoWnPzdFOXPXqdz',NULL,NULL,'desktop','Other','2026-08-17 14:44:48'),(2809,'search',NULL,NULL,'jKk6sbZookpidBCQACbj4HzT2RoWnPzdFOXPXqdz',NULL,NULL,'desktop','Other','2026-08-17 14:44:49'),(2810,'/',NULL,NULL,'l3Pi6uJUXxrF1QrwHBeZkI074vG7RP22K2VsLAIN',NULL,NULL,'desktop','Other','2026-08-17 15:18:51'),(2811,'/',NULL,NULL,'7Su2wGxUgfVRlNL0yptpEUB3NeFUJhDMDabbTkUI',NULL,NULL,'desktop','Other','2026-08-17 16:02:12'),(2812,'/',NULL,NULL,'ds0q5k2rvhcaRIpjBgT7Oxh8YmloBgh3QOUuSN9B',NULL,NULL,'desktop','Other','2026-08-17 16:45:10'),(2813,'/',NULL,NULL,'O61PTkL7BBMtTanmLFjDHYCTia1WsTwnRQYCswDA',NULL,NULL,'desktop','Other','2026-08-17 17:29:40'),(2814,'/',NULL,NULL,'pBSrCF4OnUQNiPyWk8OGlgsPZZlWE9Zcrd31ZpEy',NULL,NULL,'mobile','Chrome','2026-08-17 17:41:07'),(2815,'/',NULL,NULL,'8oaQ1oo7eoF4mOcXGi95DbE18Dp2ki7lLLV8TS0q',NULL,NULL,'desktop','Other','2026-08-17 18:13:29'),(2816,'/',NULL,NULL,'P3TnE3cvD7i1G0Z6Hz3Zq3sD1CdKHSWIrol4dxr1',NULL,NULL,'desktop','Other','2026-08-17 18:57:14'),(2817,'/',NULL,NULL,'hFDp40SaEn7xh8ADnUx71ZgmLMrihDdAGvFezHQv',NULL,NULL,'desktop','Other','2026-08-17 19:40:00'),(2818,'/',NULL,NULL,'cW20y5pZtVbPuTozTGinn6EM4JbWlDS6RWmfrkIF',NULL,NULL,'desktop','Other','2026-08-17 20:23:42'),(2819,'/',NULL,NULL,'4MxEV0RGgjAu8DSPWnFsULkfsLIrjo7R5OU4UyE7',NULL,NULL,'desktop','Other','2026-08-17 21:07:26'),(2820,'/',NULL,NULL,'7NSBUKBc7j4kqjYhiOkz4gSjsmRNBMnkQji3VSbi',NULL,NULL,'desktop','Other','2026-08-17 21:51:12'),(2821,'search',NULL,NULL,'jr4Oi3ip08D5swOjhrhmbhx8OuEctnhaqq90Cn19',NULL,NULL,'mobile','Chrome','2026-08-17 22:10:51'),(2822,'/',NULL,NULL,'9YixFSl6zKY53q5FBYY6HZoUtX08JCvfv12FcwdI',NULL,NULL,'desktop','Other','2026-08-17 22:33:42'),(2823,'/',NULL,NULL,'QoURqzpVRGVar6XmOGQ26zhVyNsIU4rhBZptJuBO',NULL,NULL,'desktop','Other','2026-08-17 23:17:01'),(2824,'/',NULL,NULL,'DIJSaSN2C5ck0SFhiIuPKRXw7ncjm0nztFoGpPCS',NULL,NULL,'desktop','Other','2026-08-18 00:00:24'),(2825,'/',NULL,NULL,'cx8lFJkhhOQ6eYnBia36G6tv8m1UYY7CaAlKkrrE',NULL,NULL,'desktop','Other','2026-08-18 00:11:52'),(2826,'login',NULL,NULL,'7jgbvImkgmCbmDHEsoutppPpHljzgvx41zeWXVNT',NULL,NULL,'desktop','Firefox','2026-08-18 00:16:46'),(2827,'login',NULL,'https://safhenokhost.ir/admin/dashboard','cr5dhzkaLkKATYpRJ9kbhQd5TmZqeTVa6ZxQEPgN',1,NULL,'desktop','Firefox','2026-08-18 00:17:03'),(2828,'/',NULL,NULL,'cEaKRA46v91E1gaBbGCmZLfuuzKHd6wjsrZgSnbF',NULL,NULL,'desktop','Other','2026-08-18 00:43:19'),(2829,'/',NULL,NULL,'m3N2ex2i5794PG1fKpNmvCu1XC10dNuw5SYSZ3UT',NULL,NULL,'desktop','Other','2026-08-18 01:27:17'),(2830,'/',NULL,NULL,'FEkGRB8PFGmfcSCTRvCF5e53yX7Zd49SC3aETUUd',NULL,NULL,'desktop','Other','2026-08-18 02:12:25'),(2831,'/',NULL,NULL,'4b4dkLmC4SEkAKXpmEFPpuDxZDlRirQtITcKjoQn',NULL,NULL,'desktop','Other','2026-08-18 02:56:45'),(2832,'/',NULL,'https://safhenokhost.ir/','B9KFn9MZLzMgNOL1j0q3q89CNsWLoCUHEjgsriwy',NULL,NULL,'mobile','Safari','2026-08-18 03:39:31'),(2833,'/',NULL,NULL,'1wWVQy3jY9sCnHd95E28L6OM2JUAauKxjyIWO5IQ',NULL,NULL,'desktop','Other','2026-08-18 03:39:51'),(2834,'/',NULL,NULL,'OtjCigNaHc1ux2mxcTU656tlnNcrGLDBM4SlVauv',NULL,NULL,'desktop','Chrome','2026-08-18 03:40:12'),(2835,'/',NULL,NULL,'dT8GHMqgZ6vrMpymrwoKN8K5N0JsIk88C6KNXP54',NULL,NULL,'desktop','Other','2026-08-18 03:40:13'),(2836,'/',NULL,NULL,'YcDJDmoA7uC2CEZu1QdyXi72lio5EjSj0WDqnSxE',NULL,NULL,'desktop','Other','2026-08-18 03:40:13'),(2837,'/',NULL,NULL,'ScbGDelNf5iswKvG6XFJhUpH9PtoN8vcL4p2Na41',NULL,NULL,'desktop','Other','2026-08-18 03:40:13'),(2838,'/',NULL,NULL,'Bt43ediVwurKKlaxSw7eNxJjT1tfEWBkBMSpQ9PX',NULL,NULL,'desktop','Other','2026-08-18 03:40:13'),(2839,'/',NULL,NULL,'LryN6yBlJ1rvQYMboqpNmtk6v85jjxawsm3hpHqP',NULL,NULL,'desktop','Other','2026-08-18 03:40:20'),(2840,'/',NULL,NULL,'zO6fEe3rjQnLBPx4MSUM6VYKS6uU66o3YwjjrVlI',NULL,NULL,'desktop','Other','2026-08-18 03:40:21'),(2841,'/',NULL,NULL,'t7bT69gBRGb7VNPHnWdcrD2vqq9uBeu9ZqaFFBVu',NULL,NULL,'desktop','Other','2026-08-18 03:40:21'),(2842,'/',NULL,NULL,'k6UogCFafsl6gVCaU0AqZW8ylCKh89Fw8Ojgr1WS',NULL,NULL,'desktop','Other','2026-08-18 03:40:21'),(2843,'sitemap.xml',NULL,NULL,'SoTQFGQrUg3Oh7YF7j0Gs3PYK8X7q9J4SVsc0XVN',NULL,NULL,'desktop','Other','2026-08-18 03:40:29'),(2844,'/',NULL,NULL,'qARuw8VDAxsDBRwrK2UhkmMR9gyCqMNw4z9GzeuY',NULL,NULL,'desktop','Other','2026-08-18 03:40:30'),(2845,'/',NULL,NULL,'mH0lR84G3q11nh4PAHzCyOq6alPrxHk5IofAz3gz',NULL,NULL,'mobile','Safari','2026-08-18 03:40:34'),(2846,'/',NULL,NULL,'78KgfXPBAvH55V4dbWZwCktGtRMSCuAT2j8Nc5SF',NULL,NULL,'desktop','Chrome','2026-08-18 03:40:39'),(2847,'/',NULL,NULL,'cMua3Ta00N8NEraeWyqhsD8896o7hKYuUudSMbVm',NULL,NULL,'desktop','Chrome','2026-08-18 03:40:40'),(2848,'/',NULL,NULL,'IVFzO3mt9jOiyxECcH1tZAAqqpBxzDMN9Vhi9uFb',NULL,NULL,'desktop','Chrome','2026-08-18 03:40:40'),(2849,'/',NULL,NULL,'RnbAZCkvVwmEdryBuJvE5yNvhwYGa4tuXeR9bDV9',NULL,NULL,'desktop','Other','2026-08-18 03:40:41'),(2850,'/',NULL,NULL,'yAlPOQgMjBPtteZEzVuMoe5U5SW01UKnxeHRZEpl',NULL,NULL,'desktop','Other','2026-08-18 03:40:41'),(2851,'/',NULL,NULL,'Qej02RYE0SMwDIsBg2RoYnXRfSDEfm1wolpsIJSL',NULL,NULL,'desktop','Other','2026-08-18 03:40:42'),(2852,'/',NULL,NULL,'C1P0NRUYJhK2b62vNlzPWIQ4miqzo22aCy0qXULX',NULL,NULL,'desktop','Other','2026-08-18 03:40:46'),(2853,'/',NULL,NULL,'YAIFnWxPny8LS9q1dM6yDQVuzFexL2bu9mRqCEnt',NULL,NULL,'desktop','Other','2026-08-18 03:40:46'),(2854,'/',NULL,NULL,'U3wAKcGQNgC4UUFvtXzKu7cQwT84LLNav7zZbzDo',NULL,NULL,'desktop','Chrome','2026-08-18 03:40:50'),(2855,'/',NULL,NULL,'4hGujiSEy4IjyOSbUT3pIvtUUPz5aCqKRca7tOV0',NULL,NULL,'desktop','Chrome','2026-08-18 03:41:20'),(2856,'/',NULL,NULL,'OBeX8tHL4uvqga5l6Z314SuabpNTyNFGavCkZQfK',NULL,NULL,'desktop','Chrome','2026-08-18 03:41:34'),(2857,'/',NULL,NULL,'59Afs8F97YUEQEiVnd5b26Dzpwadg8yKzpYCtDaT',NULL,NULL,'desktop','Chrome','2026-08-18 03:42:56'),(2858,'/',NULL,NULL,'AQzILzPVoh5fESEHLjqyYbeqRzBHBxoHBNWFTDZM',NULL,NULL,'desktop','Chrome','2026-08-18 03:43:05'),(2859,'/',NULL,NULL,'KOHZeQ9pUDcz5yC1eDswqyR0unKU9eKuZMkFZV2B',NULL,NULL,'desktop','Chrome','2026-08-18 03:45:51'),(2860,'blog/sayt-hmh-karh',NULL,NULL,'KOHZeQ9pUDcz5yC1eDswqyR0unKU9eKuZMkFZV2B',NULL,NULL,'desktop','Chrome','2026-08-18 03:45:52'),(2861,'shop/cart',NULL,NULL,'KOHZeQ9pUDcz5yC1eDswqyR0unKU9eKuZMkFZV2B',NULL,NULL,'desktop','Chrome','2026-08-18 03:45:52'),(2862,'contact',NULL,NULL,'KOHZeQ9pUDcz5yC1eDswqyR0unKU9eKuZMkFZV2B',NULL,NULL,'desktop','Chrome','2026-08-18 03:45:52'),(2863,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'KOHZeQ9pUDcz5yC1eDswqyR0unKU9eKuZMkFZV2B',NULL,NULL,'desktop','Chrome','2026-08-18 03:45:52'),(2864,'search',NULL,NULL,'KOHZeQ9pUDcz5yC1eDswqyR0unKU9eKuZMkFZV2B',NULL,NULL,'desktop','Chrome','2026-08-18 03:45:52'),(2865,'login',NULL,NULL,'KOHZeQ9pUDcz5yC1eDswqyR0unKU9eKuZMkFZV2B',NULL,NULL,'desktop','Chrome','2026-08-18 03:45:52'),(2866,'shop',NULL,NULL,'KOHZeQ9pUDcz5yC1eDswqyR0unKU9eKuZMkFZV2B',NULL,NULL,'desktop','Chrome','2026-08-18 03:45:52'),(2867,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'KOHZeQ9pUDcz5yC1eDswqyR0unKU9eKuZMkFZV2B',NULL,NULL,'desktop','Chrome','2026-08-18 03:45:53'),(2868,'blog',NULL,NULL,'KOHZeQ9pUDcz5yC1eDswqyR0unKU9eKuZMkFZV2B',NULL,NULL,'desktop','Chrome','2026-08-18 03:45:53'),(2869,'blog/series/syo',NULL,NULL,'KOHZeQ9pUDcz5yC1eDswqyR0unKU9eKuZMkFZV2B',NULL,NULL,'desktop','Chrome','2026-08-18 03:45:53'),(2870,'register',NULL,NULL,'KOHZeQ9pUDcz5yC1eDswqyR0unKU9eKuZMkFZV2B',NULL,NULL,'desktop','Chrome','2026-08-18 03:45:53'),(2871,'shop/compare',NULL,NULL,'KOHZeQ9pUDcz5yC1eDswqyR0unKU9eKuZMkFZV2B',NULL,NULL,'desktop','Chrome','2026-08-18 03:45:53'),(2872,'shop/wishlist',NULL,NULL,'KOHZeQ9pUDcz5yC1eDswqyR0unKU9eKuZMkFZV2B',NULL,NULL,'desktop','Chrome','2026-08-18 03:45:54'),(2873,'blog/category/mhtoa',NULL,NULL,'KOHZeQ9pUDcz5yC1eDswqyR0unKU9eKuZMkFZV2B',NULL,NULL,'desktop','Chrome','2026-08-18 03:45:54'),(2874,'/',NULL,NULL,'RGq26Uvv50PYzBnfMjEvKjsTMhNR1ds0m2nC2um2',NULL,NULL,'desktop','Chrome','2026-08-18 03:46:14'),(2875,'blog',NULL,NULL,'RGq26Uvv50PYzBnfMjEvKjsTMhNR1ds0m2nC2um2',NULL,NULL,'desktop','Chrome','2026-08-18 03:46:15'),(2876,'search',NULL,NULL,'RGq26Uvv50PYzBnfMjEvKjsTMhNR1ds0m2nC2um2',NULL,NULL,'desktop','Chrome','2026-08-18 03:46:15'),(2877,'shop',NULL,NULL,'RGq26Uvv50PYzBnfMjEvKjsTMhNR1ds0m2nC2um2',NULL,NULL,'desktop','Chrome','2026-08-18 03:46:15'),(2878,'shop/cart',NULL,NULL,'RGq26Uvv50PYzBnfMjEvKjsTMhNR1ds0m2nC2um2',NULL,NULL,'desktop','Chrome','2026-08-18 03:46:15'),(2879,'contact',NULL,NULL,'RGq26Uvv50PYzBnfMjEvKjsTMhNR1ds0m2nC2um2',NULL,NULL,'desktop','Chrome','2026-08-18 03:46:15'),(2880,'blog/sayt-hmh-karh',NULL,NULL,'RGq26Uvv50PYzBnfMjEvKjsTMhNR1ds0m2nC2um2',NULL,NULL,'desktop','Chrome','2026-08-18 03:46:16'),(2881,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'RGq26Uvv50PYzBnfMjEvKjsTMhNR1ds0m2nC2um2',NULL,NULL,'desktop','Chrome','2026-08-18 03:46:16'),(2882,'blog/category/mhtoa',NULL,NULL,'RGq26Uvv50PYzBnfMjEvKjsTMhNR1ds0m2nC2um2',NULL,NULL,'desktop','Chrome','2026-08-18 03:46:16'),(2883,'shop/compare',NULL,NULL,'RGq26Uvv50PYzBnfMjEvKjsTMhNR1ds0m2nC2um2',NULL,NULL,'desktop','Chrome','2026-08-18 03:46:17'),(2884,'shop/wishlist',NULL,NULL,'RGq26Uvv50PYzBnfMjEvKjsTMhNR1ds0m2nC2um2',NULL,NULL,'desktop','Chrome','2026-08-18 03:46:17'),(2885,'blog/series/syo',NULL,NULL,'RGq26Uvv50PYzBnfMjEvKjsTMhNR1ds0m2nC2um2',NULL,NULL,'desktop','Chrome','2026-08-18 03:46:17'),(2886,'/',NULL,NULL,'3oSvdf4F3L83SIU57TqZ1UHSfUDXGbCljg5LMixH',NULL,NULL,'desktop','Firefox','2026-08-18 03:55:02'),(2887,'/',NULL,NULL,'Y49V26J2tBNTGp85oIZxmWc2RzGHKtC3fBcFgx9f',NULL,NULL,'desktop','Firefox','2026-08-18 04:10:00'),(2888,'/',NULL,NULL,'LQrk0aeqGVqWCaGwCdkIVONUw0xY6H7RuT0XtQeQ',NULL,NULL,'desktop','Chrome','2026-08-18 04:23:36'),(2889,'/',NULL,NULL,'67S6gtT32VtzGy8BI9nHU3Pq1fhj5EyTUoQm8CfF',NULL,NULL,'desktop','Other','2026-08-18 04:25:43'),(2890,'/',NULL,NULL,'yg9Y0ldrCgNSl6NpuXAUh9FBr8ejScBlBVdTZt4u',NULL,NULL,'desktop','Chrome','2026-08-18 04:29:34'),(2891,'/',NULL,NULL,'27ljZsuqez4wFS3txMrc0uNd1wENCoapndrzCMVn',NULL,NULL,'desktop','Chrome','2026-08-18 04:29:35'),(2892,'/',NULL,NULL,'FuK2TONSjcgfbJMkd81BtbqpUxKxEqp2A5oirdub',NULL,NULL,'desktop','Chrome','2026-08-18 04:29:45'),(2893,'/',NULL,NULL,'D0WjeMdqMaqkcwVpP61Qh4ZnJOhoej6vaUKN9dM1',NULL,NULL,'desktop','Chrome','2026-08-18 04:37:49'),(2894,'/',NULL,NULL,'J4TifyPIWxT8CZzkhR1vNdbZIW958hyBGp00SCqQ',NULL,NULL,'desktop','Chrome','2026-08-18 04:37:51'),(2895,'/',NULL,NULL,'Hf1RAhjckQyDHeBTlkQBYTd5w3DMR3XJpBDcBiei',NULL,NULL,'desktop','Chrome','2026-08-18 04:37:51'),(2896,'/',NULL,NULL,'t233AKwA0CTrYHsINLL3pweay0RRaMNk7To8zr68',NULL,NULL,'desktop','Other','2026-08-18 04:37:57'),(2897,'/',NULL,NULL,'nhYsyyyC7VjPkmUXFVzsfYOplusDnLmUB2E09El2',NULL,NULL,'desktop','Chrome','2026-08-18 04:37:57'),(2898,'/',NULL,NULL,'SMTwqBti4B3UfnhZi5a5GMQ847jNKKEbzlK7vkJl',NULL,NULL,'desktop','Chrome','2026-08-18 04:38:00'),(2899,'/',NULL,NULL,'NIuvMac4xeYNwDIP8CpjKWbQtsXokLBsz2PBJdX1',NULL,NULL,'desktop','Other','2026-08-18 04:47:50'),(2900,'/',NULL,NULL,'TkHVX0OkzRsLq0kcXQYmQmkGKSZx4gyuxsrm6kjQ',NULL,NULL,'desktop','Other','2026-08-18 04:47:51'),(2901,'/',NULL,NULL,'uKZUtNmt5Np5BqkWcvoUaSVTRHxMzXlnSkYyKUE6',NULL,NULL,'desktop','Other','2026-08-18 04:48:03'),(2902,'/',NULL,NULL,'3OuOxdNiUOLvHUZys90IYLg0rtsgsUYP5edj2sWV',NULL,NULL,'desktop','Other','2026-08-18 05:11:45'),(2903,'/',NULL,NULL,'lr6NUC7eDQjIAzXdWoiWf4g4bGrldaQnrGNyVevo',NULL,NULL,'desktop','Chrome','2026-08-18 05:17:57'),(2904,'search',NULL,NULL,'Xq9X1Zlwz23zFWanhet7jPEJX7SziBNLSHw0hHrN',NULL,NULL,'desktop','Other','2026-08-18 05:39:11'),(2905,'login',NULL,NULL,'cQcm36ZErhfob3I3TBVfXKlr9dFzIEng22q7DbIu',NULL,NULL,'desktop','Other','2026-08-18 05:39:11'),(2906,'shop',NULL,NULL,'QMH1B7V9JW06YAoHD7Qomhg6rKHIiSBNRVC8p40q',NULL,NULL,'desktop','Other','2026-08-18 05:39:14'),(2907,'contact',NULL,NULL,'cdCzcthv9wA9Z3I2hbUE2ZkcyGlWzI0GJlGmWl6E',NULL,NULL,'desktop','Other','2026-08-18 05:39:20'),(2908,'blog',NULL,NULL,'XWrB17nrraB38e9L5z48VV6GN0wWvl2TY3zYUkfY',NULL,NULL,'desktop','Other','2026-08-18 05:40:11'),(2909,'shop/cart',NULL,NULL,'Hu0XD0lFop8YsjCAekBZx6OgWjft6vfHOoAqIObj',NULL,NULL,'desktop','Other','2026-08-18 05:42:03'),(2910,'blog/sayt-hmh-karh',NULL,NULL,'2fR3JoxU2UJhEkLycaL2WQ4hyi0EmOmH0iRLoUum',NULL,NULL,'desktop','Other','2026-08-18 05:43:37'),(2911,'blog/dr-mord-jam-jhany-fotbal-2026-chh-my-danyd',NULL,NULL,'StNz4tpK5EhxZdlCzQF0lav76IDxEC3idsYQPx04',NULL,NULL,'desktop','Other','2026-08-18 05:44:54'),(2912,'page/drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma',NULL,NULL,'dC8yoqYAanTWY2oEQdubVhWi7r0prsHrTt2jE4ir',NULL,NULL,'desktop','Other','2026-08-18 05:44:57'),(2913,'/',NULL,NULL,'4NvMbT6gF3UFahQaJqwYdnaOyPAFiYIeXkO3jpJu',NULL,NULL,'desktop','Other','2026-08-18 05:57:05'),(2914,'/',NULL,NULL,'QAzYw6o4ida34rwvRxQEHSV7KlZ8fgAlT4eUMgeb',NULL,NULL,'desktop','Firefox','2026-08-18 06:03:06'),(2915,'/',NULL,NULL,'PU36NzlUjEqp9Ur8aRNhKjvJhVn7hyUb7YeBxCHk',NULL,NULL,'mobile','Chrome','2026-08-18 06:32:30'),(2916,'shop/compare',NULL,NULL,'xUPewQYa9Va6QIl7GCF34dr4rYKBxg72EqHlqFMD',NULL,NULL,'desktop','Other','2026-08-18 06:39:50'),(2917,'register',NULL,NULL,'CSDKkECW3rv2Ieinwq04CjwDX633sU7raxsCxIhm',NULL,NULL,'desktop','Other','2026-08-18 06:39:51'),(2918,'blog/category/mhtoa',NULL,NULL,'anlTnL480yQ0QaQrSlycD8y2WcwbP866UO88SA7y',NULL,NULL,'desktop','Other','2026-08-18 06:39:59'),(2919,'shop/wishlist',NULL,NULL,'ePTv3leQqC0a4HjibcHFo0xEGd0pbVwKMWfATdZQ',NULL,NULL,'desktop','Other','2026-08-18 06:39:59'),(2920,'blog/series/syo',NULL,NULL,'S6vSVuJQQjIzqpRMFsaOYQEWBKrOyuM2ixgVeA80',NULL,NULL,'desktop','Other','2026-08-18 06:40:14'),(2921,'blog',NULL,NULL,'O5Ua5hsImAqStETFIE04GRjgJb1ju5PPMlcZBOvT',NULL,NULL,'desktop','Other','2026-08-18 06:41:10'),(2922,'/',NULL,NULL,'hhAPCAQMX7z34NIFcP4SCNLpQoKDz1hLEsk9Ygxh',NULL,NULL,'desktop','Other','2026-08-18 06:41:49'),(2923,'blog',NULL,NULL,'j4m1Mk4gYYvaG1zBUOW6shI4ojes4xpOejoO1pNE',NULL,NULL,'desktop','Other','2026-08-18 06:41:54'),(2924,'blog',NULL,NULL,'HIBsldTCPngJCMt15QgrkwKMGCCr2aJ67uy6onPb',NULL,NULL,'desktop','Other','2026-08-18 06:43:56'),(2925,'blog',NULL,NULL,'p7tNNp69XAgwzD7SaBz9Zg4hVeBDr2A4PkFarbZx',NULL,NULL,'desktop','Other','2026-08-18 06:44:49'),(2926,'blog',NULL,NULL,'WIjYoFXsf6lGyan0DdACH2SzrYutUbWphUuj4oEv',NULL,NULL,'desktop','Other','2026-08-18 06:45:38'),(2927,'blog',NULL,NULL,'ivCNk6KJo4AyGlEOM1etEjrUksvmLp4ssitHrB0b',NULL,NULL,'desktop','Other','2026-08-18 06:46:00'),(2928,'login',NULL,'https://safhenokhost.ir/admin/dashboard','cr5dhzkaLkKATYpRJ9kbhQd5TmZqeTVa6ZxQEPgN',1,NULL,'desktop','Firefox','2026-08-18 06:49:57'),(2929,'sitemap.xml',NULL,NULL,'u9JAnKd6XhAM2ZQ6H6fjhC20lYTP4b3IbTNY7hqj',NULL,NULL,'desktop','Other','2026-08-18 07:04:17'),(2930,'/',NULL,NULL,'tWprM4YjcvjjNRgVqrytaY7UZHQKAYOEhJF8MoUW',NULL,NULL,'desktop','Other','2026-08-18 07:26:48'),(2931,'/',NULL,'https://www.google.com/','wF7CeSWTipYzIkezR2OoDnrAlVj2bIZ1TABUOWsl',NULL,NULL,'desktop','Chrome','2026-08-18 07:57:05'),(2932,'/',NULL,'https://www.bing.com/','ehiKICjCtH00qVjlrMlhuz3YkSwtwoQ8xHqFFCEx',NULL,NULL,'desktop','Safari','2026-08-18 07:58:06'),(2933,'sitemap.xml',NULL,NULL,'hHtKTfy9woehyy3X96VsbiXaBGyIYff8BhNcTqIw',NULL,NULL,'desktop','Other','2026-08-18 08:05:48'),(2934,'login',NULL,'https://safhenokhost.ir/admin/dashboard','cr5dhzkaLkKATYpRJ9kbhQd5TmZqeTVa6ZxQEPgN',1,NULL,'desktop','Firefox','2026-08-18 08:06:02'),(2935,'/',NULL,NULL,'6YWql1n9QTZRSVoleSntiyyuXJpyoItKnwKTwAzu',NULL,NULL,'desktop','Chrome','2026-08-18 08:10:35'),(2936,'/',NULL,NULL,'Paoas9fYazIEvpq2ONAwYNTb5oVLNNorGQ1eebGq',NULL,NULL,'desktop','Other','2026-08-18 08:11:53'),(2937,'forms',NULL,NULL,'6Y6kIpGsEFSVle7dEs6LlK0JM0Yarno9IhrsuKAP',NULL,NULL,'desktop','Other','2026-08-18 08:15:45'),(2938,'/',NULL,NULL,'HT2K52X7YQQJqfmQI4c7g3sV1fDTV8vZrFTKrcfy',NULL,NULL,'desktop','Other','2026-08-18 08:57:03'),(2939,'sitemap.xml',NULL,NULL,'MwOa9B0vES6vbVthqcqh4Zj8cuO4jEd7ojg4eT9j',NULL,NULL,'desktop','Other','2026-08-18 09:00:31'),(2940,'/',NULL,NULL,'BoOaf9TMbpsRHAjCuRQZIe6bRsckSR4nfMmm5pHG',NULL,NULL,'desktop','Other','2026-08-18 09:45:45'),(2941,'sitemap.xml',NULL,NULL,'zlFAGF8q0ndn0ba21QQ3IEXDPQvkrhCm9mik7tSk',NULL,NULL,'desktop','Other','2026-08-18 10:08:01'),(2942,'/',NULL,NULL,'WfuxNhOcX57OzBMX6JzuzQA90hMGpDqcQEezM8Iz',NULL,NULL,'desktop','Other','2026-08-18 10:34:23'),(2943,'/',NULL,NULL,'fkGzAyY9XJUBxkbPaEKYVperAxfOVwV4Z1dUcJDl',NULL,NULL,'mobile','Safari','2026-08-18 11:10:46'),(2944,'/',NULL,NULL,'j6JNCHKxwfrBM3NHY4IUB24gKydqMgYM5w7qFKEh',NULL,NULL,'desktop','Other','2026-08-18 11:22:57'),(2945,'/',NULL,NULL,'EE4j1Skt2IPOUvcOwfz3TovIw8XOFJvFuZ589vSX',NULL,NULL,'desktop','Other','2026-08-18 12:12:27'),(2946,'/',NULL,NULL,'WIxoY7I5MpagQxTbre57HkZZAxQr6kA1rjMh0KEI',NULL,NULL,'desktop','Chrome','2026-08-18 12:36:06'),(2947,'blog',NULL,NULL,'MjW5xwn8yMkalUcO3Z3wjYQduetcUs1HtqoVPEiP',NULL,NULL,'desktop','Chrome','2026-08-18 12:36:08'),(2948,'shop',NULL,NULL,'rdL1ofZpewl4d19E3DNDwVejgwKAVCiK5Q8nOlbl',NULL,NULL,'desktop','Chrome','2026-08-18 12:36:09'),(2949,'login',NULL,NULL,'kODZsJizTnuxA9cCh2kEkDMq4PWVrEbgLYPToHsT',NULL,NULL,'desktop','Chrome','2026-08-18 12:36:10'),(2950,'/',NULL,NULL,'QZ8rMnM1nwV4wxXeTDsC4Pd6cgOpQIOtgMLirh4O',NULL,NULL,'desktop','Chrome','2026-08-18 12:36:12'),(2951,'contact',NULL,NULL,'watXDFdvTTzA8IbBd5dRCxXKrRwXMhSpA3WT3jUR',NULL,NULL,'desktop','Chrome','2026-08-18 12:36:13'),(2952,'shop/cart',NULL,NULL,'WP6KOEu04NA6sW2LhpZZQiX6Pqe3PUElXKx1TKxE',NULL,NULL,'desktop','Chrome','2026-08-18 12:36:14'),(2953,'search',NULL,NULL,'o4TkgtmAYbzhsCWx5YUNVOD89vsJxN1iHbz1b5jp',NULL,NULL,'desktop','Chrome','2026-08-18 12:36:15'),(2954,'/',NULL,'https://safhenokhost.ir/','fwrS8CL87sR7XNrdTTGCJLkUsSzv4NhIBjVt5VIF',NULL,NULL,'mobile','Safari','2026-08-18 12:47:13'),(2955,'/',NULL,NULL,'ZkUDxwLIo8bOG7Oe1U5H03qDx4nD8iXSzWcVZDC0',NULL,NULL,'desktop','Other','2026-08-18 13:01:07'),(2956,'/',NULL,NULL,'bbDhCI5rMyO68jBQdSHlxfEPUK5QGteNz7KvsfgP',NULL,NULL,'desktop','Other','2026-08-18 13:50:12'),(2957,'/',NULL,NULL,'p1kJBZMa1AvXsM2HKGrkeHcN4hr0QxzoOOvgFL4m',NULL,NULL,'desktop','Other','2026-08-18 14:38:43'),(2958,'/',NULL,NULL,'DqkDI3xNAsCuASQFHoYQUwFGQj0TiAN6q3RDUWiM',NULL,NULL,'desktop','Chrome','2026-08-18 14:58:51'),(2959,'/',NULL,NULL,'cAJAd9wwNDOSEgwwUGsruZAWbkEYQBHBUnwDJqXP',NULL,NULL,'desktop','Other','2026-08-18 15:27:54'),(2960,'/',NULL,NULL,'BaKP1B3SU4nWoPxv1p9M0Aat4SLJloov243zxqkI',NULL,NULL,'desktop','Other','2026-08-18 16:16:22'),(2961,'/',NULL,NULL,'0RUO6PotlBSPhYA1HuUDG1F4vaYqT9UgApoerG6F',NULL,NULL,'desktop','Other','2026-08-18 17:04:14'),(2962,'/',NULL,NULL,'rNNypG9Ib60rinT2EFXGAYL4QW012FNunvQ1f3VQ',NULL,NULL,'desktop','Other','2026-08-18 17:53:02'),(2963,'/',NULL,NULL,'mwW13MQ3Znk3IYbhip4p9szgMarBIh3zDj8pawh1',NULL,NULL,'desktop','Chrome','2026-08-18 18:22:57'),(2964,'contact',NULL,'https://safhenokhost.ir/','mwW13MQ3Znk3IYbhip4p9szgMarBIh3zDj8pawh1',NULL,NULL,'desktop','Chrome','2026-08-18 18:22:57'),(2965,'/',NULL,NULL,'ZIRVvi0mq2atZilI2cZZSFhsMSUjrLwc8DGUSKA9',NULL,NULL,'desktop','Firefox','2026-08-18 18:32:18'),(2966,'/',NULL,NULL,'OaaFVA7TD7OU5MzW3xW1vXiTkauKB191k8wpxVfR',NULL,NULL,'desktop','Other','2026-08-18 18:41:48'),(2967,'/',NULL,NULL,'HtnsDYRMQTB8WmSP3fWMBos4VQOm6zhpWB6KKKHo',NULL,NULL,'desktop','Other','2026-08-18 19:30:41'),(2968,'/',NULL,NULL,'ltBDgbZ36pPivWUGJEZJ5f0AjZdjmLZEXCOICILw',NULL,NULL,'desktop','Other','2026-08-18 20:01:05'),(2969,'/',NULL,NULL,'f4lTu4Sh3nZpwJuqx0xBoDBlyOtTP00NRgvObFpY',NULL,NULL,'desktop','Other','2026-08-18 20:19:19'),(2970,'/',NULL,NULL,'kNJSfIqc2qu1000Pd4iuuVHYc3T4wTSvddWuVMjT',NULL,NULL,'desktop','Chrome','2026-08-18 20:38:02'),(2971,'login',NULL,NULL,'2ZBBdBvjmgvFAs64tFKDW5grCPyFhWroOYshZ3Ag',NULL,NULL,'desktop','Chrome','2026-08-18 20:40:42'),(2972,'/',NULL,NULL,'Ft8XDEzxsRRVo0b6cPx5QXXnnig8JuflZTLb7gH9',NULL,NULL,'desktop','Other','2026-08-18 21:09:34'),(2973,'/',NULL,NULL,'Q1kasolobxQxgWzyZuiB0H7Z6EPeZua0EWphI5Cg',NULL,NULL,'desktop','Other','2026-08-18 21:26:37'),(2974,'/',NULL,NULL,'Hdy9iYYVe6XSEGgYSFt9hkBhSiIFyJHDPK8NhKWt',NULL,NULL,'desktop','Other','2026-08-18 21:58:47'),(2975,'/',NULL,NULL,'V1Y6KKTJtesA8ww3Vr4PgX7Z8Hzc5GD1Zcv7gXmh',NULL,NULL,'desktop','Other','2026-08-18 22:46:36'),(2976,'/',NULL,NULL,'B8cmWRhEcHImBewZoUiAe9JvL0bA41394MXWPqnl',NULL,NULL,'desktop','Other','2026-08-18 23:34:45'),(2977,'/',NULL,NULL,'bA8SbQJRURONpE6DgZozdiHKNwn7SOjnWjoqmzj5',NULL,NULL,'desktop','Chrome','2026-08-18 23:54:29'),(2978,'/',NULL,NULL,'WpFFNkEvvPSfiEMeDSCdE0ZorooYFzZ1SJh1OPwv',NULL,NULL,'desktop','Chrome','2026-08-19 00:21:06'),(2979,'/',NULL,NULL,'Vw05XAiV0yPh47vpZTxFQU8BOQ2orU8Fw725LMpS',NULL,NULL,'desktop','Other','2026-08-19 00:23:30'),(2980,'/',NULL,NULL,'LT425o4whgCNQrRZvFKcnD7x1Aj9Upkq7OTm58eT',NULL,NULL,'desktop','Other','2026-08-19 01:12:46'),(2981,'/',NULL,NULL,'p4TIilAAOv3sd7EF0ZyMtAhRdAaF6ASAQ4HYJ1Ha',NULL,NULL,'desktop','Other','2026-08-19 02:01:45'),(2982,'/',NULL,NULL,'XXSSOQFryrgBRQ468NBSULPFYFf1gAz76UZDIF3N',NULL,NULL,'desktop','Other','2026-08-19 02:49:57'),(2983,'/',NULL,NULL,'YWwPYqV5wFZ2FeruFpxxwXe2oOIxK1dIfYinu1MM',NULL,NULL,'desktop','Firefox','2026-08-19 03:09:55'),(2984,'login',NULL,NULL,'YWwPYqV5wFZ2FeruFpxxwXe2oOIxK1dIfYinu1MM',NULL,NULL,'desktop','Firefox','2026-08-19 03:09:57'),(2985,'login',NULL,'https://safhenokhost.ir/admin/dashboard','jzmTAUocOGnLgLlqFOe5bbxgdDPTe8IalQjW83j4',1,NULL,'desktop','Firefox','2026-08-19 03:10:12'),(2986,'/',NULL,NULL,'nsxKo951kCiAuDfGWdDGlHPhWwM46KwE8V3ivalM',NULL,NULL,'desktop','Other','2026-08-19 03:38:03'),(2987,'/',NULL,NULL,'PZzBx3Bfgyq7DzLI7SwJhzAVyVuzADL1wuTUkYax',NULL,NULL,'desktop','Other','2026-08-19 04:26:11'),(2988,'/',NULL,NULL,'sQs5Bsnl87a9yatSK9QsMLRCq6bOJaMPKyuV67s9',NULL,NULL,'desktop','Other','2026-08-19 05:15:01'),(2989,'/',NULL,NULL,'BDyBVHH9n1bKUhtLVo2WvvrJObpZXZktpixGwaL7',NULL,NULL,'desktop','Firefox','2026-08-19 05:15:08'),(2990,'/',NULL,NULL,'u8OyvWhWRNXM5S82dL0WSuGs6FA224mb5eP7fA0m',NULL,NULL,'desktop','Other','2026-08-19 06:03:44'),(2991,'/',NULL,NULL,'4pp3OQeHUpZ2m55NDD0toUfLjK0NRTjZHLhaNoVs',NULL,NULL,'desktop','Other','2026-08-19 06:49:52'),(2992,'/',NULL,NULL,'SrdeO8cRdIfZaB6ZAPhD0cAi1DpuunNsCnNYCkRz',NULL,NULL,'desktop','Other','2026-08-19 07:36:37'),(2993,'/',NULL,NULL,'hsul9UbnqkULQpkE0ftHdcD1ROlnZEdy2k69kooJ',NULL,NULL,'desktop','Other','2026-08-19 08:23:13'),(2994,'/',NULL,NULL,'sDlrzP2iFZgmVcw1HxXCgzKYG1xLEuCSh1v3Mj1m',NULL,NULL,'desktop','Other','2026-08-19 08:50:07'),(2995,'blog',NULL,NULL,'sDILUo6cbTAKCyTnwjEEYzCMwKJ3iHdEdwzB5ZS4',NULL,NULL,'desktop','Other','2026-08-19 09:02:10'),(2996,'blog',NULL,NULL,'d23PQ0R1p7hTHabecsuaWsDSOaL4jh7vcJKXIwcj',NULL,NULL,'desktop','Other','2026-08-19 09:04:39'),(2997,'blog',NULL,NULL,'KFnFsd8ffz4IGtRJajPH2h1D3RLRba7MUIW8PnuY',NULL,NULL,'desktop','Other','2026-08-19 09:05:36'),(2998,'blog',NULL,NULL,'V79COSpmHK7YHLlhSbe4HVztABdOWps5auT5nv29',NULL,NULL,'desktop','Other','2026-08-19 09:06:20'),(2999,'/',NULL,NULL,'DLCZjmXY7gqnQ6WMnuzxUfqTINqg7JEWSSmmz6sj',NULL,NULL,'desktop','Other','2026-08-19 09:10:22'),(3000,'/',NULL,NULL,'8B55o5OKcWIMYyqONV5B6VnHiSzm6mnSg89JN1KT',NULL,NULL,'desktop','Other','2026-08-19 09:57:19'),(3001,'sitemap.xml',NULL,NULL,'8T5VMITQZ13t5DPj2pjLrrTh5iR8Mz10KeaEbOW3',NULL,NULL,'desktop','Other','2026-08-19 10:11:56'),(3002,'/',NULL,NULL,'UwL46lQKdG2pxBtPqy5EqbxuZgKKRYr5MTNeQbSD',NULL,NULL,'desktop','Other','2026-08-19 10:43:29'),(3003,'/',NULL,NULL,'PXPdDyM2eiTGdpuM8u1CgKiZrPQ85j4LXTQd0eR5',NULL,NULL,'desktop','Other','2026-08-19 11:07:28'),(3004,'/',NULL,NULL,'J2CDNV83BetqIDvp7Q5SjUwLGv46KraHTDwmxTd1',NULL,NULL,'desktop','Other','2026-08-19 11:29:16'),(3005,'login',NULL,'https://safhenokhost.ir/login','glgjYA11uh0RNJ9q4wKv7cdnfTf0Z6QuLTiplvdq',NULL,NULL,'desktop','Firefox','2026-08-19 11:31:45'),(3006,'/',NULL,NULL,'rKTYKRITUgtlM6r4eezegj9b1Pa2mVk1QYDabiQW',NULL,NULL,'desktop','Other','2026-08-19 12:15:40'),(3007,'sitemap.xml',NULL,NULL,'6PpNTgOXnh7bJJxvi2S2qEZIBrhjzmmuRMFTLNoK',NULL,NULL,'desktop','Other','2026-08-19 12:17:24'),(3008,'/',NULL,NULL,'ic7XAc9E2fbTJ8lNN4eMNTHXU0A6poDG09hbm1Hs',NULL,NULL,'desktop','Other','2026-08-19 13:01:15'),(3009,'/',NULL,NULL,'i3cZzO4fs4qjBOgMnoZwIvbaycJFuY8zoYosVRd8',NULL,NULL,'desktop','Other','2026-08-19 13:47:22'),(3010,'sitemap.xml',NULL,NULL,'mD9p3m4084fgPUJIkusXj9E30GCN5JHgLm9WvUBY',NULL,NULL,'desktop','Other','2026-08-19 13:57:00'),(3011,'sitemap.xml',NULL,NULL,'G1W6Di312HkZFeFY69N7gdDfAOyAxYS7ysd7fjmu',NULL,NULL,'desktop','Other','2026-08-19 14:20:49'),(3012,'/',NULL,NULL,'AdX7rK8zUbByQq9sm4nsYnC6WltLnBHeIoNbopxF',NULL,NULL,'desktop','Other','2026-08-19 14:32:43'),(3013,'/',NULL,NULL,'robvvWu1h1q7kwSE8ILbeB6SlsDGOgF0CTOkDlHp',NULL,NULL,'desktop','Chrome','2026-08-19 14:38:23'),(3014,'/',NULL,NULL,'zgcEaNNlAmvPKOp8jxAjtIM7kgBzqKP8Fk8tABP2',NULL,NULL,'desktop','Other','2026-08-19 15:18:47'),(3015,'login',NULL,'https://safhenokhost.ir/login','b2zuUDCFBJ9iTpagCHzcbjfAs9cKyIbPsrrYzV7L',NULL,NULL,'desktop','Firefox','2026-08-19 15:34:17'),(3016,'login',NULL,'https://safhenokhost.ir/admin/dashboard','HLG55YdTLK7XHmWNScp6ZZrEBShOqfosjkuFH6xg',1,NULL,'desktop','Firefox','2026-08-19 15:34:38'),(3017,'/',NULL,NULL,'MlMLhVuNmKZLhJiW7UNDUdfJ6fZRfYpqryQQ6div',NULL,NULL,'desktop','Other','2026-08-19 15:39:03'),(3018,'/',NULL,NULL,'lSvR5k33aQPMcIZtUgk5CGRLDXTKGGXGIC1aZ4dC',NULL,NULL,'desktop','Other','2026-08-19 16:04:33'),(3019,'/',NULL,NULL,'O7zcP9PouG5WI2L0tUJNg7LKjFpiMOpXwpKT1fg6',NULL,NULL,'desktop','Other','2026-08-19 16:49:42'),(3020,'login',NULL,'https://safhenokhost.ir/admin/license','HLG55YdTLK7XHmWNScp6ZZrEBShOqfosjkuFH6xg',1,NULL,'desktop','Firefox','2026-08-19 17:15:35');
/*!40000 ALTER TABLE `analytics_page_views` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `business_cards`
--

DROP TABLE IF EXISTS `business_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `business_cards` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `order` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `business_cards_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `business_cards`
--

LOCK TABLES `business_cards` WRITE;
/*!40000 ALTER TABLE `business_cards` DISABLE KEYS */;
/*!40000 ALTER TABLE `business_cards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES ('laravel-cache-canvas_theme_data','s:0:\"\";',1787275366),('laravel-cache-illuminate:queue:restart','i:1787219831;',2102579831),('laravel-cache-license.current','O:18:\"App\\Models\\License\":33:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:8:\"licenses\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:12:{s:2:\"id\";i:2;s:11:\"license_key\";s:228:\"eyJpdiI6IldnWGUxL2xwT0QvVE9TTmtKVmtYY3c9PSIsInZhbHVlIjoiTDMrMVVRRit0eVNucDZDcEkrdlJNYkY5K1BXWHQ0VldzbHNVdW5DUHVFQT0iLCJtYWMiOiIwMWMwNjAxZDNhMzJjNTIzZjRiNGFmOTQyNDM3N2M5MDVjZWE5ODdjMDU1MTQ3MGNiODBkZjVhYTVlZjI4ZDEwIiwidGFnIjoiIn0=\";s:6:\"domain\";s:15:\"safhenokhost.ir\";s:10:\"expires_at\";s:19:\"2031-06-09 23:49:18\";s:7:\"modules\";s:741:\"[\"captcha\", \"module_labels\", \"blog\", \"shop\", \"forms\", \"advertisements\", \"bank_gateway\", \"coupon\", \"reviews\", \"referral\", \"subscription\", \"whatsapp\", \"sms\", \"courses\", \"invoice\", \"business_card\", \"social_links\", \"notifications\", \"advanced_search\", \"currency_reform\", \"seo_advanced\", \"multi_currency\", \"marketplace_sync\", \"video\", \"projects\", \"qa\", \"menu\", \"announcements\", \"backup\", \"cloud\", \"podcast\", \"marketing_automation\", \"discount_advanced\", \"wallet\", \"product_bundling\", \"shipping\", \"inventory\", \"accounting\", \"gallery\", \"services\", \"tasks\", \"contract\", \"media\", \"brand\", \"i18n\", \"crm\", \"analytics\", \"recruitment\", \"portfolio\", \"omnichannel\", \"support\", \"installments\", \"translations\", \"homepage_videos\", \"access_lists\", \"smart_image\"]\";s:18:\"support_expires_at\";s:19:\"2031-03-21 00:00:00\";s:17:\"support_starts_at\";N;s:13:\"support_level\";s:5:\"basic\";s:14:\"platform_valid\";i:1;s:17:\"last_validated_at\";s:19:\"2026-08-19 21:06:34\";s:10:\"created_at\";s:19:\"2026-06-09 23:52:54\";s:10:\"updated_at\";s:19:\"2026-08-19 21:06:34\";}s:11:\"\0*\0original\";a:12:{s:2:\"id\";i:2;s:11:\"license_key\";s:228:\"eyJpdiI6IldnWGUxL2xwT0QvVE9TTmtKVmtYY3c9PSIsInZhbHVlIjoiTDMrMVVRRit0eVNucDZDcEkrdlJNYkY5K1BXWHQ0VldzbHNVdW5DUHVFQT0iLCJtYWMiOiIwMWMwNjAxZDNhMzJjNTIzZjRiNGFmOTQyNDM3N2M5MDVjZWE5ODdjMDU1MTQ3MGNiODBkZjVhYTVlZjI4ZDEwIiwidGFnIjoiIn0=\";s:6:\"domain\";s:15:\"safhenokhost.ir\";s:10:\"expires_at\";s:19:\"2031-06-09 23:49:18\";s:7:\"modules\";s:741:\"[\"captcha\", \"module_labels\", \"blog\", \"shop\", \"forms\", \"advertisements\", \"bank_gateway\", \"coupon\", \"reviews\", \"referral\", \"subscription\", \"whatsapp\", \"sms\", \"courses\", \"invoice\", \"business_card\", \"social_links\", \"notifications\", \"advanced_search\", \"currency_reform\", \"seo_advanced\", \"multi_currency\", \"marketplace_sync\", \"video\", \"projects\", \"qa\", \"menu\", \"announcements\", \"backup\", \"cloud\", \"podcast\", \"marketing_automation\", \"discount_advanced\", \"wallet\", \"product_bundling\", \"shipping\", \"inventory\", \"accounting\", \"gallery\", \"services\", \"tasks\", \"contract\", \"media\", \"brand\", \"i18n\", \"crm\", \"analytics\", \"recruitment\", \"portfolio\", \"omnichannel\", \"support\", \"installments\", \"translations\", \"homepage_videos\", \"access_lists\", \"smart_image\"]\";s:18:\"support_expires_at\";s:19:\"2031-03-21 00:00:00\";s:17:\"support_starts_at\";N;s:13:\"support_level\";s:5:\"basic\";s:14:\"platform_valid\";i:1;s:17:\"last_validated_at\";s:19:\"2026-08-19 21:06:34\";s:10:\"created_at\";s:19:\"2026-06-09 23:52:54\";s:10:\"updated_at\";s:19:\"2026-08-19 21:06:34\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:7:{s:11:\"license_key\";s:30:\"App\\Casts\\EncryptedOrPlaintext\";s:10:\"expires_at\";s:8:\"datetime\";s:18:\"support_expires_at\";s:8:\"datetime\";s:17:\"support_starts_at\";s:8:\"datetime\";s:7:\"modules\";s:5:\"array\";s:14:\"platform_valid\";s:7:\"boolean\";s:17:\"last_validated_at\";s:8:\"datetime\";}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:9:{i:0;s:11:\"license_key\";i:1;s:6:\"domain\";i:2;s:10:\"expires_at\";i:3;s:7:\"modules\";i:4;s:18:\"support_expires_at\";i:5;s:17:\"support_starts_at\";i:6;s:13:\"support_level\";i:7;s:14:\"platform_valid\";i:8;s:17:\"last_validated_at\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1787275539),('laravel-cache-mobile:security:patches:global','a:5:{s:11:\"PLAT-M1-001\";a:8:{s:8:\"severity\";s:4:\"high\";s:4:\"type\";s:8:\"security\";s:5:\"title\";s:32:\"HMAC-SHA256 OTA Manifest Signing\";s:11:\"description\";s:92:\"Enforces HMAC-SHA256 signing on all OTA manifests. Prevents unauthorized manifest injection.\";s:19:\"applies_to_versions\";a:0:{}s:6:\"source\";s:17:\"platform_registry\";s:2:\"id\";s:11:\"PLAT-M1-001\";s:13:\"registered_at\";s:25:\"2026-08-20T09:56:51+00:00\";}s:11:\"PLAT-M1-002\";a:8:{s:8:\"severity\";s:4:\"high\";s:4:\"type\";s:8:\"security\";s:5:\"title\";s:33:\"Sanctum Mobile API Authentication\";s:11:\"description\";s:84:\"Enforces token-based authentication on all mobile API endpoints via Laravel Sanctum.\";s:19:\"applies_to_versions\";a:0:{}s:6:\"source\";s:17:\"platform_registry\";s:2:\"id\";s:11:\"PLAT-M1-002\";s:13:\"registered_at\";s:25:\"2026-08-20T09:56:51+00:00\";}s:11:\"PLAT-M1-003\";a:8:{s:8:\"severity\";s:6:\"normal\";s:4:\"type\";s:8:\"security\";s:5:\"title\";s:35:\"Device Security Baseline Validation\";s:11:\"description\";s:101:\"Enforces minimum OS version (iOS 15, Android 10) and jailbreak/root detection on device registration.\";s:19:\"applies_to_versions\";a:0:{}s:6:\"source\";s:17:\"platform_registry\";s:2:\"id\";s:11:\"PLAT-M1-003\";s:13:\"registered_at\";s:25:\"2026-08-20T09:56:51+00:00\";}s:11:\"PLAT-M1-004\";a:8:{s:8:\"severity\";s:6:\"normal\";s:4:\"type\";s:8:\"security\";s:5:\"title\";s:36:\"WebSocket Channel HMAC Authorization\";s:11:\"description\";s:89:\"Enforces HMAC token authorization (300s TTL) on all Reverb WebSocket channel connections.\";s:19:\"applies_to_versions\";a:0:{}s:6:\"source\";s:17:\"platform_registry\";s:2:\"id\";s:11:\"PLAT-M1-004\";s:13:\"registered_at\";s:25:\"2026-08-20T09:56:51+00:00\";}s:11:\"PLAT-M1-005\";a:8:{s:8:\"severity\";s:6:\"normal\";s:4:\"type\";s:10:\"governance\";s:5:\"title\";s:30:\"FCM Transport Isolation Policy\";s:11:\"description\";s:121:\"Enforces that FCM is used as transport carrier only. All push routing, priority, and policy decisions remain on platform.\";s:19:\"applies_to_versions\";a:0:{}s:6:\"source\";s:17:\"platform_registry\";s:2:\"id\";s:11:\"PLAT-M1-005\";s:13:\"registered_at\";s:25:\"2026-08-20T09:56:51+00:00\";}}',1787306211),('laravel-cache-mobile:security:platform_patch_registry','a:5:{s:11:\"PLAT-M1-001\";a:9:{s:2:\"id\";s:11:\"PLAT-M1-001\";s:5:\"title\";s:32:\"HMAC-SHA256 OTA Manifest Signing\";s:8:\"severity\";s:4:\"high\";s:4:\"type\";s:8:\"security\";s:11:\"description\";s:92:\"Enforces HMAC-SHA256 signing on all OTA manifests. Prevents unauthorized manifest injection.\";s:11:\"implemented\";b:1;s:10:\"applies_to\";s:3:\"all\";s:13:\"registered_at\";s:25:\"2026-08-20T09:56:51+00:00\";s:6:\"source\";s:18:\"platform_bootstrap\";}s:11:\"PLAT-M1-002\";a:9:{s:2:\"id\";s:11:\"PLAT-M1-002\";s:5:\"title\";s:33:\"Sanctum Mobile API Authentication\";s:8:\"severity\";s:4:\"high\";s:4:\"type\";s:8:\"security\";s:11:\"description\";s:84:\"Enforces token-based authentication on all mobile API endpoints via Laravel Sanctum.\";s:11:\"implemented\";b:1;s:10:\"applies_to\";s:3:\"all\";s:13:\"registered_at\";s:25:\"2026-08-20T09:56:51+00:00\";s:6:\"source\";s:18:\"platform_bootstrap\";}s:11:\"PLAT-M1-003\";a:9:{s:2:\"id\";s:11:\"PLAT-M1-003\";s:5:\"title\";s:35:\"Device Security Baseline Validation\";s:8:\"severity\";s:6:\"normal\";s:4:\"type\";s:8:\"security\";s:11:\"description\";s:101:\"Enforces minimum OS version (iOS 15, Android 10) and jailbreak/root detection on device registration.\";s:11:\"implemented\";b:1;s:10:\"applies_to\";s:3:\"all\";s:13:\"registered_at\";s:25:\"2026-08-20T09:56:51+00:00\";s:6:\"source\";s:18:\"platform_bootstrap\";}s:11:\"PLAT-M1-004\";a:9:{s:2:\"id\";s:11:\"PLAT-M1-004\";s:5:\"title\";s:36:\"WebSocket Channel HMAC Authorization\";s:8:\"severity\";s:6:\"normal\";s:4:\"type\";s:8:\"security\";s:11:\"description\";s:89:\"Enforces HMAC token authorization (300s TTL) on all Reverb WebSocket channel connections.\";s:11:\"implemented\";b:1;s:10:\"applies_to\";s:3:\"all\";s:13:\"registered_at\";s:25:\"2026-08-20T09:56:51+00:00\";s:6:\"source\";s:18:\"platform_bootstrap\";}s:11:\"PLAT-M1-005\";a:9:{s:2:\"id\";s:11:\"PLAT-M1-005\";s:5:\"title\";s:30:\"FCM Transport Isolation Policy\";s:8:\"severity\";s:6:\"normal\";s:4:\"type\";s:10:\"governance\";s:11:\"description\";s:121:\"Enforces that FCM is used as transport carrier only. All push routing, priority, and policy decisions remain on platform.\";s:11:\"implemented\";b:1;s:10:\"applies_to\";s:3:\"all\";s:13:\"registered_at\";s:25:\"2026-08-20T09:56:51+00:00\";s:6:\"source\";s:18:\"platform_bootstrap\";}}',1787306211),('laravel-cache-platform_site_config','a:3:{s:2:\"ux\";a:7:{s:7:\"general\";a:3:{s:13:\"platform_name\";s:17:\"پلتفرم SaaS\";s:8:\"logo_url\";N;s:17:\"registration_open\";b:1;}s:5:\"theme\";a:14:{s:13:\"theme_primary\";s:7:\"#4f46e5\";s:15:\"theme_secondary\";s:7:\"#6366f1\";s:13:\"theme_menu_bg\";s:7:\"#ffffff\";s:15:\"theme_menu_text\";s:7:\"#374151\";s:22:\"theme_menu_link_active\";s:7:\"#2563eb\";s:17:\"theme_title_color\";s:7:\"#111827\";s:16:\"theme_link_color\";s:7:\"#4f46e5\";s:16:\"theme_link_hover\";s:7:\"#4338ca\";s:16:\"theme_sidebar_bg\";s:7:\"#ffffff\";s:18:\"theme_sidebar_text\";s:7:\"#374151\";s:23:\"theme_sidebar_active_bg\";s:7:\"#eff6ff\";s:25:\"theme_sidebar_active_text\";s:7:\"#2563eb\";s:23:\"theme_button_primary_bg\";s:7:\"#4f46e5\";s:25:\"theme_button_primary_text\";s:7:\"#ffffff\";}s:4:\"font\";a:14:{s:9:\"font_body\";s:29:\"Vazirmatn, Tahoma, sans-serif\";s:10:\"font_title\";s:29:\"Vazirmatn, Tahoma, sans-serif\";s:14:\"font_size_base\";s:2:\"16\";s:15:\"font_size_title\";s:4:\"1.25\";s:18:\"font_custom_1_name\";s:0:\"\";s:17:\"font_custom_1_url\";s:0:\"\";s:18:\"font_custom_2_name\";s:0:\"\";s:17:\"font_custom_2_url\";s:0:\"\";s:18:\"font_custom_3_name\";s:0:\"\";s:17:\"font_custom_3_url\";s:0:\"\";s:18:\"font_custom_4_name\";s:0:\"\";s:17:\"font_custom_4_url\";s:0:\"\";s:18:\"font_custom_5_name\";s:0:\"\";s:17:\"font_custom_5_url\";s:0:\"\";}s:13:\"css_variables\";a:36:{s:12:\"--ds-primary\";s:7:\"#4f46e5\";s:14:\"--ds-secondary\";s:7:\"#6366f1\";s:12:\"--ds-menu-bg\";s:7:\"#ffffff\";s:14:\"--ds-menu-text\";s:7:\"#374151\";s:21:\"--ds-menu-link-active\";s:7:\"#2563eb\";s:16:\"--ds-title-color\";s:7:\"#111827\";s:15:\"--ds-link-color\";s:7:\"#4f46e5\";s:15:\"--ds-link-hover\";s:7:\"#4338ca\";s:15:\"--ds-sidebar-bg\";s:7:\"#ffffff\";s:17:\"--ds-sidebar-text\";s:7:\"#374151\";s:22:\"--ds-sidebar-active-bg\";s:7:\"#eff6ff\";s:24:\"--ds-sidebar-active-text\";s:7:\"#2563eb\";s:22:\"--ds-button-primary-bg\";s:7:\"#4f46e5\";s:24:\"--ds-button-primary-text\";s:7:\"#ffffff\";s:14:\"--ds-font-body\";s:29:\"Vazirmatn, Tahoma, sans-serif\";s:15:\"--ds-font-title\";s:29:\"Vazirmatn, Tahoma, sans-serif\";s:19:\"--ds-font-size-base\";s:4:\"16px\";s:20:\"--ds-font-size-title\";s:4:\"1.25\";s:18:\"--platform-primary\";s:7:\"#4f46e5\";s:20:\"--platform-secondary\";s:7:\"#6366f1\";s:18:\"--platform-menu-bg\";s:7:\"#ffffff\";s:20:\"--platform-menu-text\";s:7:\"#374151\";s:27:\"--platform-menu-link-active\";s:7:\"#2563eb\";s:22:\"--platform-title-color\";s:7:\"#111827\";s:21:\"--platform-link-color\";s:7:\"#4f46e5\";s:21:\"--platform-link-hover\";s:7:\"#4338ca\";s:21:\"--platform-sidebar-bg\";s:7:\"#ffffff\";s:23:\"--platform-sidebar-text\";s:7:\"#374151\";s:28:\"--platform-sidebar-active-bg\";s:7:\"#eff6ff\";s:30:\"--platform-sidebar-active-text\";s:7:\"#2563eb\";s:28:\"--platform-button-primary-bg\";s:7:\"#4f46e5\";s:30:\"--platform-button-primary-text\";s:7:\"#ffffff\";s:20:\"--platform-font-body\";s:29:\"Vazirmatn, Tahoma, sans-serif\";s:21:\"--platform-font-title\";s:29:\"Vazirmatn, Tahoma, sans-serif\";s:25:\"--platform-font-size-base\";s:4:\"16px\";s:26:\"--platform-font-size-title\";s:4:\"1.25\";}s:12:\"font_imports\";a:0:{}s:12:\"guide_widget\";a:7:{s:20:\"guide_widget_enabled\";s:1:\"1\";s:21:\"guide_widget_position\";s:12:\"bottom-right\";s:19:\"guide_widget_btn_bg\";s:7:\"#2563eb\";s:21:\"guide_widget_btn_text\";s:7:\"#ffffff\";s:21:\"guide_widget_panel_bg\";s:7:\"#ffffff\";s:28:\"guide_widget_panel_header_bg\";s:7:\"#f9fafb\";s:23:\"guide_widget_panel_text\";s:7:\"#111827\";}s:3:\"seo\";a:5:{s:17:\"seo_default_title\";s:0:\"\";s:23:\"seo_default_description\";s:0:\"\";s:10:\"seo_robots\";s:13:\"index, follow\";s:12:\"seo_og_image\";N;s:16:\"seo_twitter_card\";s:7:\"summary\";}}s:13:\"notifications\";a:0:{}s:3:\"seo\";a:5:{s:17:\"seo_default_title\";s:0:\"\";s:23:\"seo_default_description\";s:0:\"\";s:10:\"seo_robots\";s:13:\"index, follow\";s:12:\"seo_og_image\";N;s:16:\"seo_twitter_card\";s:7:\"summary\";}}',1787275539),('laravel-cache-schema.has_table.licenses','b:1;',1787278839),('laravel-cache-settings','a:36:{s:17:\"theme_preset_slug\";s:14:\"lavender-dream\";s:9:\"site_name\";s:17:\"صفحه نخست\";s:5:\"theme\";s:7:\"default\";s:16:\"about_us_enabled\";s:1:\"0\";s:14:\"about_us_title\";s:0:\"\";s:13:\"about_us_text\";s:0:\"\";s:26:\"notification_bell_position\";s:9:\"top-right\";s:23:\"builder_header_template\";N;s:23:\"builder_footer_template\";s:14:\"footer-10-full\";s:21:\"builder_sticky_header\";s:1:\"1\";s:17:\"admin_sidebar_bg1\";s:7:\"#5a7fa8\";s:17:\"admin_sidebar_bg2\";s:7:\"#456f94\";s:18:\"admin_sidebar_text\";s:7:\"#f1f6fb\";s:19:\"admin_sidebar_muted\";s:7:\"#d8ebfb\";s:20:\"admin_sidebar_accent\";s:7:\"#7dd3fc\";s:20:\"admin_sidebar_border\";s:7:\"#8aa9c4\";s:12:\"site_favicon\";s:19:\"favicon/favicon.png\";s:24:\"active_canvas_theme_data\";s:0:\"\";s:17:\"canvas_draft_data\";s:17121:\"{\"name\":\"قالب فروش و پشتیبانی حرفه‌ای\",\"slug\":\"sales-support-pro\",\"header_blocks\":[{\"id\":\"hdr-main\",\"type\":\"section\",\"props\":{\"padding\":\"sm\",\"container\":true,\"background\":\"surface\"},\"blocks\":[{\"id\":\"hdr-nav\",\"type\":\"nav_menu\",\"props\":{\"location\":\"header\"}},{\"id\":\"hdr-cart\",\"type\":\"module:shop_cart_button\",\"props\":{\"label\":\"سبد خرید\",\"style\":\"icon\"}},{\"id\":\"hdr-auth\",\"type\":\"login_register\",\"props\":[]}]}],\"footer_blocks\":[{\"id\":\"ftr-top\",\"type\":\"section\",\"props\":{\"padding\":\"lg\",\"container\":true,\"background\":\"text\"},\"blocks\":[{\"id\":\"ftr-cols\",\"type\":\"columns\",\"props\":{\"gap\":\"lg\",\"ratios\":\"1\\/3,1\\/3,1\\/3\"},\"blocks\":[{\"id\":\"ftr-brand-h\",\"type\":\"heading\",\"props\":{\"text\":\"درباره ما\",\"level\":4}},{\"id\":\"ftr-links-h\",\"type\":\"heading\",\"props\":{\"text\":\"دسترسی سریع\",\"level\":4}},{\"id\":\"ftr-contact-h\",\"type\":\"heading\",\"props\":{\"text\":\"تماس با ما\",\"level\":4}}]},{\"id\":\"ftr-social\",\"type\":\"module:social_links_bar\",\"props\":{\"size\":\"md\",\"color\":\"white\",\"style\":\"horizontal\"}},{\"id\":\"ftr-div\",\"type\":\"divider\",\"props\":[]},{\"id\":\"ftr-copy\",\"type\":\"text\",\"props\":{\"content\":\"© تمامی حقوق محفوظ است. پرداخت امن با درگاه معتبر.\"}}]}],\"pages\":{\"blog\":{\"slug\":\"blog\",\"title\":\"وبلاگ\",\"blocks\":[{\"id\":\"blog-hero\",\"data\":{\"align\":\"center\",\"title\":\"وبلاگ و مجله آموزشی\",\"subtitle\":\"آخرین مطالب، راهنماها و اخبار حوزه تخصصی ما\",\"background\":\"secondary\",\"button_url\":null,\"button_text\":null},\"type\":\"hero\"},{\"id\":\"blog-posts\",\"data\":{\"padding\":\"lg\",\"container\":true,\"background\":\"background\"},\"type\":\"section\",\"blocks\":[{\"id\":\"blog-posts-grid\",\"type\":\"module:blog_posts\",\"props\":{\"limit\":12,\"title\":\"آخرین مطالب\",\"layout\":\"grid\",\"show_date\":true,\"show_excerpt\":true,\"category_slug\":null}}]},{\"id\":\"blog-categories\",\"data\":{\"padding\":\"lg\",\"container\":true,\"background\":\"surface\"},\"type\":\"section\",\"blocks\":[{\"id\":\"blog-cat-h\",\"type\":\"heading\",\"props\":{\"text\":\"دسته‌بندی مطالب\",\"level\":3}},{\"id\":\"blog-cat-list\",\"type\":\"module:blog_categories\",\"props\":{\"limit\":12,\"style\":\"badges\",\"title\":\"دسته‌بندی‌ها\"}}]}]},\"home\":{\"slug\":\"\",\"title\":\"صفحه اصلی\",\"blocks\":[{\"id\":\"home-notif\",\"data\":{\"style\":\"top-bar\",\"show_dismiss\":true},\"type\":\"module:notifications_bar\"},{\"id\":\"home-hero\",\"data\":{\"align\":\"center\",\"title\":\"فروش هوشمند، پشتیبانی بی‌نقص\",\"subtitle\":\"محصولات باکیفیت، آموزش تخصصی، پشتیبانی ۲۴ ساعته — همه در یک پلتفرم.\",\"background\":\"primary\",\"button_url\":\"\\/products\",\"button_text\":\"مشاهده محصولات\",\"background_image\":null},\"type\":\"hero\"},{\"id\":\"home-stats\",\"data\":{\"padding\":\"lg\",\"container\":true,\"background\":\"surface\"},\"type\":\"section\",\"blocks\":[{\"id\":\"home-stats-grid\",\"type\":\"grid\",\"props\":{\"gap\":\"lg\",\"columns\":4},\"blocks\":[{\"id\":\"stat-1\",\"type\":\"counter\",\"props\":{\"label\":\"مشتری راضی\",\"value\":5000,\"suffix\":\"+\"}},{\"id\":\"stat-2\",\"type\":\"counter\",\"props\":{\"label\":\"محصول متنوع\",\"value\":1200,\"suffix\":\"+\"}},{\"id\":\"stat-3\",\"type\":\"counter\",\"props\":{\"label\":\"رضایت مشتریان\",\"value\":98,\"suffix\":\"%\"}},{\"id\":\"stat-4\",\"type\":\"counter\",\"props\":{\"label\":\"پشتیبانی آنلاین\",\"value\":24,\"suffix\":\"\\/۷\"}}]}]},{\"id\":\"home-countdown\",\"data\":{\"bg_color\":\"#dc2626\",\"end_date\":null,\"promo_text\":\"🔥 پیشنهاد ویژه هفتگی — فرصت محدود!\"},\"type\":\"module:shop_countdown\"},{\"id\":\"home-products\",\"data\":{\"padding\":\"lg\",\"container\":true,\"background\":\"background\"},\"type\":\"section\",\"blocks\":[{\"id\":\"home-prod-h\",\"type\":\"heading\",\"props\":{\"text\":\"محصولات پیشنهادی\",\"level\":2}},{\"id\":\"home-prod-grid\",\"type\":\"module:shop_product_grid\",\"props\":{\"limit\":8,\"title\":\"محصولات ویژه\",\"source\":\"featured\",\"columns\":\"4\",\"category_slug\":null}},{\"id\":\"home-prod-btn\",\"type\":\"button\",\"props\":{\"url\":\"\\/products\",\"text\":\"مشاهده همه محصولات\",\"style\":\"primary\"}}]},{\"id\":\"home-courses\",\"data\":{\"padding\":\"lg\",\"container\":true,\"background\":\"surface\"},\"type\":\"section\",\"blocks\":[{\"id\":\"home-courses-h\",\"type\":\"heading\",\"props\":{\"text\":\"دوره‌های آموزشی\",\"level\":2}},{\"id\":\"home-courses-t\",\"type\":\"text\",\"props\":{\"content\":\"با دوره‌های تخصصی ما مهارت‌های خود را ارتقا دهید.\"}},{\"id\":\"home-courses-grid\",\"type\":\"module:courses_grid\",\"props\":{\"limit\":3,\"title\":\"دوره‌های پرطرفدار\",\"layout\":\"grid\",\"columns\":\"3\",\"show_price\":true,\"show_instructor\":true}}]},{\"id\":\"home-pricing\",\"data\":{\"padding\":\"lg\",\"container\":true,\"background\":\"background\"},\"type\":\"section\",\"blocks\":[{\"id\":\"home-pricing-table\",\"type\":\"module:pricing_table\",\"props\":{\"title\":\"پلن‌های اشتراک\",\"subtitle\":\"بهترین پلن را برای کسب‌وکار خود انتخاب کنید\",\"highlight_plan\":null,\"show_annual_toggle\":false}}]},{\"id\":\"home-reviews\",\"data\":{\"padding\":\"lg\",\"container\":true,\"background\":\"surface\"},\"type\":\"section\",\"blocks\":[{\"id\":\"home-reviews-grid\",\"type\":\"module:reviews_grid\",\"props\":{\"limit\":6,\"style\":\"cards\",\"title\":\"نظرات مشتریان ما\",\"show_avatar\":true}}]},{\"id\":\"home-blog\",\"data\":{\"padding\":\"lg\",\"container\":true,\"background\":\"background\"},\"type\":\"section\",\"blocks\":[{\"id\":\"home-blog-posts\",\"type\":\"module:blog_posts\",\"props\":{\"limit\":3,\"title\":\"آخرین مطالب\",\"layout\":\"grid\",\"show_date\":true,\"show_excerpt\":true,\"category_slug\":null}}]},{\"id\":\"home-referral\",\"data\":{\"style\":\"card\",\"title\":\"دوستانت را دعوت کن، جایزه بگیر\",\"subtitle\":\"با معرفی هر دوست، اعتبار هدیه دریافت کنید\",\"show_link\":true},\"type\":\"module:referral_widget\"},{\"id\":\"home-cta\",\"data\":{\"title\":\"آماده شروع هستید؟\",\"subtitle\":\"همین الان ثبت‌نام کنید و از پشتیبانی رایگان بهره‌مند شوید.\",\"background\":\"primary\",\"button_url\":\"\\/register\",\"button_text\":\"شروع رایگان\"},\"type\":\"cta\"},{\"id\":\"home-support-btn\",\"data\":{\"label\":\"پشتیبانی آنلاین\",\"style\":\"floating\",\"bg_color\":\"#1e40af\",\"position\":\"bottom-left\"},\"type\":\"module:support_button\"}]},\"about\":{\"slug\":\"about\",\"title\":\"درباره ما\",\"blocks\":[{\"id\":\"about-hero\",\"type\":\"hero\",\"props\":{\"align\":\"center\",\"title\":\"داستان ما\",\"subtitle\":\"تعهد به کیفیت، شفافیت و رضایت مشتریان\",\"background\":\"primary\",\"button_url\":\"\\/support\",\"button_text\":\"تماس با ما\"}},{\"id\":\"about-mission\",\"type\":\"section\",\"props\":{\"padding\":\"lg\",\"container\":true,\"background\":\"surface\"},\"blocks\":[{\"id\":\"about-m-h\",\"type\":\"heading\",\"props\":{\"text\":\"ماموریت ما\",\"level\":2}},{\"id\":\"about-m-t\",\"type\":\"text\",\"props\":{\"content\":\"ما با هدف ایجاد پلتفرمی یکپارچه برای فروش، آموزش و پشتیبانی فعالیت می‌کنیم. مشتریان ما می‌توانند از بهترین محصولات، آموزش‌های تخصصی و پشتیبانی ۲۴ ساعته بهره‌مند شوند.\"}}]},{\"id\":\"about-stats\",\"type\":\"section\",\"props\":{\"padding\":\"lg\",\"container\":true,\"background\":\"background\"},\"blocks\":[{\"id\":\"about-stats-h\",\"type\":\"heading\",\"props\":{\"text\":\"ما در اعداد\",\"level\":2}},{\"id\":\"about-stats-grid\",\"type\":\"grid\",\"props\":{\"gap\":\"lg\",\"columns\":4},\"blocks\":[{\"id\":\"about-stat-1\",\"type\":\"counter\",\"props\":{\"label\":\"سابقه فعالیت\",\"value\":5,\"suffix\":\" سال\"}},{\"id\":\"about-stat-2\",\"type\":\"counter\",\"props\":{\"label\":\"مشتری راضی\",\"value\":5000,\"suffix\":\"+\"}},{\"id\":\"about-stat-3\",\"type\":\"counter\",\"props\":{\"label\":\"متخصص در تیم\",\"value\":50,\"suffix\":\"+\"}},{\"id\":\"about-stat-4\",\"type\":\"counter\",\"props\":{\"label\":\"محصول متنوع\",\"value\":1200,\"suffix\":\"+\"}}]}]},{\"id\":\"about-values\",\"type\":\"section\",\"props\":{\"padding\":\"lg\",\"container\":true,\"background\":\"surface\"},\"blocks\":[{\"id\":\"about-val-h\",\"type\":\"heading\",\"props\":{\"text\":\"چرا ما؟\",\"level\":2}},{\"id\":\"about-val-grid\",\"type\":\"grid\",\"props\":{\"gap\":\"lg\",\"columns\":3},\"blocks\":[{\"id\":\"val-1-h\",\"type\":\"heading\",\"props\":{\"text\":\"✅ محصولات اصل\",\"level\":4}},{\"id\":\"val-2-h\",\"type\":\"heading\",\"props\":{\"text\":\"🚀 ارسال سریع\",\"level\":4}},{\"id\":\"val-3-h\",\"type\":\"heading\",\"props\":{\"text\":\"🛡️ ضمانت بازگشت وجه\",\"level\":4}},{\"id\":\"val-1-t\",\"type\":\"text\",\"props\":{\"content\":\"تمام محصولات با ضمانت اصالت عرضه می‌شوند.\"}},{\"id\":\"val-2-t\",\"type\":\"text\",\"props\":{\"content\":\"ارسال در کمترین زمان ممکن به سراسر کشور.\"}},{\"id\":\"val-3-t\",\"type\":\"text\",\"props\":{\"content\":\"۷ روز ضمانت بازگشت وجه بدون سوال.\"}}]}]},{\"id\":\"about-reviews\",\"type\":\"section\",\"props\":{\"padding\":\"lg\",\"container\":true,\"background\":\"background\"},\"blocks\":[{\"id\":\"about-reviews-grid\",\"type\":\"module:reviews_grid\",\"props\":{\"limit\":3,\"style\":\"cards\",\"title\":\"چه می‌گویند\",\"show_avatar\":true}}]},{\"id\":\"about-cta\",\"type\":\"cta\",\"props\":{\"title\":\"همین امروز با ما همراه شوید\",\"subtitle\":\"از مشاوره رایگان تا پشتیبانی دائمی، کنارتان هستیم.\",\"background\":\"primary\",\"button_url\":\"\\/register\",\"button_text\":\"شروع کنید\"}}]},\"plans\":{\"slug\":\"plans\",\"title\":\"پلن‌ها و قیمت‌گذاری\",\"blocks\":[{\"id\":\"plans-hero\",\"type\":\"hero\",\"props\":{\"align\":\"center\",\"title\":\"پلن مناسب خود را انتخاب کنید\",\"subtitle\":\"بدون هزینه پنهان — تمام امکانات در یک اشتراک\",\"background\":\"primary\",\"button_url\":\"\",\"button_text\":\"\"}},{\"id\":\"plans-table\",\"type\":\"section\",\"props\":{\"padding\":\"lg\",\"container\":true,\"background\":\"background\"},\"blocks\":[{\"id\":\"plans-pricing\",\"type\":\"module:pricing_table\",\"props\":{\"title\":\"پلن‌های اشتراک\",\"subtitle\":\"بهترین پلن برای کسب‌وکار شما\",\"highlight_plan\":\"\",\"show_annual_toggle\":false}}]},{\"id\":\"plans-stats\",\"type\":\"section\",\"props\":{\"padding\":\"md\",\"container\":true,\"background\":\"surface\"},\"blocks\":[{\"id\":\"plans-stats-grid\",\"type\":\"grid\",\"props\":{\"gap\":\"lg\",\"columns\":3},\"blocks\":[{\"id\":\"plans-sub-stat\",\"type\":\"module:subscriber_stats\",\"props\":{\"label\":\"مشترک فعال\",\"style\":\"badge\",\"show_count\":true}},{\"id\":\"plans-ctr-2\",\"type\":\"counter\",\"props\":{\"label\":\"آپتایم سرویس\",\"value\":99,\"suffix\":\"%\"}},{\"id\":\"plans-ctr-3\",\"type\":\"counter\",\"props\":{\"label\":\"ضمانت بازگشت وجه\",\"value\":7,\"suffix\":\" روز\"}}]}]},{\"id\":\"plans-cta\",\"type\":\"module:plan_cta\",\"props\":{\"title\":\"همین الان شروع کنید\",\"bg_color\":\"#1e40af\",\"subtitle\":\"اشتراک رایگان، بدون نیاز به کارت بانکی\",\"button_text\":\"ثبت‌نام رایگان\"}},{\"id\":\"plans-faq\",\"type\":\"section\",\"props\":{\"padding\":\"lg\",\"container\":true,\"background\":\"background\"},\"blocks\":[{\"id\":\"plans-faq-block\",\"type\":\"module:faq_dynamic\",\"props\":{\"limit\":8,\"style\":\"accordion\",\"title\":\"سوالات متداول درباره پلن‌ها\"}}]}]},\"support\":{\"slug\":\"support\",\"title\":\"پشتیبانی\",\"blocks\":[{\"id\":\"sup-hero\",\"type\":\"hero\",\"props\":{\"align\":\"center\",\"title\":\"چطور می‌توانیم کمک کنیم؟\",\"subtitle\":\"تیم پشتیبانی ما ۲۴ ساعته آماده پاسخگویی به سوالات شما است\",\"background\":\"primary\",\"button_url\":\"\\/tickets\\/create\",\"button_text\":\"ارسال تیکت\"}},{\"id\":\"sup-channels\",\"type\":\"section\",\"props\":{\"padding\":\"lg\",\"container\":true,\"background\":\"surface\"},\"blocks\":[{\"id\":\"sup-ch-h\",\"type\":\"heading\",\"props\":{\"text\":\"کانال‌های ارتباطی\",\"level\":2}},{\"id\":\"sup-ch-grid\",\"type\":\"grid\",\"props\":{\"gap\":\"lg\",\"columns\":3},\"blocks\":[{\"id\":\"sup-ch-1\",\"type\":\"heading\",\"props\":{\"text\":\"🎫 سیستم تیکت\",\"level\":4}},{\"id\":\"sup-ch-2\",\"type\":\"heading\",\"props\":{\"text\":\"📞 تماس تلفنی\",\"level\":4}},{\"id\":\"sup-ch-3\",\"type\":\"heading\",\"props\":{\"text\":\"💬 چت آنلاین\",\"level\":4}}]}]},{\"id\":\"sup-contact\",\"type\":\"section\",\"props\":{\"padding\":\"lg\",\"container\":true,\"background\":\"background\"},\"blocks\":[{\"id\":\"sup-contact-form\",\"type\":\"module:contact_quick\",\"props\":{\"title\":\"تماس با ما\",\"show_map\":false,\"show_phone\":true,\"show_address\":true}}]},{\"id\":\"sup-faq\",\"type\":\"section\",\"props\":{\"padding\":\"lg\",\"container\":true,\"background\":\"surface\"},\"blocks\":[{\"id\":\"sup-faq-block\",\"type\":\"module:faq_dynamic\",\"props\":{\"limit\":10,\"style\":\"accordion\",\"title\":\"سوالات متداول\"}}]},{\"id\":\"sup-float-btn\",\"type\":\"module:support_button\",\"props\":{\"label\":\"ارسال تیکت\",\"style\":\"floating\",\"bg_color\":\"#1e40af\",\"position\":\"bottom-right\"}}]},\"learning\":{\"slug\":\"learning\",\"title\":\"آموزشگاه\",\"blocks\":[{\"id\":\"edu-hero\",\"type\":\"hero\",\"props\":{\"align\":\"center\",\"title\":\"آموزشگاه تخصصی\",\"subtitle\":\"دوره‌های جامع برای ارتقای مهارت‌های حرفه‌ای شما\",\"background\":\"primary\",\"button_url\":\"\\/learning\\/courses\",\"button_text\":\"مشاهده همه دوره‌ها\"}},{\"id\":\"edu-stats\",\"type\":\"section\",\"props\":{\"padding\":\"md\",\"container\":true,\"background\":\"surface\"},\"blocks\":[{\"id\":\"edu-stats-grid\",\"type\":\"grid\",\"props\":{\"gap\":\"lg\",\"columns\":3},\"blocks\":[{\"id\":\"edu-stat-1\",\"type\":\"counter\",\"props\":{\"label\":\"دوره آموزشی\",\"value\":50,\"suffix\":\"+\"}},{\"id\":\"edu-stat-2\",\"type\":\"counter\",\"props\":{\"label\":\"دانشجو فعال\",\"value\":3000,\"suffix\":\"+\"}},{\"id\":\"edu-stat-3\",\"type\":\"counter\",\"props\":{\"label\":\"رضایت دانشجویان\",\"value\":95,\"suffix\":\"%\"}}]}]},{\"id\":\"edu-courses\",\"type\":\"section\",\"props\":{\"padding\":\"lg\",\"container\":true,\"background\":\"background\"},\"blocks\":[{\"id\":\"edu-courses-h\",\"type\":\"heading\",\"props\":{\"text\":\"دوره‌های فعال\",\"level\":2}},{\"id\":\"edu-courses-grid\",\"type\":\"module:courses_grid\",\"props\":{\"limit\":9,\"title\":\"دوره‌های آموزشی\",\"layout\":\"grid\",\"columns\":\"3\",\"show_price\":true,\"show_instructor\":true}}]},{\"id\":\"edu-enroll-cta\",\"type\":\"module:course_enroll_cta\",\"props\":{\"title\":\"همین الان شروع کن!\",\"bg_color\":\"#1e40af\",\"subtitle\":\"به هزاران دانشجو بپیوند و آینده‌ات را بساز\",\"button_text\":\"ثبت‌نام رایگان\"}},{\"id\":\"edu-articles\",\"type\":\"section\",\"props\":{\"padding\":\"lg\",\"container\":true,\"background\":\"surface\"},\"blocks\":[{\"id\":\"edu-articles-h\",\"type\":\"heading\",\"props\":{\"text\":\"مقالات آموزشی\",\"level\":2}},{\"id\":\"edu-articles-grid\",\"type\":\"module:edu_article_grid\",\"props\":{\"limit\":6,\"title\":\"مقالات آموزشی\",\"layout\":\"grid\"}}]},{\"id\":\"edu-mylearning\",\"type\":\"module:my_learning_link\",\"props\":{\"label\":\"دوره‌های من\",\"style\":\"button\"}}]},\"products\":{\"slug\":\"products\",\"title\":\"فروشگاه\",\"blocks\":[{\"id\":\"shop-hero\",\"type\":\"hero\",\"props\":{\"align\":\"center\",\"title\":\"فروشگاه آنلاین\",\"subtitle\":\"بهترین محصولات با ضمانت اصالت و ارسال سریع\",\"background\":\"secondary\",\"button_url\":\"\",\"button_text\":\"\"}},{\"id\":\"shop-search\",\"type\":\"module:shop_search_box\",\"props\":{\"style\":\"bar\",\"placeholder\":\"جستجو در محصولات...\"}},{\"id\":\"shop-categories\",\"type\":\"section\",\"props\":{\"padding\":\"lg\",\"container\":true,\"background\":\"surface\"},\"blocks\":[{\"id\":\"shop-cat-h\",\"type\":\"heading\",\"props\":{\"text\":\"دسته‌بندی‌ها\",\"level\":2}},{\"id\":\"shop-cat-grid\",\"type\":\"module:shop_categories\",\"props\":{\"limit\":8,\"style\":\"grid\",\"title\":\"دسته‌بندی‌ها\",\"show_count\":true}}]},{\"id\":\"shop-new\",\"type\":\"section\",\"props\":{\"padding\":\"lg\",\"container\":true,\"background\":\"background\"},\"blocks\":[{\"id\":\"shop-new-h\",\"type\":\"heading\",\"props\":{\"text\":\"جدیدترین محصولات\",\"level\":2}},{\"id\":\"shop-new-grid\",\"type\":\"module:shop_product_grid\",\"props\":{\"limit\":12,\"title\":\"جدیدترین\",\"source\":\"recent\",\"columns\":\"4\",\"category_slug\":\"\"}}]},{\"id\":\"shop-bestsellers\",\"type\":\"section\",\"props\":{\"padding\":\"lg\",\"container\":true,\"background\":\"surface\"},\"blocks\":[{\"id\":\"shop-best-h\",\"type\":\"heading\",\"props\":{\"text\":\"پرفروش‌ترین محصولات\",\"level\":2}},{\"id\":\"shop-best-grid\",\"type\":\"module:shop_product_grid\",\"props\":{\"limit\":8,\"title\":\"پرفروش\",\"source\":\"bestselling\",\"columns\":\"4\",\"category_slug\":\"\"}}]},{\"id\":\"shop-countdown\",\"type\":\"module:shop_countdown\",\"props\":{\"bg_color\":\"#dc2626\",\"end_date\":\"\",\"promo_text\":\"⚡ پیشنهاد ویژه — فرصت محدود!\"}},{\"id\":\"shop-support\",\"type\":\"module:support_button\",\"props\":{\"label\":\"راهنمای خرید\",\"style\":\"floating\",\"bg_color\":\"#1e40af\",\"position\":\"bottom-right\"}}]}},\"global_styles\":{\"colors\":{\"text\":\"#0f172a\",\"accent\":\"#f59e0b\",\"primary\":\"#1e40af\",\"surface\":\"#ffffff\",\"secondary\":\"#3b82f6\",\"background\":\"#f8fafc\",\"text_muted\":\"#64748b\"},\"dark_mode\":{\"text\":\"#f1f5f9\",\"enabled\":false,\"primary\":\"#3b82f6\",\"surface\":\"#1e293b\",\"background\":\"#0f172a\"},\"typography\":{\"scale\":1.25,\"font_body\":\"Vazirmatn, Tahoma, sans-serif\",\"font_heading\":\"Vazirmatn, Tahoma, sans-serif\"},\"font_family\":\"Vazirmatn, Tahoma, sans-serif\",\"primary_color\":\"#1e40af\",\"secondary_color\":\"#3b82f6\",\"background_color\":\"#f8fafc\"}}\";s:20:\"canvas_preview_token\";s:40:\"E5VGJ5A7tZiAPN5jMWekkCZsSUUPBfU4rWaz5MKZ\";s:24:\"active_canvas_theme_name\";s:0:\"\";s:24:\"active_canvas_theme_slug\";s:0:\"\";s:22:\"active_canvas_theme_id\";s:0:\"\";s:21:\"site_resource_summary\";s:144:\"{\"storage_pct\":0.1,\"storage_bytes\":800000,\"storage_limit\":1073741824,\"db_bytes\":6946816,\"archive_bytes\":0,\"calculated_at\":\"2026-08-20 06:00:08\"}\";s:28:\"module_updates_dismissed_sig\";s:411:\"access_lists,accounting,analytics,announcements,backup,bank_gateway,brand,captcha,cloud,contract,crm,discount_advanced,gallery,homepage_videos,i18n,installments,inventory,marketing_automation,marketplace_sync,media,module_labels,multi_currency,notifications,omnichannel,podcast,portfolio,product_bundling,projects,qa,recruitment,seo_advanced,services,shipping,smart_image,support,tasks,translations,video,wallet\";s:12:\"sms_provider\";s:11:\"melipayamak\";s:11:\"sms_api_key\";s:36:\"88488cba-accb-452e-be5c-2d6554807f1c\";s:15:\"sms_line_number\";s:10:\"2170002345\";s:22:\"site_theme_preset_slug\";s:14:\"lavender-dream\";s:21:\"dashboard_preset_slug\";s:15:\"enterprise-blue\";s:15:\"captcha_enabled\";s:1:\"1\";s:20:\"auth_captcha_enabled\";s:1:\"1\";s:20:\"shop_captcha_enabled\";s:1:\"1\";s:12:\"captcha_type\";s:14:\"persian_number\";s:17:\"hcaptcha_site_key\";N;s:19:\"hcaptcha_secret_key\";N;}',1787278504),('laravel-cache-site_menu_1','a:1:{i:0;a:19:{s:2:\"id\";i:1;s:5:\"title\";s:17:\"صفحه نخست\";s:3:\"url\";s:23:\"http://safhenokhost.ir/\";s:6:\"target\";s:5:\"_self\";s:3:\"rel\";s:0:\"\";s:4:\"icon\";N;s:9:\"css_class\";N;s:5:\"badge\";N;s:9:\"image_url\";N;s:11:\"mega_column\";N;s:13:\"featured_html\";N;s:12:\"mega_columns\";a:0:{}s:4:\"type\";s:10:\"custom_url\";s:10:\"sort_order\";i:1;s:8:\"children\";a:0:{}s:9:\"utm_query\";N;s:8:\"utm_json\";N;s:6:\"labels\";N;s:8:\"title_en\";s:12:\"safhenokhost\";}}',1787278840),('laravel-cache-tenant_theme_tokens_default','a:43:{s:11:\"--ui-indigo\";s:7:\"#8b5cf6\";s:17:\"--ui-indigo-hover\";s:7:\"#7c3aed\";s:17:\"--ui-indigo-light\";s:7:\"#ede9fe\";s:16:\"--ui-indigo-ring\";s:22:\"rgb(139 92 246 / 0.25)\";s:15:\"--ui-focus-ring\";s:32:\"0 0 0 3px rgb(139 92 246 / 0.25)\";s:18:\"--ui-hover-overlay\";s:21:\"rgba(139,92,246,0.04)\";s:13:\"--ui-hover-bg\";s:21:\"rgba(139,92,246,0.06)\";s:19:\"--ui-active-overlay\";s:21:\"rgba(139,92,246,0.08)\";s:14:\"--ui-active-bg\";s:21:\"rgba(139,92,246,0.10)\";s:16:\"--ui-selected-bg\";s:21:\"rgba(139,92,246,0.08)\";s:16:\"--ui-primary-500\";s:7:\"#8b5cf6\";s:16:\"--ui-primary-600\";s:7:\"#7c3aed\";s:7:\"--ui-bg\";s:7:\"#faf5ff\";s:12:\"--ui-surface\";s:7:\"#ffffff\";s:17:\"--ui-surface-soft\";s:7:\"#fdf9ff\";s:17:\"--ui-text-primary\";s:7:\"#2e1065\";s:19:\"--ui-text-secondary\";s:7:\"#4c1d95\";s:15:\"--ui-text-muted\";s:7:\"#5b21b6\";s:11:\"--ui-border\";s:7:\"#ddd6fe\";s:18:\"--ui-border-strong\";s:7:\"#c4b5fd\";s:12:\"--ds-primary\";s:7:\"#8b5cf6\";s:22:\"--ds-button-primary-bg\";s:7:\"#8b5cf6\";s:24:\"--ds-button-primary-text\";s:7:\"#ffffff\";s:15:\"--ds-link-color\";s:7:\"#7c3aed\";s:12:\"--ds-menu-bg\";s:7:\"#faf5ff\";s:18:\"--platform-primary\";s:7:\"#8b5cf6\";s:21:\"--platform-link-color\";s:7:\"#7c3aed\";s:21:\"--platform-link-hover\";s:7:\"#7c3aed\";s:28:\"--platform-button-primary-bg\";s:7:\"#8b5cf6\";s:18:\"--platform-menu-bg\";s:7:\"#faf5ff\";s:27:\"--platform-menu-link-active\";s:7:\"#7c3aed\";s:22:\"--platform-title-color\";s:7:\"#2e1065\";s:24:\"--platform-primary-light\";s:7:\"#faf5ff\";s:12:\"--tb-primary\";s:7:\"#8b5cf6\";s:14:\"--tb-secondary\";s:7:\"#7c3aed\";s:30:\"--platform-button-primary-text\";s:7:\"#ffffff\";s:20:\"--platform-menu-text\";s:7:\"#f1f5f9\";s:19:\"--admin-sidebar-bg1\";s:7:\"#1e293b\";s:19:\"--admin-sidebar-bg2\";s:7:\"#0f172a\";s:20:\"--admin-sidebar-text\";s:7:\"#f1f5f9\";s:21:\"--admin-sidebar-muted\";s:7:\"#94a3b8\";s:22:\"--admin-sidebar-accent\";s:7:\"#60a5fa\";s:22:\"--admin-sidebar-border\";s:7:\"#334155\";}',1787278839),('laravel-cache-theme_settings_default','O:23:\"App\\Models\\ThemeSetting\":33:{s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:14:\"theme_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:22:{s:2:\"id\";i:1;s:7:\"site_id\";N;s:13:\"primary_color\";s:7:\"#16a34a\";s:15:\"secondary_color\";s:7:\"#14532d\";s:12:\"accent_color\";s:7:\"#15803d\";s:16:\"background_color\";s:7:\"#f0fdf4\";s:13:\"surface_color\";s:7:\"#ffffff\";s:10:\"text_color\";s:7:\"#052e16\";s:11:\"muted_color\";s:7:\"#166534\";s:12:\"border_color\";s:7:\"#bbf7d0\";s:10:\"link_color\";s:7:\"#15803d\";s:9:\"header_bg\";s:7:\"#14532d\";s:9:\"footer_bg\";s:7:\"#14532d\";s:19:\"font_family_heading\";s:29:\"Vazirmatn, Tahoma, sans-serif\";s:16:\"font_family_body\";s:29:\"Vazirmatn, Tahoma, sans-serif\";s:14:\"base_font_size\";s:4:\"16px\";s:15:\"container_width\";s:6:\"1200px\";s:13:\"border_radius\";s:3:\"8px\";s:12:\"button_style\";s:5:\"solid\";s:15:\"section_spacing\";s:2:\"md\";s:10:\"created_at\";s:19:\"2026-06-15 15:03:10\";s:10:\"updated_at\";s:19:\"2026-06-27 07:33:42\";}s:11:\"\0*\0original\";a:22:{s:2:\"id\";i:1;s:7:\"site_id\";N;s:13:\"primary_color\";s:7:\"#16a34a\";s:15:\"secondary_color\";s:7:\"#14532d\";s:12:\"accent_color\";s:7:\"#15803d\";s:16:\"background_color\";s:7:\"#f0fdf4\";s:13:\"surface_color\";s:7:\"#ffffff\";s:10:\"text_color\";s:7:\"#052e16\";s:11:\"muted_color\";s:7:\"#166534\";s:12:\"border_color\";s:7:\"#bbf7d0\";s:10:\"link_color\";s:7:\"#15803d\";s:9:\"header_bg\";s:7:\"#14532d\";s:9:\"footer_bg\";s:7:\"#14532d\";s:19:\"font_family_heading\";s:29:\"Vazirmatn, Tahoma, sans-serif\";s:16:\"font_family_body\";s:29:\"Vazirmatn, Tahoma, sans-serif\";s:14:\"base_font_size\";s:4:\"16px\";s:15:\"container_width\";s:6:\"1200px\";s:13:\"border_radius\";s:3:\"8px\";s:12:\"button_style\";s:5:\"solid\";s:15:\"section_spacing\";s:2:\"md\";s:10:\"created_at\";s:19:\"2026-06-15 15:03:10\";s:10:\"updated_at\";s:19:\"2026-06-27 07:33:42\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:19:{i:0;s:7:\"site_id\";i:1;s:13:\"primary_color\";i:2;s:15:\"secondary_color\";i:3;s:12:\"accent_color\";i:4;s:16:\"background_color\";i:5;s:13:\"surface_color\";i:6;s:10:\"text_color\";i:7;s:11:\"muted_color\";i:8;s:12:\"border_color\";i:9;s:10:\"link_color\";i:10;s:9:\"header_bg\";i:11;s:9:\"footer_bg\";i:12;s:19:\"font_family_heading\";i:13;s:16:\"font_family_body\";i:14;s:14:\"base_font_size\";i:15;s:15:\"container_width\";i:16;s:13:\"border_radius\";i:17;s:12:\"button_style\";i:18;s:15:\"section_spacing\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1787278839);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `order` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'محتوا','mhtoa',NULL,1,'2026-06-10 19:40:43','2026-06-10 19:40:43');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content_translations`
--

DROP TABLE IF EXISTS `content_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `content_translations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `translatable_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `translatable_id` bigint unsigned NOT NULL,
  `locale` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `translated_text` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_hash` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ai_model` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `generated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ct_unique` (`translatable_type`,`translatable_id`,`locale`,`field_name`),
  KEY `ct_model_idx` (`translatable_type`,`translatable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content_translations`
--

LOCK TABLES `content_translations` WRITE;
/*!40000 ALTER TABLE `content_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `content_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupons`
--

DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `coupons` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `discount_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'percent',
  `discount_percent` tinyint unsigned DEFAULT NULL,
  `discount_amount` bigint unsigned DEFAULT NULL,
  `min_order_amount` bigint unsigned DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `starts_at` timestamp NULL DEFAULT NULL,
  `usage_limit` int unsigned DEFAULT NULL,
  `product_ids` json DEFAULT NULL,
  `category_ids` json DEFAULT NULL,
  `used_count` int unsigned NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `first_order_only` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `coupons_code_unique` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupons`
--

LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_class_completions`
--

DROP TABLE IF EXISTS `course_class_completions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course_class_completions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `course_class_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `course_id` bigint unsigned NOT NULL,
  `completed_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_class_user` (`course_class_id`,`user_id`),
  KEY `idx_user_course` (`user_id`,`course_id`),
  KEY `fk_ccc_course` (`course_id`),
  CONSTRAINT `fk_ccc_class` FOREIGN KEY (`course_class_id`) REFERENCES `course_classes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ccc_course` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ccc_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_class_completions`
--

LOCK TABLES `course_class_completions` WRITE;
/*!40000 ALTER TABLE `course_class_completions` DISABLE KEYS */;
/*!40000 ALTER TABLE `course_class_completions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_classes`
--

DROP TABLE IF EXISTS `course_classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course_classes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `course_id` bigint unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `order` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `course_classes_course_id_foreign` (`course_id`),
  CONSTRAINT `course_classes_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_classes`
--

LOCK TABLES `course_classes` WRITE;
/*!40000 ALTER TABLE `course_classes` DISABLE KEYS */;
/*!40000 ALTER TABLE `course_classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_enrollments`
--

DROP TABLE IF EXISTS `course_enrollments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course_enrollments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `course_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `enrolled_at` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `course_enrollments_course_id_user_id_unique` (`course_id`,`user_id`),
  KEY `course_enrollments_user_id_foreign` (`user_id`),
  CONSTRAINT `course_enrollments_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `course_enrollments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_enrollments`
--

LOCK TABLES `course_enrollments` WRITE;
/*!40000 ALTER TABLE `course_enrollments` DISABLE KEYS */;
/*!40000 ALTER TABLE `course_enrollments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `courses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(14,2) NOT NULL DEFAULT '0.00',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `order` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `courses_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses`
--

LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` VALUES (1,'آموزش محتوا نویسی','amozsh-mhtoa-noysy','<p>آموزش محتوا نویسی آموزش محتوا نویسی آموزش محتوا نویسی آموزش محتوا نویسی آموزش محتوا نویسی آموزش محتوا نویسی آموزش محتوا نویسی آموزش محتوا نویسی آموزش محتوا نویسی آموزش محتوا نویسی آموزش محتوا نویسی آموزش محتوا نویسی آموزش محتوا نویسی آموزش محتوا نویسی&nbsp;</p>','course/2026/06/qKE1dWz3gBXk6HZJF0Ys.png',1000.00,1,1,'2026-06-11 20:01:56','2026-06-11 20:01:56');
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_activities`
--

DROP TABLE IF EXISTS `crm_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm_activities` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `contact_id` bigint unsigned NOT NULL,
  `deal_id` bigint unsigned DEFAULT NULL,
  `admin_id` bigint unsigned DEFAULT NULL,
  `type` enum('call','email','meeting','note','task') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'note',
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci,
  `outcome` enum('none','interested','not_interested','follow_up') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `scheduled_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `crm_activities_contact_id_created_at_index` (`contact_id`,`created_at`),
  KEY `crm_activities_contact_id_index` (`contact_id`),
  KEY `crm_activities_deal_id_index` (`deal_id`),
  CONSTRAINT `crm_activities_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `crm_contacts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `crm_activities_deal_id_foreign` FOREIGN KEY (`deal_id`) REFERENCES `crm_deals` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_activities`
--

LOCK TABLES `crm_activities` WRITE;
/*!40000 ALTER TABLE `crm_activities` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_attachments`
--

DROP TABLE IF EXISTS `crm_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm_attachments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint unsigned DEFAULT NULL,
  `attachable_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attachable_id` bigint unsigned NOT NULL,
  `disk` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size_bytes` bigint unsigned NOT NULL DEFAULT '0',
  `uploaded_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `crm_attachments_uploaded_by_foreign` (`uploaded_by`),
  KEY `crm_attachments_attachable_type_attachable_id_index` (`attachable_type`,`attachable_id`),
  KEY `crm_attachments_site_id_index` (`site_id`),
  CONSTRAINT `crm_attachments_site_id_foreign` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE SET NULL,
  CONSTRAINT `crm_attachments_uploaded_by_foreign` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_attachments`
--

LOCK TABLES `crm_attachments` WRITE;
/*!40000 ALTER TABLE `crm_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_companies`
--

DROP TABLE IF EXISTS `crm_companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm_companies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `domain` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `industry` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lifecycle_stage` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'lead',
  `owner_user_id` bigint unsigned DEFAULT NULL,
  `is_favorite` tinyint(1) NOT NULL DEFAULT '0',
  `archived_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `crm_companies_owner_user_id_foreign` (`owner_user_id`),
  KEY `crm_companies_site_id_lifecycle_stage_index` (`site_id`,`lifecycle_stage`),
  KEY `crm_companies_site_id_archived_at_index` (`site_id`,`archived_at`),
  CONSTRAINT `crm_companies_owner_user_id_foreign` FOREIGN KEY (`owner_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `crm_companies_site_id_foreign` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_companies`
--

LOCK TABLES `crm_companies` WRITE;
/*!40000 ALTER TABLE `crm_companies` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_companies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_contacts`
--

DROP TABLE IF EXISTS `crm_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm_contacts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source` enum('manual','order','ticket','form','import') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'manual',
  `status` enum('lead','prospect','customer','churned') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'lead',
  `city` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `tags` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `crm_contacts_status_created_at_index` (`status`,`created_at`),
  KEY `crm_contacts_user_id_index` (`user_id`),
  KEY `crm_contacts_mobile_index` (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_contacts`
--

LOCK TABLES `crm_contacts` WRITE;
/*!40000 ALTER TABLE `crm_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_deals`
--

DROP TABLE IF EXISTS `crm_deals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm_deals` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `contact_id` bigint unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stage` enum('lead','contacted','proposal','negotiation','won','lost') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'lead',
  `value` bigint unsigned NOT NULL DEFAULT '0',
  `probability` tinyint unsigned NOT NULL DEFAULT '50',
  `expected_close_date` date DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `closed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `crm_deals_stage_created_at_index` (`stage`,`created_at`),
  KEY `crm_deals_contact_id_index` (`contact_id`),
  CONSTRAINT `crm_deals_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `crm_contacts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_deals`
--

LOCK TABLES `crm_deals` WRITE;
/*!40000 ALTER TABLE `crm_deals` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_deals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_leads`
--

DROP TABLE IF EXISTS `crm_leads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm_leads` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint unsigned DEFAULT NULL,
  `first_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'new',
  `owner_user_id` bigint unsigned DEFAULT NULL,
  `converted_contact_id` bigint unsigned DEFAULT NULL,
  `converted_company_id` bigint unsigned DEFAULT NULL,
  `converted_opportunity_id` bigint unsigned DEFAULT NULL,
  `converted_at` timestamp NULL DEFAULT NULL,
  `is_favorite` tinyint(1) NOT NULL DEFAULT '0',
  `archived_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `crm_leads_owner_user_id_foreign` (`owner_user_id`),
  KEY `crm_leads_converted_contact_id_foreign` (`converted_contact_id`),
  KEY `crm_leads_converted_company_id_foreign` (`converted_company_id`),
  KEY `crm_leads_converted_opportunity_id_foreign` (`converted_opportunity_id`),
  KEY `crm_leads_site_id_status_index` (`site_id`,`status`),
  KEY `crm_leads_site_id_archived_at_index` (`site_id`,`archived_at`),
  CONSTRAINT `crm_leads_converted_company_id_foreign` FOREIGN KEY (`converted_company_id`) REFERENCES `crm_companies` (`id`) ON DELETE SET NULL,
  CONSTRAINT `crm_leads_converted_contact_id_foreign` FOREIGN KEY (`converted_contact_id`) REFERENCES `crm_suite_contacts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `crm_leads_converted_opportunity_id_foreign` FOREIGN KEY (`converted_opportunity_id`) REFERENCES `crm_opportunities` (`id`) ON DELETE SET NULL,
  CONSTRAINT `crm_leads_owner_user_id_foreign` FOREIGN KEY (`owner_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `crm_leads_site_id_foreign` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_leads`
--

LOCK TABLES `crm_leads` WRITE;
/*!40000 ALTER TABLE `crm_leads` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_leads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_opportunities`
--

DROP TABLE IF EXISTS `crm_opportunities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm_opportunities` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_id` bigint unsigned DEFAULT NULL,
  `company_id` bigint unsigned DEFAULT NULL,
  `pipeline_id` bigint unsigned NOT NULL,
  `stage_id` bigint unsigned NOT NULL,
  `stage_changed_at` timestamp NULL DEFAULT NULL,
  `stale_notified_at` timestamp NULL DEFAULT NULL,
  `amount` bigint unsigned NOT NULL DEFAULT '0',
  `probability` tinyint unsigned DEFAULT NULL,
  `expected_close_date` date DEFAULT NULL,
  `status` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `lost_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `won_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `closed_at` timestamp NULL DEFAULT NULL,
  `owner_user_id` bigint unsigned DEFAULT NULL,
  `is_favorite` tinyint(1) NOT NULL DEFAULT '0',
  `archived_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `crm_opportunities_contact_id_foreign` (`contact_id`),
  KEY `crm_opportunities_company_id_foreign` (`company_id`),
  KEY `crm_opportunities_stage_id_foreign` (`stage_id`),
  KEY `crm_opportunities_owner_user_id_foreign` (`owner_user_id`),
  KEY `crm_opportunities_site_id_status_index` (`site_id`,`status`),
  KEY `crm_opportunities_site_id_archived_at_index` (`site_id`,`archived_at`),
  KEY `crm_opportunities_pipeline_id_stage_id_index` (`pipeline_id`,`stage_id`),
  KEY `crm_opportunities_expected_close_date_index` (`expected_close_date`),
  CONSTRAINT `crm_opportunities_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `crm_companies` (`id`) ON DELETE SET NULL,
  CONSTRAINT `crm_opportunities_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `crm_suite_contacts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `crm_opportunities_owner_user_id_foreign` FOREIGN KEY (`owner_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `crm_opportunities_pipeline_id_foreign` FOREIGN KEY (`pipeline_id`) REFERENCES `crm_pipelines` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `crm_opportunities_site_id_foreign` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE SET NULL,
  CONSTRAINT `crm_opportunities_stage_id_foreign` FOREIGN KEY (`stage_id`) REFERENCES `crm_stages` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_opportunities`
--

LOCK TABLES `crm_opportunities` WRITE;
/*!40000 ALTER TABLE `crm_opportunities` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_opportunities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_pipelines`
--

DROP TABLE IF EXISTS `crm_pipelines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm_pipelines` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint unsigned DEFAULT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `position` smallint unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `crm_pipelines_site_id_position_index` (`site_id`,`position`),
  CONSTRAINT `crm_pipelines_site_id_foreign` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_pipelines`
--

LOCK TABLES `crm_pipelines` WRITE;
/*!40000 ALTER TABLE `crm_pipelines` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_pipelines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_stages`
--

DROP TABLE IF EXISTS `crm_stages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm_stages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `pipeline_id` bigint unsigned NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` smallint unsigned NOT NULL DEFAULT '0',
  `probability` tinyint unsigned NOT NULL DEFAULT '0',
  `type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `crm_stages_pipeline_id_position_index` (`pipeline_id`,`position`),
  CONSTRAINT `crm_stages_pipeline_id_foreign` FOREIGN KEY (`pipeline_id`) REFERENCES `crm_pipelines` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_stages`
--

LOCK TABLES `crm_stages` WRITE;
/*!40000 ALTER TABLE `crm_stages` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_stages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_suite_activities`
--

DROP TABLE IF EXISTS `crm_suite_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm_suite_activities` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint unsigned DEFAULT NULL,
  `subject_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_id` bigint unsigned NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8mb4_unicode_ci,
  `occurred_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `crm_suite_activities_created_by_foreign` (`created_by`),
  KEY `crm_suite_activities_subject_type_subject_id_index` (`subject_type`,`subject_id`),
  KEY `crm_suite_activities_site_id_type_index` (`site_id`,`type`),
  KEY `crm_suite_activities_occurred_at_index` (`occurred_at`),
  CONSTRAINT `crm_suite_activities_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `crm_suite_activities_site_id_foreign` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_suite_activities`
--

LOCK TABLES `crm_suite_activities` WRITE;
/*!40000 ALTER TABLE `crm_suite_activities` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_suite_activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_suite_contacts`
--

DROP TABLE IF EXISTS `crm_suite_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm_suite_contacts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint unsigned DEFAULT NULL,
  `company_id` bigint unsigned DEFAULT NULL,
  `first_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job_title` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lifecycle_stage` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'lead',
  `owner_user_id` bigint unsigned DEFAULT NULL,
  `is_favorite` tinyint(1) NOT NULL DEFAULT '0',
  `archived_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `crm_suite_contacts_owner_user_id_foreign` (`owner_user_id`),
  KEY `crm_suite_contacts_site_id_lifecycle_stage_index` (`site_id`,`lifecycle_stage`),
  KEY `crm_suite_contacts_site_id_archived_at_index` (`site_id`,`archived_at`),
  KEY `crm_suite_contacts_company_id_index` (`company_id`),
  KEY `crm_suite_contacts_email_index` (`email`),
  CONSTRAINT `crm_suite_contacts_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `crm_companies` (`id`) ON DELETE SET NULL,
  CONSTRAINT `crm_suite_contacts_owner_user_id_foreign` FOREIGN KEY (`owner_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `crm_suite_contacts_site_id_foreign` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_suite_contacts`
--

LOCK TABLES `crm_suite_contacts` WRITE;
/*!40000 ALTER TABLE `crm_suite_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_suite_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_taggables`
--

DROP TABLE IF EXISTS `crm_taggables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm_taggables` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tag_id` bigint unsigned NOT NULL,
  `taggable_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `taggable_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `crm_taggables_tag_id_taggable_type_taggable_id_unique` (`tag_id`,`taggable_type`,`taggable_id`),
  KEY `crm_taggables_taggable_type_taggable_id_index` (`taggable_type`,`taggable_id`),
  CONSTRAINT `crm_taggables_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `crm_tags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_taggables`
--

LOCK TABLES `crm_taggables` WRITE;
/*!40000 ALTER TABLE `crm_taggables` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_taggables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_tags`
--

DROP TABLE IF EXISTS `crm_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm_tags` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint unsigned DEFAULT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#6b7280',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `crm_tags_site_id_name_unique` (`site_id`,`name`),
  CONSTRAINT `crm_tags_site_id_foreign` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_tags`
--

LOCK TABLES `crm_tags` WRITE;
/*!40000 ALTER TABLE `crm_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_tasks`
--

DROP TABLE IF EXISTS `crm_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm_tasks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint unsigned DEFAULT NULL,
  `subject_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject_id` bigint unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `due_at` timestamp NULL DEFAULT NULL,
  `remind_at` timestamp NULL DEFAULT NULL,
  `reminder_sent_at` timestamp NULL DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `assigned_to` bigint unsigned DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `crm_tasks_created_by_foreign` (`created_by`),
  KEY `crm_tasks_subject_type_subject_id_index` (`subject_type`,`subject_id`),
  KEY `crm_tasks_site_id_status_index` (`site_id`,`status`),
  KEY `crm_tasks_due_at_index` (`due_at`),
  KEY `crm_tasks_assigned_to_index` (`assigned_to`),
  CONSTRAINT `crm_tasks_assigned_to_foreign` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `crm_tasks_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `crm_tasks_site_id_foreign` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_tasks`
--

LOCK TABLES `crm_tasks` WRITE;
/*!40000 ALTER TABLE `crm_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customers_mobile_unique` (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form_automations`
--

DROP TABLE IF EXISTS `form_automations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_automations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `form_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `config` json NOT NULL,
  `conditions` json DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `form_automations_uuid_unique` (`uuid`),
  KEY `form_automations_form_id_is_active_index` (`form_id`,`is_active`),
  CONSTRAINT `form_automations_form_id_foreign` FOREIGN KEY (`form_id`) REFERENCES `forms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_automations`
--

LOCK TABLES `form_automations` WRITE;
/*!40000 ALTER TABLE `form_automations` DISABLE KEYS */;
/*!40000 ALTER TABLE `form_automations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form_fields`
--

DROP TABLE IF EXISTS `form_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_fields` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `form_id` bigint unsigned NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `position` int NOT NULL DEFAULT '0',
  `options` json DEFAULT NULL,
  `placeholder` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `help_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `conditions` json DEFAULT NULL,
  `section_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `column_span` tinyint unsigned NOT NULL DEFAULT '12',
  `default_value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `css_class` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `validation_rules` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `form_fields_form_id_foreign` (`form_id`),
  CONSTRAINT `form_fields_form_id_foreign` FOREIGN KEY (`form_id`) REFERENCES `forms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_fields`
--

LOCK TABLES `form_fields` WRITE;
/*!40000 ALTER TABLE `form_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `form_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form_submissions`
--

DROP TABLE IF EXISTS `form_submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_submissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `form_id` bigint unsigned NOT NULL,
  `data` json NOT NULL,
  `ip` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `form_submissions_form_id_foreign` (`form_id`),
  CONSTRAINT `form_submissions_form_id_foreign` FOREIGN KEY (`form_id`) REFERENCES `forms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_submissions`
--

LOCK TABLES `form_submissions` WRITE;
/*!40000 ALTER TABLE `form_submissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `form_submissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form_templates`
--

DROP TABLE IF EXISTS `form_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_templates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'general',
  `thumbnail` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `schema` json NOT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT '0',
  `site_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `form_templates_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_templates`
--

LOCK TABLES `form_templates` WRITE;
/*!40000 ALTER TABLE `form_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `form_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forms`
--

DROP TABLE IF EXISTS `forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `forms` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `canonical_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_robots` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `intro_text` text COLLATE utf8mb4_unicode_ci,
  `enable_simple_captcha` tinyint(1) NOT NULL DEFAULT '0',
  `enable_hcaptcha` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `settings` json DEFAULT NULL,
  `template_id` bigint unsigned DEFAULT NULL,
  `step_count` smallint unsigned NOT NULL DEFAULT '1',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `forms_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms`
--

LOCK TABLES `forms` WRITE;
/*!40000 ALTER TABLE `forms` DISABLE KEYS */;
/*!40000 ALTER TABLE `forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `homepage_videos`
--

DROP TABLE IF EXISTS `homepage_videos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `homepage_videos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subtitle` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'youtube',
  `video_url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `thumbnail_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `autoplay` tinyint(1) NOT NULL DEFAULT '0',
  `loop` tinyint(1) NOT NULL DEFAULT '0',
  `muted` tinyint(1) NOT NULL DEFAULT '1',
  `show_controls` tinyint(1) NOT NULL DEFAULT '1',
  `overlay_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `overlay_opacity` tinyint unsigned NOT NULL DEFAULT '30',
  `cta_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cta_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` smallint unsigned NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `homepage_videos`
--

LOCK TABLES `homepage_videos` WRITE;
/*!40000 ALTER TABLE `homepage_videos` DISABLE KEYS */;
INSERT INTO `homepage_videos` VALUES (1,'فروش ویژه',NULL,'mp4','https://video-previews.elements.envatousercontent.com/h264-video-previews/2089a9e4-6395-4fdb-8300-44872375151e/1721280.mp4','video_thumb/2026/06/3AkVjytKcOnRFCVXdviXGg.webp',1,0,1,1,NULL,30,NULL,NULL,0,1,'2026-06-30 13:35:26','2026-06-30 13:43:03');
/*!40000 ALTER TABLE `homepage_videos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `installment_orders`
--

DROP TABLE IF EXISTS `installment_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `installment_orders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint unsigned DEFAULT NULL,
  `user_id` bigint unsigned NOT NULL,
  `plan_id` bigint unsigned NOT NULL,
  `total_amount` bigint unsigned NOT NULL,
  `down_payment` bigint unsigned NOT NULL,
  `remaining_amount` bigint unsigned NOT NULL,
  `monthly_installment` bigint unsigned NOT NULL,
  `installments_total` tinyint unsigned NOT NULL,
  `installments_paid` tinyint unsigned NOT NULL DEFAULT '0',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `gateway_ref` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `next_due_date` date DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `installment_orders_plan_id_foreign` (`plan_id`),
  KEY `installment_orders_user_id_status_index` (`user_id`,`status`),
  CONSTRAINT `installment_orders_plan_id_foreign` FOREIGN KEY (`plan_id`) REFERENCES `installment_plans` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `installment_orders`
--

LOCK TABLES `installment_orders` WRITE;
/*!40000 ALTER TABLE `installment_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `installment_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `installment_payments`
--

DROP TABLE IF EXISTS `installment_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `installment_payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `installment_order_id` bigint unsigned NOT NULL,
  `installment_number` tinyint unsigned NOT NULL,
  `due_date` date NOT NULL,
  `amount` bigint unsigned NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `paid_at` timestamp NULL DEFAULT NULL,
  `gateway` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gateway_ref` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `installment_payments_installment_order_id_status_index` (`installment_order_id`,`status`),
  CONSTRAINT `installment_payments_installment_order_id_foreign` FOREIGN KEY (`installment_order_id`) REFERENCES `installment_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `installment_payments`
--

LOCK TABLES `installment_payments` WRITE;
/*!40000 ALTER TABLE `installment_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `installment_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `installment_plans`
--

DROP TABLE IF EXISTS `installment_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `installment_plans` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `period_months` tinyint unsigned NOT NULL,
  `down_payment_percent` tinyint unsigned NOT NULL,
  `monthly_interest_rate` decimal(5,2) NOT NULL DEFAULT '0.00',
  `min_amount` bigint unsigned NOT NULL DEFAULT '0',
  `max_amount` bigint unsigned NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `installment_plans`
--

LOCK TABLES `installment_plans` WRITE;
/*!40000 ALTER TABLE `installment_plans` DISABLE KEYS */;
INSERT INTO `installment_plans` VALUES (1,'اقساط 4 ماهه',6,20,1.99,5000000,0,1,'2026-06-14 18:36:10','2026-06-15 16:35:12');
/*!40000 ALTER TABLE `installment_plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_items`
--

DROP TABLE IF EXISTS `inventory_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `warehouse_id` bigint unsigned NOT NULL,
  `quantity` int unsigned NOT NULL DEFAULT '0',
  `reserved_quantity` int unsigned NOT NULL DEFAULT '0',
  `low_stock_threshold` int unsigned NOT NULL DEFAULT '5',
  `reorder_quantity` int unsigned NOT NULL DEFAULT '10',
  `location` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_restocked_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `inventory_items_product_id_warehouse_id_unique` (`product_id`,`warehouse_id`),
  KEY `inventory_items_product_id_index` (`product_id`),
  KEY `inventory_items_warehouse_id_index` (`warehouse_id`),
  CONSTRAINT `inventory_items_warehouse_id_foreign` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_items`
--

LOCK TABLES `inventory_items` WRITE;
/*!40000 ALTER TABLE `inventory_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_items`
--

DROP TABLE IF EXISTS `invoice_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `invoice_id` bigint unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(14,2) NOT NULL,
  `quantity` int unsigned NOT NULL DEFAULT '1',
  `total` decimal(14,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_items_invoice_id_foreign` (`invoice_id`),
  CONSTRAINT `invoice_items_invoice_id_foreign` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_items`
--

LOCK TABLES `invoice_items` WRITE;
/*!40000 ALTER TABLE `invoice_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoices` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `invoice_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_mobile` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subtotal` decimal(14,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(14,2) NOT NULL DEFAULT '0.00',
  `total` decimal(14,2) NOT NULL DEFAULT '0.00',
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `payment_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_at` timestamp NULL DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoices_invoice_number_unique` (`invoice_number`),
  KEY `invoices_user_id_foreign` (`user_id`),
  CONSTRAINT `invoices_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `licenses`
--

DROP TABLE IF EXISTS `licenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `licenses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `license_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `domain` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `modules` json DEFAULT NULL,
  `support_expires_at` timestamp NULL DEFAULT NULL,
  `support_starts_at` timestamp NULL DEFAULT NULL,
  `support_level` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'basic',
  `platform_valid` tinyint(1) NOT NULL DEFAULT '1',
  `last_validated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `licenses`
--

LOCK TABLES `licenses` WRITE;
/*!40000 ALTER TABLE `licenses` DISABLE KEYS */;
INSERT INTO `licenses` VALUES (2,'eyJpdiI6IldnWGUxL2xwT0QvVE9TTmtKVmtYY3c9PSIsInZhbHVlIjoiTDMrMVVRRit0eVNucDZDcEkrdlJNYkY5K1BXWHQ0VldzbHNVdW5DUHVFQT0iLCJtYWMiOiIwMWMwNjAxZDNhMzJjNTIzZjRiNGFmOTQyNDM3N2M5MDVjZWE5ODdjMDU1MTQ3MGNiODBkZjVhYTVlZjI4ZDEwIiwidGFnIjoiIn0=','safhenokhost.ir','2031-06-09 20:19:18','[\"captcha\", \"module_labels\", \"blog\", \"shop\", \"forms\", \"advertisements\", \"bank_gateway\", \"coupon\", \"reviews\", \"referral\", \"subscription\", \"whatsapp\", \"sms\", \"courses\", \"invoice\", \"business_card\", \"social_links\", \"notifications\", \"advanced_search\", \"currency_reform\", \"seo_advanced\", \"multi_currency\", \"marketplace_sync\", \"video\", \"projects\", \"qa\", \"menu\", \"announcements\", \"backup\", \"cloud\", \"podcast\", \"marketing_automation\", \"discount_advanced\", \"wallet\", \"product_bundling\", \"shipping\", \"inventory\", \"accounting\", \"gallery\", \"services\", \"tasks\", \"contract\", \"media\", \"brand\", \"i18n\", \"crm\", \"analytics\", \"recruitment\", \"portfolio\", \"omnichannel\", \"support\", \"installments\", \"translations\", \"homepage_videos\", \"access_lists\", \"smart_image\"]','2031-03-20 20:30:00',NULL,'basic',1,'2026-08-19 17:36:34','2026-06-09 20:22:54','2026-08-19 17:36:34');
/*!40000 ALTER TABLE `licenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membership_points`
--

DROP TABLE IF EXISTS `membership_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `membership_points` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `amount` int NOT NULL,
  `balance_after` int NOT NULL,
  `type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_id` bigint unsigned DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `membership_points_reference_type_reference_id_index` (`reference_type`,`reference_id`),
  KEY `membership_points_user_id_created_at_index` (`user_id`,`created_at`),
  KEY `membership_points_user_id_expires_at_index` (`user_id`,`expires_at`),
  CONSTRAINT `membership_points_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_points`
--

LOCK TABLES `membership_points` WRITE;
/*!40000 ALTER TABLE `membership_points` DISABLE KEYS */;
/*!40000 ALTER TABLE `membership_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_change_logs`
--

DROP TABLE IF EXISTS `menu_change_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu_change_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `menu_id` bigint unsigned NOT NULL,
  `action` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `diff_json` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `menu_change_logs_user_id_foreign` (`user_id`),
  KEY `menu_change_logs_menu_id_created_at_index` (`menu_id`,`created_at`),
  CONSTRAINT `menu_change_logs_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`) ON DELETE CASCADE,
  CONSTRAINT `menu_change_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_change_logs`
--

LOCK TABLES `menu_change_logs` WRITE;
/*!40000 ALTER TABLE `menu_change_logs` DISABLE KEYS */;
INSERT INTO `menu_change_logs` VALUES (1,1,1,'menu_created','{\"name\": \"منوی اصلی\"}','2026-06-14 18:55:46','2026-06-14 18:55:46'),(2,1,1,'item_created','{\"item_id\": 1}','2026-06-14 18:57:45','2026-06-14 18:57:45');
/*!40000 ALTER TABLE `menu_change_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_items`
--

DROP TABLE IF EXISTS `menu_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `menu_id` bigint unsigned NOT NULL,
  `parent_id` bigint unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'custom_url' COMMENT 'internal_page, blog, shop, category, custom_url',
  `reference_id` bigint unsigned DEFAULT NULL COMMENT 'Page id, category id, etc.',
  `url` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'For custom_url or fallback',
  `icon` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` int unsigned NOT NULL DEFAULT '0',
  `open_in_new_tab` tinyint(1) NOT NULL DEFAULT '0',
  `css_class` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `title_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `labels` json DEFAULT NULL COMMENT 'برچسب‌های چندزبانه اختیاری',
  `utm_query` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `utm_json` json DEFAULT NULL,
  `rel_nofollow` tinyint(1) NOT NULL DEFAULT '0',
  `badge_label` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_url` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mega_column` tinyint unsigned DEFAULT NULL,
  `featured_html` text COLLATE utf8mb4_unicode_ci,
  `auto_list_children` tinyint(1) NOT NULL DEFAULT '0',
  `visible_modules` json DEFAULT NULL COMMENT 'slug ماژول‌ها؛ خالی = همیشه',
  PRIMARY KEY (`id`),
  KEY `menu_items_menu_id_parent_id_order_index` (`menu_id`,`parent_id`,`order`),
  CONSTRAINT `menu_items_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_items`
--

LOCK TABLES `menu_items` WRITE;
/*!40000 ALTER TABLE `menu_items` DISABLE KEYS */;
INSERT INTO `menu_items` VALUES (1,1,NULL,'صفحه نخست','custom_url',NULL,'http://safhenokhost.ir/',NULL,1,0,NULL,'2026-06-14 18:57:45','2026-06-14 18:57:45','safhenokhost',NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,0,NULL);
/*!40000 ALTER TABLE `menu_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_revisions`
--

DROP TABLE IF EXISTS `menu_revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu_revisions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `menu_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `snapshot_json` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `menu_revisions_user_id_foreign` (`user_id`),
  KEY `menu_revisions_menu_id_created_at_index` (`menu_id`,`created_at`),
  CONSTRAINT `menu_revisions_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`) ON DELETE CASCADE,
  CONSTRAINT `menu_revisions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_revisions`
--

LOCK TABLES `menu_revisions` WRITE;
/*!40000 ALTER TABLE `menu_revisions` DISABLE KEYS */;
/*!40000 ALTER TABLE `menu_revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menus`
--

DROP TABLE IF EXISTS `menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menus` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint unsigned DEFAULT NULL COMMENT 'Optional tenant/site scope',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'primary' COMMENT 'primary, footer, mobile, topbar',
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'published' COMMENT 'draft, published',
  `go_live_at` timestamp NULL DEFAULT NULL COMMENT 'انتشار زمان‌بندی‌شده',
  `preview_token` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `menus_site_id_location_unique` (`site_id`,`location`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menus`
--

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
INSERT INTO `menus` VALUES (1,NULL,'منوی اصلی','primary','published',NULL,'7b2db78b3ac649478b7e44ac12379775','2026-06-14 18:55:46','2026-06-14 18:55:46');
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messaging_channels`
--

DROP TABLE IF EXISTS `messaging_channels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `messaging_channels` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `platform` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `order` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messaging_channels`
--

LOCK TABLES `messaging_channels` WRITE;
/*!40000 ALTER TABLE `messaging_channels` DISABLE KEYS */;
/*!40000 ALTER TABLE `messaging_channels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=159 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2026_02_07_160318_create_customers_table',1),(5,'2026_02_07_160435_create_sites_table',1),(6,'2026_02_07_160522_create_modules_table',1),(7,'2026_02_22_100000_add_is_admin_to_users_table',1),(8,'2026_02_22_100001_create_settings_table',1),(9,'2026_02_22_100002_create_pages_table',1),(10,'2026_02_22_100003_create_blog_tables',1),(11,'2026_02_22_100004_create_shop_tables',1),(12,'2026_02_22_120000_create_licenses_table',1),(13,'2026_02_23_100000_add_mobile_to_users_table',1),(14,'2026_02_23_100000_add_product_categories',1),(15,'2026_02_26_150000_add_remote_fields_to_licenses_table',1),(16,'2026_02_26_210000_create_coupons_table',1),(17,'2026_02_26_210001_create_reviews_table',1),(18,'2026_02_26_210002_create_referral_tables',1),(19,'2026_02_26_210003_create_subscription_tables',1),(20,'2026_02_26_210004_create_courses_tables',1),(21,'2026_02_26_210005_create_invoices_table',1),(22,'2026_02_26_210006_create_business_cards_table',1),(23,'2026_02_26_210007_create_social_links_table',1),(24,'2026_02_26_220000_create_forms_tables',1),(25,'2026_02_26_220000_create_module_versions_table',1),(26,'2026_02_26_220001_seed_module_versions_initial',1),(27,'2026_02_27_100000_add_support_license_fields_to_licenses',1),(28,'2026_02_27_100000_create_notifications_table',1),(29,'2026_02_27_110000_create_messaging_channels_table',1),(30,'2026_02_27_110001_migrate_whatsapp_to_messaging',1),(31,'2026_02_28_100000_add_custom_fields_to_messaging_channels',1),(32,'2026_02_28_100000_add_toolbar_fields_to_notifications',1),(33,'2026_02_28_100000_create_roles_table',1),(34,'2026_02_28_100001_create_permissions_table',1),(35,'2026_02_28_100002_create_role_tables',1),(36,'2026_02_28_100003_seed_site_roles_and_permissions',1),(37,'2026_02_28_100004_assign_tenant_admin_to_existing_admins',1),(38,'2026_02_28_120000_add_audience_to_notifications',1),(39,'2026_02_28_150000_add_platform_valid_to_licenses',1),(40,'2026_02_28_180000_create_advertisements_table',1),(41,'2026_02_28_200000_add_builder_fields_to_pages_table',1),(42,'2026_02_28_200000_add_min_order_to_coupons_and_coupon_to_orders',1),(43,'2026_02_28_210000_add_user_id_to_orders_and_invoices',1),(44,'2026_02_28_210000_create_page_templates_table',1),(45,'2026_02_28_210001_create_user_notifications_table',1),(46,'2026_02_28_220000_add_profile_fields_to_users_table',1),(47,'2026_02_28_220001_create_user_addresses_table',1),(48,'2026_02_28_220002_create_user_activity_log_table',1),(49,'2026_02_28_220003_create_account_deletion_requests_table',1),(50,'2026_02_28_230000_create_notification_batches_table',1),(51,'2026_02_28_240000_add_advanced_discount_fields_to_coupons',1),(52,'2026_02_28_250000_add_page_level_header_footer_override_to_pages_table',1),(53,'2026_02_28_260000_create_menus_table',1),(54,'2026_02_28_260001_create_menu_items_table',1),(55,'2026_02_28_270000_create_theme_settings_table',1),(56,'2026_02_29_100000_add_builder_content_v2_to_pages_table',1),(57,'2026_05_05_123500_seed_staff_default_permissions',1),(58,'2026_05_08_130000_shop_product_publish_seo_categories',1),(59,'2026_05_08_130100_shop_variants_images_order_items',1),(60,'2026_05_08_130200_shop_attributes_tags_related_bundles',1),(61,'2026_05_08_130300_shop_reviews_notify_wishlist_audit_events',1),(62,'2026_05_08_170000_create_module_change_logs_table',1),(63,'2026_05_08_180000_blog_professional_features',1),(64,'2026_05_08_200000_extend_menus_professional',1),(65,'2026_05_09_140000_add_seo_to_forms_table',1),(66,'2026_05_11_180000_create_admin_activity_log_table',1),(67,'2026_05_13_100000_make_coupons_discount_percent_nullable',1),(68,'2026_05_13_100100_create_order_status_history_table',1),(69,'2026_05_13_100200_add_restocked_at_to_orders',1),(70,'2026_05_13_110000_add_timestamps_to_shop_pivots',1),(71,'2026_05_14_120000_add_causer_id_to_admin_activity_log_table',1),(72,'2026_05_23_000001_create_tickets_table',1),(73,'2026_05_23_000002_create_ticket_replies_table',1),(74,'2026_05_27_000001_add_phase9_settings_to_forms_table',1),(75,'2026_05_27_000001_add_watchers_to_tickets_table',1),(76,'2026_05_27_000002_add_phase9_columns_to_form_fields_table',1),(77,'2026_05_27_000002_create_ticket_activities_table',1),(78,'2026_05_27_000003_add_is_internal_to_ticket_replies_table',1),(79,'2026_05_27_000003_create_form_templates_table',1),(80,'2026_05_27_000004_create_form_automations_table',1),(81,'2026_05_29_140000_make_email_nullable_in_users_table',1),(82,'2026_05_30_000001_remove_email_add_mobile_to_users',1),(83,'2026_05_30_000001_rename_customer_email_to_customer_mobile_in_tickets',1),(84,'2026_05_30_000002_remove_email_from_customers',1),(85,'2026_05_30_000003_rename_customer_email_in_orders_and_invoices',1),(86,'2026_05_31_000001_add_customer_mobile_to_ticket_replies',1),(87,'2026_06_01_000010_create_support_conversations_table',1),(88,'2026_06_01_000011_create_support_conversation_participants_table',1),(89,'2026_06_01_000012_create_support_messages_table',1),(90,'2026_06_01_000013_create_support_message_attachments_table',1),(91,'2026_06_01_000014_create_support_presence_table',1),(92,'2026_06_01_000015_create_support_read_receipts_table',1),(93,'2026_06_03_100001_add_api_token_to_users_table',1),(94,'2026_06_04_000001_add_feature_request_to_tickets',1),(95,'2026_06_04_000002_add_push_subscriptions_table',1),(96,'2026_06_04_100000_create_push_subscriptions_table',1),(97,'2026_06_05_000001_add_fields_to_subscription_plans_table',1),(98,'2026_06_05_000002_add_fields_to_subscriptions_table',1),(99,'2026_06_05_000003_create_subscription_logs_table',1),(100,'2026_06_05_200001_add_advanced_fields_to_subscription_plans',1),(101,'2026_06_05_300001_update_subscription_plans_add_benefits',1),(102,'2026_06_05_300002_add_discount_notes_to_invoices',1),(103,'2026_06_06_070359_add_product_scope_to_subscription_plans',1),(104,'2026_06_06_100000_add_membership_discount_to_orders_table',1),(105,'2026_06_06_200000_create_membership_points_table',1),(106,'2026_06_06_200001_add_points_columns_to_orders_table',1),(107,'2026_06_06_200002_change_loyalty_multiplier_to_decimal_in_subscription_plans',1),(108,'2026_06_06_300000_add_reminder_columns_to_subscriptions_table',1),(109,'2026_06_06_300000_add_reward_fields_to_referrals_table',1),(110,'2026_06_07_100000_add_missing_columns_to_tags_table',1),(111,'2026_06_07_100000_add_shipping_cost_to_orders_table',1),(112,'2026_06_07_100001_add_soft_deletes_to_forms_table',1),(113,'2026_06_07_200000_add_early_access_to_products_table',1),(114,'2026_06_07_300000_add_upgrade_fields_to_subscriptions_table',1),(115,'2026_06_07_400000_create_subscription_members_table',1),(116,'2026_06_08_100000_create_webhook_tables',1),(117,'2026_06_09_100000_create_site_contents_tables',2),(118,'2026_06_10_000001_create_ai_generation_jobs_table',3),(119,'2026_06_11_000001_add_is_platform_agent_to_users_table',4),(120,'2026_06_11_100000_create_course_class_completions_table',99),(121,'2026_06_13_100000_create_homepage_videos_table',100),(122,'2026_06_13_200000_create_translations_tables',100),(123,'2026_06_13_300000_create_installment_tables',101),(124,'2026_06_13_400000_create_access_list_tables',102),(125,'2026_06_13_500000_create_analytics_page_views_table',103),(126,'2026_06_13_100000_create_customer_payment_gateways_table',104),(127,'2026_06_14_100000_create_admin_notifications_table',105),(128,'2026_06_14_200000_add_builder_content_to_posts_and_products',106),(129,'2026_06_15_100000_create_crm_tables',107),(130,'2026_06_15_200000_create_inventory_tables',107),(131,'2026_06_15_200000_add_protection_to_pages_table',108),(132,'2026_06_15_200001_create_page_revisions_table',108),(133,'2026_06_19_300001_create_site_theme_templates_table',109),(134,'2026_06_21_100000_create_sms_campaigns_tables',110),(135,'2026_06_26_110000_add_color_fields_to_theme_settings_table',111),(136,'2026_06_29_000001_add_force_password_change_to_users_table',112),(137,'2026_07_29_100000_create_seo_advanced_settings_table',113),(138,'2026_07_29_100001_create_seo_advanced_redirects_table',113),(139,'2026_07_29_100002_create_seo_advanced_audits_table',113),(140,'2026_07_30_100000_add_commercial_settings_to_seo_advanced_settings_table',113),(141,'2026_07_31_100000_add_issues_to_seo_advanced_audits_table',113),(142,'2026_07_31_100001_create_seo_advanced_keywords_table',113),(143,'2026_08_01_100000_create_crm_companies_table',113),(144,'2026_08_01_100001_create_crm_tags_table',113),(145,'2026_08_01_100002_create_crm_taggables_table',113),(146,'2026_08_01_100003_create_crm_contacts_table',113),(147,'2026_08_01_100004_create_crm_pipelines_table',113),(148,'2026_08_01_100005_create_crm_stages_table',113),(149,'2026_08_01_100006_create_crm_opportunities_table',113),(150,'2026_08_01_100007_create_crm_leads_table',113),(151,'2026_08_01_100008_create_crm_activities_table',113),(152,'2026_08_01_100009_create_crm_tasks_table',113),(153,'2026_08_01_100010_create_crm_attachments_table',113),(154,'2026_08_02_100000_add_stage_changed_at_to_crm_opportunities_table',113),(155,'2026_08_02_100000_create_seo_advanced_keyword_positions_table',113),(156,'2026_08_02_100001_add_reminder_tracking_columns',113),(157,'2026_08_02_100001_add_title_description_text_to_seo_advanced_audits_table',113),(158,'2026_08_02_100002_create_seo_advanced_search_console_connections_table',113);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `module_change_logs`
--

DROP TABLE IF EXISTS `module_change_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `module_change_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `module_slug` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `release_type` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'patch',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `changelog` text COLLATE utf8mb4_unicode_ci,
  `released_at` timestamp NULL DEFAULT NULL,
  `synced_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `module_change_logs_module_slug_version_unique` (`module_slug`,`version`),
  KEY `module_change_logs_module_slug_released_at_index` (`module_slug`,`released_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `module_change_logs`
--

LOCK TABLES `module_change_logs` WRITE;
/*!40000 ALTER TABLE `module_change_logs` DISABLE KEYS */;
INSERT INTO `module_change_logs` VALUES (1,'blog','1.4.0','minor','وبلاگ حرفه‌ای','ویرایشگر WYSIWYG (TinyMCE) برای محتوا\nپیش‌نویس، زمان‌بندی، وضعیت انتشار و گردش کار تایید (پیش‌نویس / در انتظار تایید / تایید / رد / منتشر)\nفیلدهای SEO: canonical، og:image اختصاصی\nبرچسب‌ها و مجموعهٔ مطالب (سری) با شمارهٔ قسمت\nگالری تصاویر، تاریخچهٔ نسخه‌ها با بازگردانی\nشمارش بازدید با یک‌بار در نشست، لایک ساده\nمسیرهای فرانت: سری، فیلتر برچسب، لایک','2026-06-09 13:39:34',NULL,'2026-06-09 13:39:34','2026-06-09 13:39:34');
/*!40000 ALTER TABLE `module_change_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `module_versions`
--

DROP TABLE IF EXISTS `module_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `module_versions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `module_slug` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1.0.0',
  `installed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `module_versions_module_slug_unique` (`module_slug`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `module_versions`
--

LOCK TABLES `module_versions` WRITE;
/*!40000 ALTER TABLE `module_versions` DISABLE KEYS */;
INSERT INTO `module_versions` VALUES (1,'blog','1.4.0','2026-06-09 13:39:09','2026-06-09 13:39:09','2026-06-09 13:39:34'),(2,'shop','1.0.0','2026-06-09 13:39:09','2026-06-09 13:39:09','2026-06-09 13:39:09'),(3,'coupon','1.0.0','2026-06-09 13:39:09','2026-06-09 13:39:09','2026-06-09 13:39:09'),(4,'reviews','1.0.0','2026-06-09 13:39:09','2026-06-09 13:39:09','2026-06-09 13:39:09'),(5,'referral','1.0.0','2026-06-09 13:39:09','2026-06-09 13:39:09','2026-06-09 13:39:09'),(6,'subscription','1.0.0','2026-06-09 13:39:09','2026-06-09 13:39:09','2026-06-09 13:39:09'),(7,'whatsapp','1.0.0','2026-06-09 13:39:09','2026-06-09 13:39:09','2026-06-09 13:39:09'),(8,'sms','1.0.0','2026-06-09 13:39:09','2026-06-09 13:39:09','2026-06-09 13:39:09'),(9,'courses','1.0.0','2026-06-09 13:39:09','2026-06-09 13:39:09','2026-06-09 13:39:09'),(10,'invoice','1.0.0','2026-06-09 13:39:09','2026-06-09 13:39:09','2026-06-09 13:39:09'),(11,'business_card','1.0.0','2026-06-09 13:39:09','2026-06-09 13:39:09','2026-06-09 13:39:09'),(12,'social_links','1.0.0','2026-06-09 13:39:09','2026-06-09 13:39:09','2026-06-09 13:39:09'),(13,'advertisements','1.0.0','2026-06-09 13:39:09','2026-06-09 13:39:09','2026-06-09 13:39:09'),(14,'forms','1.0.0','2026-06-09 13:39:09','2026-06-09 13:39:09','2026-06-09 13:39:09'),(15,'advanced_search','1.0.0','2026-06-09 13:39:09','2026-06-09 13:39:09','2026-06-09 13:39:09'),(16,'currency_reform','1.0.0','2026-06-09 13:39:09','2026-06-09 13:39:09','2026-06-09 13:39:09'),(17,'menu','1.0.0','2026-06-09 13:39:09','2026-06-09 13:39:09','2026-06-09 13:39:09');
/*!40000 ALTER TABLE `module_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modules`
--

DROP TABLE IF EXISTS `modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `modules` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modules`
--

LOCK TABLES `modules` WRITE;
/*!40000 ALTER TABLE `modules` DISABLE KEYS */;
/*!40000 ALTER TABLE `modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_batches`
--

DROP TABLE IF EXISTS `notification_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_batches` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'info',
  `link` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` json DEFAULT NULL,
  `sent_at` timestamp NOT NULL,
  `recipient_count` int unsigned NOT NULL DEFAULT '0',
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notification_batches_created_by_foreign` (`created_by`),
  CONSTRAINT `notification_batches_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_batches`
--

LOCK TABLES `notification_batches` WRITE;
/*!40000 ALTER TABLE `notification_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'info',
  `link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'top',
  `image_position` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'right',
  `image_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_shaking_logo` tinyint(1) NOT NULL DEFAULT '1',
  `starts_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `order` int unsigned NOT NULL DEFAULT '0',
  `audience` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'public',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (1,'فروش ویژه','<p>فروش ویژه پشتیبانی به مناسبت ...</p>','info','https://safhenokhost.ir/','همینجاست !','top','background','featured/2026/06/Vi7MzTQz0bx7ZmpdNZARRz.webp',1,'2026-06-20 00:00:00','2026-08-21 23:59:59',0,0,'public','2026-06-20 11:10:24','2026-06-25 09:46:32');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned DEFAULT NULL,
  `product_variant_id` bigint unsigned DEFAULT NULL,
  `variant_label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(14,2) NOT NULL,
  `quantity` int unsigned NOT NULL DEFAULT '1',
  `total` decimal(14,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_items_order_id_foreign` (`order_id`),
  KEY `order_items_product_id_foreign` (`product_id`),
  KEY `order_items_product_variant_id_foreign` (`product_variant_id`),
  CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL,
  CONSTRAINT `order_items_product_variant_id_foreign` FOREIGN KEY (`product_variant_id`) REFERENCES `product_variants` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_status_history`
--

DROP TABLE IF EXISTS `order_status_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_status_history` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint unsigned NOT NULL,
  `from_status` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `to_status` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `changed_by_user_id` bigint unsigned DEFAULT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `side_effects` json DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `order_status_history_changed_by_user_id_foreign` (`changed_by_user_id`),
  KEY `order_status_history_order_id_created_at_index` (`order_id`,`created_at`),
  KEY `order_status_history_to_status_index` (`to_status`),
  CONSTRAINT `order_status_history_changed_by_user_id_foreign` FOREIGN KEY (`changed_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `order_status_history_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_status_history`
--

LOCK TABLES `order_status_history` WRITE;
/*!40000 ALTER TABLE `order_status_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_status_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_mobile` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_address` text COLLATE utf8mb4_unicode_ci,
  `note` text COLLATE utf8mb4_unicode_ci,
  `subtotal` decimal(14,2) NOT NULL DEFAULT '0.00',
  `shipping_cost` decimal(12,2) NOT NULL DEFAULT '0.00',
  `total` decimal(14,2) NOT NULL DEFAULT '0.00',
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `restocked_at` timestamp NULL DEFAULT NULL,
  `coupon_id` bigint unsigned DEFAULT NULL,
  `discount_amount` decimal(14,2) NOT NULL DEFAULT '0.00',
  `membership_discount_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `membership_plan_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `points_discount_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `points_spent` int unsigned NOT NULL DEFAULT '0',
  `points_earned` int unsigned NOT NULL DEFAULT '0',
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `orders_number_unique` (`number`),
  KEY `orders_coupon_id_foreign` (`coupon_id`),
  KEY `orders_user_id_foreign` (`user_id`),
  CONSTRAINT `orders_coupon_id_foreign` FOREIGN KEY (`coupon_id`) REFERENCES `coupons` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_revisions`
--

DROP TABLE IF EXISTS `page_revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `page_revisions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `page_id` bigint unsigned NOT NULL,
  `blocks_snapshot` json NOT NULL,
  `saved_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `label` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `page_revisions_page_id_created_at_index` (`page_id`,`created_at`),
  KEY `page_revisions_page_id_index` (`page_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_revisions`
--

LOCK TABLES `page_revisions` WRITE;
/*!40000 ALTER TABLE `page_revisions` DISABLE KEYS */;
INSERT INTO `page_revisions` VALUES (1,3,'[{\"id\": \"home-notif\", \"data\": {\"style\": \"top-bar\", \"show_dismiss\": true}, \"type\": \"module:notifications_bar\"}, {\"id\": \"home-hero\", \"data\": {\"align\": \"center\", \"title\": \"فروش هوشمند، پشتیبانی بی‌نقص\", \"subtitle\": \"محصولات باکیفیت، آموزش تخصصی، پشتیبانی ۲۴ ساعته — همه در یک پلتفرم.\", \"background\": \"primary\", \"button_url\": \"/products\", \"button_text\": \"مشاهده محصولات\", \"background_image\": null}, \"type\": \"hero\"}, {\"id\": \"home-stats\", \"data\": {\"padding\": \"lg\", \"container\": true, \"background\": \"surface\"}, \"type\": \"section\", \"blocks\": [{\"id\": \"home-stats-grid\", \"type\": \"grid\", \"props\": {\"gap\": \"lg\", \"columns\": 4}, \"blocks\": [{\"id\": \"stat-1\", \"type\": \"counter\", \"props\": {\"label\": \"مشتری راضی\", \"value\": 5000, \"suffix\": \"+\"}}, {\"id\": \"stat-2\", \"type\": \"counter\", \"props\": {\"label\": \"محصول متنوع\", \"value\": 1200, \"suffix\": \"+\"}}, {\"id\": \"stat-3\", \"type\": \"counter\", \"props\": {\"label\": \"رضایت مشتریان\", \"value\": 98, \"suffix\": \"%\"}}, {\"id\": \"stat-4\", \"type\": \"counter\", \"props\": {\"label\": \"پشتیبانی آنلاین\", \"value\": 24, \"suffix\": \"/۷\"}}]}]}, {\"id\": \"home-countdown\", \"data\": {\"bg_color\": \"#dc2626\", \"end_date\": null, \"promo_text\": \"🔥 پیشنهاد ویژه هفتگی — فرصت محدود!\"}, \"type\": \"module:shop_countdown\"}, {\"id\": \"home-products\", \"data\": {\"padding\": \"lg\", \"container\": true, \"background\": \"background\"}, \"type\": \"section\", \"blocks\": [{\"id\": \"home-prod-h\", \"type\": \"heading\", \"props\": {\"text\": \"محصولات پیشنهادی\", \"level\": 2}}, {\"id\": \"home-prod-grid\", \"type\": \"module:shop_product_grid\", \"props\": {\"limit\": 8, \"title\": \"محصولات ویژه\", \"source\": \"featured\", \"columns\": \"4\", \"category_slug\": null}}, {\"id\": \"home-prod-btn\", \"type\": \"button\", \"props\": {\"url\": \"/products\", \"text\": \"مشاهده همه محصولات\", \"style\": \"primary\"}}]}, {\"id\": \"home-courses\", \"data\": {\"padding\": \"lg\", \"container\": true, \"background\": \"surface\"}, \"type\": \"section\", \"blocks\": [{\"id\": \"home-courses-h\", \"type\": \"heading\", \"props\": {\"text\": \"دوره‌های آموزشی\", \"level\": 2}}, {\"id\": \"home-courses-t\", \"type\": \"text\", \"props\": {\"content\": \"با دوره‌های تخصصی ما مهارت‌های خود را ارتقا دهید.\"}}, {\"id\": \"home-courses-grid\", \"type\": \"module:courses_grid\", \"props\": {\"limit\": 3, \"title\": \"دوره‌های پرطرفدار\", \"layout\": \"grid\", \"columns\": \"3\", \"show_price\": true, \"show_instructor\": true}}]}, {\"id\": \"home-pricing\", \"data\": {\"padding\": \"lg\", \"container\": true, \"background\": \"background\"}, \"type\": \"section\", \"blocks\": [{\"id\": \"home-pricing-table\", \"type\": \"module:pricing_table\", \"props\": {\"title\": \"پلن‌های اشتراک\", \"subtitle\": \"بهترین پلن را برای کسب‌وکار خود انتخاب کنید\", \"highlight_plan\": null, \"show_annual_toggle\": false}}]}, {\"id\": \"home-reviews\", \"data\": {\"padding\": \"lg\", \"container\": true, \"background\": \"surface\"}, \"type\": \"section\", \"blocks\": [{\"id\": \"home-reviews-grid\", \"type\": \"module:reviews_grid\", \"props\": {\"limit\": 6, \"style\": \"cards\", \"title\": \"نظرات مشتریان ما\", \"show_avatar\": true}}]}, {\"id\": \"home-blog\", \"data\": {\"padding\": \"lg\", \"container\": true, \"background\": \"background\"}, \"type\": \"section\", \"blocks\": [{\"id\": \"home-blog-posts\", \"type\": \"module:blog_posts\", \"props\": {\"limit\": 3, \"title\": \"آخرین مطالب\", \"layout\": \"grid\", \"show_date\": true, \"show_excerpt\": true, \"category_slug\": null}}]}, {\"id\": \"home-referral\", \"data\": {\"style\": \"card\", \"title\": \"دوستانت را دعوت کن، جایزه بگیر\", \"subtitle\": \"با معرفی هر دوست، اعتبار هدیه دریافت کنید\", \"show_link\": true}, \"type\": \"module:referral_widget\"}, {\"id\": \"home-cta\", \"data\": {\"title\": \"آماده شروع هستید؟\", \"subtitle\": \"همین الان ثبت‌نام کنید و از پشتیبانی رایگان بهره‌مند شوید.\", \"background\": \"primary\", \"button_url\": \"/register\", \"button_text\": \"شروع رایگان\"}, \"type\": \"cta\"}, {\"id\": \"home-support-btn\", \"data\": {\"label\": \"پشتیبانی آنلاین\", \"style\": \"floating\", \"bg_color\": \"#1e40af\", \"position\": \"bottom-left\"}, \"type\": \"module:support_button\"}]','فرشاد پیکرستان','ذخیره خودکار','2026-06-16 07:54:08','2026-06-16 07:54:08'),(2,4,'[{\"id\": \"about-hero\", \"type\": \"hero\", \"props\": {\"align\": \"center\", \"title\": \"داستان ما\", \"subtitle\": \"تعهد به کیفیت، شفافیت و رضایت مشتریان\", \"background\": \"primary\", \"button_url\": \"/support\", \"button_text\": \"تماس با ما\"}}, {\"id\": \"about-mission\", \"type\": \"section\", \"props\": {\"padding\": \"lg\", \"container\": true, \"background\": \"surface\"}, \"blocks\": [{\"id\": \"about-m-h\", \"type\": \"heading\", \"props\": {\"text\": \"ماموریت ما\", \"level\": 2}}, {\"id\": \"about-m-t\", \"type\": \"text\", \"props\": {\"content\": \"ما با هدف ایجاد پلتفرمی یکپارچه برای فروش، آموزش و پشتیبانی فعالیت می‌کنیم. مشتریان ما می‌توانند از بهترین محصولات، آموزش‌های تخصصی و پشتیبانی ۲۴ ساعته بهره‌مند شوند.\"}}]}, {\"id\": \"about-stats\", \"type\": \"section\", \"props\": {\"padding\": \"lg\", \"container\": true, \"background\": \"background\"}, \"blocks\": [{\"id\": \"about-stats-h\", \"type\": \"heading\", \"props\": {\"text\": \"ما در اعداد\", \"level\": 2}}, {\"id\": \"about-stats-grid\", \"type\": \"grid\", \"props\": {\"gap\": \"lg\", \"columns\": 4}, \"blocks\": [{\"id\": \"about-stat-1\", \"type\": \"counter\", \"props\": {\"label\": \"سابقه فعالیت\", \"value\": 5, \"suffix\": \" سال\"}}, {\"id\": \"about-stat-2\", \"type\": \"counter\", \"props\": {\"label\": \"مشتری راضی\", \"value\": 5000, \"suffix\": \"+\"}}, {\"id\": \"about-stat-3\", \"type\": \"counter\", \"props\": {\"label\": \"متخصص در تیم\", \"value\": 50, \"suffix\": \"+\"}}, {\"id\": \"about-stat-4\", \"type\": \"counter\", \"props\": {\"label\": \"محصول متنوع\", \"value\": 1200, \"suffix\": \"+\"}}]}]}, {\"id\": \"about-values\", \"type\": \"section\", \"props\": {\"padding\": \"lg\", \"container\": true, \"background\": \"surface\"}, \"blocks\": [{\"id\": \"about-val-h\", \"type\": \"heading\", \"props\": {\"text\": \"چرا ما؟\", \"level\": 2}}, {\"id\": \"about-val-grid\", \"type\": \"grid\", \"props\": {\"gap\": \"lg\", \"columns\": 3}, \"blocks\": [{\"id\": \"val-1-h\", \"type\": \"heading\", \"props\": {\"text\": \"✅ محصولات اصل\", \"level\": 4}}, {\"id\": \"val-2-h\", \"type\": \"heading\", \"props\": {\"text\": \"🚀 ارسال سریع\", \"level\": 4}}, {\"id\": \"val-3-h\", \"type\": \"heading\", \"props\": {\"text\": \"🛡️ ضمانت بازگشت وجه\", \"level\": 4}}, {\"id\": \"val-1-t\", \"type\": \"text\", \"props\": {\"content\": \"تمام محصولات با ضمانت اصالت عرضه می‌شوند.\"}}, {\"id\": \"val-2-t\", \"type\": \"text\", \"props\": {\"content\": \"ارسال در کمترین زمان ممکن به سراسر کشور.\"}}, {\"id\": \"val-3-t\", \"type\": \"text\", \"props\": {\"content\": \"۷ روز ضمانت بازگشت وجه بدون سوال.\"}}]}]}, {\"id\": \"about-reviews\", \"type\": \"section\", \"props\": {\"padding\": \"lg\", \"container\": true, \"background\": \"background\"}, \"blocks\": [{\"id\": \"about-reviews-grid\", \"type\": \"module:reviews_grid\", \"props\": {\"limit\": 3, \"style\": \"cards\", \"title\": \"چه می‌گویند\", \"show_avatar\": true}}]}, {\"id\": \"about-cta\", \"type\": \"cta\", \"props\": {\"title\": \"همین امروز با ما همراه شوید\", \"subtitle\": \"از مشاوره رایگان تا پشتیبانی دائمی، کنارتان هستیم.\", \"background\": \"primary\", \"button_url\": \"/register\", \"button_text\": \"شروع کنید\"}}]','فرشاد پیکرستان','ذخیره خودکار','2026-06-16 08:51:38','2026-06-16 08:51:38'),(3,3,'[{\"id\": \"home-notif\", \"type\": \"module:notifications_bar\", \"props\": {\"style\": \"top-bar\", \"show_dismiss\": true}}, {\"id\": \"home-hero\", \"type\": \"hero\", \"props\": {\"align\": \"center\", \"title\": \"فروش هوشمند، پشتیبانی بی‌نقص\", \"subtitle\": \"<p>محصولات باکیفیت، آموزش تخصصی، پشتیبانی ۲۴ ساعته — همه در یک پلتفرم.</p>\", \"background\": \"primary\", \"button_url\": \"/products\", \"button_text\": \"مشاهده محصولات\", \"background_image\": null}}, {\"id\": \"home-stats\", \"type\": \"section\", \"props\": {\"padding\": \"lg\", \"container\": true, \"background\": \"surface\"}}, {\"id\": \"home-countdown\", \"type\": \"module:shop_countdown\", \"props\": {\"bg_color\": \"#dc2626\", \"end_date\": null, \"promo_text\": \"🔥 پیشنهاد ویژه هفتگی — فرصت محدود!\"}}, {\"id\": \"home-products\", \"type\": \"section\", \"props\": {\"padding\": \"lg\", \"container\": true, \"background\": \"background\"}}, {\"id\": \"home-courses\", \"type\": \"section\", \"props\": {\"padding\": \"lg\", \"container\": true, \"background\": \"surface\"}}, {\"id\": \"home-pricing\", \"type\": \"section\", \"props\": {\"padding\": \"lg\", \"container\": true, \"background\": \"background\"}}, {\"id\": \"home-reviews\", \"type\": \"section\", \"props\": {\"padding\": \"lg\", \"container\": true, \"background\": \"surface\"}}, {\"id\": \"home-blog\", \"type\": \"section\", \"props\": {\"padding\": \"lg\", \"container\": true, \"background\": \"background\"}}, {\"id\": \"home-referral\", \"type\": \"module:referral_widget\", \"props\": {\"style\": \"card\", \"title\": \"دوستانت را دعوت کن، جایزه بگیر\", \"subtitle\": \"با معرفی هر دوست، اعتبار هدیه دریافت کنید\", \"show_link\": true}}, {\"id\": \"home-cta\", \"type\": \"cta\", \"props\": {\"title\": \"آماده شروع هستید؟\", \"subtitle\": \"همین الان ثبت‌نام کنید و از پشتیبانی رایگان بهره‌مند شوید.\", \"background\": \"primary\", \"button_url\": \"/register\", \"button_text\": \"شروع رایگان\"}}, {\"id\": \"home-support-btn\", \"type\": \"module:support_button\", \"props\": {\"label\": \"پشتیبانی آنلاین\", \"style\": \"floating\", \"bg_color\": \"#1e40af\", \"position\": \"bottom-left\"}}, {\"id\": \"blk_1781596315799_f8dj\", \"type\": \"heading\", \"props\": {\"text\": \"عنوان صفحه\", \"align\": \"right\", \"color\": null, \"level\": 2}}]','فرشاد پیکرستان','ذخیره خودکار','2026-06-16 08:55:24','2026-06-16 08:55:24'),(4,3,'[{\"id\": \"home-notif\", \"type\": \"module:notifications_bar\", \"props\": {\"style\": \"top-bar\", \"show_dismiss\": true}}, {\"id\": \"home-hero\", \"type\": \"hero\", \"props\": {\"align\": \"center\", \"title\": \"فروش هوشمند، پشتیبانی بی‌نقص\", \"subtitle\": \"<p>محصولات باکیفیت، آموزش تخصصی، پشتیبانی ۲۴ ساعته — همه در یک پلتفرم.</p>\", \"background\": \"primary\", \"button_url\": \"/products\", \"button_text\": \"مشاهده محصولات\", \"background_image\": null}}, {\"id\": \"home-stats\", \"type\": \"section\", \"props\": {\"padding\": \"lg\", \"container\": true, \"background\": \"surface\"}}, {\"id\": \"home-countdown\", \"type\": \"module:shop_countdown\", \"props\": {\"bg_color\": \"#dc2626\", \"end_date\": null, \"promo_text\": \"🔥 پیشنهاد ویژه هفتگی — فرصت محدود!\"}}, {\"id\": \"home-products\", \"type\": \"section\", \"props\": {\"padding\": \"lg\", \"container\": true, \"background\": \"background\"}}, {\"id\": \"home-courses\", \"type\": \"section\", \"props\": {\"padding\": \"lg\", \"container\": true, \"background\": \"surface\"}}, {\"id\": \"home-pricing\", \"type\": \"section\", \"props\": {\"padding\": \"lg\", \"container\": true, \"background\": \"background\"}}, {\"id\": \"home-reviews\", \"type\": \"section\", \"props\": {\"padding\": \"lg\", \"container\": true, \"background\": \"surface\"}}, {\"id\": \"home-blog\", \"type\": \"section\", \"props\": {\"padding\": \"lg\", \"container\": true, \"background\": \"background\"}}, {\"id\": \"home-referral\", \"type\": \"module:referral_widget\", \"props\": {\"style\": \"card\", \"title\": \"دوستانت را دعوت کن، جایزه بگیر\", \"subtitle\": \"با معرفی هر دوست، اعتبار هدیه دریافت کنید\", \"show_link\": true}}, {\"id\": \"home-cta\", \"type\": \"cta\", \"props\": {\"title\": \"آماده شروع هستید؟\", \"subtitle\": \"همین الان ثبت‌نام کنید و از پشتیبانی رایگان بهره‌مند شوید.\", \"background\": \"primary\", \"button_url\": \"/register\", \"button_text\": \"شروع رایگان\"}}, {\"id\": \"home-support-btn\", \"type\": \"module:support_button\", \"props\": {\"label\": \"پشتیبانی آنلاین\", \"style\": \"floating\", \"bg_color\": \"#1e40af\", \"position\": \"bottom-left\"}}, {\"id\": \"blk_1781596315799_f8dj\", \"type\": \"heading\", \"props\": {\"text\": \"عنوان صفحه\", \"align\": \"right\", \"color\": null, \"level\": 2}}, {\"id\": \"blk_1781599970570_8wnx\", \"type\": \"gallery\", \"props\": {\"items\": [{\"alt\": null, \"url\": \"https://safhenokhost.ir/uploads/featured/2026/06/4QQdbWGwSLxCVQ6qDnQfpH.webp\", \"caption\": null}], \"title\": null, \"columns\": \"3\"}}]','فرشاد پیکرستان','ذخیره خودکار','2026-06-16 08:55:29','2026-06-16 08:55:29'),(5,2,'[{\"id\": \"blog-hero\", \"data\": {\"align\": \"center\", \"title\": \"وبلاگ و مجله آموزشی\", \"subtitle\": \"آخرین مطالب، راهنماها و اخبار حوزه تخصصی ما\", \"background\": \"secondary\", \"button_url\": null, \"button_text\": null}, \"type\": \"hero\"}, {\"id\": \"blog-posts\", \"data\": {\"padding\": \"lg\", \"container\": true, \"background\": \"background\"}, \"type\": \"section\", \"blocks\": [{\"id\": \"blog-posts-grid\", \"type\": \"module:blog_posts\", \"props\": {\"limit\": 12, \"title\": \"آخرین مطالب\", \"layout\": \"grid\", \"show_date\": true, \"show_excerpt\": true, \"category_slug\": null}}]}, {\"id\": \"blog-categories\", \"data\": {\"padding\": \"lg\", \"container\": true, \"background\": \"surface\"}, \"type\": \"section\", \"blocks\": [{\"id\": \"blog-cat-h\", \"type\": \"heading\", \"props\": {\"text\": \"دسته‌بندی مطالب\", \"level\": 3}}, {\"id\": \"blog-cat-list\", \"type\": \"module:blog_categories\", \"props\": {\"limit\": 12, \"style\": \"badges\", \"title\": \"دسته‌بندی‌ها\"}}]}]','فرشاد پیکرستان','ذخیره خودکار','2026-06-19 12:08:34','2026-06-19 12:08:34'),(6,139,'[{\"id\": \"blk_1782853236368_0819\", \"type\": \"accordion\", \"props\": {\"items\": [{\"title\": \"سوال اول چیست؟\", \"content\": \"پاسخ سوال اول اینجا.\"}], \"title\": null}}]','مدیر صفحه نخست','ذخیره خودکار','2026-06-30 17:32:53','2026-06-30 17:32:53'),(7,139,'[{\"id\": \"blk_1782853355673_l4vo\", \"type\": \"blog_posts\", \"props\": {\"limit\": 6, \"title\": \"آخرین مطالب\", \"layout\": \"slider\"}}]','مدیر صفحه نخست','ذخیره خودکار','2026-06-30 17:33:07','2026-06-30 17:33:07'),(8,139,'[{\"id\": \"blk_1782853355673_l4vo\", \"type\": \"blog_posts\", \"props\": {\"limit\": 6, \"title\": \"آخرین مطالب\", \"layout\": \"list\"}}]','مدیر صفحه نخست','ذخیره خودکار','2026-06-30 17:33:12','2026-06-30 17:33:12'),(9,139,'[{\"id\": \"blk_1782853355673_l4vo\", \"type\": \"blog_posts\", \"props\": {\"limit\": 6, \"title\": \"آخرین مطالب\", \"layout\": \"list\"}}]','مدیر صفحه نخست','ذخیره خودکار','2026-06-30 17:33:24','2026-06-30 17:33:24');
/*!40000 ALTER TABLE `page_revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page_templates`
--

DROP TABLE IF EXISTS `page_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `page_templates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'section',
  `content` json NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_templates`
--

LOCK TABLES `page_templates` WRITE;
/*!40000 ALTER TABLE `page_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `page_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` longtext COLLATE utf8mb4_unicode_ci,
  `builder_content` json DEFAULT NULL COMMENT 'Visual builder: sections/rows/columns/elements',
  `builder_content_v2` json DEFAULT NULL COMMENT 'Visual builder v2: sections/columns/widgets with unique IDs and styles',
  `builder_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'legacy' COMMENT 'legacy=body text, builder=visual builder',
  `builder_header_template_override` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Page override: null = use site default; key = specific template',
  `builder_footer_template_override` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `builder_disable_header` tinyint(1) NOT NULL DEFAULT '0',
  `builder_disable_footer` tinyint(1) NOT NULL DEFAULT '0',
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` int unsigned NOT NULL DEFAULT '0',
  `is_published` tinyint(1) NOT NULL DEFAULT '1',
  `show_in_menu` tinyint(1) NOT NULL DEFAULT '1',
  `is_protected` tinyint(1) NOT NULL DEFAULT '0',
  `theme_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `theme_page_key` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pages_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (139,'درباره ما: آشنایی با تیم ما و خدمات ما','drbarh-ma-ashnayy-ba-tym-ma-o-khdmat-ma','<p>ما تیمی متعهد به ارائه بهترین خدمات به مشتریان خود هستیم. در این مقاله، شما را با تاریخچه، ارزش&zwnj;ها و اهداف ما آشنا می&zwnj;کنیم.</p>\r\n<h2>تاریخچه ما</h2>\r\n<p>شرکت ما در سال 1390 تأسیس شد و از آن زمان به سرعت در حال رشد و توسعه بوده&zwnj;ایم. هدف ما ارائه خدمات با کیفیت و جلب رضایت مشتریان است.</p>\r\n<p>با تکیه بر تجربه و تخصص تیم ما، توانسته&zwnj;ایم به یکی از پیشروان صنعت تبدیل شویم و در این مسیر، همیشه به دنبال نوآوری و بهبود هستیم.</p>\r\n<h2>ارزش&zwnj;های ما</h2>\r\n<p>ما به ارزش&zwnj;های خود بسیار پایبند هستیم. احترام به مشتری، صداقت و کیفیت از اصول بنیادی کار ما هستند.</p>\r\n<ul>\r\n<li><strong>احترام به مشتری:</strong> ما به نیازها و خواسته&zwnj;های مشتریان خود احترام می&zwnj;گذاریم.</li>\r\n<li><strong>صداقت:</strong> در تمام تعاملات خود، شفاف و صادق هستیم.</li>\r\n<li><strong>کیفیت:</strong> ارائه خدمات با کیفیت بالا همواره در اولویت ماست.</li>\r\n</ul>\r\n<h2>خدمات ما</h2>\r\n<p>ما مجموعه&zwnj;ای از خدمات متنوع را ارائه می&zwnj;دهیم که شامل مشاوره، طراحی و توسعه نرم&zwnj;افزار می&zwnj;شود.</p>\r\n<p>هدف ما این است که با استفاده از فناوری&zwnj;های روز، به کسب و کارها کمک کنیم تا به موفقیت&zwnj;های بیشتری دست یابند.</p>\r\n<h2>چشم&zwnj;انداز ما</h2>\r\n<p>چشم&zwnj;انداز ما تبدیل شدن به بهترین ارائه&zwnj;دهنده خدمات در صنعت خود است. ما همواره در تلاش برای بهبود و توسعه خدمات خود هستیم.</p>\r\n<p>با تمرکز بر نوآوری و فناوری، هدف ما ایجاد تجربه&zwnj;ای بی&zwnj;نظیر برای مشتریان است. به جمع ما بپیوندید و از خدمات ما بهره&zwnj;مند شوید!</p>\r\n<h3>نتیجه&zwnj;گیری</h3>\r\n<p>امیدواریم با آشنایی بیشتر با ما، اعتماد شما را جلب کنیم. برای کسب اطلاعات بیشتر و مشاوره رایگان، با ما تماس بگیرید!</p>',NULL,'{\"blocks\": [{\"id\": \"blk_1782853355673_l4vo\", \"type\": \"blog_posts\", \"props\": {\"limit\": 6, \"title\": \"آخرین مطالب\", \"layout\": \"grid\"}}]}','builder','header-1-minimal','footer-1-simple',0,0,NULL,NULL,1,1,1,0,NULL,NULL,'2026-06-30 17:26:40','2026-06-30 17:33:24');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_gateways`
--

DROP TABLE IF EXISTS `payment_gateways`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_gateways` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `driver` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `config` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `sort_order` tinyint unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_gateways_is_active_is_default_index` (`is_active`,`is_default`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_gateways`
--

LOCK TABLES `payment_gateways` WRITE;
/*!40000 ALTER TABLE `payment_gateways` DISABLE KEYS */;
INSERT INTO `payment_gateways` VALUES (1,'درگاه بانک ملی','melli','eyJpdiI6IjhBOVQxWmJielBzdmlVVGxueWk5NEE9PSIsInZhbHVlIjoicWN1a2dGNXhQaTJWUW91VlVuaVdWT1VvL2ZUNlhHSHJJYnc3VnpvNGJ1RT0iLCJtYWMiOiIwOTIxNThiMGIwYzNhMTZmZWUxMDRiZTNhMmM4NWMzNTM2NTU0MzhiYWUzN2VmNDE5NmM4YWI3MGJmMmIzOWU5IiwidGFnIjoiIn0=',1,1,0,'2026-07-03 05:32:24','2026-07-03 05:32:24');
/*!40000 ALTER TABLE `payment_gateways` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `module_slug` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guard_name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'web',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'داشبورد','dashboard','dashboard','web','2026-06-09 13:39:12','2026-06-09 13:39:12'),(2,'صفحات','pages','pages','web','2026-06-09 13:39:12','2026-06-09 13:39:12'),(3,'دسته‌بندی وبلاگ','categories','blog','web','2026-06-09 13:39:12','2026-06-09 13:39:12'),(4,'مطالب وبلاگ','posts','blog','web','2026-06-09 13:39:12','2026-06-09 13:39:12'),(5,'محصولات','products','shop','web','2026-06-09 13:39:12','2026-06-09 13:39:12'),(6,'دسته‌بندی محصولات','product_categories','shop','web','2026-06-09 13:39:12','2026-06-09 13:39:12'),(7,'سفارشات','orders','shop','web','2026-06-09 13:39:12','2026-06-09 13:39:12'),(8,'کوپن‌ها','coupon','shop','web','2026-06-09 13:39:12','2026-06-09 13:39:12'),(9,'نظرات','reviews','reviews','web','2026-06-09 13:39:12','2026-06-09 13:39:12'),(10,'معرفی دوستان','referral','referral','web','2026-06-09 13:39:12','2026-06-09 13:39:12'),(11,'پلن اشتراک','subscription','subscription','web','2026-06-09 13:39:12','2026-06-09 13:39:12'),(12,'پاسخگویی شبکه‌ها','whatsapp','messaging','web','2026-06-09 13:39:12','2026-06-09 13:39:12'),(13,'پیامک','sms','sms','web','2026-06-09 13:39:12','2026-06-09 13:39:12'),(14,'دوره‌ها','courses','courses','web','2026-06-09 13:39:12','2026-06-09 13:39:12'),(15,'فاکتورها','invoice','invoice','web','2026-06-09 13:39:12','2026-06-09 13:39:12'),(16,'کارت ویزیت','business_card','business_card','web','2026-06-09 13:39:12','2026-06-09 13:39:12'),(17,'شبکه‌های اجتماعی','social_links','social_links','web','2026-06-09 13:39:12','2026-06-09 13:39:12'),(18,'تبلیغات','advertisements','advertisements','web','2026-06-09 13:39:12','2026-06-09 13:39:12'),(19,'فرم‌ساز','forms','forms','web','2026-06-09 13:39:12','2026-06-09 13:39:12'),(20,'کپچا','captcha','captcha','web','2026-06-09 13:39:12','2026-06-09 13:39:12'),(21,'تنظیمات','settings','settings','web','2026-06-09 13:39:12','2026-06-09 13:39:12'),(22,'حذف ۴ صفر پول','currency_reform','currency_reform','web','2026-06-09 13:39:12','2026-06-09 13:39:12'),(23,'لایسنس','license','license','web','2026-06-09 13:39:12','2026-06-09 13:39:12'),(24,'پشتیبانی','support','support','web','2026-06-09 13:39:12','2026-06-09 13:39:12'),(25,'انتشار و تایید مطالب','posts_moderate','blog','web','2026-06-09 13:39:34','2026-06-09 13:39:34');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_revisions`
--

DROP TABLE IF EXISTS `post_revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `post_revisions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `snapshot` json NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `post_revisions_user_id_foreign` (`user_id`),
  KEY `post_revisions_post_id_created_at_index` (`post_id`,`created_at`),
  CONSTRAINT `post_revisions_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `post_revisions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_revisions`
--

LOCK TABLES `post_revisions` WRITE;
/*!40000 ALTER TABLE `post_revisions` DISABLE KEYS */;
INSERT INTO `post_revisions` VALUES (1,1,1,'{\"body\": null, \"slug\": \"sayt-hmh-karh\", \"title\": \"سایت همه کاره\", \"excerpt\": \"سایت همه کاره\", \"tag_ids\": [], \"og_image\": null, \"series_id\": null, \"meta_title\": \"سایت همه کاره\", \"category_id\": null, \"part_number\": 1, \"is_published\": false, \"published_at\": null, \"canonical_url\": null, \"featured_image\": null, \"gallery_images\": [], \"editorial_status\": \"pending_review\", \"meta_description\": \"سایت همه کاره\"}','2026-06-09 19:58:32','2026-06-09 19:58:32'),(2,1,1,'{\"body\": null, \"slug\": \"sayt-hmh-karh\", \"title\": \"سایت همه کاره\", \"excerpt\": \"سایت همه کاره\", \"tag_ids\": [], \"og_image\": null, \"series_id\": null, \"meta_title\": \"سایت همه کاره\", \"category_id\": null, \"part_number\": 1, \"is_published\": false, \"published_at\": null, \"canonical_url\": null, \"featured_image\": null, \"gallery_images\": [], \"editorial_status\": \"approved\", \"meta_description\": \"سایت همه کاره\"}','2026-06-10 19:40:01','2026-06-10 19:40:01'),(3,1,1,'{\"body\": \"<p>تولید محتوای مناسب یکی از مهم&zwnj;ترین مراحل در بازاریابی دیجیتال است. بسیاری از کسب&zwnj;وکارها به دنبال یادگیری چطور یک محتوای مناسب تولید کنیم تا تاثیر بیشتری بر روی مخاطبان خود بگذارند.</p>\\r\\n<h2>اهمیت محتوای مناسب در بازاریابی</h2>\\r\\n<p>محتوای مناسب می&zwnj;تواند به شما در جذب و نگه&zwnj;داشتن مخاطبان کمک کند. یک محتوای خوب نه تنها اطلاعات مفیدی ارائه می&zwnj;دهد بلکه باید جذاب و سرگرم&zwnj;کننده باشد.</p>\\r\\n<p>برای اینکه محتوای شما به درستی عمل کند، باید استراتژی مشخصی داشته باشید. این استراتژی شامل شناخت نیازهای مخاطبان و ارائه پاسخ&zwnj;های دقیق و مفید به آن&zwnj;ها است.</p>\\r\\n<h2>مراحل تولید محتوای مناسب</h2>\\r\\n<p>برای تولید محتوای مناسب، مراحل زیر را دنبال کنید:</p>\\r\\n<ul>\\r\\n<li><strong>تحقیق و تحلیل:</strong> ابتدا باید تحقیق کنید که مخاطبان شما چه می&zwnj;خواهند و در چه زمینه&zwnj;هایی به دنبال اطلاعات هستند.</li>\\r\\n<li><strong>ایجاد طرح محتوا:</strong> پس از تحلیل نیازها، یک طرح کلی برای محتوای خود تهیه کنید. این طرح شامل عناوین، زیرعناوین و نکات کلیدی خواهد بود.</li>\\r\\n<li><strong>نوشتن محتوای اولیه:</strong> بر اساس طرح خود، محتوای اولیه را بنویسید. این محتوا می&zwnj;تواند شامل متن، تصویر و ویدئو باشد.</li>\\r\\n</ul>\\r\\n<h2>بهینه&zwnj;سازی محتوا برای SEO</h2>\\r\\n<p>بهینه&zwnj;سازی محتوا برای موتورهای جستجو از اهمیت ویژه&zwnj;ای برخوردار است. برخی از نکات کلیدی در این زمینه شامل:</p>\\r\\n<ul>\\r\\n<li><strong>استفاده از کلمات کلیدی:</strong> کلمات کلیدی مرتبط با محتوای خود را در متن، عنوان و تگ&zwnj;های متا قرار دهید.</li>\\r\\n<li><strong>ایجاد لینک&zwnj;های داخلی و خارجی:</strong> لینک&zwnj;دهی به سایر محتوای خود و منابع معتبر می&zwnj;تواند به بهبود سئوی محتوای شما کمک کند.</li>\\r\\n</ul>\\r\\n<h2>نتیجه&zwnj;گیری و اقدام بعدی</h2>\\r\\n<p>تولید محتوای مناسب نیازمند زمان و تلاش است، اما با رعایت مراحل و نکات فوق می&zwnj;توانید محتوایی تاثیرگذار و جذاب ایجاد کنید. حالا زمان آن است که دست به کار شوید و محتوای خود را تولید کنید!</p>\", \"slug\": \"sayt-hmh-karh\", \"title\": \"چطور یک محتوای مناسب تولید کنیم؟ راهنمای کامل\", \"excerpt\": \"در این مقاله با مراحل و نکات ضروری برای تولید محتوای مناسب آشنا می‌شوید. محتوای مناسب می‌تواند تاثیر زیادی بر روی مخاطبان شما بگذارد.\", \"tag_ids\": [1, 2, 3, 4, 5], \"og_image\": \"featured/2026/06/GnUZalBTMpYQFrNtF4dN.jpg\", \"series_id\": null, \"meta_title\": \"چطور یک محتوای مناسب تولید کنیم!\", \"category_id\": null, \"part_number\": 1, \"is_published\": true, \"published_at\": \"2026-06-10T19:40:01+00:00\", \"canonical_url\": null, \"featured_image\": \"featured/2026/06/Shv0twk5pcdaafkiWbjy.jpg\", \"gallery_images\": [], \"editorial_status\": \"published\", \"meta_description\": \"یاد بگیرید چطور یک محتوای مناسب تولید کنیم! با مراحل و نکات کلیدی در این مقاله، محتوای خود را بهبود دهید.\"}','2026-06-10 19:41:01','2026-06-10 19:41:01'),(4,1,1,'{\"body\": \"<p>تولید محتوای مناسب یکی از مهم&zwnj;ترین مراحل در بازاریابی دیجیتال است. بسیاری از کسب&zwnj;وکارها به دنبال یادگیری چطور یک محتوای مناسب تولید کنیم تا تاثیر بیشتری بر روی مخاطبان خود بگذارند.</p>\\r\\n<h2>اهمیت محتوای مناسب در بازاریابی</h2>\\r\\n<p>محتوای مناسب می&zwnj;تواند به شما در جذب و نگه&zwnj;داشتن مخاطبان کمک کند. یک محتوای خوب نه تنها اطلاعات مفیدی ارائه می&zwnj;دهد بلکه باید جذاب و سرگرم&zwnj;کننده باشد.</p>\\r\\n<p>برای اینکه محتوای شما به درستی عمل کند، باید استراتژی مشخصی داشته باشید. این استراتژی شامل شناخت نیازهای مخاطبان و ارائه پاسخ&zwnj;های دقیق و مفید به آن&zwnj;ها است.</p>\\r\\n<h2>مراحل تولید محتوای مناسب</h2>\\r\\n<p>برای تولید محتوای مناسب، مراحل زیر را دنبال کنید:</p>\\r\\n<ul>\\r\\n<li><strong>تحقیق و تحلیل:</strong> ابتدا باید تحقیق کنید که مخاطبان شما چه می&zwnj;خواهند و در چه زمینه&zwnj;هایی به دنبال اطلاعات هستند.</li>\\r\\n<li><strong>ایجاد طرح محتوا:</strong> پس از تحلیل نیازها، یک طرح کلی برای محتوای خود تهیه کنید. این طرح شامل عناوین، زیرعناوین و نکات کلیدی خواهد بود.</li>\\r\\n<li><strong>نوشتن محتوای اولیه:</strong> بر اساس طرح خود، محتوای اولیه را بنویسید. این محتوا می&zwnj;تواند شامل متن، تصویر و ویدئو باشد.</li>\\r\\n</ul>\\r\\n<h2>بهینه&zwnj;سازی محتوا برای SEO</h2>\\r\\n<p>بهینه&zwnj;سازی محتوا برای موتورهای جستجو از اهمیت ویژه&zwnj;ای برخوردار است. برخی از نکات کلیدی در این زمینه شامل:</p>\\r\\n<ul>\\r\\n<li><strong>استفاده از کلمات کلیدی:</strong> کلمات کلیدی مرتبط با محتوای خود را در متن، عنوان و تگ&zwnj;های متا قرار دهید.</li>\\r\\n<li><strong>ایجاد لینک&zwnj;های داخلی و خارجی:</strong> لینک&zwnj;دهی به سایر محتوای خود و منابع معتبر می&zwnj;تواند به بهبود سئوی محتوای شما کمک کند.</li>\\r\\n</ul>\\r\\n<h2>نتیجه&zwnj;گیری و اقدام بعدی</h2>\\r\\n<p>تولید محتوای مناسب نیازمند زمان و تلاش است، اما با رعایت مراحل و نکات فوق می&zwnj;توانید محتوایی تاثیرگذار و جذاب ایجاد کنید. حالا زمان آن است که دست به کار شوید و محتوای خود را تولید کنید!</p>\", \"slug\": \"sayt-hmh-karh\", \"title\": \"چطور یک محتوای مناسب تولید کنیم؟ راهنمای کامل\", \"excerpt\": \"در این مقاله با مراحل و نکات ضروری برای تولید محتوای مناسب آشنا می‌شوید. محتوای مناسب می‌تواند تاثیر زیادی بر روی مخاطبان شما بگذارد.\", \"tag_ids\": [1, 2, 3, 4, 5], \"og_image\": \"featured/2026/06/GnUZalBTMpYQFrNtF4dN.jpg\", \"series_id\": null, \"meta_title\": \"چطور یک محتوای مناسب تولید کنیم!\", \"category_id\": 1, \"part_number\": 1, \"is_published\": true, \"published_at\": \"2026-06-10T19:40:01+00:00\", \"canonical_url\": null, \"featured_image\": \"featured/2026/06/Shv0twk5pcdaafkiWbjy.jpg\", \"gallery_images\": [], \"editorial_status\": \"published\", \"meta_description\": \"یاد بگیرید چطور یک محتوای مناسب تولید کنیم! با مراحل و نکات کلیدی در این مقاله، محتوای خود را بهبود دهید.\"}','2026-06-10 19:41:09','2026-06-10 19:41:09'),(5,1,1,'{\"body\": \"<p>تولید محتوای مناسب یکی از مهم&zwnj;ترین مراحل در بازاریابی دیجیتال است. بسیاری از کسب&zwnj;وکارها به دنبال یادگیری چطور یک محتوای مناسب تولید کنیم تا تاثیر بیشتری بر روی مخاطبان خود بگذارند.</p>\\r\\n<h2>اهمیت محتوای مناسب در بازاریابی</h2>\\r\\n<p>محتوای مناسب می&zwnj;تواند به شما در جذب و نگه&zwnj;داشتن مخاطبان کمک کند. یک محتوای خوب نه تنها اطلاعات مفیدی ارائه می&zwnj;دهد بلکه باید جذاب و سرگرم&zwnj;کننده باشد.</p>\\r\\n<p>برای اینکه محتوای شما به درستی عمل کند، باید استراتژی مشخصی داشته باشید. این استراتژی شامل شناخت نیازهای مخاطبان و ارائه پاسخ&zwnj;های دقیق و مفید به آن&zwnj;ها است.</p>\\r\\n<h2>مراحل تولید محتوای مناسب</h2>\\r\\n<p>برای تولید محتوای مناسب، مراحل زیر را دنبال کنید:</p>\\r\\n<ul>\\r\\n<li><strong>تحقیق و تحلیل:</strong> ابتدا باید تحقیق کنید که مخاطبان شما چه می&zwnj;خواهند و در چه زمینه&zwnj;هایی به دنبال اطلاعات هستند.</li>\\r\\n<li><strong>ایجاد طرح محتوا:</strong> پس از تحلیل نیازها، یک طرح کلی برای محتوای خود تهیه کنید. این طرح شامل عناوین، زیرعناوین و نکات کلیدی خواهد بود.</li>\\r\\n<li><strong>نوشتن محتوای اولیه:</strong> بر اساس طرح خود، محتوای اولیه را بنویسید. این محتوا می&zwnj;تواند شامل متن، تصویر و ویدئو باشد.</li>\\r\\n</ul>\\r\\n<h2>بهینه&zwnj;سازی محتوا برای SEO</h2>\\r\\n<p>بهینه&zwnj;سازی محتوا برای موتورهای جستجو از اهمیت ویژه&zwnj;ای برخوردار است. برخی از نکات کلیدی در این زمینه شامل:</p>\\r\\n<ul>\\r\\n<li><strong>استفاده از کلمات کلیدی:</strong> کلمات کلیدی مرتبط با محتوای خود را در متن، عنوان و تگ&zwnj;های متا قرار دهید.</li>\\r\\n<li><strong>ایجاد لینک&zwnj;های داخلی و خارجی:</strong> لینک&zwnj;دهی به سایر محتوای خود و منابع معتبر می&zwnj;تواند به بهبود سئوی محتوای شما کمک کند.</li>\\r\\n</ul>\\r\\n<h2>نتیجه&zwnj;گیری و اقدام بعدی</h2>\\r\\n<p>تولید محتوای مناسب نیازمند زمان و تلاش است، اما با رعایت مراحل و نکات فوق می&zwnj;توانید محتوایی تاثیرگذار و جذاب ایجاد کنید. حالا زمان آن است که دست به کار شوید و محتوای خود را تولید کنید!</p>\", \"slug\": \"sayt-hmh-karh\", \"title\": \"چطور یک محتوای مناسب تولید کنیم؟ راهنمای کامل\", \"excerpt\": \"در این مقاله با مراحل و نکات ضروری برای تولید محتوای مناسب آشنا می‌شوید. محتوای مناسب می‌تواند تاثیر زیادی بر روی مخاطبان شما بگذارد.\", \"tag_ids\": [1, 2, 3, 4, 5], \"og_image\": \"featured/2026/06/GnUZalBTMpYQFrNtF4dN.jpg\", \"series_id\": null, \"meta_title\": \"چطور یک محتوای مناسب تولید کنیم!\", \"category_id\": 1, \"part_number\": 1, \"is_published\": false, \"published_at\": null, \"canonical_url\": null, \"featured_image\": \"featured/2026/06/Shv0twk5pcdaafkiWbjy.jpg\", \"gallery_images\": [], \"editorial_status\": \"pending_review\", \"meta_description\": \"یاد بگیرید چطور یک محتوای مناسب تولید کنیم! با مراحل و نکات کلیدی در این مقاله، محتوای خود را بهبود دهید.\"}','2026-06-10 19:41:16','2026-06-10 19:41:16'),(6,1,1,'{\"body\": \"<p>تولید محتوای مناسب یکی از مهم&zwnj;ترین مراحل در بازاریابی دیجیتال است. بسیاری از کسب&zwnj;وکارها به دنبال یادگیری چطور یک محتوای مناسب تولید کنیم تا تاثیر بیشتری بر روی مخاطبان خود بگذارند.</p>\\r\\n<h2>اهمیت محتوای مناسب در بازاریابی</h2>\\r\\n<p>محتوای مناسب می&zwnj;تواند به شما در جذب و نگه&zwnj;داشتن مخاطبان کمک کند. یک محتوای خوب نه تنها اطلاعات مفیدی ارائه می&zwnj;دهد بلکه باید جذاب و سرگرم&zwnj;کننده باشد.</p>\\r\\n<p>برای اینکه محتوای شما به درستی عمل کند، باید استراتژی مشخصی داشته باشید. این استراتژی شامل شناخت نیازهای مخاطبان و ارائه پاسخ&zwnj;های دقیق و مفید به آن&zwnj;ها است.</p>\\r\\n<h2>مراحل تولید محتوای مناسب</h2>\\r\\n<p>برای تولید محتوای مناسب، مراحل زیر را دنبال کنید:</p>\\r\\n<ul>\\r\\n<li><strong>تحقیق و تحلیل:</strong> ابتدا باید تحقیق کنید که مخاطبان شما چه می&zwnj;خواهند و در چه زمینه&zwnj;هایی به دنبال اطلاعات هستند.</li>\\r\\n<li><strong>ایجاد طرح محتوا:</strong> پس از تحلیل نیازها، یک طرح کلی برای محتوای خود تهیه کنید. این طرح شامل عناوین، زیرعناوین و نکات کلیدی خواهد بود.</li>\\r\\n<li><strong>نوشتن محتوای اولیه:</strong> بر اساس طرح خود، محتوای اولیه را بنویسید. این محتوا می&zwnj;تواند شامل متن، تصویر و ویدئو باشد.</li>\\r\\n</ul>\\r\\n<h2>بهینه&zwnj;سازی محتوا برای SEO</h2>\\r\\n<p>بهینه&zwnj;سازی محتوا برای موتورهای جستجو از اهمیت ویژه&zwnj;ای برخوردار است. برخی از نکات کلیدی در این زمینه شامل:</p>\\r\\n<ul>\\r\\n<li><strong>استفاده از کلمات کلیدی:</strong> کلمات کلیدی مرتبط با محتوای خود را در متن، عنوان و تگ&zwnj;های متا قرار دهید.</li>\\r\\n<li><strong>ایجاد لینک&zwnj;های داخلی و خارجی:</strong> لینک&zwnj;دهی به سایر محتوای خود و منابع معتبر می&zwnj;تواند به بهبود سئوی محتوای شما کمک کند.</li>\\r\\n</ul>\\r\\n<h2>نتیجه&zwnj;گیری و اقدام بعدی</h2>\\r\\n<p>تولید محتوای مناسب نیازمند زمان و تلاش است، اما با رعایت مراحل و نکات فوق می&zwnj;توانید محتوایی تاثیرگذار و جذاب ایجاد کنید. حالا زمان آن است که دست به کار شوید و محتوای خود را تولید کنید!</p>\", \"slug\": \"sayt-hmh-karh\", \"title\": \"چطور یک محتوای مناسب تولید کنیم؟ راهنمای کامل\", \"excerpt\": \"در این مقاله با مراحل و نکات ضروری برای تولید محتوای مناسب آشنا می‌شوید. محتوای مناسب می‌تواند تاثیر زیادی بر روی مخاطبان شما بگذارد.\", \"tag_ids\": [1, 2, 3, 4, 5], \"og_image\": \"featured/2026/06/GnUZalBTMpYQFrNtF4dN.jpg\", \"series_id\": null, \"meta_title\": \"چطور یک محتوای مناسب تولید کنیم!\", \"category_id\": 1, \"part_number\": 1, \"is_published\": false, \"published_at\": null, \"canonical_url\": null, \"featured_image\": \"featured/2026/06/Shv0twk5pcdaafkiWbjy.jpg\", \"gallery_images\": [], \"editorial_status\": \"approved\", \"meta_description\": \"یاد بگیرید چطور یک محتوای مناسب تولید کنیم! با مراحل و نکات کلیدی در این مقاله، محتوای خود را بهبود دهید.\"}','2026-06-10 19:56:12','2026-06-10 19:56:12'),(7,2,1,'{\"body\": \"<p>جام جهانی فوتبال 2026 یکی از بزرگترین رویدادهای ورزشی جهان است که در انتظار آن هستیم. این مسابقات نه تنها به عنوان یک رقابت ورزشی شناخته می&zwnj;شود، بلکه به یک جشن جهانی تبدیل می&zwnj;شود که هواداران از سرتاسر دنیا را به هم می&zwnj;آورد.</p>\\r\\n<h2>تاریخچه جام جهانی فوتبال</h2>\\r\\n<p>جام جهانی فوتبال از سال 1930 آغاز شده و هر چهار سال یک بار برگزار می&zwnj;شود. این مسابقات به تدریج به یکی از پرطرفدارترین رویدادهای ورزشی در سطح جهانی تبدیل شده است. در طول تاریخ، تیم&zwnj;های مختلفی قهرمانی را تجربه کرده&zwnj;اند که هر یک داستان خاص خود را دارند.</p>\\r\\n<p>در جام جهانی گذشته، تیم ملی فرانسه عنوان قهرمانی را به دست آورد. این موفقیت نشان&zwnj;دهنده تلاش و عزم بالای بازیکنان و کادر فنی این تیم بود.</p>\\r\\n<h2>محل برگزاری جام جهانی 2026</h2>\\r\\n<p>جام جهانی 2026 به طور مشترک در سه کشور ایالات متحده، کانادا و مکزیک برگزار خواهد شد. این اولین باری است که سه کشور به طور مشترک میزبان این رویداد بزرگ هستند.</p>\\r\\n<p>شهرهای مختلفی در این سه کشور به عنوان میزبان انتخاب شده&zwnj;اند، که هر یک امکانات و زیرساخت&zwnj;های مدرن برای پذیرایی از تماشاگران را دارا هستند.</p>\\r\\n<h2>تغییرات و نوآوری&zwnj;ها در جام جهانی 2026</h2>\\r\\n<p>جام جهانی 2026 با تغییرات و نوآوری&zwnj;های زیادی همراه خواهد بود. یکی از این تغییرات، افزایش تعداد تیم&zwnj;های شرکت&zwnj;کننده از 32 به 48 تیم است. این تغییر به معنای افزایش رقابت و تنوع در مسابقات خواهد بود.</p>\\r\\n<h3>تجربه تماشاگران</h3>\\r\\n<ul>\\r\\n<li>فناوری&zwnj;های نوین برای بهبود تجربه تماشاگران</li>\\r\\n<li>برگزاری رویدادهای جانبی و سرگرمی&zwnj;های مختلف</li>\\r\\n<li>دسترسی آسان به استادیوم&zwnj;ها و امکانات ورزشی</li>\\r\\n</ul>\\r\\n<h2>جمع بندی و نتیجه&zwnj;گیری</h2>\\r\\n<p>جام جهانی فوتبال 2026 یک فرصت فوق&zwnj;العاده برای تمامی علاقه&zwnj;مندان به فوتبال است. با تغییرات جدید و برگزاری در سه کشور، این رویداد به شکلی متفاوت و فراموش&zwnj;نشدنی برگزار خواهد شد. اگر شما هم یکی از طرفداران فوتبال هستید، حتماً این رویداد را از دست ندهید و با ما همراه باشید.</p>\", \"slug\": \"dr-mord-jam-jhany-fotbal-2026-chh-my-danyd\", \"title\": \"در مورد جام جهانی فوتبال 2026 چه می دانید؟\", \"excerpt\": \"جام جهانی فوتبال 2026 یکی از بزرگترین رویدادهای ورزشی است که در سه کشور برگزار می‌شود و تغییرات جدیدی را به همراه دارد.\", \"tag_ids\": [6, 7, 8, 9, 10], \"og_image\": null, \"series_id\": null, \"meta_title\": \"در مورد جام جهانی فوتبال 2026 چه می دانید؟\", \"category_id\": null, \"part_number\": null, \"is_published\": true, \"published_at\": \"2026-06-11T07:57:08+00:00\", \"canonical_url\": null, \"featured_image\": null, \"gallery_images\": [], \"editorial_status\": \"published\", \"meta_description\": \"با ما همراه باشید تا درباره جام جهانی فوتبال 2026 و تغییرات آن بیشتر بدانید. فرصتی برای تجربه‌ای فراموش‌نشدنی!\"}','2026-06-11 08:12:40','2026-06-11 08:12:40');
/*!40000 ALTER TABLE `post_revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_series`
--

DROP TABLE IF EXISTS `post_series`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `post_series` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `post_series_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_series`
--

LOCK TABLES `post_series` WRITE;
/*!40000 ALTER TABLE `post_series` DISABLE KEYS */;
INSERT INTO `post_series` VALUES (1,'پشتیبانی','pshtybany',NULL,'2026-06-10 19:54:38','2026-06-10 19:54:38'),(2,'طراحی سایت','trahy-sayt',NULL,'2026-06-10 19:54:48','2026-06-10 19:54:48'),(3,'سئو','syo',NULL,'2026-06-10 19:55:07','2026-06-10 19:55:07');
/*!40000 ALTER TABLE `post_series` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_tag`
--

DROP TABLE IF EXISTS `post_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `post_tag` (
  `post_id` bigint unsigned NOT NULL,
  `tag_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`post_id`,`tag_id`),
  KEY `post_tag_tag_id_foreign` (`tag_id`),
  CONSTRAINT `post_tag_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `post_tag_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_tag`
--

LOCK TABLES `post_tag` WRITE;
/*!40000 ALTER TABLE `post_tag` DISABLE KEYS */;
INSERT INTO `post_tag` VALUES (1,1),(1,2),(1,3),(1,4),(1,5),(2,6),(2,7),(2,8),(2,9),(2,10);
/*!40000 ALTER TABLE `post_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` longtext COLLATE utf8mb4_unicode_ci,
  `builder_content` json DEFAULT NULL,
  `excerpt` text COLLATE utf8mb4_unicode_ci,
  `featured_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gallery_images` json DEFAULT NULL,
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `canonical_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_image` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_id` bigint unsigned DEFAULT NULL,
  `series_id` bigint unsigned DEFAULT NULL,
  `part_number` smallint unsigned DEFAULT NULL,
  `user_id` bigint unsigned NOT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `is_published` tinyint(1) NOT NULL DEFAULT '0',
  `editorial_status` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `view_count` int unsigned NOT NULL DEFAULT '0',
  `likes_count` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `posts_slug_unique` (`slug`),
  KEY `posts_category_id_foreign` (`category_id`),
  KEY `posts_user_id_foreign` (`user_id`),
  KEY `posts_series_id_foreign` (`series_id`),
  KEY `posts_editorial_status_index` (`editorial_status`),
  CONSTRAINT `posts_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `posts_series_id_foreign` FOREIGN KEY (`series_id`) REFERENCES `post_series` (`id`) ON DELETE SET NULL,
  CONSTRAINT `posts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES (1,'چطور یک محتوای مناسب تولید کنیم؟ راهنمای کامل','sayt-hmh-karh','<p>تولید محتوای مناسب یکی از مهم&zwnj;ترین مراحل در بازاریابی دیجیتال است. بسیاری از کسب&zwnj;وکارها به دنبال یادگیری چطور یک محتوای مناسب تولید کنیم تا تاثیر بیشتری بر روی مخاطبان خود بگذارند.</p>\r\n<h2>اهمیت محتوای مناسب در بازاریابی</h2>\r\n<p>محتوای مناسب می&zwnj;تواند به شما در جذب و نگه&zwnj;داشتن مخاطبان کمک کند. یک محتوای خوب نه تنها اطلاعات مفیدی ارائه می&zwnj;دهد بلکه باید جذاب و سرگرم&zwnj;کننده باشد.</p>\r\n<p>برای اینکه محتوای شما به درستی عمل کند، باید استراتژی مشخصی داشته باشید. این استراتژی شامل شناخت نیازهای مخاطبان و ارائه پاسخ&zwnj;های دقیق و مفید به آن&zwnj;ها است.</p>\r\n<h2>مراحل تولید محتوای مناسب</h2>\r\n<p>برای تولید محتوای مناسب، مراحل زیر را دنبال کنید:</p>\r\n<ul>\r\n<li><strong>تحقیق و تحلیل:</strong> ابتدا باید تحقیق کنید که مخاطبان شما چه می&zwnj;خواهند و در چه زمینه&zwnj;هایی به دنبال اطلاعات هستند.</li>\r\n<li><strong>ایجاد طرح محتوا:</strong> پس از تحلیل نیازها، یک طرح کلی برای محتوای خود تهیه کنید. این طرح شامل عناوین، زیرعناوین و نکات کلیدی خواهد بود.</li>\r\n<li><strong>نوشتن محتوای اولیه:</strong> بر اساس طرح خود، محتوای اولیه را بنویسید. این محتوا می&zwnj;تواند شامل متن، تصویر و ویدئو باشد.</li>\r\n</ul>\r\n<h2>بهینه&zwnj;سازی محتوا برای SEO</h2>\r\n<p>بهینه&zwnj;سازی محتوا برای موتورهای جستجو از اهمیت ویژه&zwnj;ای برخوردار است. برخی از نکات کلیدی در این زمینه شامل:</p>\r\n<ul>\r\n<li><strong>استفاده از کلمات کلیدی:</strong> کلمات کلیدی مرتبط با محتوای خود را در متن، عنوان و تگ&zwnj;های متا قرار دهید.</li>\r\n<li><strong>ایجاد لینک&zwnj;های داخلی و خارجی:</strong> لینک&zwnj;دهی به سایر محتوای خود و منابع معتبر می&zwnj;تواند به بهبود سئوی محتوای شما کمک کند.</li>\r\n</ul>\r\n<h2>نتیجه&zwnj;گیری و اقدام بعدی</h2>\r\n<p>تولید محتوای مناسب نیازمند زمان و تلاش است، اما با رعایت مراحل و نکات فوق می&zwnj;توانید محتوایی تاثیرگذار و جذاب ایجاد کنید. حالا زمان آن است که دست به کار شوید و محتوای خود را تولید کنید!</p>',NULL,'در این مقاله با مراحل و نکات ضروری برای تولید محتوای مناسب آشنا می‌شوید. محتوای مناسب می‌تواند تاثیر زیادی بر روی مخاطبان شما بگذارد.','featured/2026/06/Shv0twk5pcdaafkiWbjy.jpg','[]','چطور یک محتوای مناسب تولید کنیم!','یاد بگیرید چطور یک محتوای مناسب تولید کنیم! با مراحل و نکات کلیدی در این مقاله، محتوای خود را بهبود دهید.',NULL,'featured/2026/06/GnUZalBTMpYQFrNtF4dN.jpg',1,3,1,1,'2026-06-10 19:56:12',1,'published',57,2,'2026-06-09 19:57:51','2026-08-18 05:43:37'),(2,'در مورد جام جهانی فوتبال 2026 چه می دانید؟','dr-mord-jam-jhany-fotbal-2026-chh-my-danyd','<p>جام جهانی فوتبال 2026 یکی از بزرگترین رویدادهای ورزشی جهان است که در انتظار آن هستیم. این مسابقات نه تنها به عنوان یک رقابت ورزشی شناخته می&zwnj;شود، بلکه به یک جشن جهانی تبدیل می&zwnj;شود که هواداران از سرتاسر دنیا را به هم می&zwnj;آورد.</p>\r\n<h2>تاریخچه جام جهانی فوتبال</h2>\r\n<p>جام جهانی فوتبال از سال 1930 آغاز شده و هر چهار سال یک بار برگزار می&zwnj;شود. این مسابقات به تدریج به یکی از پرطرفدارترین رویدادهای ورزشی در سطح جهانی تبدیل شده است. در طول تاریخ، تیم&zwnj;های مختلفی قهرمانی را تجربه کرده&zwnj;اند که هر یک داستان خاص خود را دارند.</p>\r\n<p>در جام جهانی گذشته، تیم ملی فرانسه عنوان قهرمانی را به دست آورد. این موفقیت نشان&zwnj;دهنده تلاش و عزم بالای بازیکنان و کادر فنی این تیم بود.</p>\r\n<h2>محل برگزاری جام جهانی 2026</h2>\r\n<p>جام جهانی 2026 به طور مشترک در سه کشور ایالات متحده، کانادا و مکزیک برگزار خواهد شد. این اولین باری است که سه کشور به طور مشترک میزبان این رویداد بزرگ هستند.</p>\r\n<p>شهرهای مختلفی در این سه کشور به عنوان میزبان انتخاب شده&zwnj;اند، که هر یک امکانات و زیرساخت&zwnj;های مدرن برای پذیرایی از تماشاگران را دارا هستند.</p>\r\n<h2>تغییرات و نوآوری&zwnj;ها در جام جهانی 2026</h2>\r\n<p>جام جهانی 2026 با تغییرات و نوآوری&zwnj;های زیادی همراه خواهد بود. یکی از این تغییرات، افزایش تعداد تیم&zwnj;های شرکت&zwnj;کننده از 32 به 48 تیم است. این تغییر به معنای افزایش رقابت و تنوع در مسابقات خواهد بود.</p>\r\n<h3>تجربه تماشاگران</h3>\r\n<ul>\r\n<li>فناوری&zwnj;های نوین برای بهبود تجربه تماشاگران</li>\r\n<li>برگزاری رویدادهای جانبی و سرگرمی&zwnj;های مختلف</li>\r\n<li>دسترسی آسان به استادیوم&zwnj;ها و امکانات ورزشی</li>\r\n</ul>\r\n<h2>جمع بندی و نتیجه&zwnj;گیری</h2>\r\n<p>جام جهانی فوتبال 2026 یک فرصت فوق&zwnj;العاده برای تمامی علاقه&zwnj;مندان به فوتبال است. با تغییرات جدید و برگزاری در سه کشور، این رویداد به شکلی متفاوت و فراموش&zwnj;نشدنی برگزار خواهد شد. اگر شما هم یکی از طرفداران فوتبال هستید، حتماً این رویداد را از دست ندهید و با ما همراه باشید.</p>',NULL,'جام جهانی فوتبال 2026 یکی از بزرگترین رویدادهای ورزشی است که در سه کشور برگزار می‌شود و تغییرات جدیدی را به همراه دارد.','featured/2026/06/WcuYNwDT8PeIsdHfxI5b.jpg','[]','در مورد جام جهانی فوتبال 2026 چه می دانید؟','با ما همراه باشید تا درباره جام جهانی فوتبال 2026 و تغییرات آن بیشتر بدانید. فرصتی برای تجربه‌ای فراموش‌نشدنی!',NULL,NULL,1,NULL,2,1,'2026-06-11 07:57:08',1,'published',58,2,'2026-06-11 07:57:08','2026-08-18 05:44:53');
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_attribute_values`
--

DROP TABLE IF EXISTS `product_attribute_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_attribute_values` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_attribute_id` bigint unsigned NOT NULL,
  `value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_attribute_values_product_attribute_id_foreign` (`product_attribute_id`),
  CONSTRAINT `product_attribute_values_product_attribute_id_foreign` FOREIGN KEY (`product_attribute_id`) REFERENCES `product_attributes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_attribute_values`
--

LOCK TABLES `product_attribute_values` WRITE;
/*!40000 ALTER TABLE `product_attribute_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_attribute_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_attributes`
--

DROP TABLE IF EXISTS `product_attributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_attributes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filterable` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_attributes_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_attributes`
--

LOCK TABLES `product_attributes` WRITE;
/*!40000 ALTER TABLE `product_attributes` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_attributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_audit_logs`
--

DROP TABLE IF EXISTS `product_audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_audit_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `changes` json NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `product_audit_logs_product_id_foreign` (`product_id`),
  KEY `product_audit_logs_user_id_foreign` (`user_id`),
  CONSTRAINT `product_audit_logs_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_audit_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_audit_logs`
--

LOCK TABLES `product_audit_logs` WRITE;
/*!40000 ALTER TABLE `product_audit_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_bundles`
--

DROP TABLE IF EXISTS `product_bundles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_bundles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `parent_product_id` bigint unsigned NOT NULL,
  `child_product_id` bigint unsigned NOT NULL,
  `quantity` int unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_bundle_unique` (`parent_product_id`,`child_product_id`),
  KEY `product_bundles_child_product_id_foreign` (`child_product_id`),
  CONSTRAINT `product_bundles_child_product_id_foreign` FOREIGN KEY (`child_product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_bundles_parent_product_id_foreign` FOREIGN KEY (`parent_product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_bundles`
--

LOCK TABLES `product_bundles` WRITE;
/*!40000 ALTER TABLE `product_bundles` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_bundles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_categories`
--

DROP TABLE IF EXISTS `product_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_categories_slug_unique` (`slug`),
  KEY `product_categories_parent_id_foreign` (`parent_id`),
  CONSTRAINT `product_categories_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `product_categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_categories`
--

LOCK TABLES `product_categories` WRITE;
/*!40000 ALTER TABLE `product_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_images`
--

DROP TABLE IF EXISTS `product_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_images` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `path` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_images_product_id_foreign` (`product_id`),
  CONSTRAINT `product_images_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_images`
--

LOCK TABLES `product_images` WRITE;
/*!40000 ALTER TABLE `product_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_product_attribute_value`
--

DROP TABLE IF EXISTS `product_product_attribute_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_product_attribute_value` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `product_attribute_value_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_attr_val_unique` (`product_id`,`product_attribute_value_id`),
  KEY `ppav_attr_value_fk` (`product_attribute_value_id`),
  CONSTRAINT `ppav_attr_value_fk` FOREIGN KEY (`product_attribute_value_id`) REFERENCES `product_attribute_values` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_product_attribute_value_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_product_attribute_value`
--

LOCK TABLES `product_product_attribute_value` WRITE;
/*!40000 ALTER TABLE `product_product_attribute_value` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_product_attribute_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_product_tag`
--

DROP TABLE IF EXISTS `product_product_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_product_tag` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `product_tag_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_tag_unique` (`product_id`,`product_tag_id`),
  KEY `product_product_tag_product_tag_id_foreign` (`product_tag_id`),
  CONSTRAINT `product_product_tag_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_product_tag_product_tag_id_foreign` FOREIGN KEY (`product_tag_id`) REFERENCES `product_tags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_product_tag`
--

LOCK TABLES `product_product_tag` WRITE;
/*!40000 ALTER TABLE `product_product_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_product_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_related`
--

DROP TABLE IF EXISTS `product_related`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_related` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `related_product_id` bigint unsigned NOT NULL,
  `relation_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_related_unique` (`product_id`,`related_product_id`,`relation_type`),
  KEY `product_related_related_product_id_foreign` (`related_product_id`),
  CONSTRAINT `product_related_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_related_related_product_id_foreign` FOREIGN KEY (`related_product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_related`
--

LOCK TABLES `product_related` WRITE;
/*!40000 ALTER TABLE `product_related` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_related` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_reviews`
--

DROP TABLE IF EXISTS `product_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_reviews` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `guest_name` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guest_email` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rating` tinyint unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8mb4_unicode_ci,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_reviews_product_id_foreign` (`product_id`),
  KEY `product_reviews_user_id_foreign` (`user_id`),
  CONSTRAINT `product_reviews_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_reviews_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_reviews`
--

LOCK TABLES `product_reviews` WRITE;
/*!40000 ALTER TABLE `product_reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_stock_notifications`
--

DROP TABLE IF EXISTS `product_stock_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_stock_notifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `product_variant_id` bigint unsigned DEFAULT NULL,
  `email` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `session_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notified_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_stock_notifications_product_variant_id_foreign` (`product_variant_id`),
  KEY `product_stock_notifications_product_id_product_variant_id_index` (`product_id`,`product_variant_id`),
  CONSTRAINT `product_stock_notifications_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_stock_notifications_product_variant_id_foreign` FOREIGN KEY (`product_variant_id`) REFERENCES `product_variants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_stock_notifications`
--

LOCK TABLES `product_stock_notifications` WRITE;
/*!40000 ALTER TABLE `product_stock_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_stock_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_tags`
--

DROP TABLE IF EXISTS `product_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_tags` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tag_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'label',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_tags_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_tags`
--

LOCK TABLES `product_tags` WRITE;
/*!40000 ALTER TABLE `product_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_variants`
--

DROP TABLE IF EXISTS `product_variants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_variants` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `sku` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price_override` decimal(14,2) DEFAULT NULL,
  `sale_price` decimal(14,2) DEFAULT NULL,
  `stock` int unsigned DEFAULT NULL,
  `image` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `min_order_qty` int unsigned NOT NULL DEFAULT '1',
  `max_order_qty` int unsigned DEFAULT NULL,
  `allow_backorder` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_variants_product_id_foreign` (`product_id`),
  CONSTRAINT `product_variants_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_variants`
--

LOCK TABLES `product_variants` WRITE;
/*!40000 ALTER TABLE `product_variants` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_variants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `builder_content` json DEFAULT NULL,
  `shipping_text` text COLLATE utf8mb4_unicode_ci,
  `returns_text` text COLLATE utf8mb4_unicode_ci,
  `faq` json DEFAULT NULL,
  `size_chart_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size_chart_html` text COLLATE utf8mb4_unicode_ci,
  `is_new` tinyint(1) NOT NULL DEFAULT '0',
  `early_access` tinyint(1) NOT NULL DEFAULT '0',
  `sale_ends_at` timestamp NULL DEFAULT NULL,
  `low_stock_threshold` int unsigned DEFAULT NULL,
  `warranty_text` text COLLATE utf8mb4_unicode_ci,
  `guarantee_text` text COLLATE utf8mb4_unicode_ci,
  `allow_backorder` tinyint(1) NOT NULL DEFAULT '0',
  `min_order_qty` int unsigned NOT NULL DEFAULT '1',
  `max_order_qty` int unsigned DEFAULT NULL,
  `views_count` bigint unsigned NOT NULL DEFAULT '0',
  `is_bundle` tinyint(1) NOT NULL DEFAULT '0',
  `bundle_pricing` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bundle_fixed_price` decimal(14,2) DEFAULT NULL,
  `bundle_discount_percent` decimal(5,2) DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sku` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(14,2) NOT NULL DEFAULT '0.00',
  `sale_price` decimal(14,2) DEFAULT NULL,
  `stock` int unsigned NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `order` int unsigned NOT NULL DEFAULT '0',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'published',
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `canonical_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_image` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_slug_unique` (`slug`),
  KEY `products_category_id_foreign` (`category_id`),
  CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `product_categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `push_subscriptions`
--

DROP TABLE IF EXISTS `push_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `push_subscriptions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `endpoint` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `endpoint_hash` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `public_key` text COLLATE utf8mb4_unicode_ci,
  `auth_token` text COLLATE utf8mb4_unicode_ci,
  `encoding` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'aesgcm',
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_push_endpoint_hash` (`endpoint_hash`),
  KEY `push_subscriptions_user_id_index` (`user_id`),
  CONSTRAINT `push_subscriptions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `push_subscriptions`
--

LOCK TABLES `push_subscriptions` WRITE;
/*!40000 ALTER TABLE `push_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `push_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `referral_codes`
--

DROP TABLE IF EXISTS `referral_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `referral_codes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uses` int unsigned NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `referral_codes_code_unique` (`code`),
  KEY `referral_codes_user_id_foreign` (`user_id`),
  CONSTRAINT `referral_codes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `referral_codes`
--

LOCK TABLES `referral_codes` WRITE;
/*!40000 ALTER TABLE `referral_codes` DISABLE KEYS */;
INSERT INTO `referral_codes` VALUES (1,1,'NMLJWNEC',0,1,'2026-06-16 08:56:50','2026-06-16 08:56:50');
/*!40000 ALTER TABLE `referral_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `referrals`
--

DROP TABLE IF EXISTS `referrals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `referrals` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `referral_code_id` bigint unsigned NOT NULL,
  `referred_user_id` bigint unsigned NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `rewarded_at` timestamp NULL DEFAULT NULL,
  `points_awarded` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `referrals_referral_code_id_foreign` (`referral_code_id`),
  KEY `referrals_referred_user_id_foreign` (`referred_user_id`),
  CONSTRAINT `referrals_referral_code_id_foreign` FOREIGN KEY (`referral_code_id`) REFERENCES `referral_codes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `referrals_referred_user_id_foreign` FOREIGN KEY (`referred_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `referrals`
--

LOCK TABLES `referrals` WRITE;
/*!40000 ALTER TABLE `referrals` DISABLE KEYS */;
/*!40000 ALTER TABLE `referrals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reviews` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `reviewable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reviewable_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `author_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rating` tinyint unsigned NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci,
  `is_approved` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reviews_user_id_foreign` (`user_id`),
  KEY `reviews_reviewable_type_reviewable_id_index` (`reviewable_type`,`reviewable_id`),
  CONSTRAINT `reviews_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (25,1),(1,2),(2,2),(3,2),(4,2),(5,2),(6,2),(7,2),(8,2),(19,2),(20,2);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_user`
--

DROP TABLE IF EXISTS `role_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_user` (
  `role_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`user_id`),
  KEY `role_user_user_id_foreign` (`user_id`),
  CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_user`
--

LOCK TABLES `role_user` WRITE;
/*!40000 ALTER TABLE `role_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'web',
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Tenant Admin','tenant_admin','web','مدیر کامل سایت','2026-06-09 13:39:12','2026-06-09 13:39:12'),(2,'Staff','staff','web','کارمند با دسترسی محدود','2026-06-09 13:39:12','2026-06-09 13:39:12'),(3,'Customer','customer','web','مشتری بدون دسترسی ادمین','2026-06-09 13:39:12','2026-06-09 13:39:12');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seo_advanced_audits`
--

DROP TABLE IF EXISTS `seo_advanced_audits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seo_advanced_audits` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint unsigned NOT NULL,
  `page_url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_length` smallint unsigned DEFAULT NULL,
  `description_length` smallint unsigned DEFAULT NULL,
  `missing_meta` json DEFAULT NULL,
  `missing_alt_images` json DEFAULT NULL,
  `issues` json DEFAULT NULL,
  `score` tinyint unsigned NOT NULL DEFAULT '0',
  `audited_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `seo_advanced_audits_site_id_page_url_index` (`site_id`,`page_url`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seo_advanced_audits`
--

LOCK TABLES `seo_advanced_audits` WRITE;
/*!40000 ALTER TABLE `seo_advanced_audits` DISABLE KEYS */;
/*!40000 ALTER TABLE `seo_advanced_audits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seo_advanced_keyword_positions`
--

DROP TABLE IF EXISTS `seo_advanced_keyword_positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seo_advanced_keyword_positions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint unsigned NOT NULL,
  `keyword_id` bigint unsigned NOT NULL,
  `url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` smallint unsigned DEFAULT NULL,
  `recorded_at` date NOT NULL,
  `search_engine` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'google',
  `source` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'manual',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `seo_advanced_keyword_positions_keyword_id_recorded_at_index` (`keyword_id`,`recorded_at`),
  KEY `seo_advanced_keyword_positions_site_id_search_engine_index` (`site_id`,`search_engine`),
  CONSTRAINT `seo_advanced_keyword_positions_keyword_id_foreign` FOREIGN KEY (`keyword_id`) REFERENCES `seo_advanced_keywords` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seo_advanced_keyword_positions`
--

LOCK TABLES `seo_advanced_keyword_positions` WRITE;
/*!40000 ALTER TABLE `seo_advanced_keyword_positions` DISABLE KEYS */;
/*!40000 ALTER TABLE `seo_advanced_keyword_positions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seo_advanced_keywords`
--

DROP TABLE IF EXISTS `seo_advanced_keywords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seo_advanced_keywords` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint unsigned NOT NULL,
  `keyword` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `position` smallint unsigned DEFAULT NULL,
  `position_history` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `seo_advanced_keywords_site_id_status_index` (`site_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seo_advanced_keywords`
--

LOCK TABLES `seo_advanced_keywords` WRITE;
/*!40000 ALTER TABLE `seo_advanced_keywords` DISABLE KEYS */;
/*!40000 ALTER TABLE `seo_advanced_keywords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seo_advanced_redirects`
--

DROP TABLE IF EXISTS `seo_advanced_redirects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seo_advanced_redirects` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint unsigned NOT NULL,
  `from_path` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `to_path` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_code` smallint unsigned NOT NULL DEFAULT '301',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `seo_advanced_redirects_site_id_from_path_unique` (`site_id`,`from_path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seo_advanced_redirects`
--

LOCK TABLES `seo_advanced_redirects` WRITE;
/*!40000 ALTER TABLE `seo_advanced_redirects` DISABLE KEYS */;
/*!40000 ALTER TABLE `seo_advanced_redirects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seo_advanced_search_console_connections`
--

DROP TABLE IF EXISTS `seo_advanced_search_console_connections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seo_advanced_search_console_connections` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint unsigned NOT NULL,
  `google_account_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `access_token` text COLLATE utf8mb4_unicode_ci,
  `refresh_token` text COLLATE utf8mb4_unicode_ci,
  `token_expires_at` timestamp NULL DEFAULT NULL,
  `property_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `connected_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `seo_advanced_search_console_connections_site_id_unique` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seo_advanced_search_console_connections`
--

LOCK TABLES `seo_advanced_search_console_connections` WRITE;
/*!40000 ALTER TABLE `seo_advanced_search_console_connections` DISABLE KEYS */;
/*!40000 ALTER TABLE `seo_advanced_search_console_connections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seo_advanced_settings`
--

DROP TABLE IF EXISTS `seo_advanced_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seo_advanced_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint unsigned NOT NULL,
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_min_length` smallint unsigned DEFAULT NULL,
  `title_max_length` smallint unsigned DEFAULT NULL,
  `meta_description` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description_min_length` smallint unsigned DEFAULT NULL,
  `description_max_length` smallint unsigned DEFAULT NULL,
  `meta_keywords` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `robots_directive` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'index,follow',
  `canonical_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `canonical_strategy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'auto',
  `og_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_description` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_image_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_card_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'summary',
  `schema_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'website',
  `organization_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `organization_logo_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `business_address` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `business_phone` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `seo_advanced_settings_site_id_unique` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seo_advanced_settings`
--

LOCK TABLES `seo_advanced_settings` WRITE;
/*!40000 ALTER TABLE `seo_advanced_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `seo_advanced_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('emQ7FcHETdAiCUbPQU0ShjbwvaEvzNbQG7BO7Lcp',NULL,'66.249.66.192','Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.7922.137 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)','YTo1OntzOjY6Il90b2tlbiI7czo0MDoieFFWTldqR2FwMXdlU0NBR1M1ZGZqaFVmM0pMaDMxS2xIUkZhMk5OOCI7czoxMToic2l0ZV9sb2NhbGUiO3M6MjoiYXIiO3M6MTA6Il9vbGRfaW5wdXQiO2E6MDp7fXM6NjoiX2ZsYXNoIjthOjI6e3M6MzoibmV3IjthOjA6e31zOjM6Im9sZCI7YToxOntpOjA7czoxMDoiX29sZF9pbnB1dCI7fX1zOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czozMToiaHR0cHM6Ly9zYWZoZW5va2hvc3QuaXIvbGFuZy9hciI7czo1OiJyb3V0ZSI7czoxMToibGFuZy5zd2l0Y2giO319',1787228626);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `group` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'general',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'theme_preset_slug','lavender-dream','theme','2026-06-09 15:24:11','2026-06-27 11:09:35'),(2,'site_name','صفحه نخست','general','2026-06-09 18:00:07','2026-06-09 18:00:07'),(3,'theme','default','general','2026-06-09 18:00:07','2026-06-09 18:00:07'),(4,'about_us_enabled','0','general','2026-06-09 18:00:07','2026-06-09 18:00:07'),(5,'about_us_title','','general','2026-06-09 18:00:07','2026-06-09 18:00:07'),(6,'about_us_text','','general','2026-06-09 18:00:07','2026-06-09 18:00:07'),(7,'notification_bell_position','top-right','general','2026-06-09 18:00:07','2026-06-09 18:00:07'),(8,'builder_header_template',NULL,'general','2026-06-09 18:00:07','2026-06-27 12:08:04'),(9,'builder_footer_template','footer-10-full','general','2026-06-09 18:00:07','2026-06-09 18:00:07'),(10,'builder_sticky_header','1','general','2026-06-09 18:00:07','2026-06-09 18:00:07'),(11,'admin_sidebar_bg1','#5a7fa8','general','2026-06-09 18:00:07','2026-06-09 18:00:07'),(12,'admin_sidebar_bg2','#456f94','general','2026-06-09 18:00:07','2026-06-09 18:00:07'),(13,'admin_sidebar_text','#f1f6fb','general','2026-06-09 18:00:07','2026-06-09 18:00:07'),(14,'admin_sidebar_muted','#d8ebfb','general','2026-06-09 18:00:07','2026-06-09 18:00:07'),(15,'admin_sidebar_accent','#7dd3fc','general','2026-06-09 18:00:07','2026-06-09 18:00:07'),(16,'admin_sidebar_border','#8aa9c4','general','2026-06-09 18:00:07','2026-06-09 18:00:07'),(17,'site_favicon','favicon/favicon.png','general','2026-06-11 17:37:24','2026-06-11 17:37:24'),(18,'active_canvas_theme_data','','theme','2026-06-14 08:31:06','2026-06-24 05:03:48'),(19,'canvas_draft_data','{\"name\":\"قالب فروش و پشتیبانی حرفه‌ای\",\"slug\":\"sales-support-pro\",\"header_blocks\":[{\"id\":\"hdr-main\",\"type\":\"section\",\"props\":{\"padding\":\"sm\",\"container\":true,\"background\":\"surface\"},\"blocks\":[{\"id\":\"hdr-nav\",\"type\":\"nav_menu\",\"props\":{\"location\":\"header\"}},{\"id\":\"hdr-cart\",\"type\":\"module:shop_cart_button\",\"props\":{\"label\":\"سبد خرید\",\"style\":\"icon\"}},{\"id\":\"hdr-auth\",\"type\":\"login_register\",\"props\":[]}]}],\"footer_blocks\":[{\"id\":\"ftr-top\",\"type\":\"section\",\"props\":{\"padding\":\"lg\",\"container\":true,\"background\":\"text\"},\"blocks\":[{\"id\":\"ftr-cols\",\"type\":\"columns\",\"props\":{\"gap\":\"lg\",\"ratios\":\"1\\/3,1\\/3,1\\/3\"},\"blocks\":[{\"id\":\"ftr-brand-h\",\"type\":\"heading\",\"props\":{\"text\":\"درباره ما\",\"level\":4}},{\"id\":\"ftr-links-h\",\"type\":\"heading\",\"props\":{\"text\":\"دسترسی سریع\",\"level\":4}},{\"id\":\"ftr-contact-h\",\"type\":\"heading\",\"props\":{\"text\":\"تماس با ما\",\"level\":4}}]},{\"id\":\"ftr-social\",\"type\":\"module:social_links_bar\",\"props\":{\"size\":\"md\",\"color\":\"white\",\"style\":\"horizontal\"}},{\"id\":\"ftr-div\",\"type\":\"divider\",\"props\":[]},{\"id\":\"ftr-copy\",\"type\":\"text\",\"props\":{\"content\":\"© تمامی حقوق محفوظ است. پرداخت امن با درگاه معتبر.\"}}]}],\"pages\":{\"blog\":{\"slug\":\"blog\",\"title\":\"وبلاگ\",\"blocks\":[{\"id\":\"blog-hero\",\"data\":{\"align\":\"center\",\"title\":\"وبلاگ و مجله آموزشی\",\"subtitle\":\"آخرین مطالب، راهنماها و اخبار حوزه تخصصی ما\",\"background\":\"secondary\",\"button_url\":null,\"button_text\":null},\"type\":\"hero\"},{\"id\":\"blog-posts\",\"data\":{\"padding\":\"lg\",\"container\":true,\"background\":\"background\"},\"type\":\"section\",\"blocks\":[{\"id\":\"blog-posts-grid\",\"type\":\"module:blog_posts\",\"props\":{\"limit\":12,\"title\":\"آخرین مطالب\",\"layout\":\"grid\",\"show_date\":true,\"show_excerpt\":true,\"category_slug\":null}}]},{\"id\":\"blog-categories\",\"data\":{\"padding\":\"lg\",\"container\":true,\"background\":\"surface\"},\"type\":\"section\",\"blocks\":[{\"id\":\"blog-cat-h\",\"type\":\"heading\",\"props\":{\"text\":\"دسته‌بندی مطالب\",\"level\":3}},{\"id\":\"blog-cat-list\",\"type\":\"module:blog_categories\",\"props\":{\"limit\":12,\"style\":\"badges\",\"title\":\"دسته‌بندی‌ها\"}}]}]},\"home\":{\"slug\":\"\",\"title\":\"صفحه اصلی\",\"blocks\":[{\"id\":\"home-notif\",\"data\":{\"style\":\"top-bar\",\"show_dismiss\":true},\"type\":\"module:notifications_bar\"},{\"id\":\"home-hero\",\"data\":{\"align\":\"center\",\"title\":\"فروش هوشمند، پشتیبانی بی‌نقص\",\"subtitle\":\"محصولات باکیفیت، آموزش تخصصی، پشتیبانی ۲۴ ساعته — همه در یک پلتفرم.\",\"background\":\"primary\",\"button_url\":\"\\/products\",\"button_text\":\"مشاهده محصولات\",\"background_image\":null},\"type\":\"hero\"},{\"id\":\"home-stats\",\"data\":{\"padding\":\"lg\",\"container\":true,\"background\":\"surface\"},\"type\":\"section\",\"blocks\":[{\"id\":\"home-stats-grid\",\"type\":\"grid\",\"props\":{\"gap\":\"lg\",\"columns\":4},\"blocks\":[{\"id\":\"stat-1\",\"type\":\"counter\",\"props\":{\"label\":\"مشتری راضی\",\"value\":5000,\"suffix\":\"+\"}},{\"id\":\"stat-2\",\"type\":\"counter\",\"props\":{\"label\":\"محصول متنوع\",\"value\":1200,\"suffix\":\"+\"}},{\"id\":\"stat-3\",\"type\":\"counter\",\"props\":{\"label\":\"رضایت مشتریان\",\"value\":98,\"suffix\":\"%\"}},{\"id\":\"stat-4\",\"type\":\"counter\",\"props\":{\"label\":\"پشتیبانی آنلاین\",\"value\":24,\"suffix\":\"\\/۷\"}}]}]},{\"id\":\"home-countdown\",\"data\":{\"bg_color\":\"#dc2626\",\"end_date\":null,\"promo_text\":\"🔥 پیشنهاد ویژه هفتگی — فرصت محدود!\"},\"type\":\"module:shop_countdown\"},{\"id\":\"home-products\",\"data\":{\"padding\":\"lg\",\"container\":true,\"background\":\"background\"},\"type\":\"section\",\"blocks\":[{\"id\":\"home-prod-h\",\"type\":\"heading\",\"props\":{\"text\":\"محصولات پیشنهادی\",\"level\":2}},{\"id\":\"home-prod-grid\",\"type\":\"module:shop_product_grid\",\"props\":{\"limit\":8,\"title\":\"محصولات ویژه\",\"source\":\"featured\",\"columns\":\"4\",\"category_slug\":null}},{\"id\":\"home-prod-btn\",\"type\":\"button\",\"props\":{\"url\":\"\\/products\",\"text\":\"مشاهده همه محصولات\",\"style\":\"primary\"}}]},{\"id\":\"home-courses\",\"data\":{\"padding\":\"lg\",\"container\":true,\"background\":\"surface\"},\"type\":\"section\",\"blocks\":[{\"id\":\"home-courses-h\",\"type\":\"heading\",\"props\":{\"text\":\"دوره‌های آموزشی\",\"level\":2}},{\"id\":\"home-courses-t\",\"type\":\"text\",\"props\":{\"content\":\"با دوره‌های تخصصی ما مهارت‌های خود را ارتقا دهید.\"}},{\"id\":\"home-courses-grid\",\"type\":\"module:courses_grid\",\"props\":{\"limit\":3,\"title\":\"دوره‌های پرطرفدار\",\"layout\":\"grid\",\"columns\":\"3\",\"show_price\":true,\"show_instructor\":true}}]},{\"id\":\"home-pricing\",\"data\":{\"padding\":\"lg\",\"container\":true,\"background\":\"background\"},\"type\":\"section\",\"blocks\":[{\"id\":\"home-pricing-table\",\"type\":\"module:pricing_table\",\"props\":{\"title\":\"پلن‌های اشتراک\",\"subtitle\":\"بهترین پلن را برای کسب‌وکار خود انتخاب کنید\",\"highlight_plan\":null,\"show_annual_toggle\":false}}]},{\"id\":\"home-reviews\",\"data\":{\"padding\":\"lg\",\"container\":true,\"background\":\"surface\"},\"type\":\"section\",\"blocks\":[{\"id\":\"home-reviews-grid\",\"type\":\"module:reviews_grid\",\"props\":{\"limit\":6,\"style\":\"cards\",\"title\":\"نظرات مشتریان ما\",\"show_avatar\":true}}]},{\"id\":\"home-blog\",\"data\":{\"padding\":\"lg\",\"container\":true,\"background\":\"background\"},\"type\":\"section\",\"blocks\":[{\"id\":\"home-blog-posts\",\"type\":\"module:blog_posts\",\"props\":{\"limit\":3,\"title\":\"آخرین مطالب\",\"layout\":\"grid\",\"show_date\":true,\"show_excerpt\":true,\"category_slug\":null}}]},{\"id\":\"home-referral\",\"data\":{\"style\":\"card\",\"title\":\"دوستانت را دعوت کن، جایزه بگیر\",\"subtitle\":\"با معرفی هر دوست، اعتبار هدیه دریافت کنید\",\"show_link\":true},\"type\":\"module:referral_widget\"},{\"id\":\"home-cta\",\"data\":{\"title\":\"آماده شروع هستید؟\",\"subtitle\":\"همین الان ثبت‌نام کنید و از پشتیبانی رایگان بهره‌مند شوید.\",\"background\":\"primary\",\"button_url\":\"\\/register\",\"button_text\":\"شروع رایگان\"},\"type\":\"cta\"},{\"id\":\"home-support-btn\",\"data\":{\"label\":\"پشتیبانی آنلاین\",\"style\":\"floating\",\"bg_color\":\"#1e40af\",\"position\":\"bottom-left\"},\"type\":\"module:support_button\"}]},\"about\":{\"slug\":\"about\",\"title\":\"درباره ما\",\"blocks\":[{\"id\":\"about-hero\",\"type\":\"hero\",\"props\":{\"align\":\"center\",\"title\":\"داستان ما\",\"subtitle\":\"تعهد به کیفیت، شفافیت و رضایت مشتریان\",\"background\":\"primary\",\"button_url\":\"\\/support\",\"button_text\":\"تماس با ما\"}},{\"id\":\"about-mission\",\"type\":\"section\",\"props\":{\"padding\":\"lg\",\"container\":true,\"background\":\"surface\"},\"blocks\":[{\"id\":\"about-m-h\",\"type\":\"heading\",\"props\":{\"text\":\"ماموریت ما\",\"level\":2}},{\"id\":\"about-m-t\",\"type\":\"text\",\"props\":{\"content\":\"ما با هدف ایجاد پلتفرمی یکپارچه برای فروش، آموزش و پشتیبانی فعالیت می‌کنیم. مشتریان ما می‌توانند از بهترین محصولات، آموزش‌های تخصصی و پشتیبانی ۲۴ ساعته بهره‌مند شوند.\"}}]},{\"id\":\"about-stats\",\"type\":\"section\",\"props\":{\"padding\":\"lg\",\"container\":true,\"background\":\"background\"},\"blocks\":[{\"id\":\"about-stats-h\",\"type\":\"heading\",\"props\":{\"text\":\"ما در اعداد\",\"level\":2}},{\"id\":\"about-stats-grid\",\"type\":\"grid\",\"props\":{\"gap\":\"lg\",\"columns\":4},\"blocks\":[{\"id\":\"about-stat-1\",\"type\":\"counter\",\"props\":{\"label\":\"سابقه فعالیت\",\"value\":5,\"suffix\":\" سال\"}},{\"id\":\"about-stat-2\",\"type\":\"counter\",\"props\":{\"label\":\"مشتری راضی\",\"value\":5000,\"suffix\":\"+\"}},{\"id\":\"about-stat-3\",\"type\":\"counter\",\"props\":{\"label\":\"متخصص در تیم\",\"value\":50,\"suffix\":\"+\"}},{\"id\":\"about-stat-4\",\"type\":\"counter\",\"props\":{\"label\":\"محصول متنوع\",\"value\":1200,\"suffix\":\"+\"}}]}]},{\"id\":\"about-values\",\"type\":\"section\",\"props\":{\"padding\":\"lg\",\"container\":true,\"background\":\"surface\"},\"blocks\":[{\"id\":\"about-val-h\",\"type\":\"heading\",\"props\":{\"text\":\"چرا ما؟\",\"level\":2}},{\"id\":\"about-val-grid\",\"type\":\"grid\",\"props\":{\"gap\":\"lg\",\"columns\":3},\"blocks\":[{\"id\":\"val-1-h\",\"type\":\"heading\",\"props\":{\"text\":\"✅ محصولات اصل\",\"level\":4}},{\"id\":\"val-2-h\",\"type\":\"heading\",\"props\":{\"text\":\"🚀 ارسال سریع\",\"level\":4}},{\"id\":\"val-3-h\",\"type\":\"heading\",\"props\":{\"text\":\"🛡️ ضمانت بازگشت وجه\",\"level\":4}},{\"id\":\"val-1-t\",\"type\":\"text\",\"props\":{\"content\":\"تمام محصولات با ضمانت اصالت عرضه می‌شوند.\"}},{\"id\":\"val-2-t\",\"type\":\"text\",\"props\":{\"content\":\"ارسال در کمترین زمان ممکن به سراسر کشور.\"}},{\"id\":\"val-3-t\",\"type\":\"text\",\"props\":{\"content\":\"۷ روز ضمانت بازگشت وجه بدون سوال.\"}}]}]},{\"id\":\"about-reviews\",\"type\":\"section\",\"props\":{\"padding\":\"lg\",\"container\":true,\"background\":\"background\"},\"blocks\":[{\"id\":\"about-reviews-grid\",\"type\":\"module:reviews_grid\",\"props\":{\"limit\":3,\"style\":\"cards\",\"title\":\"چه می‌گویند\",\"show_avatar\":true}}]},{\"id\":\"about-cta\",\"type\":\"cta\",\"props\":{\"title\":\"همین امروز با ما همراه شوید\",\"subtitle\":\"از مشاوره رایگان تا پشتیبانی دائمی، کنارتان هستیم.\",\"background\":\"primary\",\"button_url\":\"\\/register\",\"button_text\":\"شروع کنید\"}}]},\"plans\":{\"slug\":\"plans\",\"title\":\"پلن‌ها و قیمت‌گذاری\",\"blocks\":[{\"id\":\"plans-hero\",\"type\":\"hero\",\"props\":{\"align\":\"center\",\"title\":\"پلن مناسب خود را انتخاب کنید\",\"subtitle\":\"بدون هزینه پنهان — تمام امکانات در یک اشتراک\",\"background\":\"primary\",\"button_url\":\"\",\"button_text\":\"\"}},{\"id\":\"plans-table\",\"type\":\"section\",\"props\":{\"padding\":\"lg\",\"container\":true,\"background\":\"background\"},\"blocks\":[{\"id\":\"plans-pricing\",\"type\":\"module:pricing_table\",\"props\":{\"title\":\"پلن‌های اشتراک\",\"subtitle\":\"بهترین پلن برای کسب‌وکار شما\",\"highlight_plan\":\"\",\"show_annual_toggle\":false}}]},{\"id\":\"plans-stats\",\"type\":\"section\",\"props\":{\"padding\":\"md\",\"container\":true,\"background\":\"surface\"},\"blocks\":[{\"id\":\"plans-stats-grid\",\"type\":\"grid\",\"props\":{\"gap\":\"lg\",\"columns\":3},\"blocks\":[{\"id\":\"plans-sub-stat\",\"type\":\"module:subscriber_stats\",\"props\":{\"label\":\"مشترک فعال\",\"style\":\"badge\",\"show_count\":true}},{\"id\":\"plans-ctr-2\",\"type\":\"counter\",\"props\":{\"label\":\"آپتایم سرویس\",\"value\":99,\"suffix\":\"%\"}},{\"id\":\"plans-ctr-3\",\"type\":\"counter\",\"props\":{\"label\":\"ضمانت بازگشت وجه\",\"value\":7,\"suffix\":\" روز\"}}]}]},{\"id\":\"plans-cta\",\"type\":\"module:plan_cta\",\"props\":{\"title\":\"همین الان شروع کنید\",\"bg_color\":\"#1e40af\",\"subtitle\":\"اشتراک رایگان، بدون نیاز به کارت بانکی\",\"button_text\":\"ثبت‌نام رایگان\"}},{\"id\":\"plans-faq\",\"type\":\"section\",\"props\":{\"padding\":\"lg\",\"container\":true,\"background\":\"background\"},\"blocks\":[{\"id\":\"plans-faq-block\",\"type\":\"module:faq_dynamic\",\"props\":{\"limit\":8,\"style\":\"accordion\",\"title\":\"سوالات متداول درباره پلن‌ها\"}}]}]},\"support\":{\"slug\":\"support\",\"title\":\"پشتیبانی\",\"blocks\":[{\"id\":\"sup-hero\",\"type\":\"hero\",\"props\":{\"align\":\"center\",\"title\":\"چطور می‌توانیم کمک کنیم؟\",\"subtitle\":\"تیم پشتیبانی ما ۲۴ ساعته آماده پاسخگویی به سوالات شما است\",\"background\":\"primary\",\"button_url\":\"\\/tickets\\/create\",\"button_text\":\"ارسال تیکت\"}},{\"id\":\"sup-channels\",\"type\":\"section\",\"props\":{\"padding\":\"lg\",\"container\":true,\"background\":\"surface\"},\"blocks\":[{\"id\":\"sup-ch-h\",\"type\":\"heading\",\"props\":{\"text\":\"کانال‌های ارتباطی\",\"level\":2}},{\"id\":\"sup-ch-grid\",\"type\":\"grid\",\"props\":{\"gap\":\"lg\",\"columns\":3},\"blocks\":[{\"id\":\"sup-ch-1\",\"type\":\"heading\",\"props\":{\"text\":\"🎫 سیستم تیکت\",\"level\":4}},{\"id\":\"sup-ch-2\",\"type\":\"heading\",\"props\":{\"text\":\"📞 تماس تلفنی\",\"level\":4}},{\"id\":\"sup-ch-3\",\"type\":\"heading\",\"props\":{\"text\":\"💬 چت آنلاین\",\"level\":4}}]}]},{\"id\":\"sup-contact\",\"type\":\"section\",\"props\":{\"padding\":\"lg\",\"container\":true,\"background\":\"background\"},\"blocks\":[{\"id\":\"sup-contact-form\",\"type\":\"module:contact_quick\",\"props\":{\"title\":\"تماس با ما\",\"show_map\":false,\"show_phone\":true,\"show_address\":true}}]},{\"id\":\"sup-faq\",\"type\":\"section\",\"props\":{\"padding\":\"lg\",\"container\":true,\"background\":\"surface\"},\"blocks\":[{\"id\":\"sup-faq-block\",\"type\":\"module:faq_dynamic\",\"props\":{\"limit\":10,\"style\":\"accordion\",\"title\":\"سوالات متداول\"}}]},{\"id\":\"sup-float-btn\",\"type\":\"module:support_button\",\"props\":{\"label\":\"ارسال تیکت\",\"style\":\"floating\",\"bg_color\":\"#1e40af\",\"position\":\"bottom-right\"}}]},\"learning\":{\"slug\":\"learning\",\"title\":\"آموزشگاه\",\"blocks\":[{\"id\":\"edu-hero\",\"type\":\"hero\",\"props\":{\"align\":\"center\",\"title\":\"آموزشگاه تخصصی\",\"subtitle\":\"دوره‌های جامع برای ارتقای مهارت‌های حرفه‌ای شما\",\"background\":\"primary\",\"button_url\":\"\\/learning\\/courses\",\"button_text\":\"مشاهده همه دوره‌ها\"}},{\"id\":\"edu-stats\",\"type\":\"section\",\"props\":{\"padding\":\"md\",\"container\":true,\"background\":\"surface\"},\"blocks\":[{\"id\":\"edu-stats-grid\",\"type\":\"grid\",\"props\":{\"gap\":\"lg\",\"columns\":3},\"blocks\":[{\"id\":\"edu-stat-1\",\"type\":\"counter\",\"props\":{\"label\":\"دوره آموزشی\",\"value\":50,\"suffix\":\"+\"}},{\"id\":\"edu-stat-2\",\"type\":\"counter\",\"props\":{\"label\":\"دانشجو فعال\",\"value\":3000,\"suffix\":\"+\"}},{\"id\":\"edu-stat-3\",\"type\":\"counter\",\"props\":{\"label\":\"رضایت دانشجویان\",\"value\":95,\"suffix\":\"%\"}}]}]},{\"id\":\"edu-courses\",\"type\":\"section\",\"props\":{\"padding\":\"lg\",\"container\":true,\"background\":\"background\"},\"blocks\":[{\"id\":\"edu-courses-h\",\"type\":\"heading\",\"props\":{\"text\":\"دوره‌های فعال\",\"level\":2}},{\"id\":\"edu-courses-grid\",\"type\":\"module:courses_grid\",\"props\":{\"limit\":9,\"title\":\"دوره‌های آموزشی\",\"layout\":\"grid\",\"columns\":\"3\",\"show_price\":true,\"show_instructor\":true}}]},{\"id\":\"edu-enroll-cta\",\"type\":\"module:course_enroll_cta\",\"props\":{\"title\":\"همین الان شروع کن!\",\"bg_color\":\"#1e40af\",\"subtitle\":\"به هزاران دانشجو بپیوند و آینده‌ات را بساز\",\"button_text\":\"ثبت‌نام رایگان\"}},{\"id\":\"edu-articles\",\"type\":\"section\",\"props\":{\"padding\":\"lg\",\"container\":true,\"background\":\"surface\"},\"blocks\":[{\"id\":\"edu-articles-h\",\"type\":\"heading\",\"props\":{\"text\":\"مقالات آموزشی\",\"level\":2}},{\"id\":\"edu-articles-grid\",\"type\":\"module:edu_article_grid\",\"props\":{\"limit\":6,\"title\":\"مقالات آموزشی\",\"layout\":\"grid\"}}]},{\"id\":\"edu-mylearning\",\"type\":\"module:my_learning_link\",\"props\":{\"label\":\"دوره‌های من\",\"style\":\"button\"}}]},\"products\":{\"slug\":\"products\",\"title\":\"فروشگاه\",\"blocks\":[{\"id\":\"shop-hero\",\"type\":\"hero\",\"props\":{\"align\":\"center\",\"title\":\"فروشگاه آنلاین\",\"subtitle\":\"بهترین محصولات با ضمانت اصالت و ارسال سریع\",\"background\":\"secondary\",\"button_url\":\"\",\"button_text\":\"\"}},{\"id\":\"shop-search\",\"type\":\"module:shop_search_box\",\"props\":{\"style\":\"bar\",\"placeholder\":\"جستجو در محصولات...\"}},{\"id\":\"shop-categories\",\"type\":\"section\",\"props\":{\"padding\":\"lg\",\"container\":true,\"background\":\"surface\"},\"blocks\":[{\"id\":\"shop-cat-h\",\"type\":\"heading\",\"props\":{\"text\":\"دسته‌بندی‌ها\",\"level\":2}},{\"id\":\"shop-cat-grid\",\"type\":\"module:shop_categories\",\"props\":{\"limit\":8,\"style\":\"grid\",\"title\":\"دسته‌بندی‌ها\",\"show_count\":true}}]},{\"id\":\"shop-new\",\"type\":\"section\",\"props\":{\"padding\":\"lg\",\"container\":true,\"background\":\"background\"},\"blocks\":[{\"id\":\"shop-new-h\",\"type\":\"heading\",\"props\":{\"text\":\"جدیدترین محصولات\",\"level\":2}},{\"id\":\"shop-new-grid\",\"type\":\"module:shop_product_grid\",\"props\":{\"limit\":12,\"title\":\"جدیدترین\",\"source\":\"recent\",\"columns\":\"4\",\"category_slug\":\"\"}}]},{\"id\":\"shop-bestsellers\",\"type\":\"section\",\"props\":{\"padding\":\"lg\",\"container\":true,\"background\":\"surface\"},\"blocks\":[{\"id\":\"shop-best-h\",\"type\":\"heading\",\"props\":{\"text\":\"پرفروش‌ترین محصولات\",\"level\":2}},{\"id\":\"shop-best-grid\",\"type\":\"module:shop_product_grid\",\"props\":{\"limit\":8,\"title\":\"پرفروش\",\"source\":\"bestselling\",\"columns\":\"4\",\"category_slug\":\"\"}}]},{\"id\":\"shop-countdown\",\"type\":\"module:shop_countdown\",\"props\":{\"bg_color\":\"#dc2626\",\"end_date\":\"\",\"promo_text\":\"⚡ پیشنهاد ویژه — فرصت محدود!\"}},{\"id\":\"shop-support\",\"type\":\"module:support_button\",\"props\":{\"label\":\"راهنمای خرید\",\"style\":\"floating\",\"bg_color\":\"#1e40af\",\"position\":\"bottom-right\"}}]}},\"global_styles\":{\"colors\":{\"text\":\"#0f172a\",\"accent\":\"#f59e0b\",\"primary\":\"#1e40af\",\"surface\":\"#ffffff\",\"secondary\":\"#3b82f6\",\"background\":\"#f8fafc\",\"text_muted\":\"#64748b\"},\"dark_mode\":{\"text\":\"#f1f5f9\",\"enabled\":false,\"primary\":\"#3b82f6\",\"surface\":\"#1e293b\",\"background\":\"#0f172a\"},\"typography\":{\"scale\":1.25,\"font_body\":\"Vazirmatn, Tahoma, sans-serif\",\"font_heading\":\"Vazirmatn, Tahoma, sans-serif\"},\"font_family\":\"Vazirmatn, Tahoma, sans-serif\",\"primary_color\":\"#1e40af\",\"secondary_color\":\"#3b82f6\",\"background_color\":\"#f8fafc\"}}','theme','2026-06-15 11:31:17','2026-06-15 11:31:17'),(20,'canvas_preview_token','E5VGJ5A7tZiAPN5jMWekkCZsSUUPBfU4rWaz5MKZ','theme','2026-06-15 11:31:17','2026-06-15 11:31:17'),(21,'active_canvas_theme_name','','theme','2026-06-19 21:55:49','2026-06-19 21:55:49'),(22,'active_canvas_theme_slug','','theme','2026-06-19 21:55:49','2026-06-19 21:55:49'),(23,'active_canvas_theme_id','','theme','2026-06-19 21:55:49','2026-06-19 21:55:49'),(24,'site_resource_summary','{\"storage_pct\":0.1,\"storage_bytes\":800000,\"storage_limit\":1073741824,\"db_bytes\":6946816,\"archive_bytes\":0,\"calculated_at\":\"2026-08-20 06:00:08\"}','general','2026-06-20 06:00:05','2026-08-20 02:30:08'),(25,'module_updates_dismissed_sig','access_lists,accounting,analytics,announcements,backup,bank_gateway,brand,captcha,cloud,contract,crm,discount_advanced,gallery,homepage_videos,i18n,installments,inventory,marketing_automation,marketplace_sync,media,module_labels,multi_currency,notifications,omnichannel,podcast,portfolio,product_bundling,projects,qa,recruitment,seo_advanced,services,shipping,smart_image,support,tasks,translations,video,wallet','system','2026-06-20 17:40:26','2026-06-20 17:40:26'),(26,'sms_provider','melipayamak','general','2026-06-25 14:15:30','2026-06-25 14:15:30'),(27,'sms_api_key','88488cba-accb-452e-be5c-2d6554807f1c','general','2026-06-25 14:15:30','2026-06-25 14:15:30'),(28,'sms_line_number','2170002345','general','2026-06-25 14:15:30','2026-06-25 14:15:30'),(29,'site_theme_preset_slug','lavender-dream','theme','2026-06-26 04:43:40','2026-06-27 11:09:35'),(30,'dashboard_preset_slug','enterprise-blue','theme','2026-06-26 04:44:03','2026-06-26 10:15:26'),(31,'captcha_enabled','1','captcha','2026-06-26 14:32:06','2026-06-26 14:32:06'),(32,'auth_captcha_enabled','1','captcha','2026-06-26 14:32:06','2026-06-26 14:32:06'),(33,'shop_captcha_enabled','1','captcha','2026-06-26 14:32:06','2026-06-26 14:32:06'),(34,'captcha_type','persian_number','captcha','2026-06-26 14:32:06','2026-06-26 14:32:06'),(35,'hcaptcha_site_key',NULL,'captcha','2026-06-26 14:32:06','2026-06-26 14:32:06'),(36,'hcaptcha_secret_key',NULL,'captcha','2026-06-26 14:32:06','2026-06-26 14:32:06');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shop_cart_events`
--

DROP TABLE IF EXISTS `shop_cart_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shop_cart_events` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `event_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `shop_cart_events_product_id_created_at_index` (`product_id`,`created_at`),
  CONSTRAINT `shop_cart_events_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shop_cart_events`
--

LOCK TABLES `shop_cart_events` WRITE;
/*!40000 ALTER TABLE `shop_cart_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `shop_cart_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_content_categories`
--

DROP TABLE IF EXISTS `site_content_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_content_categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'general',
  `parent_id` bigint unsigned DEFAULT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `site_content_categories_slug_unique` (`slug`),
  KEY `site_content_categories_parent_id_foreign` (`parent_id`),
  CONSTRAINT `site_content_categories_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `site_content_categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_content_categories`
--

LOCK TABLES `site_content_categories` WRITE;
/*!40000 ALTER TABLE `site_content_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `site_content_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_content_steps`
--

DROP TABLE IF EXISTS `site_content_steps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_content_steps` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `content_id` bigint unsigned NOT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci,
  `media_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `site_content_steps_content_id_sort_order_index` (`content_id`,`sort_order`),
  CONSTRAINT `site_content_steps_content_id_foreign` FOREIGN KEY (`content_id`) REFERENCES `site_contents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_content_steps`
--

LOCK TABLES `site_content_steps` WRITE;
/*!40000 ALTER TABLE `site_content_steps` DISABLE KEYS */;
INSERT INTO `site_content_steps` VALUES (1,1,1,'انتخاب محصول','در این مرحله، خریدار باید محصول مورد نظر خود را از میان گزینه‌های موجود انتخاب کند. توجه به ویژگی‌ها، قیمت و برند محصول از جمله مواردی است که باید مدنظر قرار گیرد.',NULL,NULL,'2026-06-10 12:17:06','2026-06-10 12:17:06'),(2,1,2,'بررسی شرایط قسطی','پس از انتخاب محصول، خریدار باید شرایط قسطی ارائه شده توسط فروشنده یا تأمین‌کننده مالی را بررسی کند. این شرایط شامل مدت زمان قسط، نرخ سود، و مبلغ پیش‌پرداخت است.',NULL,NULL,'2026-06-10 12:17:06','2026-06-10 12:17:06'),(3,1,3,'ثبت نام و ایجاد حساب کاربری','برای خرید قسطی، خریدار باید در وب‌سایت یا اپلیکیشن فروشنده ثبت نام کند و یک حساب کاربری ایجاد نماید. این شامل وارد کردن اطلاعات شخصی و تأیید حساب است.',NULL,NULL,'2026-06-10 12:17:06','2026-06-10 12:17:06'),(4,1,4,'تأمین مدارک لازم','خریدار باید مدارک مورد نیاز برای خرید قسطی را آماده کند. این مدارک معمولاً شامل شناسنامه، کارت ملی، و مدارک مالی مانند فیش حقوقی یا اظهارنامه مالیاتی است.',NULL,NULL,'2026-06-10 12:17:06','2026-06-10 12:17:06'),(5,1,5,'نهایی کردن خرید','پس از تأمین مدارک و تایید شرایط، خریدار می‌تواند خرید خود را نهایی کند. این شامل امضای قرارداد قسطی و پرداخت پیش‌پرداخت است. پس از این مرحله، محصول به خریدار تحویل داده می‌شود.',NULL,NULL,'2026-06-10 12:17:06','2026-06-10 12:17:06');
/*!40000 ALTER TABLE `site_content_steps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_contents`
--

DROP TABLE IF EXISTS `site_contents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_contents` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `excerpt` text COLLATE utf8mb4_unicode_ci,
  `body` longtext COLLATE utf8mb4_unicode_ci,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `ai_generated` tinyint(1) NOT NULL DEFAULT '0',
  `ai_prompt` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_id` bigint unsigned DEFAULT NULL,
  `author_id` bigint unsigned DEFAULT NULL,
  `tags` json DEFAULT NULL,
  `meta` json DEFAULT NULL,
  `panel_section` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `site_contents_slug_unique` (`slug`),
  KEY `site_contents_category_id_foreign` (`category_id`),
  KEY `site_contents_author_id_foreign` (`author_id`),
  KEY `site_contents_type_status_index` (`type`,`status`),
  KEY `site_contents_panel_section_index` (`panel_section`),
  CONSTRAINT `site_contents_author_id_foreign` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `site_contents_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `site_content_categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_contents`
--

LOCK TABLES `site_contents` WRITE;
/*!40000 ALTER TABLE `site_contents` DISABLE KEYS */;
INSERT INTO `site_contents` VALUES (1,'procedure','خرید قسطی محصول','khryd-ksty-mhsol-rjp9B','فرآیند خرید قسطی محصول شامل مراحل مشخصی است که خریدار باید برای تسهیل خرید خود از آن پیروی کند. این مراحل شامل انتخاب محصول، بررسی شرایط قسطی، ثبت نام، تأمین مدارک لازم و نهایی کردن خرید است.',NULL,'published',1,'خرید قسطی محصول',NULL,1,NULL,NULL,NULL,'2026-06-10 12:17:06','2026-06-10 12:17:06','2026-06-10 12:17:06',NULL);
/*!40000 ALTER TABLE `site_contents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_theme_templates`
--

DROP TABLE IF EXISTS `site_theme_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_theme_templates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'section',
  `category` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'hero',
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `tags` json DEFAULT NULL,
  `author` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1.0.0',
  `license_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'free',
  `blocks` json NOT NULL,
  `global_styles` json DEFAULT NULL,
  `demo_data` json DEFAULT NULL,
  `thumbnail_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `usage_count` bigint unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `site_theme_templates_uuid_unique` (`uuid`),
  KEY `site_theme_templates_type_is_active_index` (`type`,`is_active`),
  KEY `site_theme_templates_category_is_active_index` (`category`,`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_theme_templates`
--

LOCK TABLES `site_theme_templates` WRITE;
/*!40000 ALTER TABLE `site_theme_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `site_theme_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `domain` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sites_customer_id_foreign` (`customer_id`),
  CONSTRAINT `sites_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_campaign_recipients`
--

DROP TABLE IF EXISTS `sms_campaign_recipients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_campaign_recipients` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `campaign_id` bigint unsigned NOT NULL,
  `mobile` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','sent','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `sent_at` timestamp NULL DEFAULT NULL,
  `error_message` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sms_campaign_recipients_campaign_id_status_index` (`campaign_id`,`status`),
  KEY `sms_campaign_recipients_campaign_id_index` (`campaign_id`),
  CONSTRAINT `sms_campaign_recipients_campaign_id_foreign` FOREIGN KEY (`campaign_id`) REFERENCES `sms_campaigns` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_campaign_recipients`
--

LOCK TABLES `sms_campaign_recipients` WRITE;
/*!40000 ALTER TABLE `sms_campaign_recipients` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms_campaign_recipients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_campaigns`
--

DROP TABLE IF EXISTS `sms_campaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_campaigns` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `audience_type` enum('all','crm','users','manual') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'all',
  `audience_filter` json DEFAULT NULL,
  `status` enum('draft','scheduled','running','completed','failed','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `scheduled_at` timestamp NULL DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `total_recipients` int unsigned NOT NULL DEFAULT '0',
  `sent_count` int unsigned NOT NULL DEFAULT '0',
  `failed_count` int unsigned NOT NULL DEFAULT '0',
  `created_by_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sms_campaigns_site_id_index` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_campaigns`
--

LOCK TABLES `sms_campaigns` WRITE;
/*!40000 ALTER TABLE `sms_campaigns` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms_campaigns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `social_links`
--

DROP TABLE IF EXISTS `social_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `social_links` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `platform` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int unsigned NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_links`
--

LOCK TABLES `social_links` WRITE;
/*!40000 ALTER TABLE `social_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `social_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_movements`
--

DROP TABLE IF EXISTS `stock_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_movements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `inventory_item_id` bigint unsigned NOT NULL,
  `warehouse_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `type` enum('in','out','adjustment','transfer','return') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'in',
  `reference_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_id` bigint unsigned DEFAULT NULL,
  `quantity_change` int NOT NULL,
  `quantity_before` int unsigned NOT NULL,
  `quantity_after` int unsigned NOT NULL,
  `admin_id` bigint unsigned DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `moved_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stock_movements_product_id_moved_at_index` (`product_id`,`moved_at`),
  KEY `stock_movements_warehouse_id_moved_at_index` (`warehouse_id`,`moved_at`),
  KEY `stock_movements_inventory_item_id_index` (`inventory_item_id`),
  KEY `stock_movements_warehouse_id_index` (`warehouse_id`),
  KEY `stock_movements_product_id_index` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_movements`
--

LOCK TABLES `stock_movements` WRITE;
/*!40000 ALTER TABLE `stock_movements` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscription_logs`
--

DROP TABLE IF EXISTS `subscription_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscription_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `subscription_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `action` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` json DEFAULT NULL,
  `performed_by` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subscription_logs_user_id_foreign` (`user_id`),
  KEY `subscription_logs_subscription_id_action_index` (`subscription_id`,`action`),
  KEY `subscription_logs_created_at_index` (`created_at`),
  CONSTRAINT `subscription_logs_subscription_id_foreign` FOREIGN KEY (`subscription_id`) REFERENCES `subscriptions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `subscription_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscription_logs`
--

LOCK TABLES `subscription_logs` WRITE;
/*!40000 ALTER TABLE `subscription_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscription_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscription_members`
--

DROP TABLE IF EXISTS `subscription_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscription_members` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `subscription_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `invited_by` bigint unsigned NOT NULL,
  `status` enum('pending','active','removed','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `invited_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `joined_at` timestamp NULL DEFAULT NULL,
  `removed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `subscription_members_subscription_id_user_id_unique` (`subscription_id`,`user_id`),
  KEY `subscription_members_invited_by_foreign` (`invited_by`),
  KEY `subscription_members_subscription_id_status_index` (`subscription_id`,`status`),
  KEY `subscription_members_user_id_status_index` (`user_id`,`status`),
  CONSTRAINT `subscription_members_invited_by_foreign` FOREIGN KEY (`invited_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `subscription_members_subscription_id_foreign` FOREIGN KEY (`subscription_id`) REFERENCES `subscriptions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `subscription_members_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscription_members`
--

LOCK TABLES `subscription_members` WRITE;
/*!40000 ALTER TABLE `subscription_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscription_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscription_plan_products`
--

DROP TABLE IF EXISTS `subscription_plan_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscription_plan_products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `subscription_plan_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `discount_percent` int unsigned NOT NULL DEFAULT '0',
  `override_coupon_exclusion` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `spp_plan_product_unique` (`subscription_plan_id`,`product_id`),
  KEY `subscription_plan_products_product_id_foreign` (`product_id`),
  CONSTRAINT `subscription_plan_products_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `subscription_plan_products_subscription_plan_id_foreign` FOREIGN KEY (`subscription_plan_id`) REFERENCES `subscription_plans` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscription_plan_products`
--

LOCK TABLES `subscription_plan_products` WRITE;
/*!40000 ALTER TABLE `subscription_plan_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscription_plan_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscription_plans`
--

DROP TABLE IF EXISTS `subscription_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscription_plans` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `price` decimal(14,2) NOT NULL DEFAULT '0.00',
  `special_price` decimal(14,2) DEFAULT NULL,
  `discount_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_percent` decimal(5,2) DEFAULT NULL,
  `duration` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'month',
  `duration_count` int unsigned NOT NULL DEFAULT '1',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `order` int unsigned NOT NULL DEFAULT '0',
  `trial_days` int unsigned NOT NULL DEFAULT '0',
  `features` json DEFAULT NULL,
  `benefits` json DEFAULT NULL,
  `product_discount_percent` int unsigned NOT NULL DEFAULT '0',
  `apply_to_all_products` tinyint(1) NOT NULL DEFAULT '0',
  `coupon_override` tinyint(1) NOT NULL DEFAULT '0',
  `free_shipping` tinyint(1) NOT NULL DEFAULT '0',
  `vip_support` tinyint(1) NOT NULL DEFAULT '0',
  `early_access` tinyint(1) NOT NULL DEFAULT '0',
  `loyalty_multiplier` decimal(4,2) NOT NULL DEFAULT '1.00',
  `color` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `highlighted` tinyint(1) NOT NULL DEFAULT '0',
  `badge_text` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `max_users` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `subscription_plans_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscription_plans`
--

LOCK TABLES `subscription_plans` WRITE;
/*!40000 ALTER TABLE `subscription_plans` DISABLE KEYS */;
INSERT INTO `subscription_plans` VALUES (1,'پلن عادی','pln-aaady',NULL,1000000.00,NULL,NULL,NULL,'day',30,1,0,0,NULL,NULL,0,0,0,0,0,0,1.00,'#4f46e5',0,NULL,NULL,NULL,'2026-07-03 03:34:23','2026-07-03 03:34:23'),(2,'پلن پیشنهادی','pln-pyshnhady',NULL,3000000.00,NULL,NULL,NULL,'day',90,1,0,0,NULL,NULL,0,1,1,1,1,1,1.00,'#4f46e5',1,NULL,NULL,NULL,'2026-07-03 03:34:49','2026-07-03 03:35:56'),(3,'پلن حرفه ای','pln-hrfh-ay',NULL,6000000.00,NULL,NULL,NULL,'day',180,1,0,0,NULL,NULL,0,0,0,0,0,0,1.00,'#4f46e5',0,NULL,NULL,NULL,'2026-07-03 03:35:16','2026-07-03 03:35:16');
/*!40000 ALTER TABLE `subscription_plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscriptions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `subscription_plan_id` bigint unsigned NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `starts_at` timestamp NOT NULL,
  `ends_at` timestamp NOT NULL,
  `trial_ends_at` timestamp NULL DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `cancellation_reason` text COLLATE utf8mb4_unicode_ci,
  `renewed_at` timestamp NULL DEFAULT NULL,
  `auto_renew` tinyint(1) NOT NULL DEFAULT '0',
  `reminder_7d_sent_at` timestamp NULL DEFAULT NULL,
  `reminder_1d_sent_at` timestamp NULL DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `pending_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `upgrade_from_subscription_id` bigint unsigned DEFAULT NULL,
  `credit_amount` decimal(10,0) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `invoice_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subscriptions_subscription_plan_id_foreign` (`subscription_plan_id`),
  KEY `subscriptions_invoice_id_foreign` (`invoice_id`),
  KEY `subscriptions_user_id_status_index` (`user_id`,`status`),
  KEY `subscriptions_ends_at_status_index` (`ends_at`,`status`),
  KEY `subscriptions_upgrade_from_subscription_id_foreign` (`upgrade_from_subscription_id`),
  CONSTRAINT `subscriptions_invoice_id_foreign` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE SET NULL,
  CONSTRAINT `subscriptions_subscription_plan_id_foreign` FOREIGN KEY (`subscription_plan_id`) REFERENCES `subscription_plans` (`id`) ON DELETE CASCADE,
  CONSTRAINT `subscriptions_upgrade_from_subscription_id_foreign` FOREIGN KEY (`upgrade_from_subscription_id`) REFERENCES `subscriptions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `subscriptions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscriptions`
--

LOCK TABLES `subscriptions` WRITE;
/*!40000 ALTER TABLE `subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_conversation_participants`
--

DROP TABLE IF EXISTS `support_conversation_participants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_conversation_participants` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `conversation_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `participant_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `participant_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'participant',
  `display_name` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `joined_at` timestamp NULL DEFAULT NULL,
  `left_at` timestamp NULL DEFAULT NULL,
  `last_read_at` timestamp NULL DEFAULT NULL,
  `unread_count` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_support_participant` (`conversation_id`,`participant_id`,`participant_type`),
  KEY `scp_participant_idx` (`participant_id`,`participant_type`),
  KEY `support_conversation_participants_conversation_id_role_index` (`conversation_id`,`role`),
  CONSTRAINT `support_conversation_participants_conversation_id_foreign` FOREIGN KEY (`conversation_id`) REFERENCES `support_conversations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_conversation_participants`
--

LOCK TABLES `support_conversation_participants` WRITE;
/*!40000 ALTER TABLE `support_conversation_participants` DISABLE KEYS */;
INSERT INTO `support_conversation_participants` VALUES (1,'019ead3b-7075-706f-9814-42132ee5ec6e','2','user','owner',NULL,'2026-06-09 16:33:34',NULL,NULL,0,'2026-06-09 16:33:34','2026-06-09 16:33:34'),(2,'019ead3b-7075-706f-9814-42132ee5ec6e','1','admin','participant',NULL,'2026-06-09 16:37:22',NULL,NULL,0,'2026-06-09 16:37:22','2026-06-09 16:37:22');
/*!40000 ALTER TABLE `support_conversation_participants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_conversations`
--

DROP TABLE IF EXISTS `support_conversations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_conversations` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'support',
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `priority` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal',
  `channel` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'web',
  `assigned_agent_id` bigint unsigned DEFAULT NULL,
  `created_by_user_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_type` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `first_response_at` timestamp NULL DEFAULT NULL,
  `resolved_at` timestamp NULL DEFAULT NULL,
  `closed_at` timestamp NULL DEFAULT NULL,
  `last_message_at` timestamp NULL DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `tags` json DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `support_conversations_status_priority_index` (`status`,`priority`),
  KEY `support_conversations_assigned_agent_id_status_index` (`assigned_agent_id`,`status`),
  KEY `support_conversations_last_message_at_index` (`last_message_at`),
  KEY `support_conversations_created_at_index` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_conversations`
--

LOCK TABLES `support_conversations` WRITE;
/*!40000 ALTER TABLE `support_conversations` DISABLE KEYS */;
INSERT INTO `support_conversations` VALUES ('019ead3b-7075-706f-9814-42132ee5ec6e','open','support','تست ارسال سس به سایت مشتری','high','web',NULL,'2','user','2026-06-09 16:37:22',NULL,NULL,'2026-06-26 05:44:27','{\"ticket_id\": 1, \"ticket_number\": \"UT-260609-F2FL\"}',NULL,NULL,'2026-06-09 16:33:34','2026-06-26 05:44:27');
/*!40000 ALTER TABLE `support_conversations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_message_attachments`
--

DROP TABLE IF EXISTS `support_message_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_message_attachments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `message_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conversation_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stored_path` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `disk` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'local',
  `mime_type` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_size` bigint unsigned NOT NULL DEFAULT '0',
  `file_hash` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uploader_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uploader_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `support_message_attachments_message_id_foreign` (`message_id`),
  KEY `support_message_attachments_conversation_id_created_at_index` (`conversation_id`,`created_at`),
  KEY `support_message_attachments_uploader_id_index` (`uploader_id`),
  CONSTRAINT `support_message_attachments_conversation_id_foreign` FOREIGN KEY (`conversation_id`) REFERENCES `support_conversations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `support_message_attachments_message_id_foreign` FOREIGN KEY (`message_id`) REFERENCES `support_messages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_message_attachments`
--

LOCK TABLES `support_message_attachments` WRITE;
/*!40000 ALTER TABLE `support_message_attachments` DISABLE KEYS */;
INSERT INTO `support_message_attachments` VALUES (1,'019ead3e-ec37-70dc-9cd4-1afb27c698ef','019ead3b-7075-706f-9814-42132ee5ec6e','1.png','uploads/tickets/2026/06/N8BWu1WMl3pMn5xWIsxgh8Bn7ObiCYDW.png','public_uploads','image/png',177064,NULL,'1','admin',0,'2026-06-09 16:37:22','2026-06-09 16:37:22'),(2,'019ead3f-3ca2-721e-ac56-7711228e89df','019ead3b-7075-706f-9814-42132ee5ec6e','3.jpg','uploads/tickets/2026/06/OAi4jexu3dkbUn8vkm3GglxXsHJT2u59.jpg','public_uploads','image/jpeg',31624,NULL,'2','user',0,'2026-06-09 16:37:43','2026-06-09 16:37:43'),(3,'019ead58-b8b2-72b9-9fb9-1bdc30cd9bab','019ead3b-7075-706f-9814-42132ee5ec6e','1.png','uploads/tickets/2026/06/o1N39wL1Y2s6Gw1P7yGlh7yiXfnZ3XUz.png','public_uploads','image/png',177064,NULL,'1','admin',0,'2026-06-09 17:05:33','2026-06-09 17:05:33'),(4,'019eb5ad-3ef4-73f3-b85b-d85c3e33afa1','019ead3b-7075-706f-9814-42132ee5ec6e','SEO-search-engine-spider.jpg','uploads/tickets/2026/06/m3l70awyLLpou8iASM2Z3suQoptFxPhJ.jpg','public_uploads','image/jpeg',20883,NULL,'1','admin',0,'2026-06-11 07:54:50','2026-06-11 07:54:50'),(5,'019ec558-d1e0-710f-9b73-65be1e5db087','019ead3b-7075-706f-9814-42132ee5ec6e','2.png','uploads/tickets/2026/06/8gwZXzylP73PYaXYbkWzO15VZo4ZYVRM.png','public_uploads','image/png',97830,NULL,'1','admin',0,'2026-06-14 08:56:33','2026-06-14 08:56:33'),(6,'019eee2a-63ad-71b5-8bf3-6c31c2c2f6ea','019ead3b-7075-706f-9814-42132ee5ec6e','3.jpg','uploads/tickets/2026/06/8x6o7L1jEiHbXKPNGGtjVX8npOSCLysa.jpg','public_uploads','image/jpeg',31624,NULL,'1','admin',0,'2026-06-22 07:10:16','2026-06-22 07:10:16'),(7,'019f022c-dc4a-7271-b5e9-3f3ba3b358d3','019ead3b-7075-706f-9814-42132ee5ec6e','11.png','uploads/tickets/2026/06/4mLMdaEAEcRFC5T6Zgvfuf64sXfeSCdy.png','public_uploads','image/png',1402845,NULL,'2','user',0,'2026-06-26 04:25:22','2026-06-26 04:25:22');
/*!40000 ALTER TABLE `support_message_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_messages`
--

DROP TABLE IF EXISTS `support_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_messages` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conversation_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `reply_to_message_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_internal_note` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `metadata` json DEFAULT NULL,
  `edited_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `support_messages_conversation_id_created_at_index` (`conversation_id`,`created_at`),
  KEY `support_messages_sender_id_sender_type_index` (`sender_id`,`sender_type`),
  KEY `support_messages_reply_to_message_id_index` (`reply_to_message_id`),
  CONSTRAINT `support_messages_conversation_id_foreign` FOREIGN KEY (`conversation_id`) REFERENCES `support_conversations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_messages`
--

LOCK TABLES `support_messages` WRITE;
/*!40000 ALTER TABLE `support_messages` DISABLE KEYS */;
INSERT INTO `support_messages` VALUES ('019ead3b-70a1-72ac-a549-e4a836c3b3df','019ead3b-7075-706f-9814-42132ee5ec6e','2','user','text','تست ارسال سس به سایت مشتریتست ارسال سس به سایت مشتریتست ارسال سس به سایت مشتریتست ارسال سس به سایت مشتریتست ارسال سس به سایت مشتریتست ارسال سس به سایت مشتریتست ارسال سس به سایت مشتریتست ارسال سس به سایت مشتری',NULL,0,0,'[]',NULL,NULL,'2026-06-09 16:33:34','2026-06-09 16:33:34'),('019ead3e-ec37-70dc-9cd4-1afb27c698ef','019ead3b-7075-706f-9814-42132ee5ec6e','1','admin','text','سلام',NULL,0,0,'[]',NULL,NULL,'2026-06-09 16:37:22','2026-06-09 16:37:22'),('019ead3f-3ca2-721e-ac56-7711228e89df','019ead3b-7075-706f-9814-42132ee5ec6e','2','user','text','سلام',NULL,0,0,'[]',NULL,NULL,'2026-06-09 16:37:43','2026-06-09 16:37:43'),('019ead55-ba52-7223-b13e-8c9ad4204f81','019ead3b-7075-706f-9814-42132ee5ec6e','2','user','text','تست ارسال موبایل',NULL,0,0,'[]',NULL,NULL,'2026-06-09 17:02:17','2026-06-09 17:02:17'),('019ead57-9dc4-73c1-a503-85ee7bcb7fe4','019ead3b-7075-706f-9814-42132ee5ec6e','1','admin','text','سلام',NULL,0,0,'[]',NULL,NULL,'2026-06-09 17:04:20','2026-06-09 17:04:20'),('019ead58-066c-7249-b340-edf191d8b68f','019ead3b-7075-706f-9814-42132ee5ec6e','1','admin','text','بله درسته',NULL,0,0,'[]',NULL,NULL,'2026-06-09 17:04:47','2026-06-09 17:04:47'),('019ead58-746f-7099-a368-0f6d9bff1977','019ead3b-7075-706f-9814-42132ee5ec6e','2','user','text','سلام',NULL,0,0,'[]',NULL,NULL,'2026-06-09 17:05:15','2026-06-09 17:05:15'),('019ead58-8153-7101-957c-3b361755db5d','019ead3b-7075-706f-9814-42132ee5ec6e','1','admin','text','بله',NULL,0,0,'[]',NULL,NULL,'2026-06-09 17:05:19','2026-06-09 17:05:19'),('019ead58-b8b2-72b9-9fb9-1bdc30cd9bab','019ead3b-7075-706f-9814-42132ee5ec6e','1','admin','text','اینم لوگو',NULL,0,0,'[]',NULL,NULL,'2026-06-09 17:05:33','2026-06-09 17:05:33'),('019ead58-da8b-7362-b9eb-96fbfa9b2e40','019ead3b-7075-706f-9814-42132ee5ec6e','2','user','text','خداحافظ',NULL,0,0,'[]',NULL,NULL,'2026-06-09 17:05:42','2026-06-09 17:05:42'),('019eb2eb-f42c-72c3-adc2-d7d6dcd4db72','019ead3b-7075-706f-9814-42132ee5ec6e','2','user','text','سلام',NULL,0,0,'[]',NULL,NULL,'2026-06-10 19:04:28','2026-06-10 19:04:28'),('019eb5ad-0813-7398-8fad-16ed857e3b90','019ead3b-7075-706f-9814-42132ee5ec6e','1','admin','text','سلام',NULL,0,0,'[]',NULL,NULL,'2026-06-11 07:54:36','2026-06-11 07:54:36'),('019eb5ad-3ef4-73f3-b85b-d85c3e33afa1','019ead3b-7075-706f-9814-42132ee5ec6e','1','admin','text','خوبی',NULL,0,0,'[]',NULL,NULL,'2026-06-11 07:54:50','2026-06-11 07:54:50'),('019ec557-9e5c-7291-aebe-e8509d211cdc','019ead3b-7075-706f-9814-42132ee5ec6e','1','admin','text','سلام',NULL,0,0,'[]',NULL,NULL,'2026-06-14 08:55:14','2026-06-14 08:55:14'),('019ec558-0ece-72f3-a750-15cffb7e4a7d','019ead3b-7075-706f-9814-42132ee5ec6e','2','user','text','سلام',NULL,0,0,'[]',NULL,NULL,'2026-06-14 08:55:43','2026-06-14 08:55:43'),('019ec558-d1e0-710f-9b73-65be1e5db087','019ead3b-7075-706f-9814-42132ee5ec6e','1','admin','text','حل شد',NULL,0,0,'[]',NULL,NULL,'2026-06-14 08:56:32','2026-06-14 08:56:32'),('019ec559-5d88-719e-bd21-9f21a54c928f','019ead3b-7075-706f-9814-42132ee5ec6e','2','user','text','ممنونم',NULL,0,0,'[]',NULL,NULL,'2026-06-14 08:57:08','2026-06-14 08:57:08'),('019ee1b5-a548-7005-b589-102fe76b7d75','019ead3b-7075-706f-9814-42132ee5ec6e','2','user','text','سلام',NULL,0,0,'[]',NULL,NULL,'2026-06-19 21:07:18','2026-06-19 21:07:18'),('019eee2a-63ad-71b5-8bf3-6c31c2c2f6ea','019ead3b-7075-706f-9814-42132ee5ec6e','1','admin','text','سلام',NULL,0,0,'[]',NULL,NULL,'2026-06-22 07:10:15','2026-06-22 07:10:15'),('019eee2a-f8bc-71e4-ba5b-86df994f371e','019ead3b-7075-706f-9814-42132ee5ec6e','2','user','text','سلام',NULL,0,0,'[]',NULL,NULL,'2026-06-22 07:10:54','2026-06-22 07:10:54'),('019eee2b-a0a9-72a4-bb20-2bd88f111dfe','019ead3b-7075-706f-9814-42132ee5ec6e','1','admin','text','سلام',NULL,0,0,'[]',NULL,NULL,'2026-06-22 07:11:37','2026-06-22 07:11:37'),('019eee2c-a21f-728e-8e8c-1e7bb1d2288a','019ead3b-7075-706f-9814-42132ee5ec6e','1','admin','text','سلام',NULL,0,0,'[]',NULL,NULL,'2026-06-22 07:12:43','2026-06-22 07:12:43'),('019f0229-bd3c-7331-b8bb-945cb3b37031','019ead3b-7075-706f-9814-42132ee5ec6e','1','admin','text','sghl',NULL,0,0,'[]',NULL,NULL,'2026-06-26 04:21:57','2026-06-26 04:21:57'),('019f022c-dc4a-7271-b5e9-3f3ba3b358d3','019ead3b-7075-706f-9814-42132ee5ec6e','2','user','text','سلام',NULL,0,0,'[]',NULL,NULL,'2026-06-26 04:25:22','2026-06-26 04:25:22'),('019f0275-463e-7079-b793-a070485aefac','019ead3b-7075-706f-9814-42132ee5ec6e','2','user','text','س',NULL,0,0,'[]',NULL,NULL,'2026-06-26 05:44:27','2026-06-26 05:44:27');
/*!40000 ALTER TABLE `support_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_presence`
--

DROP TABLE IF EXISTS `support_presence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_presence` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `conversation_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `participant_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `participant_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'offline',
  `is_typing` tinyint(1) NOT NULL DEFAULT '0',
  `typing_started_at` timestamp NULL DEFAULT NULL,
  `last_seen_at` timestamp NULL DEFAULT NULL,
  `socket_id` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_support_presence` (`conversation_id`,`participant_id`,`participant_type`),
  KEY `support_presence_participant_id_status_index` (`participant_id`,`status`),
  CONSTRAINT `support_presence_conversation_id_foreign` FOREIGN KEY (`conversation_id`) REFERENCES `support_conversations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_presence`
--

LOCK TABLES `support_presence` WRITE;
/*!40000 ALTER TABLE `support_presence` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_presence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_read_receipts`
--

DROP TABLE IF EXISTS `support_read_receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_read_receipts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `message_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conversation_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reader_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reader_type` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_support_read_receipt` (`message_id`,`reader_id`,`reader_type`),
  KEY `support_read_receipts_conversation_id_reader_id_index` (`conversation_id`,`reader_id`),
  KEY `support_read_receipts_read_at_index` (`read_at`),
  CONSTRAINT `support_read_receipts_conversation_id_foreign` FOREIGN KEY (`conversation_id`) REFERENCES `support_conversations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `support_read_receipts_message_id_foreign` FOREIGN KEY (`message_id`) REFERENCES `support_messages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_read_receipts`
--

LOCK TABLES `support_read_receipts` WRITE;
/*!40000 ALTER TABLE `support_read_receipts` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_read_receipts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tags_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
INSERT INTO `tags` VALUES (1,'تولید محتوا','tolyd-mhtoa',NULL,NULL,1,'2026-06-10 19:40:01','2026-06-10 19:40:01',NULL),(2,'بازاریابی دیجیتال','bazaryaby-dyjytal',NULL,NULL,1,'2026-06-10 19:40:01','2026-06-10 19:40:01',NULL),(3,'SEO','seo',NULL,NULL,1,'2026-06-10 19:40:01','2026-06-10 19:40:01',NULL),(4,'محتوای وب','mhtoay-ob',NULL,NULL,1,'2026-06-10 19:40:01','2026-06-10 19:40:01',NULL),(5,'استراتژی محتوا','astratzhy-mhtoa',NULL,NULL,1,'2026-06-10 19:40:01','2026-06-10 19:40:01',NULL),(6,'فوتبال','fotbal',NULL,NULL,1,'2026-06-11 07:57:08','2026-06-11 07:57:08',NULL),(7,'جام جهانی','jam-jhany',NULL,NULL,1,'2026-06-11 07:57:08','2026-06-11 07:57:08',NULL),(8,'ورزش','orzsh',NULL,NULL,1,'2026-06-11 07:57:08','2026-06-11 07:57:08',NULL),(9,'مسابقات','msabghat',NULL,NULL,1,'2026-06-11 07:57:08','2026-06-11 07:57:08',NULL),(10,'تاریخچه','tarykhchh',NULL,NULL,1,'2026-06-11 07:57:08','2026-06-11 07:57:08',NULL);
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `theme_settings`
--

DROP TABLE IF EXISTS `theme_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `theme_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint unsigned DEFAULT NULL COMMENT 'Optional tenant scope',
  `primary_color` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT '#4f46e5',
  `secondary_color` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT '#64748b',
  `accent_color` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT '#7c3aed',
  `background_color` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT '#f9fafb',
  `surface_color` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT '#ffffff',
  `text_color` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT '#111827',
  `muted_color` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT '#6b7280',
  `border_color` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT '#e5e7eb',
  `link_color` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT '#4f46e5',
  `header_bg` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT '#1e293b',
  `footer_bg` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT '#1e293b',
  `font_family_heading` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT 'Vazirmatn, Tahoma, sans-serif',
  `font_family_body` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT 'Vazirmatn, Tahoma, sans-serif',
  `base_font_size` varchar(24) COLLATE utf8mb4_unicode_ci DEFAULT '16px',
  `container_width` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT '1200px',
  `border_radius` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT '8px',
  `button_style` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT 'solid' COMMENT 'solid, outline, rounded',
  `section_spacing` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT 'md' COMMENT 'xs, sm, md, lg, xl',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `theme_settings_site_id_unique` (`site_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `theme_settings`
--

LOCK TABLES `theme_settings` WRITE;
/*!40000 ALTER TABLE `theme_settings` DISABLE KEYS */;
INSERT INTO `theme_settings` VALUES (1,NULL,'#16a34a','#14532d','#15803d','#f0fdf4','#ffffff','#052e16','#166534','#bbf7d0','#15803d','#14532d','#14532d','Vazirmatn, Tahoma, sans-serif','Vazirmatn, Tahoma, sans-serif','16px','1200px','8px','solid','md','2026-06-15 11:33:10','2026-06-27 04:03:42');
/*!40000 ALTER TABLE `theme_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_activities`
--

DROP TABLE IF EXISTS `ticket_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket_activities` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `ticket_id` bigint unsigned NOT NULL,
  `actor_id` bigint unsigned DEFAULT NULL,
  `action_type` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `old_value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ticket_activities_actor_id_foreign` (`actor_id`),
  KEY `ticket_activities_ticket_id_created_at_index` (`ticket_id`,`created_at`),
  KEY `ticket_activities_action_type_index` (`action_type`),
  CONSTRAINT `ticket_activities_actor_id_foreign` FOREIGN KEY (`actor_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `ticket_activities_ticket_id_foreign` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_activities`
--

LOCK TABLES `ticket_activities` WRITE;
/*!40000 ALTER TABLE `ticket_activities` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_fr_subscribers`
--

DROP TABLE IF EXISTS `ticket_fr_subscribers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket_fr_subscribers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `ticket_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `customer_mobile` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_fr_sub_user` (`ticket_id`,`user_id`),
  UNIQUE KEY `uq_fr_sub_mobile` (`ticket_id`,`customer_mobile`),
  KEY `ticket_fr_subscribers_ticket_id_index` (`ticket_id`),
  CONSTRAINT `ticket_fr_subscribers_ticket_id_foreign` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_fr_subscribers`
--

LOCK TABLES `ticket_fr_subscribers` WRITE;
/*!40000 ALTER TABLE `ticket_fr_subscribers` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_fr_subscribers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_replies`
--

DROP TABLE IF EXISTS `ticket_replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket_replies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `ticket_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `author_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'staff',
  `is_internal` tinyint(1) NOT NULL DEFAULT '0',
  `customer_mobile` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachments` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ticket_replies_ticket_id_index` (`ticket_id`),
  KEY `ticket_replies_user_id_index` (`user_id`),
  CONSTRAINT `ticket_replies_ticket_id_foreign` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ticket_replies_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_replies`
--

LOCK TABLES `ticket_replies` WRITE;
/*!40000 ALTER TABLE `ticket_replies` DISABLE KEYS */;
INSERT INTO `ticket_replies` VALUES (1,1,1,'سلام','staff',0,NULL,NULL,'[{\"url\": \"http://safhenokhost.ir/uploads/tickets/2026/06/N8BWu1WMl3pMn5xWIsxgh8Bn7ObiCYDW.png\", \"mime\": \"image/png\", \"name\": \"1.png\", \"path\": \"uploads/tickets/2026/06/N8BWu1WMl3pMn5xWIsxgh8Bn7ObiCYDW.png\", \"size\": 177064}]','2026-06-09 16:37:22','2026-06-09 16:37:22',NULL),(2,1,NULL,'سلام','customer',0,'09906210511','مریم شرفی','[{\"url\": \"http://safhenokhost.ir/uploads/tickets/2026/06/OAi4jexu3dkbUn8vkm3GglxXsHJT2u59.jpg\", \"mime\": \"image/jpeg\", \"name\": \"3.jpg\", \"path\": \"uploads/tickets/2026/06/OAi4jexu3dkbUn8vkm3GglxXsHJT2u59.jpg\", \"size\": 31624}]','2026-06-09 16:37:43','2026-06-09 16:37:43',NULL),(3,1,NULL,'تست ارسال موبایل','customer',0,'09906210511','مریم شرفی',NULL,'2026-06-09 17:02:17','2026-06-09 17:02:17',NULL),(4,1,1,'سلام','staff',0,NULL,NULL,NULL,'2026-06-09 17:04:20','2026-06-09 17:04:20',NULL),(5,1,1,'بله درسته','staff',0,NULL,NULL,NULL,'2026-06-09 17:04:47','2026-06-09 17:04:47',NULL),(6,1,NULL,'سلام','customer',0,'09906210511','مریم شرفی',NULL,'2026-06-09 17:05:15','2026-06-09 17:05:15',NULL),(7,1,1,'بله','staff',0,NULL,NULL,NULL,'2026-06-09 17:05:19','2026-06-09 17:05:19',NULL),(8,1,1,'اینم لوگو','staff',0,NULL,NULL,'[{\"url\": \"http://safhenokhost.ir/uploads/tickets/2026/06/o1N39wL1Y2s6Gw1P7yGlh7yiXfnZ3XUz.png\", \"mime\": \"image/png\", \"name\": \"1.png\", \"path\": \"uploads/tickets/2026/06/o1N39wL1Y2s6Gw1P7yGlh7yiXfnZ3XUz.png\", \"size\": 177064}]','2026-06-09 17:05:33','2026-06-09 17:05:33',NULL),(9,1,NULL,'خداحافظ','customer',0,'09906210511','مریم شرفی',NULL,'2026-06-09 17:05:42','2026-06-09 17:05:42',NULL),(10,1,NULL,'سلام','customer',0,'09906210511','مریم شرفی',NULL,'2026-06-10 19:04:28','2026-06-10 19:04:28',NULL),(11,1,1,'سلام','staff',0,NULL,NULL,NULL,'2026-06-11 07:54:36','2026-06-11 07:54:36',NULL),(12,1,1,'خوبی','staff',0,NULL,NULL,'[{\"url\": \"http://safhenokhost.ir/uploads/tickets/2026/06/m3l70awyLLpou8iASM2Z3suQoptFxPhJ.jpg\", \"mime\": \"image/jpeg\", \"name\": \"SEO-search-engine-spider.jpg\", \"path\": \"uploads/tickets/2026/06/m3l70awyLLpou8iASM2Z3suQoptFxPhJ.jpg\", \"size\": 20883}]','2026-06-11 07:54:50','2026-06-11 07:54:50',NULL),(13,1,1,'سلام','staff',0,NULL,NULL,NULL,'2026-06-14 08:55:14','2026-06-14 08:55:14',NULL),(14,1,NULL,'سلام','customer',0,'09906210511','مریم شرفی',NULL,'2026-06-14 08:55:43','2026-06-14 08:55:43',NULL),(15,1,1,'حل شد','staff',0,NULL,NULL,'[{\"url\": \"http://safhenokhost.ir/uploads/tickets/2026/06/8gwZXzylP73PYaXYbkWzO15VZo4ZYVRM.png\", \"mime\": \"image/png\", \"name\": \"2.png\", \"path\": \"uploads/tickets/2026/06/8gwZXzylP73PYaXYbkWzO15VZo4ZYVRM.png\", \"size\": 97830}]','2026-06-14 08:56:32','2026-06-14 08:56:32',NULL),(16,1,NULL,'ممنونم','customer',0,'09906210511','مریم شرفی',NULL,'2026-06-14 08:57:08','2026-06-14 08:57:08',NULL),(17,1,NULL,'سلام','customer',0,'09906210511','مریم شرفی',NULL,'2026-06-19 21:07:18','2026-06-19 21:07:18',NULL),(18,1,1,'سلام','staff',0,NULL,NULL,'[{\"url\": \"https://safhenokhost.ir/uploads/tickets/2026/06/8x6o7L1jEiHbXKPNGGtjVX8npOSCLysa.jpg\", \"mime\": \"image/jpeg\", \"name\": \"3.jpg\", \"path\": \"uploads/tickets/2026/06/8x6o7L1jEiHbXKPNGGtjVX8npOSCLysa.jpg\", \"size\": 31624}]','2026-06-22 07:10:15','2026-06-22 07:10:15',NULL),(19,1,NULL,'سلام','customer',0,'09906210511','مریم شرفی',NULL,'2026-06-22 07:10:54','2026-06-22 07:10:54',NULL),(20,1,1,'سلام','staff',0,NULL,NULL,NULL,'2026-06-22 07:11:37','2026-06-22 07:11:37',NULL),(21,1,1,'سلام','staff',0,NULL,NULL,NULL,'2026-06-22 07:12:42','2026-06-22 07:12:42',NULL),(22,1,1,'sghl','staff',0,NULL,NULL,NULL,'2026-06-26 04:21:57','2026-06-26 04:21:57',NULL),(23,1,NULL,'سلام','customer',0,'09906210511','مریم شرفی','[{\"url\": \"https://safhenokhost.ir/uploads/tickets/2026/06/4mLMdaEAEcRFC5T6Zgvfuf64sXfeSCdy.png\", \"mime\": \"image/png\", \"name\": \"11.png\", \"path\": \"uploads/tickets/2026/06/4mLMdaEAEcRFC5T6Zgvfuf64sXfeSCdy.png\", \"size\": 1402845}]','2026-06-26 04:25:22','2026-06-26 04:25:22',NULL),(24,1,NULL,'س','customer',0,'09906210511','مریم شرفی',NULL,'2026-06-26 05:44:27','2026-06-26 05:44:27',NULL);
/*!40000 ALTER TABLE `ticket_replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_votes`
--

DROP TABLE IF EXISTS `ticket_votes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket_votes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `ticket_id` bigint unsigned NOT NULL,
  `voter_id` bigint unsigned DEFAULT NULL,
  `voter_mobile` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `voter_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ticket_vote_user` (`ticket_id`,`voter_id`),
  UNIQUE KEY `uq_ticket_vote_mobile` (`ticket_id`,`voter_mobile`),
  KEY `ticket_votes_ticket_id_index` (`ticket_id`),
  CONSTRAINT `ticket_votes_ticket_id_foreign` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_votes`
--

LOCK TABLES `ticket_votes` WRITE;
/*!40000 ALTER TABLE `ticket_votes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_votes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tickets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `ticket_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `priority` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal',
  `customer_id` bigint unsigned DEFAULT NULL,
  `assigned_to` bigint unsigned DEFAULT NULL,
  `site_id` bigint unsigned DEFAULT NULL,
  `customer_mobile` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'support',
  `fr_status` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fr_status_updated_at` timestamp NULL DEFAULT NULL,
  `fr_impact_score` tinyint unsigned NOT NULL DEFAULT '0',
  `fr_estimated_quarter` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tags` text COLLATE utf8mb4_unicode_ci,
  `attachments` json DEFAULT NULL,
  `watchers` json DEFAULT NULL,
  `closed_at` timestamp NULL DEFAULT NULL,
  `first_response_at` timestamp NULL DEFAULT NULL,
  `resolved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tickets_ticket_number_unique` (`ticket_number`),
  KEY `tickets_status_priority_index` (`status`,`priority`),
  KEY `tickets_customer_id_index` (`customer_id`),
  KEY `tickets_site_id_index` (`site_id`),
  KEY `tickets_assigned_to_index` (`assigned_to`),
  KEY `idx_tickets_type_fr_status` (`type`,`fr_status`),
  CONSTRAINT `tickets_assigned_to_foreign` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `tickets_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `tickets_site_id_foreign` FOREIGN KEY (`site_id`) REFERENCES `sites` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets`
--

LOCK TABLES `tickets` WRITE;
/*!40000 ALTER TABLE `tickets` DISABLE KEYS */;
INSERT INTO `tickets` VALUES (1,'UT-260609-F2FL','تست ارسال سس به سایت مشتری','تست ارسال سس به سایت مشتریتست ارسال سس به سایت مشتریتست ارسال سس به سایت مشتریتست ارسال سس به سایت مشتریتست ارسال سس به سایت مشتریتست ارسال سس به سایت مشتریتست ارسال سس به سایت مشتریتست ارسال سس به سایت مشتری','in_progress','high',2,NULL,NULL,'09906210511','مریم شرفی','billing','support',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-09 16:33:34','2026-07-01 05:15:20','2026-07-01 05:15:20');
/*!40000 ALTER TABLE `tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `translation_queue`
--

DROP TABLE IF EXISTS `translation_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `translation_queue` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `translatable_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `translatable_id` bigint unsigned NOT NULL,
  `locale` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `attempts` tinyint unsigned NOT NULL DEFAULT '0',
  `last_error` text COLLATE utf8mb4_unicode_ci,
  `queued_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `processed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tq_unique` (`translatable_type`,`translatable_id`,`locale`,`field_name`),
  KEY `translation_queue_status_index` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `translation_queue`
--

LOCK TABLES `translation_queue` WRITE;
/*!40000 ALTER TABLE `translation_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `translation_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_activity_log`
--

DROP TABLE IF EXISTS `user_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_activity_log` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `action` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_activity_log_user_id_created_at_index` (`user_id`,`created_at`),
  CONSTRAINT `user_activity_log_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=173 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_activity_log`
--

LOCK TABLES `user_activity_log` WRITE;
/*!40000 ALTER TABLE `user_activity_log` DISABLE KEYS */;
INSERT INTO `user_activity_log` VALUES (1,1,'login','ورود به حساب',NULL,NULL,'2.187.121.226','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-09 14:57:09','2026-06-09 14:57:09'),(2,2,'avatar_updated','تغییر تصویر پروفایل',NULL,NULL,'2.187.121.226','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-09 16:33:01','2026-06-09 16:33:01'),(3,2,'login','ورود به حساب',NULL,NULL,'2.187.121.226','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Mobile Safari/537.36','2026-06-09 17:01:38','2026-06-09 17:01:38'),(4,1,'login','ورود به حساب',NULL,NULL,'46.51.66.182','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-09 19:50:43','2026-06-09 19:50:43'),(5,1,'login','ورود به حساب',NULL,NULL,'2.187.121.226','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-09 21:16:57','2026-06-09 21:16:57'),(6,1,'login','ورود به حساب',NULL,NULL,'172.80.169.107','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-10 08:12:33','2026-06-10 08:12:33'),(7,2,'login','ورود به حساب',NULL,NULL,'2.187.121.111','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-10 11:23:45','2026-06-10 11:23:45'),(8,1,'login','ورود به حساب',NULL,NULL,'2.187.121.111','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-10 18:50:33','2026-06-10 18:50:33'),(9,2,'login','ورود به حساب',NULL,NULL,'2.187.121.111','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-10 19:04:19','2026-06-10 19:04:19'),(10,1,'login','ورود به حساب',NULL,NULL,'192.15.6.124','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-10 21:04:19','2026-06-10 21:04:19'),(11,1,'login','ورود به حساب',NULL,NULL,'192.15.6.124','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-11 07:53:35','2026-06-11 07:53:35'),(12,2,'login','ورود به حساب',NULL,NULL,'192.15.6.124','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-11 07:53:57','2026-06-11 07:53:57'),(13,3,'login','ورود به حساب',NULL,NULL,'192.15.6.124','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-11 09:44:04','2026-06-11 09:44:04'),(14,2,'login','ورود به حساب',NULL,NULL,'2.187.120.243','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-11 15:06:12','2026-06-11 15:06:12'),(15,1,'login','ورود به حساب',NULL,NULL,'2.187.120.243','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-11 15:21:21','2026-06-11 15:21:21'),(16,1,'login','ورود به حساب',NULL,NULL,'83.120.191.15','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-12 05:44:26','2026-06-12 05:44:26'),(17,1,'login','ورود به حساب',NULL,NULL,'83.120.191.15','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','2026-06-12 05:45:48','2026-06-12 05:45:48'),(18,1,'login','ورود به حساب',NULL,NULL,'83.120.191.15','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-12 05:56:53','2026-06-12 05:56:53'),(19,2,'login','ورود به حساب',NULL,NULL,'83.120.191.15','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-12 06:00:19','2026-06-12 06:00:19'),(20,1,'login','ورود به حساب',NULL,NULL,'2.187.120.243','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-12 10:55:32','2026-06-12 10:55:32'),(21,1,'login','ورود به حساب',NULL,NULL,'2.187.120.243','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-12 14:19:41','2026-06-12 14:19:41'),(22,1,'login','ورود به حساب',NULL,NULL,'2.187.120.191','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-12 16:21:09','2026-06-12 16:21:09'),(23,2,'login','ورود به حساب',NULL,NULL,'2.187.120.191','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-12 17:03:04','2026-06-12 17:03:04'),(24,1,'login','ورود به حساب',NULL,NULL,'2.187.120.104','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-13 09:55:14','2026-06-13 09:55:14'),(25,1,'login','ورود به حساب',NULL,NULL,'2.187.120.104','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-13 09:55:54','2026-06-13 09:55:54'),(26,1,'login','ورود به حساب',NULL,NULL,'2.187.120.104','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-13 16:48:07','2026-06-13 16:48:07'),(27,1,'login','ورود به حساب',NULL,NULL,'83.120.191.15','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-14 06:42:46','2026-06-14 06:42:46'),(28,1,'login','ورود به حساب',NULL,NULL,'83.120.191.15','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-14 06:43:11','2026-06-14 06:43:11'),(29,2,'login','ورود به حساب',NULL,NULL,'83.120.191.15','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-14 08:54:28','2026-06-14 08:54:28'),(30,1,'login','ورود به حساب',NULL,NULL,'2.187.121.152','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-14 11:46:39','2026-06-14 11:46:39'),(31,2,'login','ورود به حساب',NULL,NULL,'2.187.121.152','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-14 11:53:53','2026-06-14 11:53:53'),(32,1,'login','ورود به حساب',NULL,NULL,'2.187.121.152','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-14 16:52:43','2026-06-14 16:52:43'),(33,2,'login','ورود به حساب',NULL,NULL,'2.187.121.152','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-14 17:21:45','2026-06-14 17:21:45'),(34,1,'login','ورود به حساب',NULL,NULL,'83.120.238.130','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-15 04:26:44','2026-06-15 04:26:44'),(35,1,'login','ورود به حساب',NULL,NULL,'2.187.121.152','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-15 10:18:49','2026-06-15 10:18:49'),(36,2,'login','ورود به حساب',NULL,NULL,'2.187.121.152','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-15 11:03:04','2026-06-15 11:03:04'),(37,1,'login','ورود به حساب',NULL,NULL,'2.187.121.152','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-15 16:16:29','2026-06-15 16:16:29'),(38,1,'login','ورود به حساب',NULL,NULL,'2.187.121.152','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-15 17:39:11','2026-06-15 17:39:11'),(39,1,'login','ورود به حساب',NULL,NULL,'83.120.238.130','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-15 18:29:07','2026-06-15 18:29:07'),(40,1,'login','ورود به حساب',NULL,NULL,'83.120.238.130','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-16 04:44:31','2026-06-16 04:44:31'),(41,1,'login','ورود به حساب',NULL,NULL,'83.120.238.130','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-16 04:44:44','2026-06-16 04:44:44'),(42,1,'login','ورود به حساب',NULL,NULL,'83.120.238.130','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-16 04:56:51','2026-06-16 04:56:51'),(43,1,'login','ورود به حساب',NULL,NULL,'80.191.216.179','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-06-16 06:52:27','2026-06-16 06:52:27'),(44,1,'login','ورود به حساب',NULL,NULL,'2.187.121.168','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-16 11:13:26','2026-06-16 11:13:26'),(45,1,'login','ورود به حساب',NULL,NULL,'2.187.121.181','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-19 06:37:32','2026-06-19 06:37:32'),(46,1,'login','ورود به حساب',NULL,NULL,'2.187.121.181','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-19 09:59:27','2026-06-19 09:59:27'),(47,1,'login','ورود به حساب',NULL,NULL,'2.187.121.181','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-19 10:00:34','2026-06-19 10:00:34'),(48,1,'login','ورود به حساب',NULL,NULL,'2.187.121.181','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-19 10:21:48','2026-06-19 10:21:48'),(49,2,'login','ورود به حساب',NULL,NULL,'2.187.121.181','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-19 10:27:33','2026-06-19 10:27:33'),(50,1,'login','ورود به حساب',NULL,NULL,'2.187.121.181','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','2026-06-19 10:54:34','2026-06-19 10:54:34'),(51,1,'login','ورود به حساب',NULL,NULL,'2.187.121.181','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Mobile Safari/537.36','2026-06-19 10:57:42','2026-06-19 10:57:42'),(52,1,'login','ورود به حساب',NULL,NULL,'2.187.121.181','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','2026-06-19 12:28:17','2026-06-19 12:28:17'),(53,1,'login','ورود به حساب',NULL,NULL,'2.187.121.181','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-19 12:28:57','2026-06-19 12:28:57'),(54,1,'login','ورود به حساب',NULL,NULL,'2.187.121.181','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-19 16:55:45','2026-06-19 16:55:45'),(55,1,'login','ورود به حساب',NULL,NULL,'2.187.121.181','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-19 20:42:39','2026-06-19 20:42:39'),(56,2,'login','ورود به حساب',NULL,NULL,'2.187.121.181','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-19 20:44:17','2026-06-19 20:44:17'),(57,1,'login','ورود به حساب',NULL,NULL,'2.187.121.181','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-19 20:44:31','2026-06-19 20:44:31'),(58,2,'login','ورود به حساب',NULL,NULL,'2.187.121.181','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-19 21:06:09','2026-06-19 21:06:09'),(59,2,'login','ورود به حساب',NULL,NULL,'2.187.121.181','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-19 21:16:55','2026-06-19 21:16:55'),(60,1,'login','ورود به حساب',NULL,NULL,'2.187.121.181','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-20 05:32:15','2026-06-20 05:32:15'),(61,1,'login','ورود به حساب',NULL,NULL,'2.187.121.181','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-20 10:32:49','2026-06-20 10:32:49'),(62,2,'login','ورود به حساب',NULL,NULL,'2.187.121.181','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-20 10:47:16','2026-06-20 10:47:16'),(63,2,'login','ورود به حساب',NULL,NULL,'2.187.121.181','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-20 11:48:57','2026-06-20 11:48:57'),(64,1,'login','ورود به حساب',NULL,NULL,'2.187.121.181','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-20 14:39:26','2026-06-20 14:39:26'),(65,1,'login','ورود به حساب',NULL,NULL,'80.191.216.189','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-21 05:07:38','2026-06-21 05:07:38'),(66,2,'login','ورود به حساب',NULL,NULL,'80.191.216.189','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-21 05:55:22','2026-06-21 05:55:22'),(67,1,'login','ورود به حساب',NULL,NULL,'80.191.216.179','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0','2026-06-21 07:34:59','2026-06-21 07:34:59'),(68,1,'login','ورود به حساب',NULL,NULL,'2.187.121.22','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-21 11:16:58','2026-06-21 11:16:58'),(69,2,'login','ورود به حساب',NULL,NULL,'2.187.121.22','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-21 11:17:13','2026-06-21 11:17:13'),(70,1,'login','ورود به حساب',NULL,NULL,'2.187.121.22','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-21 21:26:25','2026-06-21 21:26:25'),(71,1,'login','ورود به حساب',NULL,NULL,'80.191.216.189','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-22 06:52:10','2026-06-22 06:52:10'),(72,2,'login','ورود به حساب',NULL,NULL,'80.191.216.189','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-22 07:09:14','2026-06-22 07:09:14'),(73,2,'login','ورود به حساب',NULL,NULL,'2.187.121.22','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-22 11:18:27','2026-06-22 11:18:27'),(74,1,'login','ورود به حساب',NULL,NULL,'2.187.121.22','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-22 11:18:40','2026-06-22 11:18:40'),(75,1,'login','ورود به حساب',NULL,NULL,'2.187.121.22','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-22 16:00:15','2026-06-22 16:00:15'),(76,1,'login','ورود به حساب',NULL,NULL,'2.187.121.22','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-22 16:00:46','2026-06-22 16:00:46'),(77,2,'login','ورود به حساب',NULL,NULL,'2.187.121.22','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-22 16:30:52','2026-06-22 16:30:52'),(78,1,'login','ورود به حساب',NULL,NULL,'2.187.121.22','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-22 20:06:29','2026-06-22 20:06:29'),(79,1,'login','ورود به حساب',NULL,NULL,'2.187.121.22','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-23 06:52:50','2026-06-23 06:52:50'),(80,2,'login','ورود به حساب',NULL,NULL,'2.187.121.22','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-23 11:49:55','2026-06-23 11:49:55'),(81,1,'login','ورود به حساب',NULL,NULL,'2.187.121.160','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-24 05:02:53','2026-06-24 05:02:53'),(82,1,'login','ورود به حساب',NULL,NULL,'2.187.121.160','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-24 07:11:35','2026-06-24 07:11:35'),(83,2,'login','ورود به حساب',NULL,NULL,'2.187.121.160','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-24 07:12:44','2026-06-24 07:12:44'),(84,1,'login','ورود به حساب',NULL,NULL,'2.187.121.160','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-24 16:19:35','2026-06-24 16:19:35'),(85,1,'login','ورود به حساب',NULL,NULL,'2.187.120.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-25 06:48:43','2026-06-25 06:48:43'),(86,2,'login','ورود به حساب',NULL,NULL,'2.187.120.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-25 06:49:49','2026-06-25 06:49:49'),(87,1,'login','ورود به حساب',NULL,NULL,'2.187.120.66','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-25 12:23:42','2026-06-25 12:23:42'),(88,1,'login','ورود به حساب',NULL,NULL,'2.187.120.66','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0','2026-06-25 12:27:56','2026-06-25 12:27:56'),(89,1,'login','ورود به حساب',NULL,NULL,'83.121.95.162','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-06-25 17:55:30','2026-06-25 17:55:30'),(90,1,'login','ورود به حساب',NULL,NULL,'83.121.95.162','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-25 21:21:07','2026-06-25 21:21:07'),(91,1,'login','ورود به حساب',NULL,NULL,'83.121.95.162','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-25 21:21:17','2026-06-25 21:21:17'),(92,1,'login','ورود به حساب',NULL,NULL,'2.187.120.123','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-25 22:55:14','2026-06-25 22:55:14'),(93,1,'login','ورود به حساب',NULL,NULL,'2.187.120.123','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36','2026-06-25 22:55:51','2026-06-25 22:55:51'),(94,1,'login','ورود به حساب',NULL,NULL,'2.187.120.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-06-26 03:40:49','2026-06-26 03:40:49'),(95,2,'login','ورود به حساب',NULL,NULL,'2.187.120.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','2026-06-26 04:22:49','2026-06-26 04:22:49'),(96,1,'login','ورود به حساب',NULL,NULL,'83.121.95.162','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-26 05:32:11','2026-06-26 05:32:11'),(97,2,'login','ورود به حساب',NULL,NULL,'2.187.120.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','2026-06-26 09:21:16','2026-06-26 09:21:16'),(98,1,'login','ورود به حساب',NULL,NULL,'2.187.120.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-06-26 14:29:46','2026-06-26 14:29:46'),(99,1,'login','ورود به حساب',NULL,NULL,'2.187.120.123','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-26 17:21:22','2026-06-26 17:21:22'),(100,2,'login','ورود به حساب',NULL,NULL,'2.187.120.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','2026-06-26 19:13:39','2026-06-26 19:13:39'),(101,1,'login','ورود به حساب',NULL,NULL,'2.187.120.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-06-26 19:14:12','2026-06-26 19:14:12'),(102,1,'login','ورود به حساب',NULL,NULL,'2.187.120.123','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-26 21:13:13','2026-06-26 21:13:13'),(103,1,'login','ورود به حساب',NULL,NULL,'2.187.120.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-06-27 04:02:07','2026-06-27 04:02:07'),(104,1,'login','ورود به حساب',NULL,NULL,'83.121.95.162','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-27 09:20:43','2026-06-27 09:20:43'),(105,1,'login','ورود به حساب',NULL,NULL,'2.187.120.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-06-27 10:58:47','2026-06-27 10:58:47'),(106,1,'login','ورود به حساب',NULL,NULL,'2.187.120.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','2026-06-27 11:07:00','2026-06-27 11:07:00'),(107,2,'login','ورود به حساب',NULL,NULL,'2.187.120.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','2026-06-27 11:07:42','2026-06-27 11:07:42'),(108,2,'login','ورود به حساب',NULL,NULL,'2.187.120.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','2026-06-27 11:08:00','2026-06-27 11:08:00'),(109,1,'login','ورود به حساب',NULL,NULL,'2.187.120.123','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-06-27 12:30:20','2026-06-27 12:30:20'),(110,1,'login','ورود به حساب',NULL,NULL,'80.191.216.189','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-06-28 05:55:51','2026-06-28 05:55:51'),(111,1,'login','ورود به حساب',NULL,NULL,'83.121.95.162','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-28 13:00:23','2026-06-28 13:00:23'),(112,1,'login','ورود به حساب',NULL,NULL,'83.121.95.162','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-06-28 13:01:34','2026-06-28 13:01:34'),(113,1,'login','ورود به حساب',NULL,NULL,'2.187.120.24','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','2026-06-28 13:20:23','2026-06-28 13:20:23'),(114,1,'login','ورود به حساب',NULL,NULL,'2.187.120.24','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-06-28 13:23:34','2026-06-28 13:23:34'),(115,2,'login','ورود به حساب',NULL,NULL,'2.187.120.24','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','2026-06-28 13:28:13','2026-06-28 13:28:13'),(116,2,'login','ورود به حساب',NULL,NULL,'2.187.120.24','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36','2026-06-28 13:29:53','2026-06-28 13:29:53'),(117,2,'login','ورود به حساب',NULL,NULL,'2.187.120.24','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-06-28 18:54:03','2026-06-28 18:54:03'),(118,1,'login','ورود به حساب',NULL,NULL,'2.187.120.24','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-06-28 18:54:16','2026-06-28 18:54:16'),(119,1,'login','ورود به حساب',NULL,NULL,'80.191.216.189','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-06-29 06:28:27','2026-06-29 06:28:27'),(120,1,'login','ورود به حساب',NULL,NULL,'2.187.120.167','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-06-29 18:39:19','2026-06-29 18:39:19'),(121,1,'login','ورود به حساب',NULL,NULL,'2.187.121.61','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-06-30 12:02:57','2026-06-30 12:02:57'),(122,1,'login','ورود به حساب',NULL,NULL,'80.191.216.189','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-01 05:05:41','2026-07-01 05:05:41'),(123,1,'login','ورود به حساب',NULL,NULL,'2.187.120.4','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-02 14:05:47','2026-07-02 14:05:47'),(124,1,'login','ورود به حساب',NULL,NULL,'83.120.92.96','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-03 02:31:21','2026-07-03 02:31:21'),(125,1,'login','ورود به حساب',NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-04 04:22:43','2026-07-04 04:22:43'),(126,1,'login','ورود به حساب',NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-04 11:06:20','2026-07-04 11:06:20'),(127,1,'login','ورود به حساب',NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-05 07:43:42','2026-07-05 07:43:42'),(128,1,'login','ورود به حساب',NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-05 13:30:12','2026-07-05 13:30:12'),(129,1,'login','ورود به حساب',NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-06 04:34:48','2026-07-06 04:34:48'),(130,1,'login','ورود به حساب',NULL,NULL,'83.120.92.96','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-06 15:31:07','2026-07-06 15:31:07'),(131,1,'login','ورود به حساب',NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-07 12:26:17','2026-07-07 12:26:17'),(132,1,'login','ورود به حساب',NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-08 03:09:51','2026-07-08 03:09:51'),(133,1,'login','ورود به حساب',NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-09 00:13:39','2026-07-09 00:13:39'),(134,1,'login','ورود به حساب',NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-09 11:32:42','2026-07-09 11:32:42'),(135,1,'login','ورود به حساب',NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 04:03:56','2026-07-10 04:03:56'),(136,1,'login','ورود به حساب',NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-10 15:27:09','2026-07-10 15:27:09'),(137,1,'login','ورود به حساب',NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-11 02:36:18','2026-07-11 02:36:18'),(138,1,'login','ورود به حساب',NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-11 11:10:49','2026-07-11 11:10:49'),(139,1,'login','ورود به حساب',NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-12 17:10:58','2026-07-12 17:10:58'),(140,1,'login','ورود به حساب',NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-13 12:04:03','2026-07-13 12:04:03'),(141,1,'login','ورود به حساب',NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-14 00:23:34','2026-07-14 00:23:34'),(142,1,'login','ورود به حساب',NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-15 15:57:30','2026-07-15 15:57:30'),(143,1,'login','ورود به حساب',NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-16 12:11:33','2026-07-16 12:11:33'),(144,1,'login','ورود به حساب',NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-17 03:31:40','2026-07-17 03:31:40'),(145,1,'login','ورود به حساب',NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-17 14:20:24','2026-07-17 14:20:24'),(146,1,'login','ورود به حساب',NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-18 08:05:39','2026-07-18 08:05:39'),(147,1,'login','ورود به حساب',NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-23 11:08:54','2026-07-23 11:08:54'),(148,1,'login','ورود به حساب',NULL,NULL,'2.187.121.224','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-24 11:50:33','2026-07-24 11:50:33'),(149,1,'login','ورود به حساب',NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-29 12:42:08','2026-07-29 12:42:08'),(150,1,'login','ورود به حساب',NULL,NULL,'37.63.176.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-07-31 08:13:02','2026-07-31 08:13:02'),(151,1,'login','ورود به حساب',NULL,NULL,'37.63.176.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-08-01 16:04:28','2026-08-01 16:04:28'),(152,1,'login','ورود به حساب',NULL,NULL,'37.63.176.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-08-02 11:46:11','2026-08-02 11:46:11'),(153,1,'login','ورود به حساب',NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-08-03 02:45:07','2026-08-03 02:45:07'),(154,1,'login','ورود به حساب',NULL,NULL,'37.63.176.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-08-04 21:03:39','2026-08-04 21:03:39'),(155,1,'login','ورود به حساب',NULL,NULL,'37.63.176.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-08-05 14:59:32','2026-08-05 14:59:32'),(156,1,'login','ورود به حساب',NULL,NULL,'37.63.176.120','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-08-05 15:58:49','2026-08-05 15:58:49'),(157,1,'login','ورود به حساب',NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-08-06 03:49:01','2026-08-06 03:49:01'),(158,1,'login','ورود به حساب',NULL,NULL,'2.187.120.176','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-08-06 16:06:05','2026-08-06 16:06:05'),(159,1,'login','ورود به حساب',NULL,NULL,'2.187.120.176','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-08-06 19:11:21','2026-08-06 19:11:21'),(160,1,'login','ورود به حساب',NULL,NULL,'2.187.121.28','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-08-08 03:53:30','2026-08-08 03:53:30'),(161,1,'login','ورود به حساب',NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-08-08 16:06:19','2026-08-08 16:06:19'),(162,1,'login','ورود به حساب',NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-08-09 08:59:13','2026-08-09 08:59:13'),(163,1,'login','ورود به حساب',NULL,NULL,'2.187.120.42','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-08-09 18:00:09','2026-08-09 18:00:09'),(164,1,'login','ورود به حساب',NULL,NULL,'2.187.120.42','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0','2026-08-11 07:05:36','2026-08-11 07:05:36'),(165,1,'login','ورود به حساب',NULL,NULL,'83.120.120.98','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36','2026-08-11 10:13:25','2026-08-11 10:13:25'),(166,1,'login','ورود به حساب',NULL,NULL,'2.187.120.163','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0','2026-08-15 06:53:03','2026-08-15 06:53:03'),(167,1,'login','ورود به حساب',NULL,NULL,'2.187.120.163','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0','2026-08-16 07:54:13','2026-08-16 07:54:13'),(168,1,'login','ورود به حساب',NULL,NULL,'2.187.120.254','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0','2026-08-18 00:16:57','2026-08-18 00:16:57'),(169,1,'login','ورود به حساب',NULL,NULL,'2.187.120.254','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:154.0) Gecko/20100101 Firefox/154.0','2026-08-19 03:10:04','2026-08-19 03:10:04'),(170,1,'login','ورود به حساب',NULL,NULL,'2.187.120.254','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:154.0) Gecko/20100101 Firefox/154.0','2026-08-19 03:10:05','2026-08-19 03:10:05'),(171,1,'login','ورود به حساب',NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:154.0) Gecko/20100101 Firefox/154.0','2026-08-19 11:50:22','2026-08-19 11:50:22'),(172,1,'login','ورود به حساب',NULL,NULL,'45.77.86.232','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:154.0) Gecko/20100101 Firefox/154.0','2026-08-19 15:34:24','2026-08-19 15:34:24');
/*!40000 ALTER TABLE `user_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_addresses`
--

DROP TABLE IF EXISTS `user_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_addresses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `label` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'آدرس پیش‌فرض',
  `address_line1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address_line2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_addresses_user_id_foreign` (`user_id`),
  CONSTRAINT `user_addresses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_addresses`
--

LOCK TABLES `user_addresses` WRITE;
/*!40000 ALTER TABLE `user_addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_notifications`
--

DROP TABLE IF EXISTS `user_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_notifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `notification_batch_id` bigint unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'info',
  `link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` json DEFAULT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_notifications_user_id_foreign` (`user_id`),
  KEY `user_notifications_notification_batch_id_foreign` (`notification_batch_id`),
  CONSTRAINT `user_notifications_notification_batch_id_foreign` FOREIGN KEY (`notification_batch_id`) REFERENCES `notification_batches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `user_notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_notifications`
--

LOCK TABLES `user_notifications` WRITE;
/*!40000 ALTER TABLE `user_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bio` text COLLATE utf8mb4_unicode_ci,
  `birth_date` date DEFAULT NULL,
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fax` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_role` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_address` text COLLATE utf8mb4_unicode_ci,
  `company_phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notification_preferences` json DEFAULT NULL,
  `privacy_settings` json DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `api_token` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `is_platform_agent` tinyint(1) NOT NULL DEFAULT '0',
  `force_password_change` tinyint(1) NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_mobile_unique` (`mobile`),
  UNIQUE KEY `users_api_token_unique` (`api_token`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'مدیر صفحه نخست','09927530317','uploads/admin-avatars/admin_1_1786455846.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'$2y$12$MOOTrh6EPEXqO9lboYMQsevZAr5j9f2TiI6AyjknElqDAb7sRSTJm',NULL,1,0,0,'9NWdKQFCXhgkqGhO89EpoaiktqSURJq9EV4ZzD2NIywTyPsGJFXvtZ8QqiqK','2026-06-09 13:44:34','2026-08-11 10:14:06'),(2,'مریم شرفی','09906210511','avatar/2026/06/8GcpQ8nRIlBQqMlvOoOe.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'$2y$12$AOKdzmjaD4AyStrsKXoU6.5A0q4xtadjzXC3n2bIhZfQEM/bM05Xm',NULL,0,0,0,'ymVy3VzbTKLrfKwj5t0FRMnqb6ria65bFchVwr4Jk4Uwpsp10hEAzZnPOyPZ','2026-06-09 15:21:05','2026-06-09 16:33:01'),(3,'پشتیبان پلتفرم','09169398161',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'$2y$12$uVegZzKYvAZbhb5NWc2RReU6kpu8jvxPVi63roLOK1GwDekbYU0gO',NULL,1,1,0,NULL,'2026-06-11 09:42:15','2026-06-11 09:42:15');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `warehouses`
--

DROP TABLE IF EXISTS `warehouses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `warehouses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `manager_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `manager_mobile` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `warehouses_code_unique` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `warehouses`
--

LOCK TABLES `warehouses` WRITE;
/*!40000 ALTER TABLE `warehouses` DISABLE KEYS */;
/*!40000 ALTER TABLE `warehouses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhook_endpoints`
--

DROP TABLE IF EXISTS `webhook_endpoints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhook_endpoints` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `events` json NOT NULL,
  `secret` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `last_called_at` timestamp NULL DEFAULT NULL,
  `last_status_code` smallint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhook_endpoints`
--

LOCK TABLES `webhook_endpoints` WRITE;
/*!40000 ALTER TABLE `webhook_endpoints` DISABLE KEYS */;
/*!40000 ALTER TABLE `webhook_endpoints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhook_events`
--

DROP TABLE IF EXISTS `webhook_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhook_events` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `webhook_endpoint_id` bigint unsigned NOT NULL,
  `event_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` json NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `attempts` tinyint unsigned NOT NULL DEFAULT '0',
  `last_attempted_at` timestamp NULL DEFAULT NULL,
  `response_code` smallint unsigned DEFAULT NULL,
  `response_body` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `webhook_events_webhook_endpoint_id_foreign` (`webhook_endpoint_id`),
  KEY `webhook_events_status_attempts_index` (`status`,`attempts`),
  CONSTRAINT `webhook_events_webhook_endpoint_id_foreign` FOREIGN KEY (`webhook_endpoint_id`) REFERENCES `webhook_endpoints` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhook_events`
--

LOCK TABLES `webhook_events` WRITE;
/*!40000 ALTER TABLE `webhook_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `webhook_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wishlist_items`
--

DROP TABLE IF EXISTS `wishlist_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wishlist_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `wishlist_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wishlist_items_wishlist_id_product_id_unique` (`wishlist_id`,`product_id`),
  KEY `wishlist_items_product_id_foreign` (`product_id`),
  CONSTRAINT `wishlist_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `wishlist_items_wishlist_id_foreign` FOREIGN KEY (`wishlist_id`) REFERENCES `wishlists` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wishlist_items`
--

LOCK TABLES `wishlist_items` WRITE;
/*!40000 ALTER TABLE `wishlist_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `wishlist_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wishlists`
--

DROP TABLE IF EXISTS `wishlists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wishlists` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `session_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wishlists_user_id_unique` (`user_id`),
  UNIQUE KEY `wishlists_session_id_unique` (`session_id`),
  CONSTRAINT `wishlists_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wishlists`
--

LOCK TABLES `wishlists` WRITE;
/*!40000 ALTER TABLE `wishlists` DISABLE KEYS */;
INSERT INTO `wishlists` VALUES (1,NULL,'bd12061986707d054ecc6e37aeab622e','2026-06-19 07:47:43','2026-06-19 07:47:43'),(2,NULL,'6b0e7e1fad1cf07e58cc0ca8da356276','2026-06-28 17:04:30','2026-06-28 17:04:30'),(3,NULL,'0f3e18ca0bae61d1853290d199c33efd','2026-07-02 23:38:16','2026-07-02 23:38:16'),(4,NULL,'1b0d03c3f3713771e3ba58742488c7b5','2026-07-03 17:18:10','2026-07-03 17:18:10'),(5,NULL,'9d282da751af58745849cd4d764a872b','2026-07-08 02:02:26','2026-07-08 02:02:26'),(6,NULL,'a5edabb65ee5facefb1e92c0cc0b099f','2026-07-08 02:02:30','2026-07-08 02:02:30'),(7,NULL,'8ed64d72fe94b38caa2bb599b47f5c41','2026-07-28 14:32:22','2026-07-28 14:32:22'),(8,NULL,'af65c82e5cfa6989061079504116054b','2026-07-31 18:41:58','2026-07-31 18:41:58'),(9,NULL,'045629aacf529b238846323abe7ca101','2026-08-18 03:45:53','2026-08-18 03:45:53'),(10,NULL,'ad9a4714a8939d026dd13288e68737bb','2026-08-18 03:46:17','2026-08-18 03:46:17'),(11,NULL,'8b56d669a52bbe2e9acef5b86cc74054','2026-08-18 06:39:59','2026-08-18 06:39:59');
/*!40000 ALTER TABLE `wishlists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'customer_site'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-21  5:30:07
